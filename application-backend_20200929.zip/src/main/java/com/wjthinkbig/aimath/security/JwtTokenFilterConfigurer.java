package com.wjthinkbig.aimath.security;

import org.springframework.security.config.annotation.SecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.DefaultSecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
  * @Date : 2020. 8. 8. 
  * @프로그램 설명 : (사용안함) JWT 토큰을 처리하기 위한 필터를 UsernamePasswordAuthenticationFilter 앞에 추가한다. 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 10.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Deprecated
public class JwtTokenFilterConfigurer extends SecurityConfigurerAdapter<DefaultSecurityFilterChain, HttpSecurity> {

	private JwtTokenProvider jwtTokenProvider;
	
	public JwtTokenFilterConfigurer(JwtTokenProvider jwtTokenProvider) {	
		this.jwtTokenProvider = jwtTokenProvider;
	}

	@Override
	public void configure(HttpSecurity builder) throws Exception {
		JwtTokenFilter jwtTokenFilter = new JwtTokenFilter(jwtTokenProvider);
		// JWT 토큰필터를 UsernamePasswordAuthenticationFilter 필터앞에
		builder.addFilterBefore(jwtTokenFilter, UsernamePasswordAuthenticationFilter.class);
	}
}