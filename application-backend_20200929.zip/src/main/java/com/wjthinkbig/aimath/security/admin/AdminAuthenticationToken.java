/**
 * 
 */
package com.wjthinkbig.aimath.security.admin;

import java.util.Collection;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

/**
  * @Date : 2020. 9. 11. 
  * @프로그램 설명 : 관리자용 인증토큰  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class AdminAuthenticationToken extends UsernamePasswordAuthenticationToken {

	private static final long serialVersionUID = 7309027941346155438L;

	/**
	 * @param principal
	 * @param credentials
	 */
	public AdminAuthenticationToken(Object principal, Object credentials) {
		super(principal, credentials);
	}

	/**
	 * @param principal
	 * @param credentials
	 * @param authorities
	 */
	public AdminAuthenticationToken(Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities) {
		super(principal, credentials, authorities);
	}
}