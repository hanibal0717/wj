package com.wjthinkbig.aimath.security.user;

import java.util.Arrays;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.mbr.service.dao.MbrDao;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 4. 
  * @프로그램 설명 : 사용자 인증을 위한 UserDetailsService 구현체  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 4.      Lee Seung Hyuk            최초작성
  * </pre>
 */
@Slf4j
@Service("userDetailsService")
public class CustomMbrDetailsService implements UserDetailsService {
	
	/**
	 * 회원서비스 Dao
	 */
	@Resource(name = "mbrDao")
	private MbrDao mbrDao;
	
	/**
	 * 메시지 소스
	 */
	@Autowired
	private MessageSource messageSource;
	
	
	@Override
	public UserDetails loadUserByUsername(String emailEn) throws UsernameNotFoundException {
		MbrVO mbrVO = mbrDao.selectMbrByEmail(emailEn);
		if(mbrVO == null) {
			throw new UsernameNotFoundException(messageSource.getMessage("S001005", null, LocaleContextHolder.getLocale()));
		} else {
			mbrVO.setRoles(Arrays.asList("ROLE_USER", "ROLE_USER"));
		}

		log.debug("검색된 회원객체 (loadUser) 정보 : {}", mbrVO);
		return new MbrAccount(mbrVO);			
	}
}