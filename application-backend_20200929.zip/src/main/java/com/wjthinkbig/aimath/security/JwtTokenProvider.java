package com.wjthinkbig.aimath.security;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.function.Function;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 7. 
  * @프로그램 설명 : JWT 토큰 프로바이더 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 7.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Slf4j
@Deprecated
//@Component("jwtTokenProvider")
public class JwtTokenProvider {
	
	// 토큰의 서명키
	@Value("${security.jwt.token.secret-key:secret-key}")
	private String secretKey;

	// 토큰의 유효시간
	@Value("${security.jwt.token.expire-length}")
	private long validityInMilliseconds;
	
	/**
	 * 사용자 인증을 위한 UserDetailsService 빈
	 */
	@Resource(name = "userDetailsServiceForUser")
	private UserDetailsService customUserDetails;

	// 이 빈의 의존성 주입이 이루어진 후 초기화를 수행하는 메소드
	@PostConstruct
	protected void init() {
		// Secret Key를 Base64로 인코딩
		secretKey = Base64.getEncoder().encodeToString(secretKey.getBytes());
	}
	
	/**
	  * @Method 설명 : 지정한 권한을 갖는 토큰을 생성한다.  
	  * @param username 사용자(JWT 토큰의 sub 항목값)
	  * @param roles 권한
	  * @return JWT 토큰
	 */
	public String createToken(String username, List<String> roles) {
		
		Claims claims = Jwts
							.claims()
							.setSubject(username);
		
		// "ath" 항목에 인증된 사용자의 권한을 넣는다. 
		claims.put("ath", roles);
		
		Date now = new Date();												// 토큰 발급시간
		Date validity = new Date(now.getTime() + validityInMilliseconds);	// 토큰의 유효기간 (밀리세컨드)

		return Jwts.builder()
				.setClaims(claims)				// JWT Body
				.setIssuedAt(now)				// 발급시간
				.setExpiration(validity)		// 만료시간
				.signWith(SignatureAlgorithm.HS256, secretKey) // 서명알고리즘 및 비밀키
				.compact();
	}
	
	/**
	  * @Method 설명 : 토큰에서 가져온 사용자정보로 인증하고 인증된 객체(UsernamePasswordAuthenticationToken)를 반환한다. 
	  * @param token
	  * @return 인증처리된 객체
	 */
	public Authentication getAuthentication(String token) {
		
		// 토큰에서 사용자정보를 가져온다. (암호화된 email)
		String username = this.getUsername(token);
		
		// 인증된 사용자의 UserAccount 인증객체
		UserDetails userDetails = customUserDetails.loadUserByUsername(username);
		
		log.debug("인증처리된 객체 (getAuthentication) : {}", userDetails);
		
		return new UsernamePasswordAuthenticationToken(
				userDetails, 						// principal
				null, 								// credentials 
				userDetails.getAuthorities());		// authorities 
	}
	
	/**
	  * @Method 설명 : 요청헤더(Authorization)에서 JWT 토큰을 가져온다. 없으면 NULL 
	  * @param req HttpServletRequest
	  * @return JWT 토큰 또는 NULL
	 */
	public String resolveToken(HttpServletRequest req) {
		String bearerToken = req.getHeader("Authorization");
		if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7);
		}
		return null;
	}
	
	/**
	  * @Method 설명 : JWT 토큰의 유효성을 검증한다. 
	  * @param token JWT 토큰키
	  * @return 문제(위변조, 만료 등)가 있으면 false, 정상토큰이면 true
	 */
	public boolean validateToken(String token) {
		try {
			Jws<Claims> claims = Jwts.parser()
					.setSigningKey(secretKey)
					.parseClaimsJws(token);
			
			ArrayList<String> auth = (ArrayList<String>) claims.getBody().get("ath");	// 토큰에서 권한정보 추출		
			Date expiratioDate = getExpirationDateFromToken(token);						// 토큰만료시간 추출
			boolean isExpired = isTokenExpired(token);									// 토큰만료여부
			
			// 정상토큰의 만료정보 출력
			log.debug("1) validateToken) 권한 : {}, 만료시간 : {}, 만료여부 : {}", 
					auth,
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(expiratioDate), 
					isExpired);
			
			return true;
		} catch (ExpiredJwtException e) { 
			// 유효 기간이 지난 JWT를 수신한 경우
			log.warn("1) validateToken 실패 : {}", e.getMessage());
			return false;			
		} catch (UnsupportedJwtException e) { 
			// 수신한 JWT의 형식이 애플리케이션에서 원하는 형식과 맞지 않는 경우. 예를 들어, 암호화된 JWT를 사용하는 어플리케이션에 암호화되지 않은 JWT가 전달되는 경우에 이 예외가 발생합니다.
			log.warn("1) validateToken 실패 : {}", e.getMessage());
			return false;
		} catch (MalformedJwtException e) { 
			// 구조적인 문제가 있는 JWT인 경우
			log.warn("1) validateToken 실패 : {}", e.getMessage());
			return false;
		} catch (SignatureException e) { 
			// 시그너처 연산이 실패하였거나, JWT의 시그너처 검증이 실패한 경우
			log.warn("1) validateToken 실패 : {}", e.getMessage());
			return false;			
		} catch (IllegalArgumentException e) {
			// a method has been passed an illegal or inappropriate argument
			log.warn("1) validateToken 실패 : {}", e.getMessage());
			return false;
		}
	}
	
	/**
	  * @Method 설명 : 토큰에서 사용자정보(JWT sub 항목값)를 가져온다.
	  * @param token JWT 토큰
	  * @return JWT sub 항목값 또는 NULL
	 */
	public String getUsername(String token) {		
		return Jwts.parser()
				.setSigningKey(secretKey)
				.parseClaimsJws(token)
				.getBody()
				.getSubject();
	}
	
	/**
	  * @Method 설명 : 토큰에서 특정 클레임의 정보만 가져오기
	  * @param token
	  * @param claimsResolver
	  * @return
	 */
	public <T> T getClaimFromToken(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getAllClaimsFromToken(token);
		return claimsResolver.apply(claims);
	}
	
	/**
	  * @Method 설명 : 토큰으로부터 JWT Body(String 또는 클레임객체)를 가져온다. 
	  * @param token JWT 토큰
	  * @return JWT body, either a String or a Claims instance
	 */
	private Claims getAllClaimsFromToken(String token) {
		return Jwts
				.parser()
				.setSigningKey(secretKey)
				.parseClaimsJws(token)
				.getBody();
	}
	
	/**
	  * @Method 설명 : 토큰에서 만료날짜 정보를 가져온다.
	  * @param token JWT 토큰
	  * @return 만료일자 및 시간
	 */
	public Date getExpirationDateFromToken(String token) {
		return getClaimFromToken(token, Claims::getExpiration);
	}
	
	/**
	  * @Method 설명 : 토큰의 만료여부를 판별한다.
	  * @param token JWT 토큰
	  * @return 만료되면 true, 유효한 토큰이면 false
	 */
	private Boolean isTokenExpired(String token) {
		final Date expiration = getExpirationDateFromToken(token);
		return expiration.before(new Date());
	}	
}