package com.wjthinkbig.aimath.qst.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.qst.service.QstService;
import com.wjthinkbig.aimath.qst.service.dao.QstDao;
import com.wjthinkbig.aimath.qst.vo.QstMetaVO;
import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseMetaVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstWrtnMngtVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseVO;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 문항관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Service("qstService")
public class QstServiceImpl extends BaseServiceImpl implements QstService {
	
	/**
	 * 문항관리 Dao
	 */
	@Resource(name = "qstDao")
	private QstDao qstDao;
	
	@Override
	public List<QstVO> selectQstList(QstSearchVO qstSearch) throws Exception {
		if( qstSearch.getCurrentPage() < 1 ) qstSearch.setCurrentPage(1);
		if( qstSearch.getRowCnt() < 1 ) qstSearch.setRowCnt(10);
		
		List<QstVO> qstList = qstDao.selectQstList(qstSearch);
		return qstList;
	}
	
	@Override
	public int selectQstCount(QstSearchVO qstSearch) throws Exception {
		int cnt = qstDao.selectQstCount(qstSearch);
		return cnt;
	}
	
	@Override
	public QstVO selectQstById(QstSearchVO qstSearch) throws Exception {
		QstVO qst = null;
		
		if( StringUtils.isNotEmpty(qstSearch.getLangCd()) ) {
			//언어 코드가 존재할 경우
			qst = qstDao.selectQst(qstSearch);
			
			if( qst != null ) {
				//오답 정보 조회
				QstWransrCrseSearchVO qstWransrCrseSearch = new QstWransrCrseSearchVO();
				qstWransrCrseSearch.setQstCd(qstSearch.getQstCd());
				qstWransrCrseSearch.setLangCd(qstSearch.getLangCd());
				
				qst.setQstWransrCrseList( qstDao.selectQstWransrCrseList(qstWransrCrseSearch) );
			}
		} else {
			//언어 코드가 존재하지 않을 경우
			qst = qstDao.selectQstById(qstSearch.getQstCd());
			
			if( qst != null ) {
				//메타 정보 리스트 조회
				qst.setQstMetaList(qstDao.selectQstMetaList(qstSearch.getQstCd()));
				
				//오답 정보 조회
				QstWransrCrseSearchVO qstWransrCrseSearch = new QstWransrCrseSearchVO();
				qstWransrCrseSearch.setQstCd(qstSearch.getQstCd());
				
				List<QstWransrCrseVO> qstWransrCrseList = qstDao.selectQstWransrCrseListById(qstSearch.getQstCd());
				
				if( qstWransrCrseList != null ) {
					//오답 메타 정보 조회
					for( int i = 0; i < qstWransrCrseList.size(); i++ ) {
						qstWransrCrseSearch.setWransrTyCd(qstWransrCrseList.get(i).getWransrTyCd());
						qstWransrCrseList.get(i).setQstWransrCrseMetaList( qstDao.selectQstWransrCrseMetaList(qstWransrCrseSearch) );
					}
				}
				
				qst.setQstWransrCrseList(qstWransrCrseList);
			}
		}
		
		return qst;
	}
	
	@Override
	public int selectQstCdDplctCeck(String qst_cd) throws Exception {
		return qstDao.selectQstCdDplctCeck(qst_cd);
	}
	
//	@Override
//	public int selectQstCdDplctCeckByQst(String qst_cd) throws Exception {
//		return qstDao.selectQstCdDplctCeckByQst(qst_cd);
//	}
	
	@Override
	public void insertQst(QstVO qst) throws Exception {
		List<QstWransrCrseVO> qstWransrCrseList = qst.getQstWransrCrseList();
		
		if( qstWransrCrseList != null && qstWransrCrseList.size() > 0 ) {
			//오답 유형 존재
			qst.setWransrTyScnCd("Y");
		} else {
			//오답 유형 존재하지 않음
			qst.setWransrTyScnCd("N");
		}
		
		//문항 저작 테이블 등록
		QstWrtnMngtVO qstWrtnMngt = new QstWrtnMngtVO();
		qstWrtnMngt.setQstCd(qst.getQstCd());
		qstWrtnMngt.setStgCd(qst.getStgCd());
		qstWrtnMngt.setWrtnStsCd("WS01");
		qstWrtnMngt.setRgtnUser(qst.getRgtnUser());
		
		//필수값 검증
		this.validateOrElseThrow(qstWrtnMngt, Groups.Insert.class);
		
		qstDao.insertQstWrtnMngt(qstWrtnMngt);
		
		//문항 테이블 등록
		//필수값 검증
		this.validateOrElseThrow(qst, Groups.Insert.class);
		
		qstDao.insertQst(qst);
		
		//문항 메타 테이블 등록
		List<QstMetaVO> qstMetaList = qst.getQstMetaList();
		for( QstMetaVO qstMeta : qstMetaList ) {
			qstMeta.setQstCd( qst.getQstCd() );
			qstMeta.setRgtnUser( qst.getRgtnUser() );
			
			qstDao.insertQstMeta(qstMeta);
		}
		
		//오답 테이블 등록
		if( qstWransrCrseList != null && qstWransrCrseList.size() > 0 ) {
			for( int i = 0; i < qstWransrCrseList.size(); i++ ) {
				QstWransrCrseVO qstWransrCrse = qstWransrCrseList.get(i);
				qstWransrCrse.setQstCd( qst.getQstCd() );
				qstWransrCrse.setRgtnUser( qst.getRgtnUser() );
				
				if( i + 1 >= 10 ) {
					qstWransrCrse.setWransrTyCd("WR" + (i + 1));
				} else {
					qstWransrCrse.setWransrTyCd("WR0" + (i + 1));
				}
				
				//필수값 검증
				this.validateOrElseThrow(qstWransrCrse, Groups.Insert.class);
				
				qstDao.insertQstWransrCrse(qstWransrCrse);
				
				//오답원인 등록
				List<QstWransrCrseMetaVO> qstWransrCrseMetaList = qstWransrCrse.getQstWransrCrseMetaList();
				for( QstWransrCrseMetaVO qstWransrCrseMeta : qstWransrCrseMetaList ) {
					qstWransrCrseMeta.setQstCd( qst.getQstCd() );
					qstWransrCrseMeta.setRgtnUser( qst.getRgtnUser() );
					qstWransrCrseMeta.setWransrTyCd( qstWransrCrse.getWransrTyCd() );
					
					//필수값 검증
					this.validateOrElseThrow(qstWransrCrseMeta, Groups.Insert.class);
					
					qstDao.insertQstWransrCrseMeta(qstWransrCrseMeta);
				}
			}
		}
	}

	@Override
	public void updateQst(QstVO qst) throws Exception {
		List<QstWransrCrseVO> qstWransrCrseList = qst.getQstWransrCrseList();
		
		if( qstWransrCrseList != null && qstWransrCrseList.size() > 0 ) {
			//오답 유형 존재 (임시 코드 값)
			qst.setWransrTyScnCd("Y");
		} else {
			//오답 유형 존재하지 않음 (임시 코드 값)
			qst.setWransrTyScnCd("N");
		}
		
		if( qstDao.selectQstCdDplctCeck(qst.getQstCd()) > 0 && qstDao.selectQstCdDplctCeckByQst(qst.getQstCd()) <= 0 ) {
			//저작 상태 테이블에 데이터를 밀어 넣엇을 경우
			//필수값 검증
			this.validateOrElseThrow(qst, Groups.Insert.class);
			
			qstDao.insertQst(qst);
			
			//문항 메타 테이블 등록
			List<QstMetaVO> qstMetaList = qst.getQstMetaList();
			for( QstMetaVO qstMeta : qstMetaList ) {
				qstMeta.setQstCd( qst.getQstCd() );
				qstMeta.setRgtnUser( qst.getModUser() );
				
				qstDao.insertQstMeta(qstMeta);
			}
		} else if( qstDao.selectQstCdDplctCeck(qst.getQstCd()) > 0 && qstDao.selectQstCdDplctCeckByQst(qst.getQstCd()) > 0 ) {
			//수정 처리
			//필수값 검증
			this.validateOrElseThrow(qst, Groups.Update.class);
			
			//문항 테이블 수정
			qstDao.updateQst(qst);
			
			//문항 메타 삭제
			qstDao.deleteQstMeta(qst.getQstCd());
			
			//문항 메타 테이블 등록
			List<QstMetaVO> qstMetaList = qst.getQstMetaList();
			for( QstMetaVO qstMeta : qstMetaList ) {
				qstMeta.setQstCd( qst.getQstCd() );
				qstMeta.setRgtnUser( qst.getModUser() );
				
				qstDao.insertQstMeta(qstMeta);
			}
			
			//오답 메타 삭제
			qstDao.deleteQstWransrCrseMeta(qst.getQstCd());
			
			//오답 삭제
			qstDao.deleteQstWransrCrse(qst.getQstCd());
		}
		
		//오답 테이블 등록
		if( qstWransrCrseList != null && qstWransrCrseList.size() > 0 ) {
			for( int i = 0; i < qstWransrCrseList.size(); i++ ) {
				QstWransrCrseVO qstWransrCrse = qstWransrCrseList.get(i);
				qstWransrCrse.setQstCd( qst.getQstCd() );
				qstWransrCrse.setRgtnUser( qst.getModUser() );
				
				if( i + 1 >= 10 ) {
					qstWransrCrse.setWransrTyCd("WR" + (i + 1));
				} else {
					qstWransrCrse.setWransrTyCd("WR0" + (i + 1));
				}
				
				//필수값 검증
				this.validateOrElseThrow(qstWransrCrse, Groups.Insert.class);
				
				qstDao.insertQstWransrCrse(qstWransrCrse);
				
				//오답원인 등록
				List<QstWransrCrseMetaVO> qstWransrCrseMetaList = qstWransrCrse.getQstWransrCrseMetaList();
				for( QstWransrCrseMetaVO qstWransrCrseMeta : qstWransrCrseMetaList ) {
					qstWransrCrseMeta.setQstCd( qst.getQstCd() );
					qstWransrCrseMeta.setRgtnUser( qst.getModUser() );
					qstWransrCrseMeta.setWransrTyCd( qstWransrCrse.getWransrTyCd() );
					
					//필수값 검증
					this.validateOrElseThrow(qstWransrCrseMeta, Groups.Insert.class);
					
					qstDao.insertQstWransrCrseMeta(qstWransrCrseMeta);
				}
			}
		}
		
		//저작상태코드값 변경
		if( StringUtils.isNotEmpty(qst.getWrtnStsCd()) ) {
			QstWrtnMngtVO qstWrtnMngt = new QstWrtnMngtVO();
			qstWrtnMngt.setQstCd(qst.getQstCd());
			qstWrtnMngt.setWrtnStsCd(qst.getWrtnStsCd());
			qstWrtnMngt.setModUser(qst.getModUser());
			
			//필수값 검증
			this.validateOrElseThrow(qstWrtnMngt, Groups.Update.class);
			
			qstDao.updateQstWrtnMngt(qstWrtnMngt);
		}
	}

	@Override
	public int deleteQst(QstVO qst) throws Exception {
		this.validateOrElseThrow(qst, Groups.Delete.class);
		
		//문항저작상태값 확인 후 오픈일 경우 삭제 불가
		QstVO tmp = qstDao.selectQstById(qst.getQstCd());
		
		if( !"WS05".equals(tmp.getWrtnStsCd()) ) {
			//문항 삭제
			return qstDao.deleteQst(qst);
		} else {
			throw this.processException("S001013");		//문항저작 상태가 오픈 상태일 경우 삭제가 불가능 합니다.
		}
	}

	@Override
	public int deleteQstList(List<QstVO> qstList) throws Exception {
		int cnt = 0;
		
		if( qstList != null && qstList.size() > 0 ) {
			for( QstVO qst : qstList ) {
				int rows = this.deleteQst(qst);
				
				if( rows == 0 ) {
					throw this.processException("S001003", qst.getQstCd());		//해당 데이터({0})는 존재하지 않습니다.
				} else {
					cnt += 1;
				}
			}
		}
		
		return cnt;
	}
	
	@Override
	public void updateQstWrtnMngt(QstWrtnMngtVO qstWrtnMngt) throws Exception {
		this.validateOrElseThrow(qstWrtnMngt, Groups.Update.class);
		qstDao.updateQstWrtnMngt(qstWrtnMngt);
	}
	
	@Override
	public void updateQstWrtnMngtList(List<QstWrtnMngtVO> qstWrtnMngtList) throws Exception {
		if( qstWrtnMngtList != null && qstWrtnMngtList.size() > 0 ) {
			for( QstWrtnMngtVO qstWrtnMngt : qstWrtnMngtList ) {
				if( !StringUtils.isEmpty(qstWrtnMngt.getWrtnStsCd()) ) {
					qstDao.updateQstWrtnMngt(qstWrtnMngt);
				} else {
					throw this.processException("S001011");		//필수값 오류입니다.
				}
			}
		} else {
			throw this.processException("S001011");		//필수값 오류입니다.
		}
	}
}