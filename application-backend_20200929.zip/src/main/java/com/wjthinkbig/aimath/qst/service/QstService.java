package com.wjthinkbig.aimath.qst.service;

import java.util.List;

import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstVO;
import com.wjthinkbig.aimath.qst.vo.QstWrtnMngtVO;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 문항관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
public interface QstService {
	
	/**
	  * @Method 설명 : 커리큘럼 문항 전체 리스트를 가져온다.
	  * @param qstSearch 검색할 조건정보를 담은 VO
	  * @return 검색된 문항리스트
	  * @throws Exception
	 */
	public List<QstVO> selectQstList(QstSearchVO qstSearch) throws Exception;
	
	/**
	  * @Method 설명 : 커리큘럼 문항 전체 건 수를 가져온다.
	  * @param qstSearch 검색조건을 담은 VO
	  * @return 검색된 건 수
	  * @throws Exception
	 */
	public int selectQstCount(QstSearchVO qstSearch) throws Exception;
	
	/**
	  * @Method 설명 : 커리큘럼 특정 문항정보를 가져온다.
	  * @param qstCd 문항 고유 키
	  * @return 해당 문항정보 VO
	  * @throws Exception
	 */
	public QstVO selectQstById(QstSearchVO qstSearch) throws Exception;
	
	/**
	  * @Method 설명 : 문항코드 중복 체크.
	  * @param qst_cd 문항 식별코드
	  * @return 문항이 이미 등록되어 있으면 true
	  * @throws Exception
	 */
	public int selectQstCdDplctCeck(String qst_cd) throws Exception;
	
//	/**
//	  * @Method 설명 : 문항코드 중복 체크. tb_cmn_qst 테이블에서 확인
//	  * @param qst_cd
//	  * @return
//	  * @throws Exception
//	  */
//	public int selectQstCdDplctCeckByQst(String qst_cd) throws Exception;
	
	/**
	  * @Method 설명 : 신규 문항정보를 등록한다.
	  * @param qst 등록할 문항정보를 담은 VO
	  * @throws Exception
	 */
	public void insertQst(QstVO qst) throws Exception;
	
	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 문항정보를 변경한다.
	  * @param qst 변경할 정보를 담고 있는 문항VO
	  * @throws Exception
	 */
	public void updateQst(QstVO qst) throws Exception;
		
	/**
	  * @Method 설명 : 등록된  문항저작정보를 변경한다.
	  * @param qstWrtnMngt 문항저작정보 VO
	  * @throws Exception
	 */
	public void updateQstWrtnMngt(QstWrtnMngtVO qstWrtnMngt) throws Exception;
	
	/**
	  * @Method 설명 : 등록된 문항저작정보들을 변경한다.
	  * @param qstWrtnMngt 문항저작정보 VO
	  * @throws Exception
	 */
	public void updateQstWrtnMngtList(List<QstWrtnMngtVO> qstWrtnMngtList) throws Exception;
	
	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 문항정보를 삭제한다.
	  * @param qst 삭제할 정보를 담고 있는 문항VO
	  * @return 삭제된 데이터 건 수 
	  * @throws Exception
	 */
	public int deleteQst(QstVO qst) throws Exception;
	
	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 문항정보 리스트를 삭제한다.
	  * @param qstCdList 삭제할 문항식별코드 리스트
	  * @return 삭제된 데이터 건 수 
	  * @throws Exception
	 */
	public int deleteQstList(List<QstVO> qstList) throws Exception;
}