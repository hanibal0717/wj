package com.wjthinkbig.aimath.common.service.dao;

import com.wjthinkbig.aimath.common.vo.ExcelQuestionVO;
import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;

/**
  * @Date : 2020. 9. 11.
  * @프로그램 설명 : 자동문항 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     19001861            최초작성
  * </pre>
  */
@Mapper("excelReadDao")
public interface ExcelReadDao {
	
	/**
	  * @Method 설명 : 자동문항 등록
	  * @param excelQuestion
	  * @throws Exception
	  */
	void insertAutoQst(ExcelQuestionVO excelQuestion) throws Exception;
	
}
