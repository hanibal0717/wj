package com.wjthinkbig.aimath.common.exception;

@Deprecated
public class SignInFailureException extends RuntimeException {

	public SignInFailureException(String msg, Throwable t) {
		super(msg, t);
	}
	
	public SignInFailureException(String msg) {
		super(msg);
	}
	
	public SignInFailureException() {
		super();
	}	
}
