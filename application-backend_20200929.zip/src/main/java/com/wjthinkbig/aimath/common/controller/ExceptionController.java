package com.wjthinkbig.aimath.common.controller;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.exception.AuthenticationEntryPointException;
import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.core.extend.service.BaseController;

/**
 * @Date : 2020. 9. 5. 
 * @프로그램 설명 : 스프링시큐리티 필터에서 인증 또는 권한실패시 리다이렉트되며 여기서 전역적 예외처리를 위해 해당 예외를 던진다.   
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 9. 5.     Lee Seung Hyuk              최초작성
 * </pre>
*/
@RequestMapping("/exception")
@RestController
public class ExceptionController extends BaseController {
	
	@GetMapping(value = "/entrypoint")
	public CommonResult entrypointException() {
		// 해당 리소스에 접근하기 위한 권한이 없습니다.
		throw new AuthenticationEntryPointException(this.getMessage("E000015"));		
	}
	
	@GetMapping(value = "/accessdenied")
	public CommonResult accessdenied() {
		// 보유한 권한으로 접근할 수 없는 리소스 입니다.
		throw new AccessDeniedException(this.getMessage("E000016"));
	}
}