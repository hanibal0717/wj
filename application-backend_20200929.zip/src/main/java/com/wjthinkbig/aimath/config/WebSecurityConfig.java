package com.wjthinkbig.aimath.config;

import javax.annotation.Resource;

import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.wjthinkbig.aimath.security.JwtAuthenticationFilter;
import com.wjthinkbig.aimath.security.JwtUtils;
import com.wjthinkbig.aimath.security.admin.AdminCustomAuthenticationProvider;
import com.wjthinkbig.aimath.security.user.UserCustomAuthenticationProvider;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {	
	
	/**
	 * 인증처리 핸들러
	 */
	@Resource(name = "authenticationEntryPoint")
	private AuthenticationEntryPoint authenticationEntryPoint;
	
	/**
	 * 권한처리 핸들러
	 */
	@Resource(name = "accessDeniedHandler")
	private AccessDeniedHandler accessDeniedHandler;
	
	/**
	 * 인증 매니저
	 */
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	/**
	 * JWT Utility
	 */
	@Resource(name = "jwtUtils")
	private JwtUtils jwtUtils;
	
	/**
	 * 회원인증용 프로바이더
	 */
	@Resource(name = "userCustomAuthenticationProvider")
	private UserCustomAuthenticationProvider userCustomAuthenticationProvider;
	
	/**
	 * 관리자인증용 프로바이더
	 */
	@Resource(name = "adminCustomAuthenticationProvider")
	private AdminCustomAuthenticationProvider adminCustomAuthenticationProvider;


	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.authenticationProvider(userCustomAuthenticationProvider);
		auth.authenticationProvider(adminCustomAuthenticationProvider);			
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		// API 기본설정 및 오류 처리
	    http
	    	.httpBasic().disable()
	    	.csrf().disable()
	    	.formLogin().disable()
	    	.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)	
	    	.and()
				.exceptionHandling().authenticationEntryPoint(authenticationEntryPoint) // 인증에 실패한 경우
				.accessDeniedHandler(accessDeniedHandler); // 권한이 없는 경우

	    // 요청 경로별 처리
	    http
	    	.authorizeRequests()  
	    		.antMatchers(HttpMethod.POST, "/api/members").permitAll()			// 회원가입
	    		.antMatchers(HttpMethod.POST, "/api/members/signin").permitAll() 		// 사용자 로그인
	    		.antMatchers(HttpMethod.POST, "/api/members/pw").permitAll() 		// 비밀번호 찾기
	    		.antMatchers(HttpMethod.GET, "/api/members").permitAll() 		// 임시..
	    		.antMatchers(HttpMethod.POST, "/api/account/signin").permitAll() // 관리자 로그인
	    		//.antMatchers("/api/members/**").hasAnyRole("USER")
	    		//.antMatchers("/api/account/**").hasAnyRole("ADMIN");
	    		.antMatchers("/**").permitAll();	

	    // Custom Filter 처리
	    http
	    	.addFilterBefore(new JwtAuthenticationFilter(jwtUtils, adminCustomAuthenticationProvider, userCustomAuthenticationProvider), UsernamePasswordAuthenticationFilter.class);
	}

	@Override
	public void configure(WebSecurity web) throws Exception {
		// SpringSecurity에서는 Security FilterChain을 적용하고 싶지 않은 리소스에 대해 설정을 할수있도록 ignoring() 메소드를 제공
		web.ignoring()
			.antMatchers("/v2/api-docs")
			.antMatchers("/swagger-resources/**")
			.antMatchers("/swagger-ui.html")
			.antMatchers("/configuration/**")
			.antMatchers("/webjars/**")
			.antMatchers("/exception/**")	// ExceptionController(인증이나 권한실패 시 리다이렉트할 컨트롤러) 참조경로
			.antMatchers("/error/**")		// CustomErrorController 참조경로
			.antMatchers("/api/members/email-auth/**");//이메일 인증시 
		
		// 정적자원에 대해 스프링 시큐리티 필터를 타지 않도록 설정
		web.ignoring().requestMatchers(PathRequest.toStaticResources().atCommonLocations());
	}
}