package com.wjthinkbig.aimath.corse.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.corse.vo.CorseSearchVO;
import com.wjthinkbig.aimath.corse.vo.CorseSingleVO;
import com.wjthinkbig.aimath.corse.vo.CorseVO;

/**
  * @Date : 2020. 9. 3.
  * @프로그램 설명 : 교육과정 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 3.     19001861            최초작성
  * </pre>
  */
@Mapper("corseDao")
public interface CorseDao {
	
	/**
	  * @Method 설명 : 교육과정 전체 리스트 조회
	  * @param corseSearch
	  * @return
	  * @throws Exception
	  */
	List<CorseVO> selectCorseList(CorseSearchVO corseSearch);
	
	/**
	  * @Method 설명 : 교육과정 소주제 정보 조회
	  * @param corseSearch
	  * @return
	  * @throws Exception
	  */
	CorseSingleVO selectCorseById(CorseSearchVO corseSearch);
	
	/**
	  * @Method 설명 : 교육과정 소주제 맵핑 리스트 조회
	  * @param corseSearch
	  * @return
	  * @throws Exception
	  */
	List<CorseVO> selectCorseListById(CorseSearchVO corseSearch);
	
	/**
	  * @Method 설명 : 교육과정 등록
	  * @param corse
	  * @throws Exception
	  */
	void insertCorse(CorseVO corse);
	
	/**
	  * @Method 설명 : 교육과정 수정
	  * @param corse
	  * @throws Exception
	  */
	void updateCorse(CorseVO corse);
	
	/**
	  * @Method 설명 : 교육과정 삭제
	  * @param corse
	  * @return
	  * @throws Exception
	  */
	int deleteCorse(CorseVO corse);
}
