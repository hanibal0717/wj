package com.wjthinkbig.aimath.corse.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.corse.service.CorseService;
import com.wjthinkbig.aimath.corse.service.dao.CorseDao;
import com.wjthinkbig.aimath.corse.vo.CorseSearchVO;
import com.wjthinkbig.aimath.corse.vo.CorseSingleVO;
import com.wjthinkbig.aimath.corse.vo.CorseVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 3.
  * @프로그램 설명 : 교육과정 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 3.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Service("corseService")
public class CorseServiceImpl extends BaseServiceImpl implements CorseService {
	
	/**
	 * 교육과정관리 Dao
	 */
	@Resource(name = "corseDao")
	private CorseDao corseDao;
	
	@Override
	public List<CorseVO> selectCorseList(CorseSearchVO corseSearch) throws Exception {
		return corseDao.selectCorseList(corseSearch);
	}

	@Override
	public CorseSingleVO selectCorseById(CorseSearchVO corseSearch) throws Exception {
		CorseSingleVO corseSingle = corseDao.selectCorseById(corseSearch);
		
		if( corseSingle != null ){
			corseSingle.setCorseList(corseDao.selectCorseListById(corseSearch));
		}
		
		return corseSingle;
	}

	@Override
	public void procCorse(SaveVO<CorseVO> corseSave) throws Exception {
		List<CorseVO> insertList = corseSave.getInsertList();
		List<CorseVO> updateList = corseSave.getUpdateList();
		List<CorseVO> deleteList = corseSave.getDeleteList();
		
		//교육과정 삭제 일괄 처리
		if( deleteList != null && deleteList.size() > 0 ) {
			int deleteCnt = 0;
			for( CorseVO corse : deleteList ) {
				log.info("등록할 교육과정 정보 : {}", corse.toString());
				
				corseDao.deleteCorse(corse);
				deleteCnt++;
				log.info("삭제 건수 : {}건", deleteCnt);
			}
		}
		
		//교육과정 수정 일괄 처리
		if( updateList != null && updateList.size() > 0 ) {
			int updateCnt = 0;
			for( CorseVO corse : updateList ) {
				log.info("등록할 교육과정 정보 : {}", corse.toString());
				
				corseDao.updateCorse(corse);
				updateCnt++;
				log.info("수정 건수 : {}건", updateCnt);
			}
		}
		
		//교육과정 등록 일괄 처리
		if( insertList != null && insertList.size() > 0 ) {
			int insertCnt = 0;
			for( CorseVO corse : insertList ) {
				log.info("등록할 교육과정 정보 : {}", corse.toString());
				
				corseDao.insertCorse(corse);
				insertCnt++;
				log.info("등록 건수 : {}건", insertCnt);
			}
		}
	}

}
