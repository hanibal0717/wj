package com.wjthinkbig.aimath.corse.vo;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 3.
  * @프로그램 설명 : 교육과정 관리 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 3.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="교육과정 관리 정보")
public class CorseVO extends BaseVO {
	
	@Min(value=0, groups = {Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="스테이지교과일련번호")
	@FieldName("스테이지교과일련번호")
	private int stgCorseSno; 		/* 스테이지교과일련번호 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd; 			/* 소주제코드(스테이지코드) */
	
	@ApiModelProperty(value="소주제명")
	@FieldName("소주제명")
	private String stgNm; 			/* 스테이지명 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="교육과정코드")
	@FieldName("교육과정코드")
	private String eduCursYearCd; 	/* 교육과정코드 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="학년학기코드")
	@FieldName("학년학기코드")
	private String eduCursCd; 		/* 학년학기코드 */
	
	@ApiModelProperty(value="교육과정코드명")
	@FieldName("학년학기코드명")
	private String eduCursCdNm; 	/* 학년학기코드명 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="단원코드")
	@FieldName("단원코드")
	private String unitCd; 			/* 단원코드 */
	
	@ApiModelProperty(value="단원코드명")
	@FieldName("단원코드명")
	private String unitCdNm;	 	/* 단원코드명 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="단원명")
	@FieldName("단원명")
	private String unitNm;	 		/* 단원명 */
	
}
