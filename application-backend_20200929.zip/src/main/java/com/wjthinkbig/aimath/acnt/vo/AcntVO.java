package com.wjthinkbig.aimath.acnt.vo;

import java.time.LocalDateTime;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.wjthinkbig.aimath.core.utils.WpinUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.constraints.CustomEmail;
import com.wjthinkbig.aimath.core.validator.constraints.Password;
import com.wjthinkbig.aimath.core.validator.constraints.PhoneNo;
import com.wjthinkbig.aimath.core.validator.constraints.UserID;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.ToString;

/**
  * @Date : 2020. 9. 7.
  * @프로그램 설명 : 관리자 계정 정보 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 7.     19001861            최초작성
  * </pre>
  */

@ToString(callSuper=true)
@ApiModel(description="관리자 계정 정보")
public class AcntVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@UserID
	@ApiModelProperty(value="관리자ID")
	@FieldName("관리자ID")
	private String mngtUserId; 			/* 관리자ID */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="관리자명")
	@FieldName("관리자명")
	private String useUserNm; 			/* 관리자명 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@JsonProperty(access = Access.WRITE_ONLY) 
	@Password
	@ApiModelProperty(value="비밀번호")
	@FieldName("비밀번호")
	private String pw; 					/* 비밀번호 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@Password
	@ApiModelProperty(value="비밀번호확인")
	@FieldName("비밀번호확인")
	private String pwCheck;				/* 비밀번호확인 */
	
	@ApiModelProperty(value="변경비밀번호확인")
	@Password
	@FieldName("변경비밀번호확인")
	private String newPw;				/* 변경비밀번호 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@CustomEmail
	@ApiModelProperty(value="이메일")
	@FieldName("이메일")
	private String emailAdrs; 			/* 이메일 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@PhoneNo
	@ApiModelProperty(value="휴대폰번호") 
	@FieldName("휴대폰번호")
	private String phone; 				/* 휴대폰번호 */
	 
	@Pattern(regexp = "SP|SM|PM|BM|CM")
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="관리자권한코드")
	@FieldName("관리자권한코드")
	private String authCd; 				/* 관리자권한코드 */
	
	@ApiModelProperty(value="관리자권한코드명")
	@FieldName("관리자권한코드명")
	private String authNm; 				/* 관리자권한코드명 */
	
	@ApiModelProperty(value="최근접속일")
	@FieldName("최근접속일")
	private String lastLoginDt; 		/* 최근접속일 */
	
	@ApiModelProperty(value="비밀번호변경일시")
	private LocalDateTime pwChngeDt;	/* 비밀번호 변경일시 */
	
	/**
	 * 권한
	 */
	@ApiModelProperty(value = "권한")
	private List<String> roles;
		
	/**
	  * @Method 설명 : 휴대폰번호 Wpin 복호화 작업
	  * @param num
	  */
	public void setPhoneDe(String num) throws Exception {
		//휴대폰번호 복호화 작업
		if( StringUtils.isNotEmpty( num ) ) {
			JSONObject obj = WpinUtils.wpinDecryption("P", num);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.phone = obj.getString("rtnVal");
			} else {
				this.phone = num;
			}
		}
	}
	
	/**
	  * @Method 설명 : 이메일 Wpin 암호화 작업
	  * @param email
	  */
	public String getPhoneEn() throws Exception {
		//휴대폰번호 암호화 작업
		if( StringUtils.isNotEmpty( this.phone ) ) {
			JSONObject obj = WpinUtils.wpinEncryption("P", this.phone);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.phone = obj.getString("rtnVal");
			}
		}
		
		return this.phone;
	}
	
	/**
	  * @Method 설명 : 이메일 Wpin 복호화 작업
	  * @param email
	  */
	public void setEmailAdrsDe(String email) throws Exception {
		//이메일 복호화 작업
		if( StringUtils.isNotEmpty( email ) ) {
			JSONObject obj = WpinUtils.wpinDecryption("E", email);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.emailAdrs = obj.getString("rtnVal");
			} else {
				this.emailAdrs = email;
			}
		}
	}
	
	/**
	  * @Method 설명 : 이메일 Wpin 암호화 작업
	  * @param email
	  */
	public String getEmailAdrsEn() throws Exception {
		//이메일 암호화 작업
		if( StringUtils.isNotEmpty( this.emailAdrs ) ) {
			JSONObject obj = WpinUtils.wpinEncryption("E", this.emailAdrs);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.emailAdrs = obj.getString("rtnVal");
			}
		}
		
		return this.emailAdrs;
	}

	public String getMngtUserId() {
		return mngtUserId;
	}

	public void setMngtUserId(String mngtUserId) {
		this.mngtUserId = mngtUserId;
	}

	public String getUseUserNm() {
		return useUserNm;
	}

	public void setUseUserNm(String useUserNm) {
		this.useUserNm = useUserNm;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getPwCheck() {
		return pwCheck;
	}

	public void setPwCheck(String pwCheck) {
		this.pwCheck = pwCheck;
	}

	public String getNewPw() {
		return newPw;
	}

	public void setNewPw(String newPw) {
		this.newPw = newPw;
	}

	public String getEmailAdrs() {
		return emailAdrs;
	}

	public void setEmailAdrs(String emailAdrs) {
		this.emailAdrs = emailAdrs;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAuthCd() {
		return authCd;
	}

	public void setAuthCd(String authCd) {
		this.authCd = authCd;
	}

	public String getAuthNm() {
		return authNm;
	}

	public void setAuthNm(String authNm) {
		this.authNm = authNm;
	}

	public String getLastLoginDt() {
		return lastLoginDt;
	}

	public void setLastLoginDt(String lastLoginDt) {
		this.lastLoginDt = lastLoginDt;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public LocalDateTime getPwChngeDt() {
		return pwChngeDt;
	}
	
	
}
