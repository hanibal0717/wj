package com.wjthinkbig.aimath.acnt.service.impl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;

import com.wjthinkbig.aimath.acnt.service.AcntService;
import com.wjthinkbig.aimath.acnt.service.dao.AcntDao;
import com.wjthinkbig.aimath.acnt.vo.AcntSearchVO;
import com.wjthinkbig.aimath.acnt.vo.AcntVO;
import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.acnt.vo.LoginAdminVO;
import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.DateUtils;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.security.JwtUtils;
import com.wjthinkbig.aimath.security.admin.AdminAuthenticationToken;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 7.
  * @프로그램 설명 : 관리자 정보 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 7.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Service("acntService")
public class AcntServiceImpl extends BaseServiceImpl implements AcntService {
	
	/**
	 * 단방향 암호화
	 */
	@Autowired
	@Qualifier("passwordEncoder")
	private PasswordEncoder passwordEncoder;
	
	/**
	 * 관리자 관리 Dao
	 */
	@Resource(name = "acntDao")
	private AcntDao acntDao;
	
	/**
	 * 인증을 처리하는 Spring Security AuthenticationManager
	 */
	@Autowired
	private AuthenticationManager authenticationManager; 
	
	/**
	 * JWT Utility
	 */
	@Resource(name = "jwtUtils")
	private JwtUtils jwtUtils;
	
	@Override
	public List<AcntVO> selectAcntList(AcntSearchVO acntSearch) throws Exception {
		return acntDao.selectAcntList(acntSearch);
	}

	@Override
	public int selectAcntCnt(AcntSearchVO acntSearch) throws Exception {
		return acntDao.selectAcntCnt(acntSearch);
	}

	@Override
	public AcntVO selectAcntById(String mngt_user_id) throws Exception {
		AcntVO acnt = acntDao.selectAcntById(mngt_user_id);
		return acnt;
	}

	@Override
	public int selectUserIdDplctCeck(String mngt_user_id) throws Exception {
		return acntDao.selectUserIdDplctCeck(mngt_user_id);
	}

	@Override
	public void insertAcnt(AcntVO acnt) throws Exception {
		//아이디, 이메일 중복 체크
		if( acntDao.selectUserIdDplctCeck(acnt.getMngtUserId()) > 0 || acntDao.selectEmailDplctCeck(acnt.getEmailAdrs()) > 0 ) {
			throw this.processException("S001001"); // 이미 존재하는 데이터입니다.
		}
		
		//비밀번호 확인
		if( !acnt.getPw().equals(acnt.getPwCheck()) ) {
			throw this.processException("S001018"); // 입력한 비밀번호와 재입력한 비밀번호가 일치하지 않습니다.
		}
		
		//비밀번호 암호화
		acnt.setPw( passwordEncoder.encode(acnt.getPw()) );
		acntDao.insertAcnt(acnt);
	}

	@Override
	public void updateAcnt(AcntVO acnt) throws Exception {
		//필수값 체크
		this.validateOrElseThrow(acnt, Groups.Update.class);
		
		//비밀번호 변경
		if( StringUtils.isNotEmpty(acnt.getPw()) ) {
			//기존 비밀번호 검증
			if( !this.selectPasswordCeck(acnt) ) {
				throw this.processException("S001006"); // 계정이 존재하지 않거나 계정정보가 올바르지 않습니다.
			}
			
			if( StringUtils.isNotEmpty(acnt.getPwCheck()) && StringUtils.isNotEmpty(acnt.getNewPw()) ) {
				//비밀번호 확인
				if( !acnt.getNewPw().equals(acnt.getPwCheck()) ) {
					throw this.processException("S001018"); // 입력한 비밀번호와 재입력한 비밀번호가 일치하지 않습니다.
				}
				
				//현재 비밀번호와 같은지 비교
				String pw = acntDao.selectPassword(acnt.getMngtUserId());
				if( passwordEncoder.matches(acnt.getNewPw(), pw) ) {
					throw this.processException("S001019"); // 현재 비밀번호와 동일한 비밀번호 입니다.
				}
				
				//비밀번호 암호화
				acnt.setNewPw( passwordEncoder.encode(acnt.getNewPw()) );
			} else {
				throw this.processException("S001011"); // 필수값 오류입니다.
			}
		}
		
		acntDao.updateAcnt(acnt);
	}

	@Override
	public int deleteAcnt(String mngt_user_id) throws Exception {
		return acntDao.deleteAcnt(mngt_user_id);
	}

	@Override
	public boolean selectPasswordCeck(AcntVO acnt) throws Exception {
		String pw = acntDao.selectPassword(acnt.getMngtUserId());
		
		if( StringUtils.isNotEmpty(pw) ) {
			return passwordEncoder.matches(acnt.getPw(), pw);
		}
		return false;
	}

	
	@Override
	public String signin(@Valid LoginAdminVO user) throws Exception {

		try {
			// 정상적으로 인증처리가 되면
			AdminAuthenticationToken authenticationToken = new AdminAuthenticationToken(user.getMngtUserId(), user.getPw());
			Authentication authentication = authenticationManager.authenticate(authenticationToken);
			
			log.debug("정상인증된 관리자 객체 (a fully populated Authentication object (including granted authorities) : " + authentication.toString());
			
			// 토큰을 발급한다.			
			AdminAccount userAccount = (AdminAccount) authentication.getPrincipal();
			
			HashMap<String, String> tokenClaims = new HashMap<String, String>();
//			tokenClaims.put("sid", userAccount.getUserInfo().getMngtUserId());	// 관리자 아이디
			
			String token = jwtUtils.createToken(user.getMngtUserId(), userAccount.getUserInfo().getRoles(), tokenClaims);
			
			return token;
		} catch (BadCredentialsException e) {
			log.debug("관리자 로그인 인증실패({}) : {}", ClassUtils.getShortName(e.getClass()), e.getMessage());
			
			// 인증처리 실패시 BadCredentialsException 반환
			throw this.processException("S001006"); // 계정이 존재하지 않거나 계정정보가 올바르지 않습니다.
		} catch (AuthenticationException e) {
			log.debug("관리자 로그인 인증실패({}) : {}", ClassUtils.getShortName(e.getClass()), e.getMessage());
			
			// 인증처리 실패시 AuthenticationException 반환
			throw this.processException("E000015"); // 해당 리소스에 접근하기 위한 권한이 없습니다.
		}
	}
	
	@Override
	public long selectPassedDaysFromChangeDt(String mngtUserId) throws Exception {
		long elapsedDays = 0L;
		
		AcntVO account = acntDao.selectAcntById(mngtUserId);
		if(account != null) {			
			LocalDateTime pwChngeDt = account.getPwChngeDt();
			if(pwChngeDt != null) {
				// 비밀번호를 변경한 적이 있으면 최종 변경일자로부터 산정
				elapsedDays = DateUtils.betweenDays(pwChngeDt, LocalDateTime.now());				
			} else {
				// 비밀번호를 변경한 적이 없으면 등록일시로부터 산정
				pwChngeDt = account.getRgtnDt();
				elapsedDays = DateUtils.betweenDays(pwChngeDt, LocalDateTime.now());
			}
		}
		
		return elapsedDays;
	}
	
	@Override
	public int updateLastLoginDt(String mngt_user_id) throws Exception {
		return acntDao.updateLastLoginDt(mngt_user_id);
	}

	@Override
	public int updatePasswordChangeDate(String mngt_user_id) throws Exception {
		return acntDao.updatePasswordChangeDate(mngt_user_id);
	}
}