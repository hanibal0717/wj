package com.wjthinkbig.aimath.acnt.vo;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

/**
  * @Date : 2020. 9. 11. 
  * @프로그램 설명 : 스프링시큐리티가 제공하는 User 객체에 대한 Custom Admin 객체
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk            최초작성
  * </pre>
 */
public class AdminAccount extends org.springframework.security.core.userdetails.User {
	
	private static final long serialVersionUID = -7495793419409636738L;
	
	// 실제 서비스용 AcntVO 객체
	private AcntVO user;

	public AdminAccount(AcntVO user) {		
		super(user.getMngtUserId(), user.getPw(), getAuthorities(user));		
		this.user = user;
	}
	
	// 실제 서비스용 UserVO 객체에 대한 Getter
	public AcntVO getUserInfo() {		
		return this.user;		
	}
	
	// DB에 등록된 권한에 따라 인증객체의 권한을 설정
	private static Collection<SimpleGrantedAuthority> getAuthorities(AcntVO user){
		Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        for(String authority : user.getRoles()) {
        	authorities.add(new SimpleGrantedAuthority(authority));
        }
        return authorities;
    }
}