package com.wjthinkbig.aimath.acnt.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.acnt.vo.AcntSearchVO;
import com.wjthinkbig.aimath.acnt.vo.AcntVO;
import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;

@Mapper("acntDao")
public interface AcntDao {
	
	/**
	  * @Method 설명 : 검색조건에 맞는 관리자 정보 전체 리스트를 가져온다.
	  * @param acntSearch 검색할 정보를 담은 관리자 VO
	  * @return 검색된 관리자 정보 리스트
	  * @throws Exception
	 */
	List<AcntVO> selectAcntList(AcntSearchVO acntSearch);
	
	/**
	  * @Method 설명 : 검색조건에 맞는 관리자 정보 전체 리스트 수를 가져온다.
	  * @param acntSearch 검색할 정보를 담은 관리자 VO
	  * @return 검색된 관리자 정보 리스트 수
	  * @throws Exception
	  */
	int selectAcntCnt(AcntSearchVO acntSearch);
	
	/**
	  * @Method 설명 : 관리자 정보 단일 조회
	  * @param mngt_user_id
	  * @return
	  * @throws Exception
	  */
	AcntVO selectAcntById(String mngt_user_id);
	
	/**
	  * @Method 설명 : 관리자ID 중복체크
	  * @param mngt_user_id
	  * @return
	  * @throws Exception
	  */
	int selectUserIdDplctCeck(String mngt_user_id);
	
	/**
	  * @Method 설명 : 관리자 email 중복체크
	  * @param email_adrs
	  * @return
	  * @throws Exception
	  */
	int selectEmailDplctCeck(String email_adrs);
	
	/**
	  * @Method 설명 : 관리자 비밀번호 조회
	  * @param mngt_user_id
	  * @return
	  * @throws Exception
	  */
	String selectPassword(String mngt_user_id);
	
	/**
	  * @Method 설명 : 신규 관리자 정보 등록
	  * @param acnt
	  * @throws Exception
	  */
	void insertAcnt(AcntVO acnt);
	
	/**
	  * @Method 설명 : 관리자 정보 수정
	  * @param acnt
	  * @throws Exception
	  */
	void updateAcnt(AcntVO acnt);
	
	/**
	  * @Method 설명 : 관리자 정보 삭제 
	  * @param mngt_user_id 관리자 ID
	  * @return
	  */
	int deleteAcnt(String mngt_user_id);
	
	/**
	  * @Method 설명 : 로그인 시 최종 로그인일시 갱신
	  * @param mngt_user_id 관리자 ID
	  * @return
	 */
	int updateLastLoginDt(String mngt_user_id);
	
	/**
	  * @Method 설명 : 최종비밀번호변경일자를 기준일로부터 5개월전으로 갱신 (1개월후에 비밀번호 변경도래)
	  * @param mngt_user_id 관리자 ID
	  * @return
	 */
	int updatePasswordChangeDate(String mngt_user_id);
}
