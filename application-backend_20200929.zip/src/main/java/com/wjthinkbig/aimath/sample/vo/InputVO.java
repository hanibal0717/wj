/**
 * 
 */
package com.wjthinkbig.aimath.sample.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.constraints.CustomEmail;
import com.wjthinkbig.aimath.core.validator.constraints.Password;
import com.wjthinkbig.aimath.core.validator.constraints.PhoneNo;
import com.wjthinkbig.aimath.core.validator.constraints.UserID;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
  * @Date : 2020. 9. 8. 
  * @프로그램 설명 :
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 8.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@ApiModel(value = "입력값 검증을 위한 샘플 VO")
@Getter
@Setter
public class InputVO {
	
	@FieldName("이메일주소")
	@ApiModelProperty(value = "이메일")
	@CustomEmail
	private String email; 
	
	@FieldName("비밀번호")
	@ApiModelProperty(value = "비밀번호")
	@Password
	private String password;
	
	@FieldName("아이디")
	@ApiModelProperty(value = "아이디")
	@UserID
	private String userid;
	
	@FieldName("전화번호(휴대폰)")
	@ApiModelProperty(value = "전화번호 또는 휴대폰번호")
	@PhoneNo
	private String phone;
	
}