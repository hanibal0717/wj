package com.wjthinkbig.aimath.core.extend.service;

import java.util.Locale;
import java.util.Objects;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.MessageSourceAware;
import org.springframework.context.i18n.LocaleContextHolder;

import com.wjthinkbig.aimath.core.exception.BizException;

import lombok.extern.slf4j.Slf4j;

/**
 * <pre>
 * 기본 기능 구현 클래스
 * </pre>
 *
 * @author Kang Seok Han
 * @version 1.0
 * @since
 * <pre>
 * since			author			 description
 * =============	===============	===========================
 * 2019. 05. 28.	Kang Seok Han	  최초 생성
 * </pre>
 */
@Slf4j
public abstract class BaseSupport implements MessageSourceAware {

	/**
	 * 메시지 소스
	 */
	protected MessageSource messageSource;

	
	/**
	 * Validator
	 * 빈 검증 Validator
	 */
	@Autowired
	private Validator validator;

	/**
	 * 메시지 소스를 설정 한다.
	 *
	 * @param messageSource 메시지 소스
	 */
	@Override
	public void setMessageSource(MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	/**
	 * 메시지키에 해당하는 메시지를 반환한다.
	 * @param msgKey
	 * @return
	 */
	public String getMessage(String msgKey) {
		return messageSource.getMessage(msgKey, null, LocaleContextHolder.getLocale());
	}

	/**
	 * 메시지키에 해당하는 메시지를 반환한다.
	 * @param msgKey
	 * @param args
	 * @return
	 */
	public String getMessage(String msgKey, String... args) {
		return messageSource.getMessage(msgKey, args, LocaleContextHolder.getLocale());
	}

	/**
	 * 메시지 키에 해당하는 메시지를 적용한 예외를 생성한다.
	 * @param msgKey 메시지 키
	 * @return
	 */
	protected RuntimeException processException(String msgKey) {
		return processException(msgKey, new String[0]);
	}

	/**
	 * 메시지 키 에 해당하는 메시지에 파라미터를 적용한 예외를 생성한다.
	 * @param msgKey 메시지 키
	 * @param msgArgs 메시지 파라미터 치환을 위한 인자 배열
	 * @return
	 */
	protected RuntimeException processException(String msgKey, String... msgArgs) {
		return processException(msgKey, msgArgs, null);
	}
	
	/**
	 * 메시지 키 에 해당하는 메시지를 적용한 예외를 생성한다.
	 * @param msgKey 메시지 키
	 * @param e
	 * @return
	 */
	protected RuntimeException processException(String msgKey, Exception e) {
		return processException(msgKey, new String[0], e);
	}

	/**
	 * 메시지 키 에 해당하는 메시지에 파리미터를 적용한 예외를 생성한다.
	 * @param msgKey 메시지 키
	 * @param msgArgs 메시지 파라미터 치환을 위한 인자 배열
	 * @param e
	 * @return
	 */
	protected RuntimeException processException(String msgKey, String[] msgArgs, Exception e) {
		return processException(msgKey, msgArgs, e, LocaleContextHolder.getLocale());
	}

	/**
	 * 로케일이 적용된 메시지 키 에 해당하는 메시지에 파리미터를 적용한 예외를 생성한다.
	 * @param msgKey 메시지 키
	 * @param msgArgs 메시지 파라미터 치환을 위한 인자 배열
	 * @param e
	 * @param locale 적용할 로케일
	 * @return
	 */
	protected RuntimeException processException(String msgKey, String[] msgArgs, Exception e, Locale locale) {
		return processException(msgKey, msgArgs, e, locale, null);
	}

	/**
	 * 로케일이 적용된 메시지 키 에 해당하는 메시지에 파리미터를 적용한 예외를 생성한다.
	 * @param msgKey 메시지 키
	 * @param msgArgs 메시지 파라미터 치환을 위한 인자 배열
	 * @param e
	 * @param locale 적용할 로케일
	 * @param exceptionCreator
	 * @return
	 */
	protected RuntimeException processException(final String msgKey, final String[] msgArgs, final Exception e,
			final Locale locale, ExceptionCreator exceptionCreator) {
		ExceptionCreator eC = null;

		if (exceptionCreator == null) {
			eC = new ExceptionCreator() {
				public RuntimeException createBizException(MessageSource messageSource) {
					return new BizException(messageSource, msgKey, msgArgs, locale, null, e);
				}
			};
		}
		return eC.createBizException(this.messageSource);
	}

	/**
	 * 예외 생성 인터페이스
	 * @author Kang Seok Han
	 *
	 */
	protected static abstract interface ExceptionCreator {
		public abstract RuntimeException createBizException(MessageSource messageSource);
	}
	
	/**
	 * JSR380 유효성을 검증하고 유효성 검증에 실패할 경우 예외를 발생한다.
	 * @Author Kang Seok Han
	 * @param object
	 * @param groups
	 */
	protected <T> void validateOrElseThrow(T object, Class<?>... groups) {
		Set<ConstraintViolation<T>> violations = validator.validate(object, groups);
		if(!violations.isEmpty()) {
			throw new ConstraintViolationException(violations);
		}
	}


	

	/**
	 * <pre>
	 * 개발자가 정의한 Exception 일 경우 해당 Exception의 메시지를 반환한다.
	 * 만약 아닐 경우 파라미터로 넘어온 msgKey, param 로 메시지를 반환한다.
	 * </pre>
	 * @param e 확인할  Exception 객체
	 * @param msgKey 대신 보여줄 메시지코드 키
	 * @param param 파라미터
	 * @author 이주황
	 * @since 2020.05.22
	 * */
	public String unWrapperExceptionMessage(Exception e, String msgKey, String... param) {
		if(Objects.isNull(e)) {
			return getMessage(msgKey, param);
		} else {
			Package pack = e.getClass().getPackage();
			if(pack.getName().contains("com.wjthinkbig")) {
				return e.getMessage();
			} else {
				return getMessage(msgKey, param);
			}
		}
	}

	/**
	 * <pre>
	 * 개발자가 정의한 Exception 일 경우 해당 Exception의 메시지를 반환한다.
	 * 만약 아닐 경우 파라미터로 넘어온 msgKey 로 메시지를 반환한다.
	 * </pre>
	 * @param e 확인할  Exception 객체
	 * @param msgKey 대신 보여줄 메시지코드 키
	 * @author 이주황
	 * @since 2020.05.22
	 * */
	public String unWrapperExceptionMessage(Exception e, String msgKey) {
		if(Objects.isNull(e)) {
			return getMessage(msgKey);
		} else {
			Package pack = e.getClass().getPackage();
			if(pack.getName().contains("com.wjthinkbig")) {
				return e.getMessage();
			} else {
				return getMessage(msgKey);
			}
		}
	}

}
