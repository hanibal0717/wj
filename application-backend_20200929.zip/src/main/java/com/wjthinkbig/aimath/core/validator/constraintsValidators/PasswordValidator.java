/**
 * 
 */
package com.wjthinkbig.aimath.core.validator.constraintsValidators;

import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.wjthinkbig.aimath.core.validator.constraints.Password;

/**
  * @Date : 2020. 9. 8. 
  * @프로그램 설명 : 비밀번호 검증을 위한 Custom Validator 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 8.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class PasswordValidator implements ConstraintValidator<Password, String> {

	// 비밀번호 검증패턴		
	private final String REGEX_PATTERN = "(?=.*[A-Za-z])(?=.*[0-9])(?=.*[$@$!%*#?&])[A-Za-z[0-9]$@$!%*#?&]{8,16}$";
	
	public Pattern pattern = Pattern.compile(REGEX_PATTERN);
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		
		if(value == null) {
			return true;
		} else {
			return pattern.matcher(value).matches();
		}			
	}
}