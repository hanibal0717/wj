/**
 * 
 */
package com.wjthinkbig.aimath.core.validator.constraints;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.wjthinkbig.aimath.core.validator.constraintsValidators.CustomEmailValidator;

/**
 * @Date : 2020. 9. 8. 
 * @프로그램 설명 : Email Custom Validator 
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 9. 8.     Lee Seung Hyuk            최초작성
 * </pre>
 */
@Documented
@Retention(RUNTIME)
@Target({ FIELD, METHOD, ElementType.PARAMETER })
@Constraint(validatedBy = CustomEmailValidator.class)
public @interface CustomEmail {
	
	String message() default "{S001020}";
	
    Class<?>[] groups() default {};
    
    Class<? extends Payload>[] payload() default{};
}
