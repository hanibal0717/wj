package com.wjthinkbig.aimath.core.exception;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;


/**
 * @Date : 2020. 8. 22. 
 * @작성자 : Lee Seung Hyuk
 * @프로그램 설명 : 빈검증과 같은 상황에서 Exception 발생시 세부내용을 저장할 객체 
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 8. 22.     seung              최초작성
 * </pre>
*/
@Getter
@Setter
public class Errors implements Serializable {
	
	private static final long serialVersionUID = 3211489980457456046L;

	private List<Error> errors = new ArrayList<Error>();

	/**
	 *
	 * @param error the error
	 */
	public void add(Error error) {
		this.errors.add(error);
	}
}