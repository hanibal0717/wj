/**
 * 
 */
package com.wjthinkbig.aimath.core.web.bind;

import java.time.LocalDateTime;

import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 8. 12. 
  * @프로그램 설명 : 모든 VO에 대한 부모 VO 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 3.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Getter
@Setter
@ToString
public abstract class BaseVO {
		
	@ApiModelProperty(value = "등록일시")
	@FieldName("등록일자")
	private LocalDateTime rgtnDt; 	/* 등록일시 */
	
//	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value = "등록자")
	@FieldName("등록자ID")
	private String rgtnUser; 		/* 관리자id */
		
	@ApiModelProperty(value = "수정일시") 
	@FieldName("수정일시")
	private LocalDateTime modDt; 	/* 수정일시 */
	
//	@NotBlank(groups = {Groups.Update.class})
	@ApiModelProperty(value = "수정자")
	@FieldName("수정자ID")
	private String modUser; 		/* 수정자 */
	
	/**
	  * @Method 설명 : 로그인한 사용자의 ID로 등록자와 수정자 및 등록/수정 시간을 세팅 
	  * @param user
	 */
	public void setLoginUser(String user) {
		LocalDateTime now = LocalDateTime.now();
		
		this.setRgtnUser(LoginUtils.getUserId());
		this.setRgtnDt(now);		
		this.setModUser(LoginUtils.getUserId());
		this.setModDt(now);
	}
}