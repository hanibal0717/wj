package com.wjthinkbig.aimath.core.utils;

import org.springframework.stereotype.Component;

@Component
public class SeedUtils {
	
	// 쿠키 암호화 키
	public static String COOKIE_ENCRYPT_KEY = "NZnSgKa1fL9SFKtz6CtknDNH5WFsR98u";
	
	
	/**
	 * URL의 REQUEST 정보에 대한 암호화 처리
	 * KISA 권고 SEED 128비트 알고리즘 적용
	 */
	public String getEnCrypt(String inputvalue) {		
		return seedEnCrypt (COOKIE_ENCRYPT_KEY, inputvalue);
	}

	/**
	 * URL의 REQUEST 정보에 대한 복호화 처리
	 * KISA 권고 SEED 128 비트 알고리즘 이용
	 */
	public String getDeCrypt(String inputvalue) {
		return seedDeCrypt (COOKIE_ENCRYPT_KEY, inputvalue == null ? inputvalue : inputvalue.replaceAll(" ","+"));
	}
	
	
    /**
	 * URL의 REQUEST 정보에 대한 암호화 처리
	 * KISA 권고 SEED 128비트 알고리즘 적용
     * @param inputvalue2 
     * @param encryptKey 
	 */
	public static String seedEnCrypt(String encryptKey, String inputvalue) {
		String outvalue = "";
		
		try {
			 
			//바이트단위로 배열에 넣어준다
			byte pbUserKey[]  = encryptKey.getBytes();
			// Round keys for encryption or decryption
			int pdwRoundKey[] = new int[32];  //User secret key
			byte pbCipher[]   = new byte[16];
			 
			//암호화키로 사용할 16비트 문자열
			//Seed알고리즘에 key값 전달
			
			//byte 수 채우기 16bit단위에서 모자란 값을 자리수 채워주기
			int max = 0;
			if(inputvalue.getBytes().length % 16 != 0){
				max = 16-(inputvalue.getBytes().length % 16);	
			}
 			for(int i=0; i<max ; i++){
				inputvalue += (char)(0); //null값으로 채움
			} 
			int size=inputvalue.getBytes().length;
			
			//사용자 입력값을 배열에 넣어준다
			byte pbData[]     = inputvalue.getBytes(); 
			byte reData[][]   = new byte[size/16][16];
			byte reCipher[]   = new byte[size];
			SeedX.SeedRoundKey(pdwRoundKey, pbUserKey);
			// Encryption
			int b1=0, b2=0;	
			for(int i=0; i < size; i++){
				b1 = (i / 16);
				b2 = (i % 16);					
				reData[ b1 ][ b2 ] = pbData[i];	 
			}
			int rf = 0;
			for(int i=0; i<reData.length; i++){
				//암호화 실행
				SeedX.SeedEncrypt(reData[i], pdwRoundKey, pbCipher);				
				for(int j=0; j<pbCipher.length; j++){
					reCipher[rf++] = pbCipher[j];
				}
			}
			//base 64 encoding 선언 및 처리
			sun.misc.BASE64Encoder encoder = new sun.misc.BASE64Encoder();	        
	        outvalue = encoder.encode(reCipher);
	        
		} catch (Exception e) {			
			e.printStackTrace();
		}
		return outvalue;
	}

	/**
	 * URL의 REQUEST 정보에 대한 복호화 처리
	 * KISA 권고 SEED 128 비트 알고리즘 이용
	 */
	public static String seedDeCrypt(String encryptKey, String inputvalue) {
		
		String outvalue = "";
		int pdwRoundKey[] = new int[32];  //User secret key
		byte pbCipher[]   = new byte[16];
		byte pbPlain[]    = new byte[16];
		byte pbUserKey[]  = encryptKey.getBytes();
		
		try {
		 //base64값을 복호화를 사전 진행
		 sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder();
		 //base64로 처리된 값을 decode
		 pbCipher = decoder.decodeBuffer(inputvalue);
		 
         //Seed128비트 복호화 진행
         int size = pbCipher.length;
         byte reData[][] = new byte[size/16][16];
         byte rePlain[]  = new byte[size];
         
         SeedX.SeedRoundKey(pdwRoundKey, pbUserKey);
         
         int b1=0, b2=0;
         for (int i=0; i<size; i++) {
        	 b1=(i/16);
        	 b2=(i%16);
        	 reData[b1][b2]=pbCipher[i];
        	
         } 
         int rf=0;

         for(int i=0; i<reData.length;i++){
        	 SeedX.SeedDecrypt(reData[i], pdwRoundKey, pbPlain);
      	 
        	 for(int j=0; j<pbPlain.length;j++){
        		 rePlain[rf++]=pbPlain[j]; 
        	 }
         }

         //평문 전환 값 전달
         outvalue = new String( rePlain );

		} catch (NullPointerException npe) { 
            return inputvalue;
		} catch (Exception e) { 
			e.printStackTrace(); 
		}
 
		return  nullTrim(outvalue);
	}
	
	public static String nullTrim(String decryptText) {

	    int idx = decryptText.indexOf(0x00);
	    if(idx >= 0)
	    {
	      decryptText =  decryptText.substring(0, idx);
	    } 
			return decryptText;
	}
	
	/**
	 * 문자열 변수가 널/공백 체크
	 * @param val 문자열 변수
	 * @return 널/공백인 경우 true
	 */
	public static boolean isEmpty(String val) {
		if(val == null || "".equals(val.trim())) { 
			return true;
		} 
		return false;
	}
	
	
}