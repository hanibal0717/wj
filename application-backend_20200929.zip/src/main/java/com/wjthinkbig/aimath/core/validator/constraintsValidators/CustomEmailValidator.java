/**
 * 
 */
package com.wjthinkbig.aimath.core.validator.constraintsValidators;

import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.wjthinkbig.aimath.core.validator.constraints.CustomEmail;

/**
  * @Date : 2020. 9. 8. 
  * @프로그램 설명 : 이메일 검증을 위한 Custom Validator 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 8.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class CustomEmailValidator implements ConstraintValidator<CustomEmail, String> {

	// 이메일 검증 패턴
	private final String REGEX_PATTERN = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
	
	public Pattern pattern = Pattern.compile(REGEX_PATTERN);
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {

		if(value == null) {
			return true;
		} else {
			return pattern.matcher(value).matches();
		}
	}
}