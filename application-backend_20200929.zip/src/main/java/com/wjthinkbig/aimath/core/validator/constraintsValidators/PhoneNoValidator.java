/**
 * 
 */
package com.wjthinkbig.aimath.core.validator.constraintsValidators;

import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.wjthinkbig.aimath.core.validator.constraints.PhoneNo;

/**
  * @Date : 2020. 9. 9. 
  * @프로그램 설명 : 전화번호(휴대폰) Custom Validator
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 9.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class PhoneNoValidator implements ConstraintValidator<PhoneNo, String> {

	// 전화번호(휴대폰) 검증패턴		
	private final String REGEX_PATTERN = "^\\d{2,3}\\d{3,4}\\d{4}$";
	
	private Pattern pattern = Pattern.compile(REGEX_PATTERN);	
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		if(value == null) {
			return true;
		} else {
			return pattern.matcher(value).matches();
		}
	}
}