/**
 * 
 */
package com.wjthinkbig.aimath.core.web.method.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.mvc.method.annotation.JsonViewRequestBodyAdvice;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;

/**
  * @Date : 2020. 9. 28. 
  * @프로그램 설명 : 컨트롤러에서 @RequestBody 어노테이션을 적용한 BaseVO 또는 SaveVO의 최초등록자ID, 최종수정자ID를 로그인 정보를 기반으로 자동 할당 한다.
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 28.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Configuration
public class RequestMappingHandlerAdapterBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
		
		if(beanName.equals("requestMappingHandlerAdapter")) {
			RequestMappingHandlerAdapter requestMappingHandlerAdapter = (RequestMappingHandlerAdapter)bean;
			
			List<Object> requestResponseBodyAdvice = new ArrayList<Object>();
			requestResponseBodyAdvice.add(new JsonViewRequestBodyAdvice());
			
			List<HandlerMethodArgumentResolver> argumentResolvers = requestMappingHandlerAdapter.getArgumentResolvers();
			
			List<HandlerMethodArgumentResolver> modifiedArgumentResolvers = new ArrayList<>(argumentResolvers.size());
			modifiedArgumentResolvers.add(new CustomRequestResponseBodyMethodProcessor(requestMappingHandlerAdapter.getMessageConverters(), requestResponseBodyAdvice));

			for(int i = 1; i < argumentResolvers.size(); i++) {
				modifiedArgumentResolvers.add(argumentResolvers.get(i));
			}
			
			requestMappingHandlerAdapter.setArgumentResolvers(null);			
			requestMappingHandlerAdapter.setArgumentResolvers(modifiedArgumentResolvers);
			
			return requestMappingHandlerAdapter;
		}

		return bean;
	}	
}