/**
 * 
 */
package com.wjthinkbig.aimath.core.utils;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;


/**
  * @Date : 2020. 9. 28. 
  * @프로그램 설명 : 로그인한 사용자의 정보를 제공한다.
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 28.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class LoginUtils {

	/**
	 * 로그인 사용자/관리자 ID를 반환한다.
	 * @return 로그인한 사용자 또는 관리자의 ID를 반환한다. 로그인하지 않았으면 'anonymousUser'
	 */
	public static String getUserId() {		
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof AdminAccount) {
			return ((AdminAccount)principal).getUserInfo().getMngtUserId();
		} else if(principal instanceof MbrAccount) {
			return ((MbrAccount)principal).getMbrInfo().getMbrId();
		} else {
			return principal.toString();
		}
	}
	
	/**
	  * @Method 설명 : 로그인 여부를 반환한다.
	  * @return true/false
	 */
	public static boolean isLogin() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if( auth == null) {
			return false;
		}
		
		return auth != null && "anonymousUser".equals(auth.getPrincipal()) ? false : true;
	}
}