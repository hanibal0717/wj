package com.wjthinkbig.aimath.core.utils;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetBucketLocationRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.wjthinkbig.aimath.common.vo.FileVO;

@Component
public class FileUtils {
	
	/**
	 * AWS S3 Access 키값
	 */
	private static String accessKey;
	@Value("${aws.key.access-key}")
	public void setAccessKey(String key) {
		accessKey = key;
	}
	
	/**
	 * AWS S3 Secret 키값
	 */
	private static String secretKey;
	@Value("${aws.key.secret-key}")
	public void setSecretKey(String key) {
		secretKey = key;
	}
	
	/**
	 * AWS S3 bucketName 키값
	 */
	private static String bucketName;
	@Value("${aws.bucket.name}")
	public void setBucketName(String name) {
		bucketName = name;
	}
	
	/**
	 * AWS S3 bucketPath
	 */
	private static String bucketPath;
	@Value("${aws.bucket.path}")
	public void setBucketPath(String path) {
		bucketPath = path;
	}
	
	/**
	 * AWS S3 도메인
	 */
	private static String domain;
	@Value("${aws.domain}")
	public void setDomain(String url) {
		domain = url;
	}
	
	/**
	  * @Method 설명 : AWS S3 로 파일 업로드
	  * @param mFile
	  * @param filePath
	  * @return
	  * @throws Exception
	  */
	public static FileVO sendAWSS3(MultipartFile mFile, String filePath) throws Exception {
		FileVO file = null;
		
		if( mFile != null && !mFile.isEmpty() && StringUtils.isNotEmpty(filePath) ) {
			AWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
			ClientConfiguration clientConfig = new ClientConfiguration();
			clientConfig.setProtocol(Protocol.HTTP);
			
			AmazonS3 amazonS3 = new AmazonS3Client(awsCredentials, clientConfig);
			amazonS3.setRegion(Region.getRegion(Regions.AP_NORTHEAST_2));			//리전 설정
			
			String bucketLocation = amazonS3.getBucketLocation(new GetBucketLocationRequest(bucketName));
			
			if( bucketLocation != null ) {
				//S3 인증 성공
				file = new FileVO();
				
				//파일명 변경
				String orgFileNm = mFile.getOriginalFilename();
				long t = System.currentTimeMillis();
				int r = (int)(Math.random() * 1000000);
				String fileNm = "" + t + r + orgFileNm.substring(orgFileNm.lastIndexOf("."));
				
				PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName + bucketPath + filePath, fileNm, mFile.getInputStream(), null);
				amazonS3.putObject(putObjectRequest);
				
				String s3Url = amazonS3.getUrl(bucketName + bucketPath + filePath, fileNm).toString();
				s3Url = s3Url.replace(domain + "/" + bucketName, "");
				s3Url = s3Url.substring(0, s3Url.lastIndexOf("/") + 1);
				
				file.setFilePath(s3Url);
				file.setFileNm(fileNm);
				file.setOrgFileNm(orgFileNm);
				file.setFileSize(mFile.getSize());
			} else {
				//S3 인증 실패
			}
		}
		
		return file;
	}
	
	/**
	  * @Method 설명 : AWS S3 로 파일 다중 업로드
	  * @param mFile
	  * @param filePath
	  * @return
	  * @throws Exception
	  */
	public static List<FileVO> sendAWSS3Multiple(List<MultipartFile> mFiles, String filePath) throws Exception {
		List<FileVO> fileList = null;
		
		if( mFiles != null && mFiles.size() > 0 && StringUtils.isNotEmpty(filePath) ) {
			AWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
			ClientConfiguration clientConfig = new ClientConfiguration();
			clientConfig.setProtocol(Protocol.HTTP);
			
			AmazonS3 amazonS3 = new AmazonS3Client(awsCredentials, clientConfig);
			amazonS3.setRegion(Region.getRegion(Regions.AP_NORTHEAST_2));			//리전 설정
			
			String bucketLocation = amazonS3.getBucketLocation(new GetBucketLocationRequest(bucketName));
			
			if( bucketLocation != null ) {
				//S3 인증 성공
				fileList = new ArrayList<FileVO>();
				
				for( MultipartFile mFile : mFiles ) {
					FileVO file = new FileVO();
					
					//파일명 변경
					String orgFileNm = mFile.getOriginalFilename();
					long t = System.currentTimeMillis();
					int r = (int)(Math.random() * 1000000);
					String fileNm = "" + t + r + orgFileNm.substring(orgFileNm.lastIndexOf("."));
					
					PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName + bucketPath + filePath, fileNm, mFile.getInputStream(), null);
					amazonS3.putObject(putObjectRequest);
					
					String s3Url = amazonS3.getUrl(bucketName + bucketPath + filePath, fileNm).toString();
					
					file.setFilePath(s3Url.replace(domain + "/" + bucketName, "").substring(0, s3Url.lastIndexOf("/") + 1));
					file.setFileNm(fileNm);
					file.setOrgFileNm(orgFileNm);
					file.setFileSize(mFile.getSize());
					
					fileList.add(file);
				}
				
			} else {
				//S3 인증 실패
			}
		}
		
		return fileList;
	}
	
	/**
	  * @Method 설명 : AWS S3 파일 삭제
	  * @param filePath
	  * @param fileNm
	  * @return
	  * @throws Exception
	  */
	public static boolean deleteAWSS3(String filePath, String fileNm) throws Exception {
		boolean flag = false;
		
		if( StringUtils.isNotEmpty(filePath) && StringUtils.isNotEmpty(fileNm) ) {
			AWSCredentials awsCredentials = new BasicAWSCredentials(accessKey, secretKey);
			ClientConfiguration clientConfig = new ClientConfiguration();
			clientConfig.setProtocol(Protocol.HTTP);
			
			AmazonS3 amazonS3 = new AmazonS3Client(awsCredentials, clientConfig);
			amazonS3.setRegion(Region.getRegion(Regions.AP_NORTHEAST_2));			//리전 설정
			
			String bucketLocation = amazonS3.getBucketLocation(new GetBucketLocationRequest(bucketName));
			
			if( bucketLocation != null ) {
				// 인증 성공
				if( filePath.lastIndexOf("/") == filePath.length() - 1 ) {
					filePath = filePath.substring(0, filePath.lastIndexOf("/"));
				}
				
				if( filePath.indexOf(bucketPath) > -1 ) {
					filePath = "/" + bucketName + filePath;
					
					if( amazonS3.doesObjectExist(filePath, fileNm) ) {
						//파일 존재
						//파일 삭제 처리
						amazonS3.deleteObject(new DeleteObjectRequest(filePath, fileNm));
						flag = true;
					} else {
						//파일 없음
						flag = true;
					}
				} else {
					// bucketPath 없을 경우 S3에 업로드 된 파일이 아니라고 간주하여 삭제 완료 처리 한다.
					flag = true;
				}
			} else {
				// 인증 실패
			}
		}
		
		return flag;
	}
	
}
