/**
 * 
 */
package com.wjthinkbig.aimath.mbr.controller;

import java.time.LocalDateTime;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.annotation.AuthenticationPrincipal;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;

import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrLoginVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.security.JwtUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 : AI연산 회원서비스 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * 2020. 9. 17.    Kim Hee Seok              수정작업 
  * </pre>
  */
@Slf4j
@Api(description = "서비스 회원정보")
@RestController
public class MbrController extends BaseController {
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 회원서비스
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService; 
	
	/**
	 * JWT Utility
	 */
	@Resource(name = "jwtUtils")
	private JwtUtils jwtUtils;		
	
	/**
	  * @Method 설명 : 신규 회원을 등록(가입)한다.
	  * @param userVO 등록할 회원정보를 담은 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "신규 회원등록")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/members")
	public CommonResult insertMbr(@RequestBody MbrVO mbr,HttpSession session) throws Exception {
		mbr.setSessionId(session.getId());
		mbrService.insertMbr(mbr);
		return responseService.getResult(true,"S001030",mbr.getEmailAdrs());
	}
	
	@ApiOperation(value = "이메일 url 인증")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/members/email-auth/{code}")
	public CommonResult selectMbrEmailAuth(@ApiParam(value = "회원아이디 암호화 코드") @PathVariable(name="code",required=true) String code) throws Exception {
		int rows=mbrService.updateEmailCertYn(code);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.(인증실패)
		}
		return responseService.getResult(true); //이미 인증 하셨거나 회원가입이 되지 않았습니다.
	}
	
	/**
	  * @Method 설명 : 신규 학습 회원을 등록한다.
	  * @param mbrId 
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "신규 학습 회원등록")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/members/sm")
	public CommonResult insertMbrLrn(@RequestBody MbrLrnVO mbrLrn) throws Exception {
		mbrService.insertMbrLrn(mbrLrn);
		return responseService.getResult(true);
	}

	/**
	  * @Method 설명 : 특정 가입 회원을 조회한다.
	  * @param mbrId 회원식별코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입 회원조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/members/{member}")
	public SingleResult<MbrVO> selectMbrById(@ApiParam(value = "회원식별코드") @PathVariable(name="member",required=true) String mbrId,HttpServletRequest request) throws Exception {
		MbrVO mbr = mbrService.selectMbrById(mbrId);
		if(mbr == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		return responseService.getSingleResult(mbr);
	}
	
	/**
	  * @Method 설명 : 특정 학습 회원을 조회한다.
	  * @param mbrId 회원식별코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 학습 회원조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/members/sm/{member}")
	public SingleResult<MbrLrnVO> selectMbrLrnById(@ApiParam(value = "회원식별코드") @PathVariable(name="member",required=true) String mbrId) throws Exception {
		MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(mbrId);
		if(mbrLrn == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		
		return responseService.getSingleResult(mbrLrn);
	}
	
	/**
	  * @Method 설명 : selectPwByEmail 	비밀번호 찾기 
	  * @작성일 : 2020. 9. 29
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param mbr
	  * @return
	  * @throws Exception
	*/
	@ApiOperation(value="회원 비밀번호 찾기")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language",value = "Accept-language 헤더", required = false, dataType = "String", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/members/pw")
	public CommonResult selectPwByEmail(@RequestBody MbrVO mbr) throws Exception {
		mbrService.selectPwByEmail(mbr);
		return responseService.getResult(true,"S001029",mbr.getEmailAdrs());
	}
	
	/**
	  * @Method 설명 : 회원 로그인
	  * @param user 로그인정보를 담고 있는 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="회원 로그인")	
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/members/signin")	
	public SingleResult<HashMap<String, String>> login(@ApiParam(value="로그인 VO") @Valid @RequestBody MbrLoginVO mbrLogin) throws Exception {
		log.debug("로그인 인증요청정보 : {}", mbrLogin);
		String token = mbrService.signin(mbrLogin);
		log.info("발급된 토큰 : {}", token);
		HashMap<String, String> data = new HashMap<>();
		data.put("accessToken", token);
						
		//최근 비밀번호 변경일로부터의 경과일수가 6개월(180일)을 초과시 변경대상자 표시
		/*String isNeedToChange = "N";
		long elapsedDays = mbrService.selectPassedDaysFromChangeDt(mbrLogin);
		log.info("비밀번호 최근 변경일로부터 {}일 경과", elapsedDays);
		if(elapsedDays > 180) {
			isNeedToChange = "Y";
		}
		data.put("isNeedToChange", isNeedToChange);*/
		
		// 회원 접속 로그를 쌓는다.
		mbrService.insertLog(token);

		return responseService.getSingleResult(data);
	}
	
	/**
	  * @Method 설명 : 학습자 삭제
	  * @param account
	  * @param mbrId
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="학습자 삭제")
	@ApiImplicitParams({@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")})
	@DeleteMapping("/api/members/sm/{member}")
	public CommonResult deleteMbrLrn(@AuthenticationPrincipal MbrAccount account,HttpServletRequest request,
			@ApiParam(value = "회원식별코드") @PathVariable(name="member",required=true) String mbrId) throws Exception {
		MbrLrnVO mbrLrn = new MbrLrnVO();
		mbrLrn.setMbrId(mbrId);	
		int rows = mbrService.deleteMbrLrn(mbrLrn);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 회원정보 삭제
	  * @param mbrId
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="회원정보 삭제")
	@ApiImplicitParams({@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")})
	@DeleteMapping("/api/members/{member}")	
	public CommonResult deleteMbr(@AuthenticationPrincipal MbrAccount account, HttpServletRequest request,
			@ApiParam(value = "회원식별코드") @PathVariable(name="member",required=true) String mbrId) throws Exception {
		MbrVO mbr = new MbrVO();
		mbr.setMbrId(mbrId);
		mbr.setModDt(LocalDateTime.now());
		int rows = mbrService.deleteMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}

	/**
	  * @Method 설명 : 학습 회원정보 변경 (이름,성별만 변경)
	  * @param MbrLrnVO
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value = "학습 회원정보 변경")
	@ApiImplicitParams({@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")})
	@PutMapping("/api/members/sm")
	public CommonResult updateMbrLrn(@ApiParam(value="학습회원 VO")  @RequestBody MbrLrnVO mbrLrn) throws Exception {
		String MbrAccountId="MBR20200921080000212"; // Test용 UserAccount ######
		mbrLrn.setModUser(MbrAccountId);
		mbrLrn.setModDt(LocalDateTime.now());
		int rows=mbrService.updateMbrLrn(mbrLrn);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}

	/**
	  * @Method 설명 : 회원정보 변경 (비밀번호만 변경)
	  * @param mbrId
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value = "회원정보 변경")
	@ApiImplicitParams({@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")})
	@PutMapping("/api/members")
	public CommonResult updateMbr(@ApiParam(value="가입회원 VO") @RequestBody MbrVO mbr) throws Exception {
		mbr.setPwChngeDt(LocalDateTime.now());
		int rows=mbrService.updateMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 전체 회원 조회
	  * @param account
	  * @param userSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="전체 회원조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")})	
	@GetMapping("/api/members")	
	public SingleResult<HashMap<String,Object>> selectMbrsList(@AuthenticationPrincipal MbrAccount account,
			@ModelAttribute MbrSearchVO mbrSearch) throws Exception {
		//log.debug("로그인 인증객체의 사용자 정보 : {}", account.getUserInfo());
		mbrSearch.setRowCnt((int)mbrSearch.getRowCnt());
		mbrSearch.setCurrentPage((int)mbrSearch.getCurrentPage());
		List<MbrVO> mbrs = mbrService.selectMbrs(mbrSearch);
		int cnt = mbrService.selectMbrsCnt(mbrSearch);
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("mbrs", mbrs);
		data.put("totalCount", cnt);
		return responseService.getSingleResult(data);
	}
	
	/**
	  * @Method 설명 : 전체 회원 수 조회
	  * @param account
	  * @param userSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="전체 회원 수 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")})	
	@GetMapping("/api/members/cnt")	
	public SingleResult<Integer> selectMbrsCnt(@RequestBody MbrSearchVO mbrSearch) throws Exception {
		int cnt = mbrService.selectMbrsCnt(mbrSearch);
		return responseService.getSingleResult(cnt);
	}
}