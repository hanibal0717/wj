package com.wjthinkbig.aimath.mbr.vo;

import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.wjthinkbig.aimath.core.utils.WpinUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 8.
  * @프로그램 설명 : 회원관리 검색 정보 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 8.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="회원관리 검색 정보")
public class MbrSearchVO {
	
	@ApiModelProperty(value="채널구분코드")
	@FieldName("채널구분코드")
	private String chnCd; 					/* 채널구분코드 */
	
	@ApiModelProperty(value="검색타입")
	@FieldName("검색타입")
	private String srchTy;						/* 검색타입 */
	
	@ApiModelProperty(value="검색어")
	@FieldName("검색어")
	private String srchTxt;						/* 검색어 */
	
	@ApiModelProperty(value="가입일 검색 시작일")
	@FieldName("가입일 검색 시작일")
	private String startSbsceYmd;			/* 가입일 검색 시작일 */
	
	@ApiModelProperty(value="가입일 검색 종료일")
	@FieldName("가입일 검색 종료일")
	private String endSbsceYmd;					/* 가입일 검색 종료일 */
	
	@ApiModelProperty(value="페이징 처리 여부")
	@FieldName("페이징 처리 여부")
	private String pagingYn;					/* 페이징 처리 여부 */
	
	@ApiModelProperty(value="현재 페이지")
	@FieldName("현재 페이지")
	private int currentPage;					/* 현재 페이지 */
	
	@ApiModelProperty(value="페이지에 노출될 리스트 수")
	@FieldName("페이지에 노출될 리스트 수")
	private int rowCnt;							/* 페이지에 노출될 리스트 수 */
		
	@ApiModelProperty(value="가입회원 ID")
	@FieldName("가입회원 ID")
	private String sbsceMbrId;
	
	/**
	  * @Method 설명 : 검색어 email 타입으로 Wpin 암호화 작업
	  * @param email
	  */
	public String getSrchTxtEnE() throws Exception {
		//이메일 암호화 작업
		if( StringUtils.isNotEmpty( this.srchTxt ) ) {
			JSONObject obj = WpinUtils.wpinEncryption("E", this.srchTxt);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.srchTxt = obj.getString("rtnVal");
			}
		}
		
		return this.srchTxt;
	}
}
