package com.wjthinkbig.aimath.inq.vo;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 22.
  * @프로그램 설명 : 1:1문의 답변 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 22.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="1:1문의 답변 정보")
public class InqRplVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="가입회원ID")
	@FieldName("가입회원ID")
	private String sbsceMbrId;		/* 가입회원ID */
	
	@Min(value = 1, groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="회원질문일련번호")
	@FieldName("회원질문일련번호")
	private int mbrInqSno;			/* 회원질문일련번호 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="답변내용")
	@FieldName("답변내용")
	private String rplCn;			/* 답변내용 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="답변자")
	@FieldName("답변자")
	private String user;			/* 답변자 */
}
