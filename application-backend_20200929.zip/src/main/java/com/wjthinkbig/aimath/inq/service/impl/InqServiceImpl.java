package com.wjthinkbig.aimath.inq.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.inq.service.InqService;
import com.wjthinkbig.aimath.inq.service.dao.InqDao;
import com.wjthinkbig.aimath.inq.vo.InqRplVO;
import com.wjthinkbig.aimath.inq.vo.InqSearchVO;
import com.wjthinkbig.aimath.inq.vo.InqVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 22.
  * @프로그램 설명 : 1:1문의 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 22.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Service("inqService")
public class InqServiceImpl extends BaseServiceImpl implements InqService {
	
	/**
	 * 1:1문의 관리 Dao
	 */
	@Resource(name = "inqDao")
	private InqDao inqDao;

	@Override
	public List<InqVO> selectInqList(InqSearchVO inqSearch) throws Exception {
		if( inqSearch.getRowCnt() <= 0 ) inqSearch.setRowCnt(10);
		if( inqSearch.getCurrentPage() <= 0 ) inqSearch.setCurrentPage(1);
		
		return inqDao.selectInqList(inqSearch);
	}

	@Override
	public int selectInqCnt(InqSearchVO inqSearch) throws Exception {
		return inqDao.selectInqCnt(inqSearch);
	}

	@Override
	public InqVO selectInqById(InqSearchVO inqSearch) throws Exception {
		return inqDao.selectInqById(inqSearch);
	}
	
	@Override
	public void insertInq(InqVO inq) throws Exception {
		inq.setRplStsCd("RSC01");
		this.validateOrElseThrow(inq, Groups.Insert.class);
		
		inqDao.insertInq(inq);
	}

	@Override
	public void updateInq(InqVO inq) throws Exception {
		InqSearchVO inqSearch = new InqSearchVO();
		inqSearch.setSbsceMbrId(inq.getSbsceMbrId());
		inqSearch.setMbrInqSno(inq.getMbrInqSno());
		
		InqVO inqTmp = inqDao.selectInqById(inqSearch);
		
		if( inqTmp != null ) {
			if( "RSC01".equals(inqTmp.getRplStsCd()) ) {
				//답변대기 상태일 경우 수정 가능
				this.validateOrElseThrow(inq, Groups.Update.class);
				inqDao.updateInq(inq);
			} else {
				//답변완료 상태일 경우 수정 불가능
				throw this.processException("S001020");		//답변완료된 문의는 수정이 불가능합니다.
			}
		} else {
			throw this.processException("S001003", Integer.toString(inq.getMbrInqSno()));		//해당 데이터({0})는 존재하지 않습니다.
		}
	}

	@Override
	public int deleteInq(InqVO inq) throws Exception {
		InqSearchVO inqSearch = new InqSearchVO();
		inqSearch.setSbsceMbrId(inq.getSbsceMbrId());
		inqSearch.setMbrInqSno(inq.getMbrInqSno());
		
		InqVO inqTmp = inqDao.selectInqById(inqSearch);
		
		if( inqTmp != null ) {
			if( "RSC01".equals(inqTmp.getRplStsCd()) ) {
				//답변대기 상태일 경우 수정 가능
				this.validateOrElseThrow(inq, Groups.Delete.class);
				return inqDao.deleteInq(inq);
			} else {
				//답변완료 상태일 경우 삭제 불가능
				throw this.processException("S001021");		//답변완료된 문의는 삭제가 불가능합니다.
			}
		} else {
			throw this.processException("S001003", Integer.toString(inq.getMbrInqSno()));		//해당 데이터({0})는 존재하지 않습니다.
		}
	}

	@Override
	public void saveInqRpl(InqRplVO inqRpl) throws Exception {
		InqSearchVO inqSearch = new InqSearchVO();
		inqSearch.setSbsceMbrId(inqRpl.getSbsceMbrId());
		inqSearch.setMbrInqSno(inqRpl.getMbrInqSno());
		
		InqVO inqTmp = inqDao.selectInqById(inqSearch);
		
		if( inqTmp != null ) {
			if( "RSC01".equals(inqTmp.getRplStsCd()) ) {
				//답변대기 상태일 경우 답변 등록
				inqRpl.setRgtnUser(inqRpl.getUser());
				
				this.validateOrElseThrow(inqRpl, Groups.Insert.class);
				inqDao.insertInqRpl(inqRpl);
				
				//답변 상태값 변경
				InqVO inq = new InqVO();
				inq.setSbsceMbrId(inqRpl.getSbsceMbrId());
				inq.setMbrInqSno(inqRpl.getMbrInqSno());
				inq.setRplStsCd("RSC02");
				inq.setModUser(inqRpl.getUser());
				
				inqDao.updateInqRplStsCd(inq);
				
				//TODO 이메일 발송 로직 필요
			} else {
				//답변완료 상태일 경우 답변변경
				inqRpl.setModUser(inqRpl.getUser());
				
				this.validateOrElseThrow(inqRpl, Groups.Update.class);
				inqDao.updateInqRpl(inqRpl);
				
				//TODO 이메일 발송 로직 필요
			}
		} else {
			throw this.processException("S001003", Integer.toString(inqRpl.getMbrInqSno()));		//해당 데이터({0})는 존재하지 않습니다.
		}
	}

	
}
