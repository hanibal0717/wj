package com.wjthinkbig.aimath.stg.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.stg.service.StgService;
import com.wjthinkbig.aimath.stg.vo.StgSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 소주제 관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Slf4j
@Api(description="커리큘럼 소주제정보")
@RestController
public class StgController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 소주제(스테이지)관리 서비스
	 */
	@Resource(name = "stgService")
	private StgService stgService;
	
	/**
	  * @Method 설명 : 커리큘럼 소주제정보 전체 조회
	  * @param stgSearch 소주제 검색조건을 담은 검색 VO 
	  * @return 검색된 소주제 리스트
	  * @throws Exception
	 */
	@ApiOperation(value="전체 커리큘럼 소주제정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/stage")
	public ListResult<StgVO> selectStgList(@Valid @ModelAttribute StgSearchVO stgSearch) throws Exception {
		List<StgVO> stgList = stgService.selectStgList(stgSearch);
		return responseService.getListResult(stgList);
	}
	
	/**
	  * @Method 설명 : 특정 코드의 소주제정보 조회
	  * @param stg_cd 소주제 식별코드(PK 필드)
	  * @return 해당 식별코드를 갖는 소주제 정보 VO
	  * @throws Exception
	 */
	@ApiOperation(value="특정 코드의 소주제정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/stage/{stage}")	
	public SingleResult<StgVO> selectStgById(@ModelAttribute StgSearchVO stgSearch, @ApiParam(value = "소주제 코드") @PathVariable(name="stage",required=true) String stg_cd) throws Exception {
		stgSearch.setStgCd(stg_cd);
		StgVO stg = stgService.selectStgById(stgSearch);
		if(stg == null) {
			throw this.processException("S001003", stg_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(stg);
	}
	
	/**
	  * @Method 설명 : 신규 소주제정보를 등록한다. (파일업로드 필수, 서비스단에서 Validation 처리)
	  * @param stg 등록할 정보를 담은 소주제 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="신규 소주제정보 등록")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/stage")
	public CommonResult insertStg(@ApiParam("등록할 정보를 담은 커리큘럼 소주제 객체") @ModelAttribute StgVO stg) throws Exception {
		//소주제코드 중복체크
		if( stgService.selectStgCdDplctCeck(stg.getStgCd()) > 0 ) {
			throw this.processException("S001001"); // 이미 존재하는 데이터입니다.
		}
		
		stgService.insertStg(stg);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 소주제의 정보를 변경한다.
	  * @param stg 변경할 정보를 담은 소주제 VO
	  * @param stg_cd 변경할 소주제 식별코드 
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "커리큘럼 소주제정보 변경")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PutMapping("/api/stage/{stage}")
	public CommonResult updateStg(@ApiParam("변경할 정보를 담은 커리큘럼 소주제 객체") @ModelAttribute StgVO stg, @ApiParam("변경할 컬리큘럼 소주제의 고유키") @PathVariable(name="stage", required=true) String stg_cd) throws Exception {
		stg.setStgCd(stg_cd);
		stgService.updateStg(stg);
		return responseService.getResult(true);
	}
	
	/**
	 * 
	  * @Method 설명 : 등록된 커리큘럼 소주제 삭제
	  * @param stg_cd 삭제할 소주제정보의 식별키
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="등록된 커리큘럼 소주제 삭제")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@DeleteMapping("/api/stage/{stage}")	
	public CommonResult deleteStg(@ApiParam("삭제대상 소주제정보의 고유키") @PathVariable("stage") String stg_cd) throws Exception {
		int rows = stgService.deleteStg(stg_cd);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	/**
	 * 
	  * @Method 설명 : 등록된 커리큘럼 소주제 리스트 삭제
	  * @param stgList 삭제대상 소주제정보의 객체 리스트
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="등록된 커리큘럼 소주제 삭제")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@DeleteMapping("/api/stage")	
	public CommonResult deletestgList(@ApiParam("삭제대상 소주제정보의 객체 리스트") @RequestBody(required=true) List<StgVO> stgList) throws Exception {
		int rows = stgService.deleteStgList(stgList);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
}