package com.wjthinkbig.aimath.stg.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 4.
  * @프로그램 설명 : 커리큘럼 소주제 연령 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 4.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 소주제 연령 정보")
public class StgAgeInfoVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Delete.class})
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd; 			/* 소주제코드(스테이지코드) */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Delete.class})
	@ApiModelProperty(value="연령코드")
	@FieldName("연령코드")
	private String ageCd; 			/* 연령코드 */
	
}
