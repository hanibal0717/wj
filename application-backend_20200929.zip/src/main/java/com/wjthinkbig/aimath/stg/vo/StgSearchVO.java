package com.wjthinkbig.aimath.stg.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @FileName : StgSearchVO.java
 * @Project : application-backend
 * @Date : 2020. 8. 14. 
 * @작성자 : 19001861
 * @프로그램 설명 : 커리큘럼 소주제 Search VO
 * @변경이력 :
*/
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 소주제 검색 정보")
public class StgSearchVO {
	
	@ApiModelProperty(value="대주제 코드")
	@FieldName("대주제 코드")
	private String thmaCd; 						/* 대주제 코드 */
	
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd; 						/* 소주제코드(스테이지코드) */
	
	@ApiModelProperty(value="소주제 약어 코드")
	@FieldName("소주제 약어 코드")
	private String stgAbrvCd; 					/* 소주제 약어 코드 */
	
	@NotBlank
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;	 					/* 언어코드 */
	
	@ApiModelProperty(value="검색타입")
	@FieldName("검색타입")
	private String srchTy;						/* 검색타입 */
	
	@ApiModelProperty(value="검색어")
	@FieldName("검색어")
	private String srchTxt;						/* 검색어 */
	
	@ApiModelProperty(value="정렬타입")
	@FieldName("정렬타입")
	private String odrTy;						/* 정렬타입 */
	
	@ApiModelProperty(value="페이징 처리 여부")
	@FieldName("페이징 처리 여부")
	private String pagingYn;					/* 페이징 처리 여부 */
	
	@ApiModelProperty(value="현재 페이지")
	@FieldName("현재 페이지")
	private int currentPage;					/* 현재 페이지 */
	
	@ApiModelProperty(value="페이지에 노출될 리스트 수")
	@FieldName("페이지에 노출될 리스트 수")
	private int rowCnt;							/* 페이지에 노출될 리스트 수 */
	
}
