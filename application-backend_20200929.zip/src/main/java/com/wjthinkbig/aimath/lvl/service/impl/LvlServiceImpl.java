package com.wjthinkbig.aimath.lvl.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.lvl.service.LvlService;
import com.wjthinkbig.aimath.lvl.service.dao.LvlDao;
import com.wjthinkbig.aimath.lvl.vo.LvlMetaVO;
import com.wjthinkbig.aimath.lvl.vo.LvlSearchVO;
import com.wjthinkbig.aimath.lvl.vo.LvlStgSearchVO;
import com.wjthinkbig.aimath.lvl.vo.LvlStgVO;
import com.wjthinkbig.aimath.lvl.vo.LvlVO;

/**
  * @Date : 2020. 8. 28.
  * @프로그램 설명 : 코스학습 레벨관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 28.     19001861            최초작성
  * </pre>
  */
@Service("lvlService")
public class LvlServiceImpl extends BaseServiceImpl implements LvlService {
	
	/**
	 * 코스학습 레벨관리 Dao
	 */
	@Resource(name = "lvlDao")
	private LvlDao lvlDao;
	
	@Override
	public List<LvlVO> selectLvlList(LvlSearchVO lvlSearch) throws Exception {
		if( StringUtils.isNotEmpty(lvlSearch.getLangCd()) ) return lvlDao.selectLvlListByLangCd(lvlSearch); 
		else return lvlDao.selectLvlList(lvlSearch);
	}

	@Override
	public LvlVO selectLvlById(LvlSearchVO lvlSearch) throws Exception {
		LvlVO lvl = null;
		if( StringUtils.isNotEmpty(lvlSearch.getLangCd()) ){
			lvl = lvlDao.selectLvl(lvlSearch); 
		} else {
			lvl = lvlDao.selectLvlById(lvlSearch);
			if( lvl != null ) {
				//언어코드별 레벨명 조회
				lvl.setLvlMetaList(lvlDao.selectLvlMetaList(lvl.getLvlCd()));
			}
		}
		
		return lvl;
	}

	@Override
	public void insertLvl(LvlVO lvl) throws Exception {
		//신규 레벨코드 채번
		lvl.setLvlCd(lvlDao.selectNewLvlCd());
		
		this.validateOrElseThrow(lvl, Groups.Insert.class);
		
		//레벨 등록
		lvlDao.insertLvl(lvl);
		
		//레벨 메타 등록
		List<LvlMetaVO> lvlMetaList = lvl.getLvlMetaList();
		if( lvlMetaList != null ) {
			for( LvlMetaVO lvlMeta : lvlMetaList ) {
				lvlMeta.setLvlCd(lvl.getLvlCd());
				lvlMeta.setRgtnUser(lvl.getRgtnUser());
				
				this.validateOrElseThrow(lvlMeta, Groups.Insert.class);
				
				lvlDao.insertLvlMeta(lvlMeta);
			}
		}
	}

	@Override
	public void updateLvl(LvlVO lvl) throws Exception {
		//필수값 체크
		this.validateOrElseThrow(lvl, Groups.Update.class);
		
		LvlSearchVO lvlSearch = new LvlSearchVO();
		lvlSearch.setLvlCd(lvl.getLvlCd());
		lvlSearch.setChnCd(lvl.getChnCd());
		
		//기존 정렬순서 조회를 위해 단일 정보를 조회한다
		LvlVO prevLvl = lvlDao.selectLvlById(lvlSearch);
		
		//레벨 정보 수정
		lvlDao.updateLvl(lvl);
		
		//정렬 순서가 변경 되었을 경우
		if( lvl.getDspOdr() != prevLvl.getDspOdr() ) {
			lvl.setPrevDspOdr(prevLvl.getDspOdr());
			lvlDao.updateLvlOdr(lvl);
		}
		
		//레벨 메타 삭제 후 등록
		lvlDao.deleteLvlMeta(lvl.getLvlCd());
		
		//레벨 메타 등록
		List<LvlMetaVO> lvlMetaList = lvl.getLvlMetaList();
		if( lvlMetaList != null ) {
			for( LvlMetaVO lvlMeta : lvlMetaList ) {
				lvlMeta.setLvlCd(lvl.getLvlCd());
				lvlMeta.setRgtnUser(lvl.getModUser());
				
				this.validateOrElseThrow(lvlMeta, Groups.Insert.class);
				
				lvlDao.insertLvlMeta(lvlMeta);
			}
		}
	}

	@Override
	public int deleteLvl(LvlVO lvl) throws Exception {
		int rows = 0;
		
		//레벨 하위에 소주제가 등록 되어있는지 판단 후 없으면 삭제
		LvlStgSearchVO lvlStgSearch = new LvlStgSearchVO();
		lvlStgSearch.setLvlCd(lvl.getLvlCd());
		
		if( lvlDao.selectLvlStgCeck(lvlStgSearch) <= 0 ) {
			//필수값 체크
			this.validateOrElseThrow(lvl, Groups.Delete.class);
			
			LvlSearchVO lvlSearch = new LvlSearchVO();
			lvlSearch.setLvlCd(lvl.getLvlCd());
			lvlSearch.setChnCd(lvl.getChnCd());
			
			//기존 정렬순서 조회를 위해 단일 정보를 조회한다
			LvlVO prevLvl = lvlDao.selectLvlById(lvlSearch);
			
			rows = lvlDao.deleteLvl(lvl.getLvlCd());
			
			if( rows > 0 ) {
				//메타정보 삭제
				lvlDao.deleteLvlMeta(lvl.getLvlCd());
				
				//정렬 순서 변경
				lvl.setPrevDspOdr(prevLvl.getDspOdr());
				lvlDao.updateLvlOdr(lvl);
			}
		} else {
			throw this.processException("ExS001014");		//하위 소주제가 존재할 경우 삭제가 불가능합니다.
		}
		
		return rows;
	}

	@Override
	public List<LvlStgVO> selectLvlStgList(LvlStgSearchVO lvlStgSearch) throws Exception {
		return lvlDao.selectLvlStgList(lvlStgSearch);
	}

	@Override
	public LvlStgVO selectLvlStgById(LvlStgSearchVO lvlStgSearch) throws Exception {
		return lvlDao.selectLvlStgById(lvlStgSearch);
	}

	@Override
	public void insertLvlStg(LvlStgVO lvlStg) throws Exception {
		this.validateOrElseThrow(lvlStg, Groups.Insert.class);
		lvlDao.insertLvlStg(lvlStg);
	}

	@Override
	public void updateLvlStg(LvlStgVO lvlStg) throws Exception {
		this.validateOrElseThrow(lvlStg, Groups.Update.class);
		lvlDao.updateLvlStg(lvlStg);
	}

	@Override
	public int deleteLvlStg(LvlStgVO lvlStg) throws Exception {
		this.validateOrElseThrow(lvlStg, Groups.Delete.class);
		return lvlDao.deleteLvlStg(lvlStg);
	}

	@Override
	public List<LvlVO> selectLvlAllList(LvlSearchVO lvlSearch) throws Exception {
		return lvlDao.selectLvlAllList(lvlSearch);
	}

}
