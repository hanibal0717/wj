package com.wjthinkbig.aimath.lvl.service;

import java.util.List;

import com.wjthinkbig.aimath.lvl.vo.LvlSearchVO;
import com.wjthinkbig.aimath.lvl.vo.LvlStgSearchVO;
import com.wjthinkbig.aimath.lvl.vo.LvlStgVO;
import com.wjthinkbig.aimath.lvl.vo.LvlVO;

/**
  * @Date : 2020. 8. 28.
  * @프로그램 설명 : 코스학습 레벨 Service
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 28.     19001861            최초작성
  * </pre>
  */
public interface LvlService {
	
	/**
	  * @Method 설명 : 코스학습 레벨 전체 리스트를 가져온다.
	  * @param lvlSearch 검색 조건 VO
	  * @return 검색된 레벨리스트
	  * @throws Exception
	 */
	public List<LvlVO> selectLvlList(LvlSearchVO lvlSearch) throws Exception;
	
	/**
	  * @Method 설명 : 코스학습 레벨 단일 정보를 가져온다.
	  * @param lvlSearch 검색 조건 VO
	  * @return 검색된 레벨 단일 정보
	  * @throws Exception
	 */
	public LvlVO selectLvlById(LvlSearchVO lvlSearch) throws Exception;
	
	/**
	  * @Method 설명 : 신규 레벨정보를 등록한다.
	  * @param lvl 등록할 레벨정보를 담은 VO
	  * @throws Exception
	 */
	public void insertLvl(LvlVO lvl) throws Exception;
	
	/**
	  * @Method 설명 : 특정 레벨정보 수정
	  * @param lvl 수정할 레벨정보를 담은 VO
	  * @throws Exception
	  */
	public void updateLvl(LvlVO lvl) throws Exception;
	
	/**
	  * @Method 설명 : 특정 레벨정보 삭제
	  * @param lvl 삭제할 레벨정보를 담은 VO
	  * @return
	  * @throws Exception
	  */
	public int deleteLvl(LvlVO lvl) throws Exception;
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 리스트 조회
	  * @param lvlStgSearch
	  * @return
	  * @throws Exception
	  */
	public List<LvlStgVO> selectLvlStgList(LvlStgSearchVO lvlStgSearch) throws Exception;
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 단일 조회
	  * @param lvlStgSearch
	  * @return
	  * @throws Exception
	  */
	public LvlStgVO selectLvlStgById(LvlStgSearchVO lvlStgSearch) throws Exception;
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 신규 등록
	  * @param lvlStg
	  * @throws Exception
	  */
	public void insertLvlStg(LvlStgVO lvlStg) throws Exception;
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 수정
	  * @param lvlStg
	  * @throws Exception
	  */
	public void updateLvlStg(LvlStgVO lvlStg) throws Exception;
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 삭제
	  * @param lvlStg
	  * @return
	  * @throws Exception
	  */
	public int deleteLvlStg(LvlStgVO lvlStg) throws Exception;
	
	/**
	  * @Method 설명 : 코스학습 레벨 전체 조회 및 하위 스테이지까지 포함 조회
	  * @param lvlSearch
	  * @return
	  * @throws Exception
	  */
	public List<LvlVO> selectLvlAllList(LvlSearchVO lvlSearch) throws Exception;
}
