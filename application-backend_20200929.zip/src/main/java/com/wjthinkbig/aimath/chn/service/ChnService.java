package com.wjthinkbig.aimath.chn.service;

import java.util.List;

import com.wjthinkbig.aimath.chn.vo.ChnSearchVO;
import com.wjthinkbig.aimath.chn.vo.ChnVO;

/**
  * @Date : 2020. 9. 21.
  * @프로그램 설명 : 채널 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 21.     19001861            최초작성
  * </pre>
  */
public interface ChnService {
	
	/**
	  * @Method 설명 : 채널 전체 리스트 조회
	  * @param chnSearch
	  * @return
	  * @throws Exception
	  */
	public List<ChnVO> selectChnList(ChnSearchVO chnSearch) throws Exception;
	
	/**
	  * @Method 설명 : 채널 정보 단일 조회
	  * @param chn_cd
	  * @return
	  * @throws Exception
	  */
	public ChnVO selectChnById(String chn_cd) throws Exception;
	
	/**
	  * @Method 설명 : 채널코드 중복 체크
	  * @param chn_cd
	  * @return
	  * @throws Exception
	  */
	public int selectChnCdDplctCeck(String chn_cd) throws Exception;
	
	/**
	  * @Method 설명 : 신규 채널 정보 등록
	  * @param chn
	  * @throws Exception
	  */
	public void insertChn(ChnVO chn) throws Exception;
	
	/**
	  * @Method 설명 : 채널 정보 수정
	  * @param chn
	  * @throws Exception
	  */
	public void updateChn(ChnVO chn) throws Exception;
	
	/**
	  * @Method 설명 : 채널 정보 삭제
	  * @param chn_cd
	  * @return
	  * @throws Exception
	  */
	public int deleteChn(String chn_cd) throws Exception;
}
