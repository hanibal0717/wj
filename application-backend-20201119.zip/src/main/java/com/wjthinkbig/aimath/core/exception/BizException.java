package com.wjthinkbig.aimath.core.exception;

import java.util.Locale;

import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;

import lombok.Getter;
import lombok.Setter;

/**
 * @Date : 2020. 8. 22. 
 * @작성자 : Lee Seung Hyuk
 * @프로그램 설명 : 서비스 단 처리 중 예외처리 시킨 Exception을 정의한다. ServiceImpl 단에서 예외처리시켜야 하는 경우 이 BizException을 사용한다.
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 8. 22.     seung              최초작성
 * </pre>
*/
@Getter
@Setter
public class BizException extends RuntimeException {
	
	private static final long serialVersionUID = 4845832553096378489L;

	/**
	 * 메시지
	 */
	protected String message = null;

	/**
	 * 메시지키
	 */
	protected String messageKey = null;

	/**
	 * 메시지 파라미터
	 */
	protected Object[] messageParameters = null;

	/**
	 * Exception
	 */
	protected Exception wrappedException = null;

	public BizException(MessageSource messageSource, String messageKey, String... messageParameters) {
		this(messageSource, messageKey, messageParameters, LocaleContextHolder.getLocale(), null, null);
	}

	public BizException(MessageSource messageSource, String messageKey, Object[] messageParameters, Locale locale, String defaultMessage, Exception wrappedException) {
		super(wrappedException);

		this.message = messageSource.getMessage(messageKey, messageParameters, defaultMessage, locale);
		this.messageKey = messageKey;
		this.messageParameters = messageParameters;
		this.wrappedException = wrappedException;
	}
}