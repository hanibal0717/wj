package com.wjthinkbig.aimath.core.utils;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Component;

@Component
public class WpinUtils {
	
	/**
	 * log 
	 */
	private static final Logger log = LoggerFactory.getLogger(WpinUtils.class);
	
	/**
	 * Wpin Api encryption Url
	 */
	private static String wpinEncrytionApiUrl;
	@Value("${wpin.api-url.encryption}")
	public void setWpinApiUrl(String url) {
		wpinEncrytionApiUrl = url;
	}
	
	/**
	 * Wpin Api decryption Url
	 */
	private static String wpinDecrytionApiUrl;
	@Value("${wpin.api-url.decryption}")
	public void setWpinApiUrl2(String url) {
		wpinDecrytionApiUrl = url;
	}
	
	/**
	  * @Method 설명 : Wpin 암호화
	  * @param type - A: 계좌번호, C: 카드번호, E: 이메일, P: 전화번호, R: 주민번호, D: 주소
	  * @param val
	  * @return
	  * @throws Exception
	  */
	public static JSONObject wpinEncryption(String type, String val) throws Exception {
		//log 남기기
		log.info("Wpin Encryption Request Data ======= type : " + type + " / val : " + val);
		
		URL url = new URL(wpinEncrytionApiUrl);
		HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
		con.setConnectTimeout(5000);
		con.setReadTimeout(5000);
		
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-Type", "application/json");
		con.setRequestProperty("Accept", "application/json");
		con.setDoInput(true);
		con.setDoOutput(true);
		con.setUseCaches(false);
		con.setDefaultUseCaches(false);
		
		OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
		wr.write("{\"type\":\"" + type + "\", \"val\": \"" + val + "\"}");
		wr.flush();
		
		log.info("Wpin Encryption Request Json ======= " + "{\"type\":\"" + type + "\", \"val\": \"" + val + "\"}");
		
		StringBuffer sb = new StringBuffer();
		if( con.getResponseCode() == HttpsURLConnection.HTTP_OK ) {
			//Stream 처리
			BufferedReader br = new BufferedReader( new InputStreamReader(con.getInputStream(), "UTF-8") );
			String line = null;
			
			while( (line = br.readLine()) != null ) {
				sb.append(line);
			}
			br.close();
			
			JSONObject obj = new JSONObject(sb.toString());
			
			log.info("Wpin Encryption Response Json ======= " + obj.toString());
			
			if( obj != null ) {
				//{"rtnMsg":"정상적으로 처리되었습니다.","rtnVal":"$EN59kqn8@naver.com","rtnCode":"Y"}
				return obj.getJSONObject("resp_model");
			}
		}
		
		return null;
	}
	
	/**
	  * @Method 설명 : Wpin 복호화
	  * @param type - A: 계좌번호, C: 카드번호, E: 이메일, P: 전화번호, R: 주민번호, D: 주소
	  * @param val
	  * @return
	  * @throws Exception
	  */
	public static JSONObject wpinDecryption(String type, String val) throws Exception {
		//log 남기기
		log.info("Wpin Decryption Request Data ======= type : " + type + " / val : " + val);
		
		URL url = new URL(wpinDecrytionApiUrl);
		HttpsURLConnection con = (HttpsURLConnection) url.openConnection();
		con.setConnectTimeout(5000);
		con.setReadTimeout(5000);
		
		con.setRequestMethod("POST");
		con.setRequestProperty("Content-Type", "application/json");
		con.setRequestProperty("Accept", "application/json");
		con.setDoInput(true);
		con.setDoOutput(true);
		con.setUseCaches(false);
		con.setDefaultUseCaches(false);
		
		OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
		wr.write("{\"type\":\"" + type + "\", \"val\": \"" + val + "\"}");
		wr.flush();
		
		log.info("Wpin Decryption Request Json ======= " + "{\"type\":\"" + type + "\", \"val\": \"" + val + "\"}");
		
		StringBuffer sb = new StringBuffer();
		if( con.getResponseCode() == HttpsURLConnection.HTTP_OK ) {
			//Stream 처리
			BufferedReader br = new BufferedReader( new InputStreamReader(con.getInputStream(), "UTF-8") );
			String line = null;
			
			while( (line = br.readLine()) != null ) {
				sb.append(line);
			}
			br.close();
			
			JSONObject obj = new JSONObject(sb.toString());
			
			log.info("Wpin Decryption Response Json ======= " + obj.toString());
			
			if( obj != null ) {
				//{"rtnMsg":"정상적으로 처리되었습니다.","rtnVal":"hjs2904@naver.com","rtnCode":"Y"}
				return obj.getJSONObject("resp_model");
			}
		}
		
		return null;
	}
	
}
