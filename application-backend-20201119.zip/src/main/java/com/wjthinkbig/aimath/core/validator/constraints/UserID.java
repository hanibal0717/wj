/**
 * 
 */
package com.wjthinkbig.aimath.core.validator.constraints;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.wjthinkbig.aimath.core.validator.constraintsValidators.UserIDValidator;

/**
 * @Date : 2020. 9. 8. 
 * @프로그램 설명 : UserID 아이디 검증을 위한 Custom Validator
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 9. 8.     Lee Seung Hyuk            최초작성
 * </pre>
 */
@Documented
@Retention(RUNTIME)
@Target({ FIELD, METHOD })
@Constraint(validatedBy = UserIDValidator.class)
public @interface UserID {

	String message() default "{S001016}";
	
    Class<?>[] groups() default {};
    
    Class<? extends Payload>[] payload() default{};
}