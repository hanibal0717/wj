/**
 * 
 */
package com.wjthinkbig.aimath.core.validator.constraints;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.wjthinkbig.aimath.core.validator.constraintsValidators.PhoneNoValidator;

/**
 * @Date : 2020. 9. 9. 
 * @프로그램 설명 : 전화번호 Custom Validator
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 9. 9.     Lee Seung Hyuk            최초작성
 * </pre>
 */
@Documented
@Retention(RUNTIME)
@Target({ FIELD, METHOD })
@Constraint(validatedBy = PhoneNoValidator.class)
public @interface PhoneNo {
	
	String message() default "{S001021}";
	
    Class<?>[] groups() default {};
    
    Class<? extends Payload>[] payload() default{};

}
