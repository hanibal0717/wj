/**
 * 
 */
package com.wjthinkbig.aimath.core.web.method.support;

import java.util.List;

import org.springframework.core.MethodParameter;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.mvc.method.annotation.RequestResponseBodyMethodProcessor;

import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;

/**
  * @Date : 2020. 9. 28. 
  * @프로그램 설명 : 컨트롤러에서 @RequestBody 어노테이션을 적용한 BaseVO 또는 SaveVO의 최초등록자ID, 최종수정자ID를 로그인 정보를 기반으로 자동 할당 한다.
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 28.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class CustomRequestResponseBodyMethodProcessor extends RequestResponseBodyMethodProcessor {

	/**
	 * @param converters
	 * @param requestResponseBodyAdvice
	 */
	public CustomRequestResponseBodyMethodProcessor(List<HttpMessageConverter<?>> converters, List<Object> requestResponseBodyAdvice) {
		super(converters, null, requestResponseBodyAdvice);
	}

	@Override
	public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer, NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {		
		Object obj = super.resolveArgument(parameter, mavContainer, webRequest, binderFactory);
				
		// @RequestBody를 통해 전송되는 객체가 BaseVO/SaveVO인 경우 로그인했으면 로그인한 사용자의 ID를 등록자/수정자로 세팅, 로그인하지 않았으면 "SYSTEM"으로 세팅
		if(obj instanceof BaseVO) {
			String defaultUserId = "SYSTEM";
			if(StringUtils.isNotBlank(((BaseVO) obj).getRgtnUser())) {
				defaultUserId = ((BaseVO) obj).getRgtnUser();
			} else if(StringUtils.isNotBlank(((BaseVO) obj).getModUser())) {
				defaultUserId = ((BaseVO) obj).getModUser();
			}
			
			((BaseVO)obj).setLoginUser(LoginUtils.isLogin() ? LoginUtils.getUserId() : defaultUserId);
//			((BaseVO)obj).setLoginUser(LoginUtils.isLogin() ? LoginUtils.getUserId() : defaultUserId);			
		} else if(obj instanceof SaveVO) {
			((SaveVO)obj).setLoginUser(LoginUtils.isLogin() ? LoginUtils.getUserId() : "SYSTEM");
		}
		
		return obj;
	}	
}