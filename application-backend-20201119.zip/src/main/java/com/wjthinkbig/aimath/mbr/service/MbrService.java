package com.wjthinkbig.aimath.mbr.service;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.security.core.userdetails.User;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLogVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrRcntLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrTermsVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 : 회원서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * 2020. 9. 17.    Kim Hee Seok              수정작업 
  * </pre>
  */
public interface MbrService {

	/** (OK)
	 * @Method 설명 : 신규 가입처리 (가입회원, 학습회원 및 약관등록)
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbr 등록할 회원 정보를 담은 VO 객체 (가입회원, 학습회원, 약관동의내역)
	 * @throws Exception
	 */
	public void insertMbr(MbrVO mbr) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 가입회원 로그인이력 저장 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param logVO 가입회원로그인이력 VO 
	 * @param request HttpServletRequest
	 * @throws Exception
	 */
	public void insertLog(MbrLogVO logVO, HttpServletRequest request) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 특정 가입자 회원에 새로운 학습 회원을 추가한다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrLrn 등록할 학습회원 정보를 담은 VO 객체
	 * @throws Exception
	 */
	public void insertMbrLrn(MbrLrnVO mbrLrn) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 검색조건(이메일 또는 자녀명)을 만족하는 정상 가입회원 조회
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrSearch 검색조건 객체 
	 * @return 가입회원 리스트
	 * @throws Exception
	 */
	public List<MbrVO> selectMbrs(MbrSearchVO mbrSearch) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 검색조건(이메일 또는 자녀명)을 만족하는 정상 가입회원 건 수
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrSearch 검색조건 객체 
	 * @return 검색 건 수
	 * @throws Exception
	 */
	public int selectMbrsCnt(MbrSearchVO mbrSearch) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 가입회원아이디로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrId 가입회원 아이디 
	 * @return 가입회원정보
	 * @throws Exception
	 */
	public MbrVO selectMbrById(String mbrId) throws Exception;
	 
	/** (OK)
	 * @Method 설명 : 특정 가입회원의 정상 학습회원 리스트를 가져온다. 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrId 가입회원ID
	 * @return 학습회원 리스트
	 * @throws Exception
	 */
	public List<MbrLrnVO> selectMbrLrnListById(String mbrId) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 특정 가입회원의 최근로그인이력정보 (최종로그인 날짜, 디바이스구분코드)를 가져온다. 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrId 가입회원ID 
	 * @return 로그인이력 Map
	 * @throws Exception
	 */
	public HashMap<String, String> selectMbrHstById(String mbrId) throws Exception;
	
	/** (OK)
	 * @Method 설명 : (삭제되지않은 정상) 특정 학습회원의 정보 조회
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrId 학습회원ID 
	 * @return 학습회원정보
	 * @throws Exception
	 */
	public MbrLrnVO selectMbrLrnById(String mbrId) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 특정 학습회원의 정보를 변경한다. (이름, 성별만 수정)
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrLrn 학습회원 VO
	 * @return 변경 건 수
	 * @throws Exception
	 */
	public int updateMbrLrn(MbrLrnVO mbrLrn) throws Exception;	
	
	/** (OK)
	 * @Method 설명 : 특정 학습회원을 삭제처리한다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrLrn 삭제할 정보를 담은 학습회원 VO 
	 * @return 처리 건 수
	 * @throws Exception
	 */
	public int deleteMbrLrn(MbrLrnVO mbrLrn) throws Exception;	
	
	/** (OK)
	 * @Method 설명 : 특정 가입회원의 학습회원정보를 일괄 변경처리한다. (이름, 성별, 이모티콘만 변경가능)
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param sbsceMbrId 가입회원ID
	 * @param mbrLrnSaveVO 일괄처리할 학습회원 정보를 담은 리스트
	 * @return 처리 건 수
	 * @throws Exception
	 */
	public int learnersUpdate(String sbsceMbrId, @Valid SaveVO<MbrLrnVO> mbrLrnSaveVO) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 특정 아이디의 가입회원정보 (비밀번호, 비밀번호 변경일자)를 변경한다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbr 회원 정보를 담은 VO 객체
	 * @return 변경된 건 수 
	 * @throws Exception
	 */
	public int updateMbr(MbrVO mbr) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 이 가입회원 및 가입회원에 있는 학습회원 모두를 삭제처리한다. 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbr 가입회원 정보를 담은 VO 객체
	 * @return 처리 건 수
	 * @throws Exception
	 */
	public int deleteMbr(MbrVO mbr) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 로그아웃 처리 - 레디스에서 토큰 삭제
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param userContext 로그인 시큐리티 정보 객체 
	 * @throws Exception
	 */
	public void signout(User userContext) throws Exception;
	
	/**
	 * @Method 설명 : 특정 학습회원의 진입 로그를 쌓는다. 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param learner 학습회원ID
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @throws Exception
	 */
	public void insertMbrLrnLog(String learner,Boolean sameDevice, HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 특정 학습회원의 최근 학습 내역을 가져온다. (진단이력, 주제진입이력, 코스진입이력) 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param learner 학습회원ID
	 * @return 최근학습내역 VO
	 * @throws Exception
	 */
	public MbrRcntLrnVO selectRcntLrn(String learner) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 회원의 약관내역리스트를 가져온다.  
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param map (회원아이디,언어코드,채널코드)
	 * @return 회원약관동의내역 리스트
	 * @throws Exception
	 */
	public List<MbrTermsVO> selectMbrTermsListById(HashMap<String, String> map) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 특정 회원의 특정 약관에 대한 동의여부를 변경한다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param termsVO 약관내역 VO 
	 * @return
	 * @throws Exception
	 */
	public int updateTerms(MbrTermsVO termsVO) throws Exception;

	/** (OK)
	 * @Method 설명 : 비밀번호 변경일로부터 몇 일 경과했는지를 반환한다. 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrId 가입회원 아이디 
	 * @return 경과일수
	 * @throws Exception
	 */
	public long selectPassedDaysFromChangeDt(String mbrId) throws Exception;

	/** (OK)
	 * @Method 설명 : 특정 가입회원의 (삭제되지않은 정상) 학습회원 리스트 조회
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrId 가입회원 ID
	 * @return 이 회원의 (삭제되지않은 정상) 학습회원 리스트
	 * @throws Exception
	 */
	public List<MbrLrnVO> selectLearnersBySbsceMbrId(String mbrId) throws Exception;
	
	/** (OK)
	 * @Method 설명 : 해당 가입회원에게 임시비밀번호를 발급하여 변경한 후 해당 정보를 이메일로 전송한다. 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbr 회원 VO
	 * @throws Exception
	 */
	public void procForgottenEmail(MbrVO mbr) throws Exception;
		
	/** (OK)
	 * @Method 설명 : updateEmailCertYn 이메일 인증
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param code 사용자가 이메일로 받은 인증코드 
	 * @return
	 * @throws Exception
	 */
	public int updateEmailCertYn(String code) throws Exception;
}