package com.wjthinkbig.aimath.mbr.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/** (OK)
  * @Date : 2020. 10. 6 
  * @프로그램 설명 : 회원약관내역 VO (가입회원 약관동의여부) 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 6      Kim Hee Seok       최초작성
  * 2020. 11.16      10013871           코드검수
  * </pre>
  */
@Getter
@Setter
@ApiModel(value = "회원약관내역 VO", description = "가입회원 약관동의 여부(TB_CMN_MBR_TERMS)")
@ToString(callSuper=true)
public class MbrTermsVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty("가입회원ID")
	@FieldName("가입회원ID")
	private String sbsceMbrId;  /* 가입회원ID */

	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty("약관ID")
	@FieldName("약관ID")
	private String termsId;      /* 약관ID */

	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "Y|N")
	@ApiModelProperty("동의여부")
	@FieldName("동의여부")
	private String agrmtYn;      /* 동의여부 */
	

	@ApiModelProperty("약관명")
	@FieldName("약관명")
	private String termsNm;      /* 약관명 */
	
	@ApiModelProperty("필수여부")
	@FieldName("필수여부")
	private String esntlYn;      /* 필수여부  */
}