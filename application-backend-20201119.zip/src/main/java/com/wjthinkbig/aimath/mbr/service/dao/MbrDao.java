/**
 * 
 */
package com.wjthinkbig.aimath.mbr.service.dao;

import java.util.HashMap;
import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.mbr.vo.MbrLogVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrRcntLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrTermsVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
/**
  * @Date : 2020. 9. 25 
  * @프로그램 설명 : MbrDao.java
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 25          Kim Hee Seok       최초작성
  * </pre>
  */
@Mapper("mbrDao")
public interface MbrDao {

	/** (OK)
	  * @Method 설명 : 가입회원 신규등록
	  * @param mbr 등록할 회원정보를 담고 있는 가입회원 VO 객체
	 */
	void insertMbr(MbrVO mbr);	
	
	/** (OK)
	  * @Method 설명 : 특정 가입회원의 이메일 인증을 완료처리
	  * @param mbrId 가입회원ID
	  * @return 처리 건 수
	 */
	int updateEmailCertYn(String mbrId);
	
	/** (OK)
	  * @Method 설명 : 학습회원 신규등록
	  * @param mbrLrn 등록할 학습회원 VO
	 */
	void insertMbrLrn(MbrLrnVO mbrLrn);
	
	/** (OK)
	  * @Method 설명 : 특정회원의 약관내역을 신규등록한다 
	  * @param vo 등록할 회원약관내역 VO
	 */
	void insertMbrTerms(MbrTermsVO vo);
	
	/** (OK)
	  * @Method 설명 : 해당 이메일 주소를 가지고 있는 회원의 존재여부를 반환한다.
	  * @param email 검색할 이메일 주소
	  * @return true/false  
	 */
	boolean isExistsByEmail(String email);	
	
	/** (OK) 
	  * @Method 설명 : 이메일로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다.
	  * @param email 이메일
	  * @return 가입회원정보 
	 */
	MbrVO selectMbrByEmail(String email);

	/** (OK) 
	 * @Method 설명 : 특정 가입회원의 가장 최근 로그인 이력정보를 가져온다.
	 * @author Kim Hee Seok [2020. 11. 11]
	 * @param mbrId 가입회원ID
	 * @return 최근로그인이력정보 (최종로그인 날짜, 디바이스구분코드)
	 */
	HashMap<String, String> selectMbrHstById(String mbrId);
	
	/** (OK)
	  * @Method 설명 : 가입회원아이디로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다.
	  * @param mbrId 가입회원ID
	  * @return 가입회원정보
	 */
	MbrVO selectMbrById(String mbrId);
	
	/** (OK)
	  * @Method 설명 : 특정 가입회원의 (삭제되지않은 정상) 학습회원 리스트 조회
	  * @param sbsceMbrId 가입회원ID
	  * @return 해당 가입회원의 (정상) 학습자 리스트
	 */
	List<MbrLrnVO> selectMbrLrnListById(String sbsceMbrId);
		
	/** (OK)
	  * @Method 설명 : (삭제되지않은 정상) 특정 학습회원의 정보 조회
	  * @param lrnMbrId 학습회원 ID
	  * @return 학습회원 정보
	 */
	MbrLrnVO selectMbrLrnById(String lrnMbrId);

	/** (OK)
	  * @Method 설명 : 검색조건을 만족하는 (정상) 가입회원 리스트 조회 : 특정 이메일을 가진 회원 또는 특정 이름의 자녀를 가진 회원
	  * @param mbrSearch 검색조건
	  * @return 가입회원 리스트
	 */
	List<MbrVO> selectMbrs(MbrSearchVO mbrSearch);
	
	/** (OK)
	  * @Method 설명 : 검색조건을 만족하는 (정상) 가입회원의 건 수 조회 : 특정 이메일을 가진 회원 또는 특정 이름의 자녀를 가진 회원
	  * @param mbrSearch 검색조건
	  * @return 가입회원 검색 건 수 
	 */
	int selectMbrsCnt(MbrSearchVO mbrSearch);

	/** (OK)
	  * @Method 설명 : 특정 학습회원을 삭제처리한다.
	  * @param mbrLrn 삭제할 정보를 담은 학습회원 VO
	  * @return 삭제 건 수
	 */
	int deleteMbrLrn(MbrLrnVO mbrLrn);
	
	/** (OK)
	  * @Method 설명 : 특정 아이디를 갖는 가입회원을 탈퇴처리한다.
	  * @param mbr 탈퇴처리할 회원정보를 담은 VO
	  * @return 탈퇴처리 건 수
	 */
	int deleteMbr(MbrVO mbr);
	
	/** (OK)
	  * @Method 설명 : 특정 가입회원의 학습회원을 일괄 모두 삭제처리한다.
	  * @param mbr 삭제할 학습회원의 가입회원정보를 담고 있는 VO
	 */
	int deleteMbrLrnBySbsceId(MbrVO mbr);
	
	/** (OK)
	  * @Method 설명 : 특정 아이디의 가입회원정보 (비밀번호)를 변경한다.
	  * @param mbr 변경할 정보를 담고 있는 VO
	  * @return 변경처리된 건 수
	 */
	int updateMbr(MbrVO mbr);
	
	/** (OK)
	  * @Method 설명 : 특정 가입자의 학습 회원 중 특정 학습회원의 정보(이름,성별)를 변경한다.
	  * @param mbrLrn 변경할 정보를 담고 있는 VO
	  * @return 변경 처리 건 수
	 */
	int updateMbrLrn(MbrLrnVO mbrLrn);
	
	/** (OK)
	  * @Method 설명 : 가입회원 로그인이력 등록
	  * @param logVO 가입회원 로그인이력VO
	 */
	void insertMbrLog(MbrLogVO logVO);

	/** (OK)
	  * @Method 설명 : 학습회원 진입이력 등록 
	  * @param logData HashMap (학습회원ID, 진입시작일시)
	 */
	void insertMbrLrnLog(HashMap<String, Object> logData);

	/** (OK) 
	 * @Method 설명 : 학습자의 최근 학습 내역을 가져온다. -->
	 * @author Kim Hee Seok [2020. 11. 12]
	 * @param learner 학습회원 ID
	 * @return 최근 학습정보 (진단이력, 주제진입이력, 코스진입이력)
	 */
	MbrRcntLrnVO selectRcntLrn(String learner);
	
	/** (OK)
	 * @Method 설명 : 회원의 약관내역리스트를 가져온다.  
	 * @author Kim Hee Seok [2020. 11. 13]
	 * @param map (회원아이디,언어코드,채널코드)
	 * @return 동의한 약관 정보 리스트 
	 */
	List<MbrTermsVO> selectMbrTermsListById(HashMap<String, String> map);

	/** (OK)
	 * @Method 설명 : 특정 회원의  특정 약관에 대한 동의여부를 변경한다.
	 * @author Kim Hee Seok [2020. 11. 13]
	 * @param termsVO
	 * @return 변경된 건 수
	 */
	int updateTerms(MbrTermsVO termsVO);
	
	/** (NOT)
	 * @Method 설명 : selectMbrByCtrCode   스마트 올 연동 (스마트 올 패드에서 호출)
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @param contract 게약번호
	 * @return MbrVO 회원정보 
	 */
	@Deprecated
	MbrVO selectMbrByCtrCode(String contract);	
}