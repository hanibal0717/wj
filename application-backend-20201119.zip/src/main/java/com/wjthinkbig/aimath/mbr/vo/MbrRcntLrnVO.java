package com.wjthinkbig.aimath.mbr.vo;

import java.time.LocalDateTime;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 11. 12 
  * @프로그램 설명 :  MbrRcntLrnVO.java  학습회원의 최근 학습내역
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 12     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ApiModel(value = "학습회원 학습내역", description = "학습회원의 최근 학습내역")
@ToString(callSuper=true)
public class MbrRcntLrnVO {
	
	/**
	 * 학습회원 아이디 
	 */
	@ApiModelProperty(value = "학습회원 아이디")
	@FieldName("학습회원 아이디")
	private String mbrLrnId;
	
	/**
	 * 진단 테스트 추천 스테이지 
	 */
	@ApiModelProperty(value = "진단 테스트 추천 스테이지")
	@FieldName("진단 테스트 추천 스테이지")
	private String dgnsStg;
	
	/**
	 * 진단테스트 종료날짜 
	 */
	@ApiModelProperty(value = "진단테스트 종료날짜")
	@FieldName("진단테스트 종료날짜")
	private LocalDateTime dgnsEndDt;
	
	/**
	 *  최근코스 학습 스테이지
	 */
	@ApiModelProperty(value = "최근코스 학습 스테이지")
	@FieldName("최근코스 학습 스테이지")
	private String rctCousStg;
	
	/**
	 * 최근 코스학습 날짜 
	 */
	@ApiModelProperty(value = "최근 코스학습 날짜")
	@FieldName("최근 코스학습 날짜")
	private String rctCousDt;
	
	/**
	 * 최근 주제학습 스테이지 
	 */
	@ApiModelProperty(value = "최슨 주제학습 스테이지")
	@FieldName("최슨 주제학습 스테이지")
	private String rctThmaStg;
	
	/**
	 * 최근 주제학습 날짜
	 */
	@ApiModelProperty(value = "최근 주제학습 날짜")
	@FieldName("최근 주제학습 날짜")
	private String rctThmaDt;
}
