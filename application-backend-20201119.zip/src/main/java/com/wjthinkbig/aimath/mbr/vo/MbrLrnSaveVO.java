/**
 * 
 */
package com.wjthinkbig.aimath.mbr.vo;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;

/**
  * @Date : 2020. 10. 5. 
  * @프로그램 설명 : 학습자VO 일괄처리를 위한 SaveVO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 5.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class MbrLrnSaveVO extends SaveVO<MbrLrnVO> {
	
	private static final long serialVersionUID = 7864507788685426645L;
	
}