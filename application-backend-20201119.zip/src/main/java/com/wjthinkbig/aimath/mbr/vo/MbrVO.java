package com.wjthinkbig.aimath.mbr.vo;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.PositiveOrZero;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.wjthinkbig.aimath.core.utils.WpinUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.constraints.Password;
import com.wjthinkbig.aimath.core.validator.constraints.PhoneNo;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.ToString;

/** (OK)
  * @Date : 2020. 9. 1. 
  * @프로그램 설명 : AI연산서비스 회원정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 1.     Lee Seung Hyuk            최초작성
  * 2020. 9. 17.    Kim Hee Seok              수정작업 
  * </pre>
  */
@ApiModel(value = "서비스 회원", description = "AI연산 서비스 회원")
@ToString(callSuper=true)
public class MbrVO extends BaseVO implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 가입회원 ID
	 */
	@NotBlank(groups = {Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value = "가입회원 ID")
	@FieldName("가입회원 ID")
	private String mbrId;
	
	/**
	 * 이메일주소  
	 */
	@Email
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value = "이메일주소")
	@FieldName("이메일주소")
	private String emailAdrs;
	
	/**
	 * 채널코드 
	 */
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value = "채널코드")
	@FieldName("채널코드")
	private String chnCd;
	
	/**
	 * 비밀번호
	 */
	@JsonProperty(access = Access.WRITE_ONLY)
	@NotBlank(groups = {Groups.Insert.class, Groups.Delete.class})
	@Password
	@ApiModelProperty(value = "비밀번호")
	@FieldName("비밀번호")
	private String pw;
	
	/**
	 * 휴대폰번호
	 */
	@ApiModelProperty(value = "휴대폰번호")
	@FieldName("휴대폰번호")
	@PhoneNo
	private String phone;
	
	/**
	 * 비밀번호 변경일시
	 */
	@ApiModelProperty(value = "비밀번호 변경일시")
	@FieldName("비밀번호 변경일시")
	private LocalDateTime pwChngeDt;	
	
	/**
	 * 이메일인증여부
	 */
	@Pattern(regexp = "Y|N")
	@ApiModelProperty(value = "이메일인증여부")
	@FieldName("이메일인증여부")
	private String emailCertYn;
	
	/**
	 * 고객번호
	 */
	@ApiModelProperty(value = "고객번호")
	@FieldName("고객번호")
	private String cstmrNo;
	
	/**
	 * 계약번호
	 */
	@ApiModelProperty(value = "계약번호")
	@FieldName("계약번호")
	private String cntrtNo;	
	
	/**
	 * 세션아이디
	 */
	@ApiModelProperty(value = "세션아이디")
	@FieldName("세션아이디")
	private String sessionId;
	
	/**
	 * 회원 탈퇴여부
	 */
	@Pattern(regexp = "Y|N")
	@ApiModelProperty(value = "탈퇴여부")
	@FieldName("탈퇴여부")
	private String delYn;
	
	
	
	
	/**
	 * 권한(시큐리티 부가정보로 토큰에 저장될 권한코드)
	 */
	@ApiModelProperty(value = "권한")
	private List<String> roles;
	
	/**
	 * 이 가입자의 학습자 리스트 정보
	 */
	@NotEmpty(groups = {Groups.Insert.class})
	@ApiModelProperty(value = "학습자 정보")
	@FieldName("학습자 정보")
	private List<MbrLrnVO> mbrLrnList;
	
	/**
	 * 회원약관내역 리스트
	 */
	@NotEmpty(groups = {Groups.Insert.class})
	@ApiModelProperty(value = "회원약관내역 리스트")
	@FieldName("회원약관내역 리스트")
	private List<MbrTermsVO> mbrTermsList;
	
	/**
	 * 학습자수 (왜 필요?)
	 */
	@PositiveOrZero
	@ApiModelProperty(value = "학습자수")
	@FieldName("학습자수")
	private int mbrLrnCnt;
		
	/**
	 * 마지막 접속일
	 */
	@ApiModelProperty(value = "마지막 접속일")
	@FieldName("마지막 접속일")
	private String loginDt;
	
	/**
	 * 최종디바이스
	 */
	@ApiModelProperty(value = "최종디바이스")
	@FieldName("최종디바이스")
	private String device;
	
	
	
	/**
	  * @Method 설명 : 암호화된 휴대폰번호를 받아 복호화시키고 현재 객체의 휴대폰번호로 세팅
	  * @param num 암호화된 휴대폰번호 
	  */
	public void setPhoneDe(String num) throws Exception {
		// 휴대폰번호 복호화 작업
		if( StringUtils.isNotEmpty( num ) ) {
			JSONObject obj = WpinUtils.wpinDecryption("P", num);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.phone = obj.getString("rtnVal");
			} else {
				this.phone = num;
			}
		}
	}
	
	/**
	  * @Method 설명 : 현재 객체의 휴대폰번호를 암호화시킨다. 
	  * @return 암호화된 휴대폰번호
	  * @throws Exception
	 */
	public String getPhoneEn() throws Exception {
		// 휴대폰번호 암호화 작업
		if( StringUtils.isNotEmpty( this.phone ) ) {
			JSONObject obj = WpinUtils.wpinEncryption("P", this.phone);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.phone = obj.getString("rtnVal");
			}
		}
		
		return this.phone;
	}
	
	/**
	  * @Method 설명 : 인자로 전달받은 이메일 정보를 복호화시켜 가져온다. 
	  * @param email 암호화된 이메일
	  * @return 복호화된 이메일
	  * @throws Exception
	 */
	public String getEmailAdrsDe(String email) throws Exception {
		// 이메일 복호화 작업
		if( StringUtils.isNotEmpty( email ) ) {
			JSONObject obj = WpinUtils.wpinDecryption("E", email);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				return obj.getString("rtnVal");
			} else {
				return email;
			}
		} else {
			return email;
		}
	}
	
	/**
	  * @Method 설명 : 암호화된 이메일을 받아 복호화시키고 현재 객체의 이메일로 세팅한다.   
	  * @param email 암호화된 이메일
	  * @throws Exception
	 */
	public void setEmailAdrsDe(String email) throws Exception {
		// 이메일 복호화 작업
		if( StringUtils.isNotEmpty( email ) ) {
			JSONObject obj = WpinUtils.wpinDecryption("E", email);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.emailAdrs = obj.getString("rtnVal");
			} else {
				this.emailAdrs = email;
			}
		}
	}
	
	/**
	  * @Method 설명 : 현재 객체의 이메일 정보를 암호화시킨다.  
	  * @return  암호화된 이메일, 성공하지 못 할 경우 현재 이메일을 그대로 반환  
	  * @throws Exception
	 */
	public String getEmailAdrsEn() throws Exception {
		// 이메일 암호화 작업
		if( StringUtils.isNotEmpty( this.emailAdrs ) ) {
			JSONObject obj = WpinUtils.wpinEncryption("E", this.emailAdrs);
			if( "Y".equals(obj.getString("rtnCode")) ) {				
				this.emailAdrs = obj.getString("rtnVal");
			}
		}
		
		return this.emailAdrs;
	}

	public String getMbrId() {
		return mbrId;
	}

	public void setMbrId(String mbrId) {
		this.mbrId = mbrId;
	}

	public String getEmailAdrs() {
		return emailAdrs;
	}

	public void setEmailAdrs(String emailAdrs) {
		this.emailAdrs = emailAdrs;
	}

	public String getChnCd() {
		return chnCd;
	}

	public void setChnCd(String chnCd) {
		this.chnCd = chnCd;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public LocalDateTime getPwChngeDt() {
		return pwChngeDt;
	}

	public void setPwChngeDt(LocalDateTime pwChngeDt) {
		this.pwChngeDt = pwChngeDt;
	}

	public String getEmailCertYn() {
		return emailCertYn;
	}

	public void setEmailCertYn(String emailCertYn) {
		this.emailCertYn = emailCertYn;
	}

	public String getCstmrNo() {
		return cstmrNo;
	}

	public void setCstmrNo(String cstmrNo) {
		this.cstmrNo = cstmrNo;
	}

	public String getCntrtNo() {
		return cntrtNo;
	}

	public void setCntrtNo(String cntrtNo) {
		this.cntrtNo = cntrtNo;
	}
	
	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getDelYn() {
		return delYn;
	}

	public void setDelYn(String delYn) {
		this.delYn = delYn;
	}

	public List<MbrLrnVO> getMbrLrnList() {
		return mbrLrnList;
	}

	public void setMbrLrnList(List<MbrLrnVO> mbrLrnList) {
		this.mbrLrnList = mbrLrnList;
	}
	
	public List<MbrTermsVO> getMbrTermsList() {
		return mbrTermsList;
	}

	public void setMbrTermsList(List<MbrTermsVO> mbrTermsList) {
		this.mbrTermsList = mbrTermsList;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	// 삭제대상 - 정말 필요한지 검토 필요?
	public int getMbrLrnCnt() {
		return mbrLrnCnt;
	}

	// 삭제대상 - 정말 필요한지 검토 필요?
	public void setMbrLrnCnt(int mbrLrnCnt) {
		this.mbrLrnCnt = mbrLrnCnt;
	}

	public String getDevice() {
		return device;
	}

	public void setDevice(String device) {
		this.device = device;
	}

	public String getLoginDt() {
		return loginDt;
	}

	public void setLoginDt(String loginDt) {
		this.loginDt = loginDt;
	}
	
	
}