package com.wjthinkbig.aimath.mbr.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 11. 4 
  * @프로그램 설명 :  SmartAllMbrVO.java  스마트올 패드에서 가져올 정보 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 4       Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "스마트올에서 가져올 객체 ")
public class SmartAllMbrVO {
	
	/**
	 * 스마트올 계약번호 
	 */
	@NotBlank
	@ApiModelProperty(value="스마트올 계약번호")
	@FieldName("스마트올 계약번호")
	private String ctrCode;
	
	/**
	 * 생년월
	 */
	@Pattern(regexp = "(19|20)\\d{2}(0[1-9]|1[012])")
	@NotBlank
	@ApiModelProperty(value="생년월")
	@FieldName("생년월")
	private String brthmt;
	
	/**
	 * 학습자이름
	 */
	@NotBlank
	@ApiModelProperty(value="학습자이름")
	@FieldName("학습자이름")
	private String mbrNm;
	
	/**
	 * 성별
	 */
	@Pattern(regexp = "M|F")
	@NotBlank
	@ApiModelProperty(value="성별")
	@FieldName("성별")
	private String sxdnCd;
	
	/**
	 * 언어코드
	 */
	@NotBlank
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;
}
