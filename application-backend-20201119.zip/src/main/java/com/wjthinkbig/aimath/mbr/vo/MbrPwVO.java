package com.wjthinkbig.aimath.mbr.vo;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.constraints.Password;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.ToString;

/**
  * @Date : 2020. 11. 17. 
  * @프로그램 설명 : 비밀번호 변경을 위한 요청정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 17.     Lee Seung Hyuk    코드검수
  * </pre>
 */
@ApiModel(value = "비밀번호 변경요청정보", description = "비밀번호 변경을 위한 요청정보")
@ToString(callSuper=true)
public class MbrPwVO extends BaseVO {
	
	/**
	 * 가입회원 ID
	 */
	@NotBlank(groups = {Groups.Update.class})
	@ApiModelProperty(value = "가입회원 ID")
	@FieldName("가입회원 ID")
	private String mbrId;
	
	/**
	 * 비밀번호
	 */
	@JsonProperty(access = Access.WRITE_ONLY)
	@NotBlank(groups = {Groups.Update.class})
	@ApiModelProperty(value = "비밀번호")
	@FieldName("비밀번호")
	private String pw;
	
	/**
	 * 비밀번호
	 */
	@JsonProperty(access = Access.WRITE_ONLY)
	@NotBlank(groups = {Groups.Update.class})
	@Password
	@ApiModelProperty(value = "새 비밀번호")
	@FieldName("새 비밀번호")
	private String newPw;

	public String getMbrId() {
		return mbrId;
	}

	public void setMbrId(String mbrId) {
		this.mbrId = mbrId;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getNewPw() {
		return newPw;
	}

	public void setNewPw(String newPw) {
		this.newPw = newPw;
	}
}