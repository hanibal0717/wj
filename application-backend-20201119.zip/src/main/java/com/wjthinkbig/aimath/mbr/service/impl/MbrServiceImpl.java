package com.wjthinkbig.aimath.mbr.service.impl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.DateUtils;
import com.wjthinkbig.aimath.core.utils.EmailUtils;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.SeedUtils;
import com.wjthinkbig.aimath.core.utils.SessionUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.utils.WebUtil;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.service.dao.MbrDao;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrLogVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrRcntLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrTermsVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.security.JwtUtils;
import com.wjthinkbig.aimath.terms.service.dao.TermsDao;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 : 회원관리 서비스 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
@Service("mbrService")
public class MbrServiceImpl extends BaseServiceImpl implements MbrService {

	/**
	 * 회원서비스 Dao
	 */
	@Resource(name = "mbrDao")
	private MbrDao mbrDao;
	
	/**
	 * 이용약관 Dao
	 */
	@Resource(name = "termsDao")
	private TermsDao termsDao;
		
	/**
	 * 단방향 암호화
	 */
	@Resource(name = "passwordEncoder")
	private PasswordEncoder passwordEncoder;
	
	/**
	 * 회원ID 신규생성 서비스
	 */
	@Resource(name = "mbrIdGenService")
	private EgovIdGnrService mbrIdGenService;
	
	/**
	 * 학습 회원ID 신규생성 서비스
	 */
	@Resource(name = "lrnIdGenService")
	private EgovIdGnrService lrnIdGenService;
	
	/**
	 * 비회원 (guest) 아이디 신규생성 서비스
	 */
	@Resource(name = "gstIdGenService")
	private EgovIdGnrService gstIdGenService;
	
	/**
	 * Email Utility
	 */
	@Resource(name = "emailUtils")
	private EmailUtils emailUtils;
	
	/**
	 * 이메일 인증 암호화 Utility
	 */
	@Resource(name = "seedUtils")
	private SeedUtils seedUtils;	
		
	/**
	 * Redis Template
	 */
	@Resource(name = "redisTemplate")
	private RedisTemplate<String, Object> redisTemplate;
	
	/**
	 * Session Utility
	 */
	@Resource(name = "sessionUtils")
	private SessionUtils sessionUtils;	

	@Autowired
	CacheManager cacheManager;
	
	
	
	/** (OK)
	 * 신규 가입처리 (가입회원, 학습회원 및 약관등록)
	 */
	@Override
	public void insertMbr(MbrVO mbr) throws Exception {
		
		// 이메일주소 (필수, 단독서비스에서 필수, 북패드 연동서비스의 경우 회원ID 기준으로 강제할당)		
		String rawEmail = mbr.getEmailAdrs();	// 암호화전 이메일
		String encEmail = mbr.getEmailAdrsEn();	// 이메일 암호화
		
		// 가입할 이메일이 이미 등록되어 있는지 확인
		if(mbrDao.isExistsByEmail(encEmail)) {
			throw this.processException("S001015"); // 해당 이메일은 이미 등록되어 있습니다.
		}
		
		// 채널코드 (필수)
		
		// 비밀번호 (필수, 단독서비스에서는 필수, 북패드 연동서비스의 경우 NULL이므로 옵션) : 옵션으로 변경필요
		if(StringUtils.isNotBlank(mbr.getPw())) {
			// 비밀번호를 입력받은 경우에는 암호화
			mbr.setPw(passwordEncoder.encode(mbr.getPw()));
		}
		
		// 휴대폰번호 (옵션, 존재할 경우 WPIN 암호화)
		if(StringUtils.isNotBlank(mbr.getPhone())) {
			mbr.getPhoneEn();
		}

		// 비밀번호 변경일시 (옵션, 비밀번호 있을 경우 현재 시간으로)
		if(StringUtils.isNotBlank(mbr.getPw())) {
			mbr.setPwChngeDt(LocalDateTime.now());
		}
		
		// 이메일인증여부 (옵션, 로직에서 결정하므로 옵션, 단독 서비스의 경우 이메일인증이 필요하므로 'N', 연동서비스의 경우 강제가입이므로 'Y'로 세팅)
		if(StringUtils.isNotBlank(encEmail)) {
			mbr.setEmailCertYn("N");
		}
		
		// 고객번호 (옵션, 글로벌 버전의 경우 없음)
		
		// 세션ID (옵션, 글로벌 버전의 경우 세션ID를 저장, 연동서비스의 경우 세션 필요없음)
		if(StringUtils.isBlank(mbr.getSessionId())) {
			mbr.setSessionId(gstIdGenService.getNextStringId());
		}

		// 탈퇴여부 (옵션, 로직에서 결정)
		mbr.setDelYn("N");		
		
		// 회원ID 채번 (옵션, 신규가입시는 로직에서 채번)
		String newMbrId = mbrIdGenService.getNextStringId();
		mbr.setMbrId(newMbrId);
		
		// 등록, 수정자 및 일시정보
		mbr.setLoginUser(newMbrId);		
		
		// 입력값 검증 (신규등록시)	: 컨트롤러에서 처리하므로 생략			
		/*this.validateOrElseThrow(mbr, Groups.Insert.class);*/

		// [1/3] 가입회원 신규등록 
		mbrDao.insertMbr(mbr);
		
		// [2/3] 등록할 학습회원 리스트 (필수, 1명 이상의 학습회원 정보가 있어야 함) 
		List<MbrLrnVO> mbrLrnList = mbr.getMbrLrnList();		
		for(MbrLrnVO mbrLrn : mbrLrnList) {
			// 회원ID 채번
			String newMbrLrnId = lrnIdGenService.getNextStringId();
			mbrLrn.setMbrId(newMbrLrnId);
			
			// 가입회원ID (필수, 로직에서 결정)
			mbrLrn.setSbsceMbrId(mbr.getMbrId());
			
			// 고객번호 (옵션, 글로벌 버전의 경우 없음)
			
			// 이모티콘 일련번호 (옵션, 로직에서 결정)
			mbrLrn.setEmotcSno(1);

			// 삭제여부 (옵션, 로직에서 결정)
			mbrLrn.setDelYn("N");		
			
			// 등록, 수정자 및 일시정보
			mbrLrn.setLoginUser(newMbrId);
			
			// 학습회원 입력값 검증 (신규등록시)				
			this.validateOrElseThrow(mbrLrn, Groups.Insert.class);
			
			// 학습회원 신규등록
			mbrDao.insertMbrLrn(mbrLrn);
		}
				
		// [3/3] 회원 약관동의여부 등록 (필수)
		List<MbrTermsVO> mbrTermsList=mbr.getMbrTermsList();
		for(MbrTermsVO vo : mbrTermsList) {
			// 가입회원ID
			vo.setSbsceMbrId(newMbrId);
			
			// 등록, 수정자 및 일시정보
			vo.setLoginUser(newMbrId);
			
			// 회원약관등록 입력값검증 (신규등록시)	
			this.validateOrElseThrow(vo, Groups.Insert.class);
			
			// 개별약관에 대한 신규등록
			mbrDao.insertMbrTerms(vo);
		}
		
		if(log.isDebugEnabled()) {
			log.debug("등록요청 가입회원({})정보 : {}", newMbrId, mbr);
		}
		
		// 등록자의 이메일로 인증메일을 발송한다.
		emailUtils.mailAuth(seedUtils.getEnCrypt(newMbrId), rawEmail);
	}
	
	/** (OK)
	 * 가입회원 로그인이력 저장 
	 */
	@Override
	public void insertLog(MbrLogVO logVO, HttpServletRequest request) throws Exception {
		logVO.setDeviceScnCd(WebUtil.getDeviceKind(request));
		logVO.setLoginBgnDt(LocalDateTime.now());
		mbrDao.insertMbrLog(logVO);		
	}

	/** (OK)
	 * 특정 가입자 회원에 새로운 학습 회원을 추가한다.
	 */
	@Override
	public void insertMbrLrn(MbrLrnVO mbrLrn) throws Exception{
		
		// 등록하려는 학습자 정보가 이미 가입자의 학습자 중에 존재하는지 확인 (이름/성별/생년월 일치조건)
		List<MbrLrnVO> learners = mbrDao.selectMbrLrnListById(mbrLrn.getSbsceMbrId());
		long learnerCnt = learners.stream().filter(x -> {
			return x.getBrthmt().equals(mbrLrn.getBrthmt()) &&
					x.getMbrNm().equals(mbrLrn.getMbrNm()) &&
					x.getSxdnCd().equals(mbrLrn.getSxdnCd());
		}).count();
		
		if(learnerCnt > 0) {
			throw this.processException("S001004"); // 이미 사용자가 등록되어 있습니다.
		}
		
		String newMbrLrnId = lrnIdGenService.getNextStringId();
		mbrLrn.setMbrId(newMbrLrnId);
				
		// 이모티콘일련번호 
		mbrLrn.setEmotcSno(1);

		// 학습회원 삭제여부
		mbrLrn.setDelYn("N");
		
		mbrLrn.setLoginUser(mbrLrn.getSbsceMbrId());

		// 입력값 검증 (신규등록시)				
		this.validateOrElseThrow(mbrLrn);
		
		// 학습회원 신규등록
		mbrDao.insertMbrLrn(mbrLrn);
	}
	
	/** (OK)
	 * 검색조건(이메일 또는 자녀명)을 만족하는 가입회원 리스트를 가져온다.
	 */
	@Override
	public List<MbrVO> selectMbrs(MbrSearchVO mbrSearch) throws Exception {
		if(mbrSearch != null) {
			// 검색어가 이메일이거나 이메일일 수 있는 전체로 설정된 경우 WPIN 암호화한다. -> 이메일 타입인지 확인 후 이메일인 경우에 한해서만 WPIN 암호화 호출하도록 변경
			if(mbrSearch.getSrchTy().equals("EMAIL") || mbrSearch.getSrchTy().equals("ALL")) {
				// 검색어가 이메일 형식인지 체크 (true/false)
				if(emailUtils.isEmail(mbrSearch.getSrchTxt())) {
					mbrSearch.setSrchTxt(mbrSearch.getSrchTxtEnE());
				}					
			}
		}
		
		// 검색조건을 만족하는 (정상) 가입회원 리스트 조회 : 특정 이메일을 가진 회원 또는 특정 이름의 자녀를 가진 회원
		List<MbrVO> mbrs = mbrDao.selectMbrs(mbrSearch);
		
		for(int i = 0; i < mbrs.size(); i++) {
			mbrs.get(i).setEmailAdrsDe(mbrs.get(i).getEmailAdrs());
		}
		return mbrs;
	}

	/** (OK)
	 * 검색조건(이메일 또는 자녀명)을 만족하는 가입회원 전체 건 수 
	 */
	@Override
	public int selectMbrsCnt(MbrSearchVO mbrSearch) throws Exception {
		if(mbrSearch.getSrchTy().equals("EMAIL") || mbrSearch.getSrchTy().equals("ALL")) {
			// 검색어가 이메일 형식인지 체크 (true/false)
			if(emailUtils.isEmail(mbrSearch.getSrchTxt())) {
				mbrSearch.setSrchTxt(mbrSearch.getSrchTxtEnE());
			}	
		}
		return mbrDao.selectMbrsCnt(mbrSearch);
	}		

	/** (OK)
	 * 가입회원아이디로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다
	 */
	@Override
	@Cacheable(value = "cache_mbr", key = "#mbrId")
	public MbrVO selectMbrById(String mbrId) throws Exception {
		MbrVO mbr = mbrDao.selectMbrById(mbrId);
//		mbr.setEmailAdrsDe(mbr.getEmailAdrs()); // 이메일 복호화
//		mbr.setPhoneDe(mbr.getPhone());			// 전화번호 복호화
		return mbr;
	}

	/** (OK)
	 * 특정 가입회원의 정상 학습회원 리스트를 가져온다. 
	 */
	@Override
	public List<MbrLrnVO> selectMbrLrnListById(String sbsceMbrId) {
		return mbrDao.selectMbrLrnListById(sbsceMbrId);
	}

	/** (OK)
	 * 특정 가입회원의 최근로그인이력정보 (최종로그인 날짜, 디바이스구분코드)를 가져온다.
	 */
	@Override
	public HashMap<String, String> selectMbrHstById(String mbrId) throws Exception {
		HashMap<String, String> map = mbrDao.selectMbrHstById(mbrId);
		return map;
	}
	
	/** (OK)
	 * (삭제되지않은 정상) 특정 학습회원의 정보 조회
	 */
	@Override
	public MbrLrnVO selectMbrLrnById(String mbrLrnId) throws Exception {
		MbrLrnVO mbrLrn = mbrDao.selectMbrLrnById(mbrLrnId);
		return mbrLrn;
	}
	
	/** (OK)
	 * 특정 학습회원의 정보를 변경한다. (회원명과 성별만 변경)
	 */
	@Override
	public int updateMbrLrn(MbrLrnVO mbrLrn) throws Exception {		
		mbrLrn.setModUser(LoginUtils.getUserId());
		mbrLrn.setModDt(LocalDateTime.now());
		
		return mbrDao.updateMbrLrn(mbrLrn);
	}
	
	/** (OK)
	 * 특정 학습회원을 삭제처리한다.
	 */
	@Override
	public int deleteMbrLrn(MbrLrnVO mbrLrn) throws Exception {
		mbrLrn.setModUser(LoginUtils.getUserId());
		mbrLrn.setModDt(LocalDateTime.now());
		
		return mbrDao.deleteMbrLrn(mbrLrn);
	}
	
	/** (OK)
	 * 특정 가입회원의 학습회원정보를 일괄 변경처리한다. (이름, 성별, 이모티콘만 변경가능)
	 */
	@Override
	public int learnersUpdate(String sbsceMbrId, @Valid SaveVO<MbrLrnVO> mbrLrnSaveVO) {
		
		// 처리대상 가입자의 학습자 정보가 일치하는지 검증
		long notMatchedCnt = 0;
		
		List<MbrLrnVO> updateList = mbrLrnSaveVO.getUpdateList();		
		if(updateList != null) {
			// 실제 가입자와 입력값에 기술된 가입자가 일치하는지 검증
			notMatchedCnt = updateList.stream().filter(x -> {
				return !sbsceMbrId.equals(x.getSbsceMbrId());
			}).count();
		}
		
		if(notMatchedCnt > 0) {
			throw this.processException("S002004"); // 학습자의 가입자 정보가 실제 가입자 정보와 일치하지 않습니다.
		}
		
		// 일괄 처리된 건 수
		int updateCnt = 0;
		
		for(MbrLrnVO vo : updateList) {
			int rowsAffected = 0;
			
			// 특정 가입자의 학습 회원 중 특정 학습회원의 정보(이름,성별)를 변경한다.
			rowsAffected = mbrDao.updateMbrLrn(vo);
			updateCnt += rowsAffected;
		}
		
		return updateCnt;
	}
	
	/** (OK)
	 * 특정 아이디의 가입회원정보 (비밀번호, 비밀번호 변경일자)를 변경한다.
	 */
	@Override
	public int updateMbr(MbrVO mbr) throws Exception {		
		// 정보 변경시 캐시된 데이터 삭제
		cacheManager.getCache("cache_mbr").evict(mbr.getMbrId());
				
		return mbrDao.updateMbr(mbr);
	}
	
	/** (OK)
	 * 이 가입회원 및 가입회원에 있는 학습회원 모두를 삭제처리한다. 
	 */
	@Override
	public int deleteMbr(MbrVO mbr) throws Exception {
		// 캐시된 데이터 삭제
		cacheManager.getCache("cache_mbr").evict(mbr.getMbrId());
		
		mbr.setModUser(LoginUtils.getUserId());
		mbr.setModDt(LocalDateTime.now());
		
		// 이 가입회원의 정상 학습회원을 일괄 모두 삭제처리한다.
		int rows = mbrDao.deleteMbrLrnBySbsceId(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		// 특정 아이디를 갖는 가입회원을 탈퇴처리한다.
		return mbrDao.deleteMbr(mbr);
	}
	
	/** (OK)
	 * 로그아웃 처리 - 레디스에서 토큰 삭제
	 */
	@Override
	public void signout(User userContext) throws Exception {
		MbrAccount mbrAccount = (MbrAccount)userContext;
		
		// 회원의 서비스 ID 및 채널
		String chnCd = mbrAccount.getMbrInfo().getChnCd();
		String userId = mbrAccount.getUserId();
		
		String redisKey = "token:refresh:" + chnCd + ":" + userId;
		String redisVal = (String) redisTemplate.opsForValue().get(redisKey);
		
		if(StringUtils.isNotBlank(redisVal)) {
			redisTemplate.delete(redisKey);
			log.info("사용자({}) 리프레시 토큰 파기", redisKey);
		}
	}
	
	/** (NOT) 동작하는지 테스트 필요 ????
	 * 특정 학습회원의 진입 로그를 쌓는다
	 */
	@Override
	public void insertMbrLrnLog(String learner, Boolean sameDevice, HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		// 해당 아이디의 동시 사용을 막기위해서 이미 사용중인 아이디 인지를 확인한다.
		log.info("사용여부 : {}",sessionUtils.isUsing(learner));
		sessionUtils.printMbrLrn();
		//같은 학습회원 집입 여부에 따라 예외처리한다 
		if(sessionUtils.isUsing(learner) && sameDevice == false) {
			throw this.processException("S002362"); // 같은 학습아이디가 학습중입니다.  
		}
		if(sessionUtils.isUsing(learner) == false) {
			// 같은 학습자가 session에 없을경우 세션과 쿠키를 설정한다.
			HttpSession session = request.getSession(true);
			sessionUtils.setSession(session, learner);
			Cookie cookie = new Cookie("mbrLrn", learner);
			cookie.setMaxAge(60*10); 
			response.addCookie(cookie);
		}
		// 학습회원 진입이력 등록
		HashMap<String, Object> logData = new HashMap<String, Object>();
		logData.put("lrnMbrId", learner);
		logData.put("entyBgnDt", LocalDateTime.now());		
		
		mbrDao.insertMbrLrnLog(logData);
	}

	/** (OK)
	 * 학습자의 최근 학습 내역을 가져온다. : 진단이력, 주제진입이력, 코스진입이력
	 */
	@Override
	public MbrRcntLrnVO selectRcntLrn(String learner) {
		return mbrDao.selectRcntLrn(learner);
	}
	
	/** (OK)
	 * 회원의 약관내역리스트를 가져온다. 
	 */
	@Override
	public List<MbrTermsVO> selectMbrTermsListById(HashMap<String, String> map) {
		return mbrDao.selectMbrTermsListById(map);
	}
	
	/** (OK)
	 * 특정 회원의 특정 약관에 대한 동의여부를 변경한다.
	 */
	@Override
	public int updateTerms(MbrTermsVO termsVO) throws Exception {
		return mbrDao.updateTerms(termsVO);
	}

	/** (OK)
	 * 비밀번호 변경일로부터 몇일 경과했는지를 반환한다. 
	 */
	@Override
	public long selectPassedDaysFromChangeDt(String mbrId) throws Exception {
		MbrVO mbrVO = mbrDao.selectMbrById(mbrId);		
		if(mbrVO == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다
		}
		
		// 주어진 시작일시 종료일시 간의 일수 차이를 반환한다. 
		long elapsedDays = DateUtils.betweenDays(mbrVO.getPwChngeDt(), LocalDateTime.now());		
		return elapsedDays;
	}

	/** (OK)
	 * 특정 가입회원의 (삭제되지않은 정상) 학습회원 리스트 조회
	 */
	@Override
	public List<MbrLrnVO> selectLearnersBySbsceMbrId(String mbrId) throws Exception {
		return mbrDao.selectMbrLrnListById(mbrId);
	}
	
	/** (OK)
	 * 해당 가입회원에게 임시비밀번호를 발급하여 변경한 후 해당 정보를 이메일로 전송한다.
	 */
	@Override
	public void procForgottenEmail(MbrVO mbr) throws Exception {
		String rawEmail = mbr.getEmailAdrs();
		String encEmail = mbr.getEmailAdrsEn();
		
		// 이메일로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다.
		MbrVO mbrVO = mbrDao.selectMbrByEmail(encEmail);
		if(mbrVO == null) {
			throw this.processException("S002011"); //해당 이메일이 존재하지 않습니다. 
		}
		
		// 임시비밀번호를 발급한다.
		String newRawPasswd = emailUtils.getTempPw(8);
				
		// 암호화 및 업데이트 셋팅
		mbr.setPw(passwordEncoder.encode(newRawPasswd));
		mbr.setPwChngeDt(LocalDateTime.now());
		mbr.setMbrId(mbrVO.getMbrId());
		mbr.setModDt(LocalDateTime.now());
		mbr.setModUser(mbrVO.getMbrId());
		
		// 발급한 임시비밀번호로 변경 
		int rows = mbrDao.updateMbr(mbr);
		if(rows == 0) {
			throw this.processException("S002013"); // 임시 비밀번호로 변경 되지 않았습니다. 
		}
		
		// 정보 변경시 캐시된 데이터 삭제
		cacheManager.getCache("cache_mbr").evict(mbrVO.getMbrId());

		// 회원의 이메일로 임시발급 비밀번호 정보를 발송한다. 
		emailUtils.findPw(newRawPasswd, rawEmail);
	}
	
	/** (OK)
	 * 링크를 통해 확인된 회원을 이메일 인증처리한다. 
	 */
	@Override
	public int updateEmailCertYn(String code) throws Exception {
		String mbrId = seedUtils.getDeCrypt(code);
		log.debug("mbrId : {}", mbrId);
		MbrVO mbr = mbrDao.selectMbrById(mbrId);
		if(mbr == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다
		}
		
		if(mbr.getEmailCertYn().equals("Y")) {
			throw this.processException("S002010");		// 이미 이메일 인증한 회원입니다. 
		}
		
		int rows = mbrDao.updateEmailCertYn(mbrId);
		return rows;
	}
}