package com.wjthinkbig.aimath.mbr.vo;

import java.time.LocalDateTime;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/** (OK)
  * @Date : 2020. 11. 12 
  * @프로그램 설명 :  가입회원로그인이력 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 12     Kim Hee Seok       최초작성
  * 2020. 11. 16     10013781			코드검수
  * </pre>
  */
@Getter
@Setter
@ApiModel(value = "가입회원로그인이력 VO", description = "가입회원로그인이력 VO")
@ToString(callSuper=true)
public class MbrLogVO {	
	/**
	 * 가입회원 아이디 
	 */
	@ApiModelProperty(value = "가입회원 아이디")
	@FieldName("가입회원 아이디")
	private String sbsceMbrId;

	/**
	 * 로그인시작일시
	 */
	@ApiModelProperty(value = "로그인시작일시")
	@FieldName("로그인시작일시")
	private LocalDateTime loginBgnDt;
	
	/**
	 * 디바이스 구분코드 
	 */
	@ApiModelProperty(value = "디바이스 구분코드")
	@FieldName("디바이스 구분코드")
	private String deviceScnCd;
	
	/**
	 * 계약번호 
	 */
	@ApiModelProperty(value = "계약번호")
	@FieldName("계약번호")
	private String cntrtNo;
}