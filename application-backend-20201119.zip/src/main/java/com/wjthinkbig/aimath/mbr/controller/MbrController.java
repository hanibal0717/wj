package com.wjthinkbig.aimath.mbr.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrPwVO;
import com.wjthinkbig.aimath.mbr.vo.MbrRcntLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrTermsVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.security.model.token.JwtTokenFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 : AI연산 회원서비스 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * 2020. 9. 17.    Kim Hee Seok              수정작업 
  * </pre>
  */
@Slf4j
@Api(description = "서비스 회원정보")
@RestController
public class MbrController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 회원서비스
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService; 
	
	/**
	 * 로그인 인증 서비스 
	 */
	@Resource(name = "userDetailsService")
	protected UserDetailsService userDetailsService;
	
	/**
	 * 단방향 암호화
	 */
	@Autowired
	@Qualifier("passwordEncoder")
	private PasswordEncoder passwordEncoder;
	
	/**
	 * 토큰 
	 */
	@Autowired
	private JwtTokenFactory tokenFactory;
	
	
	
	
	
	
	/** (OK)
	 * @Method 설명 : 신규 가입처리 (가입회원, 학습회원 및 약관등록)
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbr 가입처리할 회원정보를 담고 있는 VO (가입회원, 학습회원 리스트, 약관동의내역 리스트)
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "가입자 회원 신규등록", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/members")
	public CommonResult insertMbr(@ApiParam(value = "가입자회원정보") @Validated(value = Groups.Insert.class) @RequestBody MbrVO mbr) throws Exception {
		mbrService.insertMbr(mbr);
		return responseService.getResult(true);
	}
	
	/** (OK)
	 * @Method 설명 : 특정 가입자 회원의 학습자 회원을 신규 등록한다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param member 가입자회원 ID
	 * @param mbrLrn 학습자회원 VO
	 * @return 
	 * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원의 학습자회원 신규등록", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/members/{member}/learners")	
	public CommonResult insertMbrLrn(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member, @ApiParam(value = "학습자회원ID") @Validated(value = Groups.Insert.class) @RequestBody MbrLrnVO mbrLrn) throws Exception {	
		MbrVO mbr = mbrService.selectMbrById(member);
		if(mbr == null) {
			throw this.processException("S002012 ");		// 해당 가입자가 존재하지 않습니다.
		}
		
		// @RequestBody를 통해 전송된 데이터에 가입자ID가 있다면 경로변수의 가입자 ID와 일치해야 한다. 
		if(StringUtils.isBlank(mbrLrn.getSbsceMbrId()) || !member.equals(mbrLrn.getSbsceMbrId())) {
			throw this.processException("S002008"); // 데이터가 일치하지 않습니다. 
		}
		
		mbrService.insertMbrLrn(mbrLrn);
		return responseService.getResult(true);		
	}
	
	/** (OK)
	 * @Method 설명 : 검색조건(이메일 또는 자녀명)을 만족하는 정상 가입회원 조회
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrSearch 검색조건 VO
	 * @return 가입회원 리스트
	 * @throws Exception
	 */
	@ApiOperation(value="검색조건(이메일 또는 자녀명)을 만족하는 정상 가입회원 조회", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members")
	public SingleResult<HashMap<String,Object>> selectMbrsList(@ApiParam(value = "회원검색VO") @Valid @ModelAttribute MbrSearchVO mbrSearch) throws Exception {
		// 검색유형을 선택하지 않았을 경우 
		if(mbrSearch.getSrchTy() == null) {
			throw this.processException("S002002"); // 검색조건이 필요합니다.
		}
		
		// 페이징 조건
		mbrSearch.setRowCnt((int) mbrSearch.getRowCnt());
		mbrSearch.setCurrentPage((int) mbrSearch.getCurrentPage());
		
		// 검색조건에 따른 전체 대상 회원수 및 리스트
		int cnt = mbrService.selectMbrsCnt(mbrSearch);		
		List<MbrVO> mbrs = mbrService.selectMbrs(mbrSearch);
		
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("mbrs", mbrs);
		data.put("totalCount", cnt);
		
		return responseService.getSingleResult(data);
	}
	
	/** (OK)
	 * @Method 설명 : 가입회원아이디로 (탈퇴하지 않은 정상) 가입회원의 정보(자녀리스트 포함)를 가져온다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrId 가입회원ID
	 * @return 가입회원정보
	 * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원정보 조회", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/{member}")
	public SingleResult<MbrVO> selectMbrById(@ApiParam(value = "가입자회원ID") @PathVariable(name="member", required=true) String mbrId) throws Exception {
		MbrVO mbr = mbrService.selectMbrById(mbrId);
		if(mbr == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다.
		}
		
		// 이 가입회원의 정상 학습회원 리스트를 가져온다. 
		mbr.setMbrLrnList(mbrService.selectMbrLrnListById(mbrId));
		
		// 해당 회원의 최종 로그인 날짜와 최종 접속 디바이스를 가져온다 
		HashMap<String, String> map= mbrService.selectMbrHstById(mbrId);
		if(map != null) {
			mbr.setLoginDt(map.get("logindt").substring(0,19));
			mbr.setDevice(map.get("device"));
		}
		
		return responseService.getSingleResult(mbr);
	}
	
	/** (OK)
	 * @Method 설명 : selectLearnerOfMbr 특정 가입자 회원의 특정 학습자 정보를 조회한다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param member 가입회원ID
	 * @param learner 학습회원ID
	 * @return 학습회원정보
	 * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원의 특정 학습자정보 조회", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/{member}/learners/{learner}")
	public SingleResult<MbrLrnVO> selectLearnerOfMbr(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member, @ApiParam(value = "학습자회원ID") @PathVariable(name="learner",required=true) String learner) throws Exception {
		// 가입회원아이디로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다
		MbrVO mbr = mbrService.selectMbrById(member);
		if(mbr == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다..
		}
		
		// (삭제되지않은 정상) 특정 학습회원의 정보 조회
		MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
		if(mbrLrn == null) {
			throw this.processException("S002017");		// 해당 학습자가 존재하지 않습니다.
		}
		
		// 해당 학습회원의 가입자회원ID가 경로변수와 일치해야 한다. 
		if(!member.equals(mbrLrn.getSbsceMbrId())) {
			throw this.processException("S002001"); 	// 해당 학습자 정보를 처리할 수 없습니다.
		}
		return responseService.getSingleResult(mbrLrn);
	}
	
	/** (OK)
	 * @Method 설명 : 특정 가입자 회원의 특정 학습자정보를 변경한다. (이름,성별만 변경)
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param member 가입회원ID
	 * @param learner 학습회원ID
	 * @param mbrLrn 변경할 정보를 담고 있는 학습회원VO
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "특정 가입회원의 특정 학습회원 정보 변경", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}/learners/{learner}")
	public CommonResult updateLearnerOfMbr(@ApiParam(value = "가입회원ID") @PathVariable("member") String member
			, @ApiParam(value = "학습자회원ID") @PathVariable("learner") String learner
			, @ApiParam(value="학습회원 VO") @Validated(value = Groups.Update.class)  @RequestBody MbrLrnVO mbrLrn) throws Exception {
		
		// @RequestBody를 통해 전송된 데이터에 가입자ID가 있다면 경로변수의 가입자 ID와 일치해야 한다.
		if(StringUtils.isBlank(mbrLrn.getSbsceMbrId()) || !member.equals(mbrLrn.getSbsceMbrId())
				 || StringUtils.isBlank(mbrLrn.getMbrId()) || !learner.equals(mbrLrn.getMbrId())) {
			throw this.processException("S002000"); // 학습자 정보가 일치하지 않습니다.
		}
		
		// 특정 학습회원의 정보를 변경한다. (이름, 성별만 수정)
		int rows = mbrService.updateMbrLrn(mbrLrn);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	/** (OK)
	 * @Method 설명 : 특정 가입회원의 특정 학습회원을 삭제처리 (상태변경)
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param member 가입회원ID
	 * @param learner 학습회원ID
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value="특정 가입회원의 특정 학습회원을 삭제처리", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/members/{member}/learners/{learner}")
	public CommonResult deleteLearnerOfMbr(@ApiParam(value = "가입회원ID") @PathVariable("member") String member, @ApiParam(value = "학습회원ID") @PathVariable(name="learner", required=true) String learner) throws Exception {
		// 가입회원아이디로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다
		MbrVO mbrSrc = mbrService.selectMbrById(member);
		if(mbrSrc == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다.
		}
		
		// (삭제되지않은 정상) 특정 학습회원의 정보 조회
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrLrnSrc == null) {
			throw this.processException("S002017");		// 해당 학습자가 존재하지 않습니다.
		}
		
		// 이 가입회원에 정상 학습회원이 최소 1명이상은 있어야 한다. 
		List<MbrLrnVO> lrnList = mbrService.selectMbrLrnListById(member);
		if(lrnList.size() < 2) {
			throw this.processException("S002003");		// 더이상 학습회원을 삭제할 수 없습니다. 
		}
		
		// 삭제처리할 학습회원정보
		MbrLrnVO mbrLrn = new MbrLrnVO();
		mbrLrn.setSbsceMbrId(member);
		mbrLrn.setMbrId(learner);
		mbrLrn.setModDt(LocalDateTime.now());
		mbrLrn.setModUser(LoginUtils.getUserId());
		
		// 이 학습회원을 삭제처리한다.
		int rows = mbrService.deleteMbrLrn(mbrLrn); 
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	/** (OK)
	 * @Method 설명 : 특정 가입회원의 학습회원정보를 일괄 변경처리한다. (이름, 성별, 이모티콘만 변경가능) 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param member 가입회원ID
	 * @param mbrLrnSaveVO 변경할 정보를 담고 있는 학습회원 VO 리스트
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "특정 가입회원의 학습회원 정보를 일괄변경", notes = "전송한 VO 리스트에 대해 일괄적으로 등록, 수정 또는 삭제 처리를 한다.", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}/learners")	
	public CommonResult learnersUpdate(@ApiParam(value = "가입회원ID") @PathVariable("member") String member, 
			@Validated(value = Groups.Update.class) @RequestBody @ApiParam(value = "변경할 학습회원 리스트") SaveVO<MbrLrnVO> mbrLrnSaveVO) throws Exception {
		int rows = mbrService.learnersUpdate(member, mbrLrnSaveVO);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/** (OK)
	 * @Method 설명 : 특정 가입자 회원정보(비밀번호 및 변경일자) 변경
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param mbrId 가입회원ID
	 * @param pwdVO 비밀번호 변경을 위한 요청정보 VO
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원정보(비밀번호 및 변경일자) 변경", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}")
	public CommonResult updateMbr(@ApiParam(value = "가입회원ID") @PathVariable(name="member",required=true) String mbrId, @ApiParam(value="비밀번호 VO") @Validated(value = Groups.Update.class) @RequestBody MbrPwVO pwdVO) throws Exception {
		// 변경할 회원정보를 가져온다.
		MbrVO mbrSrc = mbrService.selectMbrById(mbrId);
		if(mbrSrc == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다.
		}
		
		log.debug("mbrSrc : {}", mbrSrc);
		log.debug("pwdVO.getPw() :{}", pwdVO.getPw());
		log.debug("일치 : {}", passwordEncoder.matches(pwdVO.getPw(), mbrSrc.getPw()));
		
		
		// @RequestBody를 통해 전송된 데이터에 가입자ID가 있다면 경로변수의 가입자 ID와 일치해야 한다. 
		if(!mbrId.equals(pwdVO.getMbrId())) {
			throw this.processException("S002008"); // 데이터가 일치하지 않습니다. 
		}
		
		// 입력한 비밀번호가 있고 기존 비밀번호와 다른 경우 (북패드 연동과 같이 비밀번호가 Null인 경우 변경불가로 처리) 
		if(!passwordEncoder.matches(pwdVO.getPw(), mbrSrc.getPw() == null ? "" : mbrSrc.getPw()) || mbrSrc.getPw() == null) {
			throw this.processException("S002016");		// 입력한 비밀번호와 현재 비밀번호가 일치하지 않습니다.
		}
		
		// 변경정보 (비밀번호, 비밀번호 변경일)
		mbrSrc.setPw(passwordEncoder.encode(pwdVO.getNewPw()));
		mbrSrc.setPwChngeDt(LocalDateTime.now());
		mbrSrc.setModUser(LoginUtils.getUserId());
		mbrSrc.setModDt(LocalDateTime.now());
		
		// updateMbr 가입 회원정보 변경 (비밀번호 및 비밀번호 변경일 정보만 수정)
		int rows = mbrService.updateMbr(mbrSrc);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/** (OK)
	 * @Method 설명 : 특정 가입회원을 삭제처리한다.(비밀번호 확인절차 없이 관리자에 의한)
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param member 가입회원ID
	 * @return 
	 * @throws Exception
	 */
	@ApiOperation(value="특정 가입회원정보 삭제", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/members/{member}")	
	public CommonResult deleteMbr(@ApiParam(value = "가입회원ID") @PathVariable(name="member", required=true) String member) throws Exception {
		// 가입회원아이디로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다
		MbrVO mbr = mbrService.selectMbrById(member);
		if(mbr == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다.
		}
		
		// 변경자 정보
		mbr.setModUser(LoginUtils.getUserId());
		mbr.setModDt(LocalDateTime.now());
		
		// 가입자 및 가입자의 학습자를 모두 삭제상태로 변경처리한다.
		int rows = mbrService.deleteMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);		
	}
	
	/** (OK)
	 * @Method 설명 : 특정 가입회원 탈퇴처리 (사용자에 의한), 해당 회원 및 학습회원 모두 삭제처리한다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param paramMbr 삭제할 회원정보를 담은 회원VO (회원ID, 비밀번호)
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value="특정 가입회원 탈퇴처리", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/members/revoke")	
	public CommonResult deleteRevokeMbr(@ApiParam(value="삭제요청회원 VO") @Validated(value = Groups.Delete.class) @RequestBody MbrVO paramMbr) throws Exception {
		// 삭제할 회원정보를 가져온다.
		MbrVO mbr = mbrService.selectMbrById(paramMbr.getMbrId());
		if(mbr == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다.
		}
		
		// 입력한 비밀번호가 있고 기존 비밀번호와 다른 경우 
		if(!passwordEncoder.matches(paramMbr.getPw(), mbr.getPw() == null ? "" : mbr.getPw())) {
			throw this.processException("S002016"); // 입력한 비밀번호와 현재 비밀번호가 일치하지 않습니다.
		}
		
		// 변경자 정보
		mbr.setModUser(LoginUtils.getUserId());
		mbr.setModDt(LocalDateTime.now());
		
		// 이 가입회원 및 가입회원에 있는 학습회원 모두를 삭제처리한다. 
		int rows = mbrService.deleteMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);		
	}
	
	/**
	 * @Method 설명 : 회원 로그아웃 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param userContext
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value="회원 로그아웃", tags = "인증")	
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/members/signout")	
	public CommonResult logout(@ApiParam(value="로그인 회원 객체") @AuthenticationPrincipal User userContext) throws Exception {
		if(userContext instanceof MbrAccount) {
			log.info("사용자 로그아웃 : ({}) {}", userContext.getClass().getSimpleName(), ((MbrAccount)userContext).getUserId());
			
			// Redis에서 이 회원의 리프레시 토큰을 제거한다.
			mbrService.signout(userContext);
			
			return responseService.getResult(true);
		} else {
			// 사용자 로그인을 통해 발급된 토큰이 아닌 경우
			return responseService.getResult(false);
		}
	}
	
	/** (NOT) - 로직이상, 메시지 이상, 검증필요
	 * @Method 설명 : 특정 학습자의 학습시작 시 진입이력을 남기고 최근학습정보를 불러온다.
	 *  - 이미 타 디바이스에서 학습 중인 경우 동시 학습을 차단한다. 동작하는지 검증 필요
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @param request HttpServletRequest
	 * @param response HttpServletResponse
	 * @param member 가입회원ID
	 * @param learner 학습회원ID
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value="특정 학습자의 진입 로그를 쌓고 최근학습정보를 불러온다.", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/log/members/{member}/learners/{learner}")
	public SingleResult<MbrRcntLrnVO> insertLearnerOfMbrLog(HttpServletRequest request, HttpServletResponse response, 
			@ApiParam(value = "가입회원ID") @PathVariable("member") String member, 
			@ApiParam(value = "학습회원ID") @PathVariable(name="learner", required=true) String learner) throws Exception{
		// 가입회원아이디로 (탈퇴하지 않은 정상) 가입회원의 정보를 가져온다
		MbrVO mbrSrc = mbrService.selectMbrById(member);
		if(mbrSrc == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다. 
		}
		
		// (삭제되지않은 정상) 특정 학습회원의 정보 조회 
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrLrnSrc == null) {
			throw this.processException("S002017");		// 해당 학습자가 존재하지 않습니다.
		}
		
		// 쿠키 여부에 따라 같은 디바이스 인지 판다
		boolean sameDevice  = false;
		Cookie[]  cookies = request.getCookies();
		for(Cookie cookie:cookies) {
			if(cookie.getName().equals("mbrLrn") && cookie.getValue().equals(learner)) {
				sameDevice = true;
			}
		}
		// 진입 로그를 쌓는다.
		mbrService.insertMbrLrnLog(learner, sameDevice, request, response);
		
		// 이 학습회원의 최근 학습 내역을 가져온다. (진단이력, 주제진입이력, 코스진입이력) 
		MbrRcntLrnVO rcntLrnVO = mbrService.selectRcntLrn(learner);
		
		return responseService.getSingleResult(rcntLrnVO);
	}
	
	/** (OK)
	 * @Method 설명 : 특정 가입회원의 약관동의내역을 가져온다.
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param member 가입회원ID
	 * @param channel 채널코드
	 * @param language 언어코드
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "특정 가입회원의 약관동의내역을 가져온다.", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/{member}/channels/{channel}/languages/{language}/terms")
	public SingleResult<List<MbrTermsVO>> selectTermsListById(@ApiParam(value = "가입자회원ID") @PathVariable(name="member", required=true) String member, 
			@ApiParam(value = "채널코드") @PathVariable(name="channel", required=true) String channel, 
			@ApiParam(value = "언어코드") @PathVariable(name="language", required=true) String language) throws Exception{
		MbrVO mbrSrc = mbrService.selectMbrById(member);
		if(mbrSrc == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다.
		}
		
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("mbrId", member);
		map.put("chnCd", channel);
		map.put("langCd", language);
		
		// 해당 회원의 가입시 약관동의내역리스트를 가져온다. 
		List<MbrTermsVO> termsVO = mbrService.selectMbrTermsListById(map);
		
		return responseService.getSingleResult(termsVO);
	}
	
	/** (OK)
	 * @Method 설명 : 특정 약관에 대한 동의내역 변경
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param member 가입회원ID
	 * @param termsVO 약관내역
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value="특정 약관에 대한 동의내역 변경 ", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}/terms")
	public CommonResult updateTermsYn(@ApiParam(value = "가입자회원ID") @PathVariable(name="member", required=true) String member, 
			@ApiParam(value = "약관내역", required = true)  @Validated(value = Groups.Update.class)  @RequestBody MbrTermsVO termsVO)  throws Exception {
		
		MbrVO mbr = mbrService.selectMbrById(member);
		if(mbr == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다.
		}
		
		if(StringUtils.isNotBlank(member) && !member.equals(termsVO.getSbsceMbrId())) {
			throw this.processException("S002008");     // 데이터가 일치하지 않습니다. 
		}
		
		int rows = mbrService.updateTerms(termsVO);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	/** (OK)
	 * @Method 설명 : 해당 가입회원에게 임시비밀번호를 발급하여 변경한 후 해당 정보를 이메일로 전송한다.
	 * @author Kim Hee Seok [2020. 9. 29]
	 * @param mbr 가입회원 VO
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value="회원 비밀번호 찾기", tags = {"회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/members/password")
	public CommonResult selectPwByEmail(@ApiParam(value = "회원 객체") @RequestBody MbrVO mbr) throws Exception {
		String rawEmail = mbr.getEmailAdrs();
		
		// 해당 가입회원에게 임시비밀번호를 발급하여 변경한 후 해당 정보를 이메일로 전송한다.
		mbrService.procForgottenEmail(mbr);
		
		return responseService.getResult(true, "S001023", rawEmail); // 회원님의 {0} 메일로 임시 비밀번호를 발송하였습니다. 
	}
	
	/**
	 * @Method 설명 : 가입 후 이메일 인증처리
	 * @author Kim Hee Seok [2020. 10. 5]
	 * @param code
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "가입 후 이메일 인증처리",  tags = {"인증", "회원서비스"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/email/verification")
	public CommonResult selectMbrEmailAuth(@ApiParam(value = "회원아이디 암호화 코드") @RequestParam(name="uid",required=true) String uid) throws Exception {
		int rows = mbrService.updateEmailCertYn(uid);
		if(rows == 0) {
			throw this.processException("S002009"); // 이메일 인증이 실패하였습니다. 
		}
		return responseService.getResult(true); 
	}
}