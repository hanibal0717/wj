package com.wjthinkbig.aimath.chn.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 21.
  * @프로그램 설명 : 채널 검색 정보 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 21.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="채널 검색 정보")
public class ChnSearchVO {
	
	@ApiModelProperty(value="페이징 처리 여부")
	@FieldName("페이징 처리 여부")
	private String pagingYn;					/* 페이징 처리 여부 */
	
	@ApiModelProperty(value="현재 페이지")
	@FieldName("현재 페이지")
	private int currentPage;					/* 현재 페이지 */
	
	@ApiModelProperty(value="페이지에 노출될 리스트 수")
	@FieldName("페이지에 노출될 리스트 수")
	private int rowCnt;							/* 페이지에 노출될 리스트 수 */
	
}
