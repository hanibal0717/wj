package com.wjthinkbig.aimath.corse.service;

import java.util.List;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.corse.vo.CorseSearchVO;
import com.wjthinkbig.aimath.corse.vo.CorseSingleVO;
import com.wjthinkbig.aimath.corse.vo.CorseVO;

/**
  * @Date : 2020. 9. 3.
  * @프로그램 설명 : 교육과정 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 3.     19001861            최초작성
  * </pre>
  */
public interface CorseService {
	
	/**
	  * @Method 설명 : 교육과정 전체 리스트 조회
	  * @param corseSearch
	  * @return
	  * @throws Exception
	  */
	public List<CorseVO> selectCorseList(CorseSearchVO corseSearch) throws Exception;
	
	/**
	  * @Method 설명 : 교육과정 전체 리스트 수 조회 (검색 조건 적용)
	  * @param corseSearch
	  * @return
	  * @throws Exception
	  */
	public int selectCorseListCnt(CorseSearchVO corseSearch) throws Exception;
	
	/**
	  * @Method 설명 : 교육과정 단일 정보 조회
	  * @param stg_cd
	  * @return
	  * @throws Exception
	  */
	public CorseSingleVO selectCorseById(CorseSearchVO corseSearch) throws Exception;
	
	/**
	  * @Method 설명 : CorseVO 빈에 대해 일괄 업무처리(등록/수정/삭제) 및 검증을 수행한다.
	  * @param corseSave 일괄 처리할 VO 리스트를 담고 있는 객체
	  * @throws Exception
	  */
	public void procCorse(SaveVO<CorseVO> corseSave) throws Exception;
	
}
