package com.wjthinkbig.aimath.corse.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.corse.service.CorseService;
import com.wjthinkbig.aimath.corse.vo.CorseSearchVO;
import com.wjthinkbig.aimath.corse.vo.CorseSingleVO;
import com.wjthinkbig.aimath.corse.vo.CorseVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 3.
  * @프로그램 설명 : 교육과정 관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 3.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="교육과정 관리 정보")
@RestController
public class CorseController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 교육과정 관리 서비스
	 */
	@Resource(name = "corseService")
	private CorseService corseService;
	
	/**
	  * @Method 설명 : 교육과정 전체 조회
	  * @param corseSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="교육과정 전체 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/course")
	public SingleResult<Map<String, Object>> selectCorseList(@ModelAttribute CorseSearchVO corseSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<CorseVO> corseList = corseService.selectCorseList(corseSearch);
		
		resultMap.put("corseList", corseList);
		resultMap.put("totalCnt", corseService.selectCorseListCnt(corseSearch));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 특정 코드의 교육과정 정보 조회
	  * @param stg_cd 소주제 식별코드
	  * @return 해당 식별코드를 갖는 교육과정 정보 VO
	  * @throws Exception
	 */
	@ApiOperation(value="특정 코드의 교육과정 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/course/{course}")	
	public SingleResult<CorseSingleVO> selectCorseById(@ModelAttribute CorseSearchVO corseSearch, @ApiParam(value = "소주제 코드") @PathVariable(name="course",required=true) String stg_cd) throws Exception {
		corseSearch.setStgCd(stg_cd);
		
		CorseSingleVO corseInfo = corseService.selectCorseById(corseSearch);
		if(corseInfo == null) {
			throw this.processException("S001003", stg_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(corseInfo);
	}
	
	/**
	  * @Method 설명 : CorseVO 빈에 대해 일괄 업무처리(등록/수정/삭제) 및 검증을 수행한다.
	  * @param corseSaveVO corseVO의 (등록/수정/삭제용) 리스트 객체 
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="CorseVO 빈에 대해 일괄 업무처리(등록/수정/삭제) 및 검증을 수행한다.")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/course")	
	public CommonResult procCorse(@Valid @RequestBody @ApiParam(value = "일괄처리 CorseVO 리스트") SaveVO<CorseVO> corseSave) throws Exception {
		corseService.procCorse(corseSave);
		return responseService.getResult(true);
	}
	
}
