package com.wjthinkbig.aimath.blbr.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.blbr.vo.BlbrSearchVO;
import com.wjthinkbig.aimath.blbr.vo.BlbrVO;
import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;

/**
  * @Date : 2020. 9. 23.
  * @프로그램 설명 : 게시판 관리 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 23.     19001861            최초작성
  * </pre>
  */
@Mapper("blbrDao")
public interface BlbrDao {
	
	/**
	  * @Method 설명 : 게시물 전체 리스트 조회
	  * @param blbrSearch
	  * @return
	  */
	List<BlbrVO> selectBlbrList(BlbrSearchVO blbrSearch);
	
	/**
	  * @Method 설명 : 게시물 전체 리스트 수 조회 (검색 조건 적용)
	  * @param blbrSearch
	  * @return
	  */
	int selectBlbrListCnt(BlbrSearchVO blbrSearch);
	
	/**
	  * @Method 설명 : 게시물 정보 단일 조회
	  * @param blbrSearch
	  * @return
	  */
	BlbrVO selectBlbrById(BlbrSearchVO blbrSearch);
	
	/**
	  * @Method 설명 : 게시물 등록
	  * @param blbr
	  */
	void insertBlbr(BlbrVO blbr);
	
	/**
	  * @Method 설명 : 게시물 수정
	  * @param blbr
	  */
	void updateBlbr(BlbrVO blbr);
	
	/**
	  * @Method 설명 : 게시물 조회 수 업
	  * @param blbr
	  */
	void updateBlbrChkCtUp(BlbrVO blbr);
	
	/**
	  * @Method 설명 : 게시물 삭제
	  * @param blbr
	  * @return
	  */
	int deleteBlbr(BlbrVO blbr);
}
