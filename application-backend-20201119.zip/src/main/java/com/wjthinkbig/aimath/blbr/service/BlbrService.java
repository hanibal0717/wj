package com.wjthinkbig.aimath.blbr.service;

import java.util.List;

import com.wjthinkbig.aimath.blbr.vo.BlbrSearchVO;
import com.wjthinkbig.aimath.blbr.vo.BlbrVO;

/**
  * @Date : 2020. 9. 23.
  * @프로그램 설명 : 게시판 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 23.     19001861            최초작성
  * </pre>
  */
public interface BlbrService {
	
	/**
	  * @Method 설명 : 게시판 전체 리스트 조회
	  * @param blbrSearch
	  * @return
	  * @throws Exception
	  */
	public List<BlbrVO> selectBlbrList(BlbrSearchVO blbrSearch) throws Exception;
	
	/**
	  * @Method 설명 : 게시물 전체 리스트 수 조회 (검색 조건 적용)
	  * @param blbrSearch
	  * @return
	  * @throws Exception
	  */
	public int selectBlbrListCnt(BlbrSearchVO blbrSearch) throws Exception;
	
	/**
	  * @Method 설명 : 게시판 정보 단일 조회
	  * @param blbrSearch
	  * @return
	  * @throws Exception
	  */
	public BlbrVO selectBlbrById(BlbrSearchVO blbrSearch) throws Exception;
	
	/**
	  * @Method 설명 : 게시물 등록
	  * @param blbr
	  * @throws Exception
	  */
	public void insertBlbr(BlbrVO blbr) throws Exception;
	
	/**
	  * @Method 설명 : 게시물 수정
	  * @param blbr
	  * @throws Exception
	  */
	public void updateBlbr(BlbrVO blbr) throws Exception;
	
	/**
	  * @Method 설명 : 게시물 조회 수 업
	  * @param blbr
	  * @throws Exception
	  */
	public void updateBlbrChkCtUp(BlbrVO blbr) throws Exception;
	
	/**
	  * @Method 설명 : 게시물 삭제
	  * @param blbr
	  * @return
	  * @throws Exception
	  */
	public int deleteBlbr(BlbrVO blbr) throws Exception;
	
}
