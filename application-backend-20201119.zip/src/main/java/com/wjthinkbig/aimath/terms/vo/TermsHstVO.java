package com.wjthinkbig.aimath.terms.vo;

import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 24.
  * @프로그램 설명 : 이용약관 이력 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 24.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="이용약관 이력 정보")
public class TermsHstVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="이용약관ID")
	@FieldName("이용약관ID")
	private String termsId; 			/* 이용약관ID */
	
	@ApiModelProperty(value="약관명")
	@FieldName("약관명")
	private String termsNm; 			/* 약관명 */
	
	@Min(value = 1, groups = {Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="약관이력일련번호")
	@FieldName("약관이력일련번호")
	private int termsHstSno; 			/* 약관이력일련번호 */
	
	@ApiModelProperty(value="약관주제")
	@FieldName("약관주제")
	private String termsThma; 			/* 약관주제 */
	
	@ApiModelProperty(value="약관내용")
	@FieldName("약관내용")
	private String termsCn; 			/* 약관내용 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;	 			/* 채널코드 */
	
	@ApiModelProperty(value="채널명")
	@FieldName("채널명")
	private String chnNm;	 			/* 채널명 */
	
	@ApiModelProperty(value="순서")
	@FieldName("순서")
	private int odr; 					/* 순서 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="적용일자")
	@FieldName("적용일자")
	private String aplcnYmd; 			/* 적용일자 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn;				/* 사용여부 */
	
	@Pattern(regexp = "(Y|N)")
	@ApiModelProperty(value="필수여부")
	@FieldName("필수여부")
	private String esntlYn;				/* 필수여부 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="내용포함여부")
	@FieldName("내용포함여부")
	private String cnInclnYn;			/* 내용포함여부 */
	
	@ApiModelProperty(value="등록언어")
	@FieldName("등록언어")
	private String langText;			/* 등록언어 */
	
	@ApiModelProperty(value="약관메타리스트")
	@FieldName("약관메타리스트")
	private List<TermsMetaVO> termsMetaList;		/* 약관메타리스트 */
}
