package com.wjthinkbig.aimath.terms.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.terms.service.TermsService;
import com.wjthinkbig.aimath.terms.vo.TermsHstSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsHstVO;
import com.wjthinkbig.aimath.terms.vo.TermsSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 24.
  * @프로그램 설명 : 이용약관 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 24.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="이용약관 정보")
@RestController
public class TermsController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 게시판 관리 서비스
	 */
	@Resource(name = "termsService")
	private TermsService termsService;
	
	/**
	  * @Method 설명 : 이용약관 설정 전체 리스트 정보 조회
	  * @param termsSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 설정 전체 리스트 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/terms")
	public SingleResult<Map<String, Object>> selectTermsList(@ModelAttribute TermsSearchVO termsSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<TermsVO> termsList = termsService.selectTermsList(termsSearch);
		
		resultMap.put("termsList", termsList);
		resultMap.put("totalCnt", termsService.selectTermsListCnt(termsSearch));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 이용약관 설정 단일 정보 조회
	  * @param terms_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 설정 단일 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/terms/{termsId}")
	public SingleResult<TermsVO> selectTermsById(@ApiParam(value = "이용약관ID") @PathVariable(name="termsId",required=true) String terms_id) throws Exception {
		TermsVO terms = termsService.selectTermsById(terms_id);
		return responseService.getSingleResult(terms);
	}
	
	/**
	  * @Method 설명 : 이용약관 설정 신규 등록
	  * @param terms
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 설정 신규 등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/terms")
	public CommonResult insertTerms(@RequestBody(required=true) TermsVO terms) throws Exception {
		termsService.insertTerms(terms);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 이용약관 설정 수정
	  * @param terms
	  * @param terms_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 설정 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/terms/{termsId}")
	public CommonResult updateTerms(@RequestBody(required=true) TermsVO terms
			, @ApiParam(value = "이용약관ID") @PathVariable(name="termsId",required=true) String terms_id) throws Exception {
		terms.setTermsId(terms_id);
		termsService.updateTerms(terms);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 이용약관 설정 삭제
	  * @param terms_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 설정 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/terms/{termsId}")	
	public CommonResult deleteTerms(@ApiParam(value = "이용약관ID") @PathVariable(name="termsId",required=true) String terms_id) throws Exception {
		int rows = termsService.deleteTerms(terms_id);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	
	/******************************************************************
	 * 이용약관 이력 
	 ******************************************************************/
	
	/**
	  * @Method 설명 : 이용약관 설정 전체 리스트 정보 조회
	  * @param termsHstSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 설정 전체 리스트 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/terms/history")
	public SingleResult<Map<String, Object>> selectTermsHstList(@ModelAttribute TermsHstSearchVO termsHstSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<>();
		List<TermsHstVO> termsHstList = termsService.selectTermsHstList(termsHstSearch);
		
		resultMap.put("termsHstList", termsHstList);
		resultMap.put("totalCnt", termsService.selectTermsHstListCnt(termsHstSearch));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 이용약관 이력 단일 정보 조회
	  * @param termsHstSearch
	  * @param terms_id
	  * @param terms_hst_sno
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 이력 단일 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/terms/history/{termsId}/{history}")
	public SingleResult<TermsHstVO> selectTermsHstById(@ModelAttribute TermsHstSearchVO termsHstSearch
			, @ApiParam(value = "이용약관ID") @PathVariable(name="termsId",required=true) String terms_id
			, @ApiParam(value = "이용약관이력일련번호") @PathVariable(name="history",required=true) int terms_hst_sno) throws Exception {
		termsHstSearch.setTermsId(terms_id);
		termsHstSearch.setTermsHstSno(terms_hst_sno);
		
		TermsHstVO termsHst = termsService.selectTermsHstById(termsHstSearch);
		return responseService.getSingleResult(termsHst);
	}
	
	/**
	  * @Method 설명 : 이용약관 이력 신규 등록
	  * @param termsHst
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 이력 신규 등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/terms/history")
	public CommonResult insertTermsHst(@RequestBody(required=true) TermsHstVO termsHst) throws Exception {
		termsService.insertTermsHst(termsHst);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 이용약관 이력 수정
	  * @param termsHst
	  * @param terms_hst_sno
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 이력 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/terms/history/{history}")
	public CommonResult updateTermsHst(@RequestBody(required=true) TermsHstVO termsHst
			, @ApiParam(value = "이용약관이력일련번호") @PathVariable(name="history",required=true) int terms_hst_sno) throws Exception {
		termsHst.setTermsHstSno(terms_hst_sno);
		termsService.updateTermsHst(termsHst);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 이용약관 이력 삭제
	  * @param termsHst
	  * @param terms_id
	  * @param terms_hst_sno
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 이력 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/terms/history/{termsId}/{history}")	
	public CommonResult deleteTerms(@RequestBody(required=true) TermsHstVO termsHst
			, @ApiParam(value = "이용약관ID") @PathVariable(name="termsId",required=true) String terms_id
			, @ApiParam(value = "이용약관이력일련번호") @PathVariable(name="history",required=true) int terms_hst_sno) throws Exception {
		termsHst.setTermsId(terms_id);
		termsHst.setTermsHstSno(terms_hst_sno);
		
		int rows = termsService.deleteTermsHst(termsHst);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	/******************************************************************
	 * 사용자 
	 ******************************************************************/
	
	/**
	  * @Method 설명 : 사용자 회원 가입 시 이용약관 리스트 정보 조회
	  * @param chn_cd
	  * @param lang_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="사용자 회원 가입 시 이용약관 리스트 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/terms/channels/{channel}/language/{language}")
	public ListResult<TermsHstVO> selectTermsChannelsList(@ApiParam(value = "채널코드") @PathVariable(name="channel",required=true) String chn_cd
			, @ApiParam(value = "언어코드") @PathVariable(name="language",required=true) String lang_cd) throws Exception {
		TermsHstSearchVO termsHstSearch = new TermsHstSearchVO();
		termsHstSearch.setChnCd(chn_cd);
		termsHstSearch.setLangCd(lang_cd);
		
		List<TermsHstVO> termsHstList = termsService.selectTermsChannelsList(termsHstSearch);
		return responseService.getListResult(termsHstList);
	}
	
	/**
	  * @Method 설명 : 이용약관 이력 약관ID별 리스트 조회
	  * @param terms_id
	  * @param chn_cd
	  * @param lang_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="이용약관 이력 약관ID별 리스트 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/terms/{terms}/channels/{channel}/language/{language}")
	public ListResult<TermsHstVO> selectTermsHstListByTermsId(@ApiParam(value = "약관ID") @PathVariable(name="terms",required=true) String terms_id
			, @ApiParam(value = "채널코드") @PathVariable(name="channel",required=true) String chn_cd
			, @ApiParam(value = "언어코드") @PathVariable(name="language",required=true) String lang_cd) throws Exception {
		TermsHstSearchVO termsHstSearch = new TermsHstSearchVO();
		termsHstSearch.setChnCd(chn_cd);
		termsHstSearch.setLangCd(lang_cd);
		termsHstSearch.setTermsId(terms_id);
		
		List<TermsHstVO> termsHstList = termsService.selectTermsHstListByTermsId(termsHstSearch);
		return responseService.getListResult(termsHstList);
	}
}
