package com.wjthinkbig.aimath.terms.vo;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 24.
  * @프로그램 설명 : 이용약관 메타 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 24.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="이용약관 메타 정보")
public class TermsMetaVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="이용약관ID")
	@FieldName("이용약관ID")
	private String termsId; 			/* 이용약관ID */
	
	@Min(value = 1, groups = {Groups.Insert.class, Groups.Delete.class})
	@ApiModelProperty(value="약관이력일련번호")
	@FieldName("약관이력일련번호")
	private int termsHstSno; 			/* 약관이력일련번호 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;	 			/* 언어코드 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;	 			/* 채널코드 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="약관주제")
	@FieldName("약관주제")
	private String termsThma; 			/* 약관주제 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="약관내용")
	@FieldName("약관내용")
	private String termsCn;	 			/* 약관내용 */
	
}
