package com.wjthinkbig.aimath.inq.vo;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.wjthinkbig.aimath.core.utils.WpinUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 22.
  * @프로그램 설명 : 1:1문의 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 22.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="1:1문의 정보")
public class InqVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="가입회원ID")
	@FieldName("가입회원ID")
	private String sbsceMbrId;		/* 가입회원ID */
	
	@Min(value = 1, groups = {Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="회원질문일련번호")
	@FieldName("회원질문일련번호")
	private int mbrInqSno;			/* 회원질문일련번호 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="질문제목")
	@FieldName("질문제목")
	private String inqTitle;		/* 질문제목 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="질문내용")
	@FieldName("질문내용")
	private String inqCn;			/* 질문내용 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="답변상태코드")
	@FieldName("답변상태코드")
	private String rplStsCd;		/* 답변상태코드 */
	
	@ApiModelProperty(value="답변내용")
	@FieldName("답변내용")
	private String rplCn;			/* 답변내용 */
	
	@ApiModelProperty(value="답변상태코드명")
	@FieldName("답변상태코드명")
	private String rplStsNm;		/* 답변상태코드명 */
	
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;			/* 채널코드 */
	
	@ApiModelProperty(value="채널코드명")
	@FieldName("채널코드명")
	private String chnNm;			/* 채널코드명 */
	
	@ApiModelProperty(value="이메일")
	@FieldName("이메일")
	private String emailAdrs;		/* 이메일 */
	
	/**
	  * @Method 설명 : 이메일 Wpin 복호화 작업
	  * @param email
	  */
	public void setEmailAdrsDe(String email) throws Exception {
		//이메일 복호화 작업
		if( StringUtils.isNotEmpty( email ) ) {
			JSONObject obj = WpinUtils.wpinDecryption("E", email);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.emailAdrs = obj.getString("rtnVal");
			} else {
				this.emailAdrs = email;
			}
		}
	}
}
