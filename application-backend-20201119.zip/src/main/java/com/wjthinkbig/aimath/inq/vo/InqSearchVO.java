package com.wjthinkbig.aimath.inq.vo;

import javax.validation.constraints.NotBlank;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.wjthinkbig.aimath.core.utils.WpinUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 22.
  * @프로그램 설명 : 1:1문의 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 22.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="1:1문의 검색 정보")
public class InqSearchVO {
	
	@ApiModelProperty(value="검색타입")
	@FieldName("검색타입")
	private String srchTy;						/* 검색타입 */
	
	@ApiModelProperty(value="검색어")
	@FieldName("검색어")
	private String srchTxt;						/* 검색어 */
	
	@ApiModelProperty(value="현재 페이지")
	@FieldName("현재 페이지")
	private int currentPage;					/* 현재 페이지 */
	
	@ApiModelProperty(value="페이지에 노출될 리스트 수")
	@FieldName("페이지에 노출될 리스트 수")
	private int rowCnt;							/* 페이지에 노출될 리스트 수 */
	
	@ApiModelProperty(value="답변상태코드")
	@FieldName("답변상태코드")
	private String rplStsCd;					/* 답변상태코드 */
	
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;						/* 채널코드 */
	
	@ApiModelProperty(value="가입회원ID")
	@FieldName("가입회원ID")
	private String sbsceMbrId;					/* 가입회원ID */
	
	@ApiModelProperty(value="회원질문일련번호")
	@FieldName("회원질문일련번호")
	private int mbrInqSno;						/* 회원질문일련번호 */
	
	/**
	  * @Method 설명 : 이메일 Wpin 암호화 작업
	  * @param email
	  */
	public String getSrchTxtEn() throws Exception {
		//이메일 암호화 작업
		if( StringUtils.isNotEmpty( this.srchTxt ) ) {
			JSONObject obj = WpinUtils.wpinEncryption("E", this.srchTxt);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				return obj.getString("rtnVal");
			}
		}
		
		return this.srchTxt;
	}
}
