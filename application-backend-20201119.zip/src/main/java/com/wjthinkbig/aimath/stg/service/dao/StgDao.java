package com.wjthinkbig.aimath.stg.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.stg.vo.StgAgeInfoSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgAgeInfoVO;
import com.wjthinkbig.aimath.stg.vo.StgMetaSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgMetaVO;
import com.wjthinkbig.aimath.stg.vo.StgSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;

/** (OK)
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 스테이지 관리 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * 2020. 11. 9.     10013871            코드검수
  * </pre>
 */
@Mapper("stgDao")
public interface StgDao {
	
	/** (OK)
	  * @Method 설명 : 검색조건에 맞는 소주제 리스트를 가져온다.
	  * @param stgSearch 검색할 정보를 담은 소주제 VO
	  * @return 검색된 소주제 리스트
	  */
	List<StgVO> selectStgList(StgSearchVO stgSearch);
	
	/** (OK)
	  * @Method 설명 : 특정 스테이지의 특정 언어에 대한 단일정보 조회(언어코드 필수)
	  * @param stgSearch 검색할 정보를 담은 소주제 VO
	  * @return 특정 스테이지의 단일정보 
	  */
	StgVO selectStg(StgSearchVO stgSearch);
	
	/** (OK) 
	  * @Method 설명 : 특정 스테이지 단일정보 조회
	  * @param stg_cd 스테이지코드
	  * @return 스테이지 VO
	 */
	StgVO selectStgById(String stg_cd);
	
	/** (OK)
	  * @Method 설명 : 검색조건에 맞는  소주제 건 수 조회 : 대주제의 하위 또는 특정 코드로 시작하는 소주제만 조회
	  * @param stgSearch
	  * @return
	  */
	int selectStgCnt(StgSearchVO stgSearch);
	
	/** (OK) 
	  * @Method 설명 : 검색조건에 맞는 소주제 건 수 조회 
	  * @param stgSearch
	  * @return
	  */
	int selectStgListCnt(StgSearchVO stgSearch);
	
	/** (OK)
	  * @Method 설명 : 특정 소주제의 건수 조회 (커리큘럼 소주제 코드 중복 여부 체크)
	  * @param stg_cd
	  * @return
	  */
	int selectStgCdDplctCheck(String stg_cd);
	
	/** (OK)
	  * @Method 설명 : 특정 스테이지의 언어별 메타 리스트 조회 
	  * @param stgMetaSearch 스테이지메타 VO
	  * @return 특정 스테이지의 메타 리스트
	  */
	List<StgMetaVO> selectStgMetaList(StgMetaSearchVO stgMetaSearch);
	
	/** (OK) 
	  * @Method 설명 : 특정 스테이지의 연령정보 리스트 조회
	  * @param stgAgeInfoSearch 스테이지연령정보 VO
	  * @return 스테이지연령정보 리스트
	  */
	List<StgAgeInfoVO> selectStgAgeInfoList(StgAgeInfoSearchVO stgAgeInfoSearch);
	
	/** (OK) 
	  * @Method 설명 : 스테이지 메타에서 스테이지명 건수 조회  (코드가 있을 경우 해당 코드를 제외한 다른 코드에서 사용되는 스테이지명이 존재하는지 체크)
	  * @param stgMetaSearch
	  * @return
	  */
	int selectStgNmDplctCheck(StgMetaSearchVO stgMetaSearch);
	
	/** (OK)
	  * @Method 설명 : 신규 스테이지 등록 (스테이지 테이블 기준)
	  * @param stg 등록할 소주제정보 VO
	 */
	void insertStg(StgVO stg);
	
	/** (OK)
	  * @Method 설명 : 신규 스테이지 메타정보 등록 (스테이지메타 테이블 기준)
	  * @param stgLangMeta
	  */
	void insertStgMeta(StgMetaVO stgMeta);
	
	/** (OK)
	  * @Method 설명 : 신규 스테이지연령정보 등록 
	  * @param stgAgeInfo
	  */
	void insertStgAgeInfo(StgAgeInfoVO stgAgeInfo);
	
	/** (OK)
	  * @Method 설명 : 특정스테이지의 스테이지 기본정보 수정
	  * @param stg 변경할 스테이지정보를 담은 VO
	 */
	void updateStg(StgVO stg);
	
	/** (OK)
	  * @Method 설명 : 특정 스테이지 기본정보 삭제
	  * @param stg_cd 삭제대상 스테이지코드
	  * @return 삭제된 건 수 
	 */
	int deleteStg(String stg_cd);
	
	/** (OK) 
	  * @Method 설명 : 특정 스테이지의 메타정보 삭제 
	  * @param stg_cd 삭제대상 스테이지코드
	  * @return
	  */
	int deleteStgMeta(String stg_cd);
	
	/** (OK)
	  * @Method 설명 : 특정 스테이지의 연령정보 삭제
	  * @param stg_cd
	  * @return
	  */
	int deleteStgAgeInfo(String stg_cd);
}