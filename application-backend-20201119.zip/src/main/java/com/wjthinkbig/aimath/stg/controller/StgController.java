package com.wjthinkbig.aimath.stg.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.stg.service.StgService;
import com.wjthinkbig.aimath.stg.vo.StgSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 소주제(스테이지) 관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Api(description="커리큘럼 스테이지 정보")
@RestController
public class StgController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 소주제(스테이지)관리 서비스
	 */
	@Resource(name = "stgService")
	private StgService stgService;
	
	
	/** (OK)
	  * @Method 설명 : 검색조건에 해당하는 스테이지정보 (리스트 및 전체 건수)를 제공한다
	  * @param stgSearch 소주제 검색조건을 담은 검색 VO 
	  * @return 검색된 스테이지정보 리스트
	  * @throws Exception
	 */
	@ApiOperation(value="검색조건에 해당하는 스테이지 리스트(및 전체 건수)를 제공한다.", tags = {"커리큘럼 스테이지 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/stage")
	public SingleResult<Map<String, Object>> selectStgList(@Valid @ModelAttribute StgSearchVO stgSearch) throws Exception {
		Map<String,Object> resultMap = new HashMap<String, Object>();
		List<StgVO> stgList = stgService.selectStgList(stgSearch);
		
		resultMap.put("stgList", stgList);
		resultMap.put("totalCnt", stgService.selectStgListCnt(stgSearch));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/** (OK)
	  * @Method 설명 : 단일 스테이지 정보를 제공한다.
	  * @param stg_cd 스테이지코드
	  * @return 해당 스테이지 정보
	  * @throws Exception
	 */
	@ApiOperation(value="단일 스테이지 정보를 제공한다.", tags = {"커리큘럼 스테이지 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/stage/{stage}")
	public SingleResult<StgVO> selectStgById(@ModelAttribute StgSearchVO stgSearch, @ApiParam(value = "소주제 코드") @PathVariable(name="stage",required=true) String stg_cd) throws Exception {
		stgSearch.setStgCd(stg_cd);
		StgVO stg = stgService.selectStgById(stgSearch);
		if(stg == null) {
			throw this.processException("S001003", stg_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(stg);
	}
	
	/** (OK)
	  * @Method 설명 : 신규 스테이지정보(기본, 메타, 연령)를 등록한다. (파일업로드 필수, 서비스단에서 Validation 처리)
	  * @param stg 등록할 정보를 담은 소주제 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="신규 스테이지정보 등록", tags = {"커리큘럼 스테이지 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/stage")
	public CommonResult insertStg(@ApiParam("등록할 정보를 담은 커리큘럼 소주제 객체") @ModelAttribute StgVO stg) throws Exception {
		// 등록하려는 코드와 동일한 스테이지코드가 있으면 안된다.
		if( stgService.selectStgCdDplctCheck(stg.getStgCd()) > 0 ) {
			throw this.processException("S001001"); // 이미 존재하는 데이터입니다.
		}
		
		// 인자로 전달받은 스테이지 객체로부터 스테이지, 스테이지메타, 스테이지연령 정보를 신규 등록한다. 
		stgService.insertStg(stg);
		
		return responseService.getResult(true);
	}
	
	/** (OK)
	  * @Method 설명 : 스테이지의 정보를 변경한다.
	  * @param stg 변경할 정보를 담은 스테이지 VO
	  * @param stg_cd 변경할 스테이지 식별코드 
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "커리큘럼 스테이지정보 변경", tags = {"커리큘럼 스테이지 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/stage/{stage}")
	public CommonResult updateStg(@ApiParam("변경할 정보를 담은 커리큘럼 스테이지 객체") @ModelAttribute StgVO stg, @ApiParam("변경할 컬리큘럼 스테이지의 고유키") @PathVariable(name="stage", required=true) String stg_cd) throws Exception {
		stg.setStgCd(stg_cd);
		stgService.updateStg(stg);
		return responseService.getResult(true);
	}
	
	/** (OK)
	  * @Method 설명 : 등록된 커리큘럼 스테이지 삭제
	  * @param stg_cd 삭제할 스테이지정보의 식별키
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="등록된  스테이지 삭제", tags = {"커리큘럼 스테이지 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/stage/{stage}")	
	public CommonResult deleteStg(@ApiParam("삭제대상 스테이지정보의 고유키") @PathVariable("stage") String stg_cd) throws Exception {
		int rows = stgService.deleteStg(stg_cd);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	/** (OK) 
	  * @Method 설명 : 등록된 커리큘럼 스테이지 리스트 일괄삭제
	  * @param stgList 삭제대상 스테이지정보를 담은 SaveVO 객체
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="등록된 커리큘럼 스테이지 삭제", tags = {"커리큘럼 스테이지 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/stage")	
	public CommonResult deletestgList(@ApiParam("삭제대상 스테이지정보의 객체 리스트") @RequestBody(required=true) SaveVO<StgVO> saveStg) throws Exception {
		int rows = stgService.deleteStgList(saveStg);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
}