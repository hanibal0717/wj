package com.wjthinkbig.aimath.stg.vo;

import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @FileName : StgVo.java
 * @Project : application-backend
 * @Date : 2020. 8. 14. 
 * @작성자 : 19001861
 * @프로그램 설명 : 커리큘럼 소주제 VO
 * @변경이력 :
*/
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 소주제 정보")
public class StgVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd; 			/* 소주제코드(스테이지코드) */
	
	@ApiModelProperty(value="스테이지명")
	@FieldName("스테이지명")
	private String stgNm; 			/* 스테이지명 */
	
	@ApiModelProperty(value="스텝명")
	@FieldName("스텝명")
	private String stepNm; 			/* 스텝명 */
	
	@ApiModelProperty(value="상세내용")
	@FieldName("상세내용")
	private String dtlCn;			/* 상세내용 */
	
	@ApiModelProperty(value="개념메타")
	@FieldName("개념메타")
	private String cncpMeta;		/* 개념메타 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="주제코드")
	@FieldName("주제코드")
	private String thmaCd;			/* 주제코드 */
	
	@ApiModelProperty(value="주제명")
	@FieldName("주제명")
	private String thmaNm;			/* 주제명 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="스테이지 이미지 파일경로")
	@FieldName("스테이지 이미지 파일경로")
	private String stgImgFilePath;	/* 스테이지 이미지 파일경로 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="스테이지 이미지 파일명")
	@FieldName("스테이지 이미지 파일명")
	private String stgImgFileNm;	/* 스테이지 이미지 파일명 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="키패드유형코드")
	@FieldName("키패드유형코드")
	private String kypdTyCd;		/* 키패드유형코드 */
	
	@ApiModelProperty(value="키패드유형코드명")
	@FieldName("키패드유형코드명")
	private String kypdTyNm;		/* 키패드유형코드명 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class})
	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn;			/* 사용여부 */
	
	@ApiModelProperty(value="개념메타 등록여부")
	@FieldName("개념메타 등록여부")
	private String metaYn;			/* 개념메타 등록여부 */
	
	@ApiModelProperty(value="선행학습 스테이지 코드")
	@FieldName("선행학습 스테이지 코드")
	private String preStgCd;		/* 선행학습 스테이지 코드 */
	
	@ApiModelProperty(value="이미지 첨부파일")
	@FieldName("이미지 첨부파일")
	private MultipartFile mFile;	/* 이미지 첨부파일 */
	
	@ApiModelProperty(value="연령 리스트")
	@FieldName("연령 리스트")
	private List<StgAgeInfoVO> stgAgeInfoList;	/* 언어 개념메타 리스트 */
	
	@ApiModelProperty(value="언어 메타 리스트")
	@FieldName("언어 메타 리스트")
	private List<StgMetaVO> stgMetaList;		/* 소주제메타 리스트 */
}
