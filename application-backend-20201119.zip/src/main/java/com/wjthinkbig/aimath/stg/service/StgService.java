package com.wjthinkbig.aimath.stg.service;

import java.util.List;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.stg.vo.StgSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;

/** (OK)
 * @Date : 2020. 8. 22. 
 * @프로그램 설명 : 소주제(스테이지) 관리서비스
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 8. 22.     Lee Seung Hyuk     최초작성
 * 2020. 11. 9.     10013871            코드검수
 * </pre>
*/
public interface StgService {
	
	/** (OK)
	  * @Method 설명 : 검색조건에 따른 스테이지 관련 스테이지 기본 및 메타정보를 가져와 반환한다.
	  * @param stgSearch 검색할 조건 정보를 담은 소주제 검색 VO
	  * @return 검색된 소주제 리스트
	  * @throws Exception
	 */
	public List<StgVO> selectStgList(StgSearchVO stgSearch) throws Exception;
		
	/** (OK)
	  * @Method 설명 : 검색조건을 만족하는 소주제 건수를 가져온다.
	  * @param stgSearch
	  * @return
	  * @throws Exception
	  */
	public int selectStgListCnt(StgSearchVO stgSearch) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 특정 스테이지의 메타, 연령 등 모든 정보를 가져온다.   
	  * @param stgSearch 검색할 조건 정보를 담은 소주제 검색 VO
	  * @return 스테이지 정보
	  * @throws Exception
	 */
	public StgVO selectStgById(StgSearchVO stgSearch) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 특정 스테이지 건 수 조회 (중복체크를 위해)
	  * @param stg_cd 스테이지코드
	  * @return 해당 스테이지의 건 수
	  * @throws Exception
	 */
	public int selectStgCdDplctCheck(String stg_cd) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 인자로 전달받은 스테이지 객체로부터 스테이지, 스테이지메타, 스테이지연령 정보를 신규 등록한다. 
	  * @param stg 등록할 소주제정보를 담은 VO
	  * @throws Exception
	 */
	public void insertStg(StgVO stg) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 스테이지 정보를 변경한다. 이 스테이지의 기존 메타, 연령정보를 초기화(삭제) 후 신규 등록한다.
	  * @param stg 변경할 정보를 담은 소주제 VO
	  * @throws Exception
	 */
	public void updateStg(StgVO stg) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 이 스테이지코드에 문항이 하나도 없을 경우에 한해 삭제처리한다. 스테이지기본, 메타, 연령 정보를 모두 삭제한다.
	  * @param stg_cd 삭제하고자 하는 소주제 식별코드
	  * @return 삭제된 레코드 건 수
	  * @throws Exception
	 */
	public int deleteStg(String stg_cd) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 전송된 SaveVO로부터 스테이지로부터 일괄 삭제
	  * @param saveStg 삭제하고자 하는 스테이지 정보를 담고 있는 SaveVO 객체
	  * @return 삭제된 레코드 건 수
	  * @throws Exception
	 */
	public int deleteStgList(SaveVO<StgVO> saveStg) throws Exception;
}