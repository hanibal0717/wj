package com.wjthinkbig.aimath.qst.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.qst.vo.QstMetaVO;
import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseMetaVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseVO;
import com.wjthinkbig.aimath.qst.vo.QstWrtnMngtVO;

/** (OK) 
  * @Date : 2020. 8. 14. 
  * @프로그램 설명 : 문항정보 관리 Dao 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 14. 	 19001861                         최초작성
  * 2020. 11. 9.     10013871           코드검수
  * </pre>
 */
@Mapper("qstDao")
public interface QstDao {
	
	/** (OK)
	  * @Method 설명 : 특정 언어의 문항 정보 (저작관리, 메타정보) 리스트 조회 (페이징)
	  * @param qstSearch 검색조건 객체 (스테이지코드, 저작상태, 검색어 등)
	  * @return 문항정보 리스트 
	  * @throws Exception
	  */
	List<QstVO> selectQstList(QstSearchVO qstSearch);
	
	/** (OK)
	  * @Method 설명 : 문항 저작건 수 조회 - 특정 스테이지 또는 전체 문항 건 수 조회
	  * @param qstSearch 검색조건 객체 (스테이지코드)
	  * @return 건 수
	  * @throws Exception
	  */
	int selectQstCount(QstSearchVO qstSearch);
	
	/** (OK)
	  * @Method 설명 : 특정 언어의 문항 정보 (저작관리, 메타정보) 건수 조회
	  * @param qstSearch 검색조건 객체 (스테이지코드, 저작상태, 검색어 등)
	  * @return 건 수
	  */
	int selectQstListCount(QstSearchVO qstSearch);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 특정 언어에 대한 단일정보 조회 (언어코드 필수)
	  * @param qstSearch 검색조건 객체 (언어코드, 문항코드)
	  * @return 단일 문항정보
	  * @throws Exception
	  */
	QstVO selectQst(QstSearchVO qstSearch);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 단일정보 조회 (저작정보, 문항기본)
	  * @param qstCd 검색조건 객체 (문항코드)
	  * @return 단일 문항정보
	  */
	QstVO selectQstById(String qstCd);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 언어별 문항메타정보  리스트 조회
	  * @param qstCd 문항코드
	  * @return 해당 코드의 문항메타 리스트
	  */
	List<QstMetaVO> selectQstMetaList(String qstCd);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 특정 언어에 대한 오답정보 리스트 조회(오답경로 및 오답경로 메타정보)
	  * @param qstWransrCrseSearch 검색조건 (문항코드, 언어코드)
	  * @return 오답정보 리스트 (오답경로 및 오답경로 메타정보) 
	 */
	List<QstWransrCrseVO> selectQstWransrCrseList(QstWransrCrseSearchVO qstWransrCrseSearch);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 오답유형코드별 정보 리스트 조회
	  * @param qstCd 문항코드
	  * @return 해당문항의 문항오답경로 리스트
	  */
	List<QstWransrCrseVO> selectQstWransrCrseListById(String qstCd);
	
	/** (OK)
	  * @Method 설명 : 특정문항의 특정 오답유형코드에 대한 문항오답경로메타정보 리스트 조회
	  * @param qstWransrCrseSearch 검색조건 (문항코드, 오답유형코드)
	  * @return 문항오답경로메타 리스트
	  */
	List<QstWransrCrseMetaVO> selectQstWransrCrseMetaList(QstWransrCrseSearchVO qstWransrCrseSearch);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 저작정보 건수 조회 (문항코드 중복체크)
	  * @param qst_cd 문항코드
	  * @return 건수
	  * @throws Exception
	  */
	int selectQstCdDplctCheck(String qst_cd);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 기본정보 건수 조회 (커리큘럼 문항코드 중복체크)
	  * @param qst_cd 문항코드
	  * @return 건수
	  */
	int selectQstCdDplctCheckByQst(String qst_cd);
	
	/** (OK)
	  * @Method 설명 : 신규 문항기본정보를 등록한다.
	  * @param qst 문항 기본정보를 담은 VO
	  */
	void insertQst(QstVO qst);
	
	/** (OK)
	  * @Method 설명 : 신규 문항메타정보 등록한다.
	  * @param qstMeta 문항 메타정보를 담은 VO
	  */
	void insertQstMeta(QstMetaVO qstMeta);
	
	/** (OK)
	  * @Method 설명 : 신규 문항오답경로 등록한다.
	  * @param qstWransrCrse 문항오답경로를 담은 VO
	  */
	void insertQstWransrCrse(QstWransrCrseVO qstWransrCrse);
	
	/** (OK)
	  * @Method 설명 : 신규 문항저작관리정보 등록 (필수항목만 등록) 
	  * @param qstWrtnMngt 등록할 문항저작정보를 담은 VO
	  */
	void insertQstWrtnMngt(QstWrtnMngtVO qstWrtnMngt);
	
	/** (OK)
	  * @Method 설명 : 신규 문항오답경로메타(원인정보) 등록한다.
	  * @param qstWransrCrseMeta 등록할 문항오답 원인정보를 담은 VO
	  */
	void insertQstWransrCrseMeta(QstWransrCrseMetaVO qstWransrCrseMeta);
	
	/** (OK)
	  * @Method 설명 : 기등록된 특정 문항의 기본정보를 변경한다.
	  * @param qst 문항기본정보 VO
	  */
	void updateQst(QstVO qst);
	
	/** (OK)
	  * @Method 설명 : 기등록된 특정 문항의 문항저작관리정보 변경 (수정자 및 저작상태 변경)
	  * @param qstWrtnMngt 문항저작관리정보 VO
	  */
	void updateQstWrtnMngt(QstWrtnMngtVO qstWrtnMngt);
	
	/** (OK)
	  * @Method 설명 : 기등록된 특정 문항의 스테이지 변경 (문항기본)
	  * @param qst 문항기본정보 VO
	  */
	void updateQstChngeStgCd(QstVO qst);
	
	/** (OK)
	  * @Method 설명 : 기등록된 특정 문항의 스테이지 변경 (문항저작관리)
	  * @param qstWrtnMngt
	  */
	void updateQstWrtnMngtChngeStgCd(QstWrtnMngtVO qstWrtnMngt);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 오답경로정보 삭제
	  * @param qst_cd 문항코드
	  * @return 삭제 건수
	  */
	int deleteQstWransrCrse(String qst_cd);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 문항오답경로메타 정보 삭제
	  * @param qst_cd 문항코드
	  * @return 삭제 건수
	  */
	int deleteQstWransrCrseMeta(String qst_cd);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 문항메타정보 삭제 
	  * @param qst_cd 문항코드
	  * @return 삭제 건수
	  */
	int deleteQstMeta(String qst_cd);
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 문항저작관리 정보 삭제
	  * @param qst_cd 문항코드
	  * @return 삭제 건수
	  */
	int deleteQstWrtnMngt(String qst_cd);
}