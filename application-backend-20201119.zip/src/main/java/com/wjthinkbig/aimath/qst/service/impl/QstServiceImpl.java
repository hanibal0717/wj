package com.wjthinkbig.aimath.qst.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.qst.service.QstService;
import com.wjthinkbig.aimath.qst.service.dao.QstDao;
import com.wjthinkbig.aimath.qst.vo.QstMetaVO;
import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseMetaVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseVO;
import com.wjthinkbig.aimath.qst.vo.QstWrtnMngtVO;

/** (OK) 
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 문항관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871           최초작성
  * 2020. 11. 9.     10013871           코드검수
  * </pre>
 */
@Service("qstService")
public class QstServiceImpl extends BaseServiceImpl implements QstService {
	
	/**
	 * 문항관리 Dao
	 */
	@Resource(name = "qstDao")
	private QstDao qstDao;
	
	
	/** (OK)
	 * 특정 언어의 문항 정보 (저작관리, 메타정보) 리스트 조회 (페이징)
	 */
	@Override
	public List<QstVO> selectQstList(QstSearchVO qstSearch) throws Exception {
		if( qstSearch.getCurrentPage() < 1 ) {
			qstSearch.setCurrentPage(1);
		}
		
		if( qstSearch.getRowCnt() < 1 ) {
			qstSearch.setRowCnt(10);
		}
		
		List<QstVO> qstList = qstDao.selectQstList(qstSearch);
		return qstList;
	}
	
	/** (OK)
	 * 문항 저작건 수 조회 - 특정 스테이지 또는 전체 문항 건 수 조회
	 */
	@Override
	public int selectQstCount(QstSearchVO qstSearch) throws Exception {
		int cnt = qstDao.selectQstCount(qstSearch);
		return cnt;
	}
	
	/** (OK)
	 * 특정 언어의 문항 정보 (저작관리, 메타정보) 건수 조회
	 */
	@Override
	public int selectQstListCount(QstSearchVO qstSearch) throws Exception {
		return qstDao.selectQstListCount(qstSearch);
	}
	
	/** (OK) 
	 * 특정 문항의 모든 정보(문항기본, 메타, 오답경로)를 가져온다.
	 */
	@Override
	public QstVO selectQstById(QstSearchVO qstSearch) throws Exception {
		QstVO qst = null;
		
		if( StringUtils.isNotEmpty(qstSearch.getLangCd()) ) {
			// 언어 코드가 존재할 경우 특정 문항의 해당 언어에 대한 단일정보(저작, 문항, 메타) 조회
			qst = qstDao.selectQst(qstSearch);
			
			if( qst != null ) {
				// 오답 정보 조회
				QstWransrCrseSearchVO qstWransrCrseSearch = new QstWransrCrseSearchVO();
				qstWransrCrseSearch.setQstCd(qstSearch.getQstCd());
				qstWransrCrseSearch.setLangCd(qstSearch.getLangCd());
				
				// 이 문항의 해당 언어에 대한 오답경로정보를 가져와 세팅
				qst.setQstWransrCrseList( qstDao.selectQstWransrCrseList(qstWransrCrseSearch) );
			}
		} else {
			// 언어 코드가 존재하지 않을 경우 이 문항의 단일정보 조회 (저작정보, 문항기본)
			qst = qstDao.selectQstById(qstSearch.getQstCd());
			
			if( qst != null ) {
				// 이 문항의 모든 메타 정보 리스트를 가져와 세팅
				qst.setQstMetaList(qstDao.selectQstMetaList(qstSearch.getQstCd()));
				
				// 이 문항의 문항오답 정보를 가져와 세팅
				QstWransrCrseSearchVO qstWransrCrseSearch = new QstWransrCrseSearchVO();
				qstWransrCrseSearch.setQstCd(qstSearch.getQstCd());
				
				List<QstWransrCrseVO> qstWransrCrseList = qstDao.selectQstWransrCrseListById(qstSearch.getQstCd());
				
				if( qstWransrCrseList != null ) {
					// 이 문항에 대한 오답경로정보가 있다면 각각의 오답유형코드에 대한 경로메타정보를 가져와 세팅한다. 
					for( int i = 0; i < qstWransrCrseList.size(); i++ ) {
						qstWransrCrseSearch.setWransrTyCd(qstWransrCrseList.get(i).getWransrTyCd());
						qstWransrCrseList.get(i).setQstWransrCrseMetaList( qstDao.selectQstWransrCrseMetaList(qstWransrCrseSearch) );
					}
				}
				
				qst.setQstWransrCrseList(qstWransrCrseList);
			}
		}
		
		return qst;
	}
	
	/** (OK)
	 * 특정 문항의 저작정보 건수 조회 (문항코드 중복체크)
	 */
	@Override
	public int selectQstCdDplctCheck(String qst_cd) throws Exception {
		return qstDao.selectQstCdDplctCheck(qst_cd);
	}
	
	/** (OK)
	 * 신규 문항정보 일체(문항저작관리, 문항기본, 문항메타, 문항오답경로, 문항오답경로메타)를 등록한다.
	 */
	@Override
	public void insertQst(QstVO qst) throws Exception {
		// 등록할 문항오답경로 정보가 있으면
		List<QstWransrCrseVO> qstWransrCrseList = qst.getQstWransrCrseList();
		
		// 문항기본의 오답유형구분(Y/N)정보를 세팅
		if( qstWransrCrseList != null && qstWransrCrseList.size() > 0 ) {
			// 오답 유형 존재
			qst.setWransrTyScnCd("Y");
		} else {
			// 오답 유형 존재하지 않음
			qst.setWransrTyScnCd("N");
		}
		
		// 문항 저작 테이블 등록
		QstWrtnMngtVO qstWrtnMngt = new QstWrtnMngtVO();
		qstWrtnMngt.setQstCd(qst.getQstCd());
		qstWrtnMngt.setStgCd(qst.getStgCd());
		qstWrtnMngt.setWrtnStsCd("WS01");  // 저작대기
		qstWrtnMngt.setRgtnUser(qst.getRgtnUser());
		
		// 필수값 검증
		this.validateOrElseThrow(qstWrtnMngt, Groups.Insert.class);
		
		// [1] 신규 문항저작관리정보 등록 (저작대기 상태로) 
		qstDao.insertQstWrtnMngt(qstWrtnMngt);
		
		// 문항 테이블 등록
		// 필수값 검증
		this.validateOrElseThrow(qst, Groups.Insert.class);
		
		// [2] 신규 문항기본정보를 등록한다.
		qstDao.insertQst(qst);
		
		// [3] 언어별 문항 메타정보 테이블 등록
		List<QstMetaVO> qstMetaList = qst.getQstMetaList();
		for( QstMetaVO qstMeta : qstMetaList ) {
			qstMeta.setQstCd( qst.getQstCd() );
			qstMeta.setRgtnUser( qst.getRgtnUser() );
			
			qstDao.insertQstMeta(qstMeta);
		}
		
		// [4/5] 문항오답경로 및 오답경로메타정보 등록
		if( qstWransrCrseList != null && qstWransrCrseList.size() > 0 ) {
			for( int i = 0; i < qstWransrCrseList.size(); i++ ) {
				QstWransrCrseVO qstWransrCrse = qstWransrCrseList.get(i);
				qstWransrCrse.setQstCd( qst.getQstCd() );
				qstWransrCrse.setRgtnUser( qst.getRgtnUser() );
				
				if( i + 1 >= 10 ) {
					qstWransrCrse.setWransrTyCd("WR" + (i + 1));
				} else {
					// 현재 오답유형은 3개만 존재
					qstWransrCrse.setWransrTyCd("WR0" + (i + 1));
				}
				
				// 필수값 검증
				this.validateOrElseThrow(qstWransrCrse, Groups.Insert.class);
				
				// [4] 신규 문항오답경로 등록한다
				qstDao.insertQstWransrCrse(qstWransrCrse);
				
				// 오답원인 등록
				List<QstWransrCrseMetaVO> qstWransrCrseMetaList = qstWransrCrse.getQstWransrCrseMetaList();
				for( QstWransrCrseMetaVO qstWransrCrseMeta : qstWransrCrseMetaList ) {
					qstWransrCrseMeta.setQstCd( qst.getQstCd() );
					qstWransrCrseMeta.setRgtnUser( qst.getRgtnUser() );
					qstWransrCrseMeta.setWransrTyCd( qstWransrCrse.getWransrTyCd() );
					
					// 필수값 검증
					this.validateOrElseThrow(qstWransrCrseMeta, Groups.Insert.class);
					
					// [5] 신규 문항오답경로메타정보를 등록한다.
					qstDao.insertQstWransrCrseMeta(qstWransrCrseMeta);
				}
			}
		}
	}

	/** (OK)
	 * 등록된 문항정보(문항저작관리, 문항기본, 문항메타, 문항오답경로, 문항오답경로메타)를 변경한다.
	 */
	@Override
	public void updateQst(QstVO qst) throws Exception {
		// 등록할 문항오답경로 정보가 있으면
		List<QstWransrCrseVO> qstWransrCrseList = qst.getQstWransrCrseList();
		
		// 문항기본의 오답유형구분(Y/N)정보를 세팅
		if( qstWransrCrseList != null && qstWransrCrseList.size() > 0 ) {
			//오답 유형 존재 (임시 코드 값)
			qst.setWransrTyScnCd("Y");
		} else {
			//오답 유형 존재하지 않음 (임시 코드 값)
			qst.setWransrTyScnCd("N");
		}

		if( qstDao.selectQstCdDplctCheck(qst.getQstCd()) > 0 && qstDao.selectQstCdDplctCheckByQst(qst.getQstCd()) <= 0 ) {
			// 저작 상태 테이블에 데이터를 밀어 넣었을 경우 (문항저작관리 테이블에는 존재하나 문항기본 테이블에 없는 경우) 문항기본정보와 문항메타정보를 새로 등록한다.
			// 필수값 검증
			this.validateOrElseThrow(qst, Groups.Insert.class);
			
			// 문항기본정보 신규등록
			qstDao.insertQst(qst);
			
			// 문항 메타 테이블 신규 등록
			List<QstMetaVO> qstMetaList = qst.getQstMetaList();
			for( QstMetaVO qstMeta : qstMetaList ) {
				qstMeta.setQstCd( qst.getQstCd() );
				qstMeta.setRgtnUser( qst.getModUser() );
				
				qstDao.insertQstMeta(qstMeta);
			}
		} else if( qstDao.selectQstCdDplctCheck(qst.getQstCd()) > 0 && qstDao.selectQstCdDplctCheckByQst(qst.getQstCd()) > 0 ) {
			// 이미 문항저작관리 테이블과 문항 기본 테이블에 존재하는 문항인 경우 수정 처리
			// 필수값 검증
			this.validateOrElseThrow(qst, Groups.Update.class);
			
			// 해당 문항의 문항기본정보 수정
			qstDao.updateQst(qst);
			
			// 문항 메타정보를 삭제 후
			qstDao.deleteQstMeta(qst.getQstCd());
			
			// 문항 메타정보 새로 등록한다.
			List<QstMetaVO> qstMetaList = qst.getQstMetaList();
			for( QstMetaVO qstMeta : qstMetaList ) {
				qstMeta.setQstCd( qst.getQstCd() );
				qstMeta.setRgtnUser( qst.getModUser() );
				
				qstDao.insertQstMeta(qstMeta);
			}
			
			// 이미 존재하는 경우 오답 메타정보 삭제 후
			qstDao.deleteQstWransrCrseMeta(qst.getQstCd());
			
			// 오답경로정보도 삭제
			qstDao.deleteQstWransrCrse(qst.getQstCd());
		}
		
		// 오답 테이블(문항오답경로, 문항오답경로메타)을 변경된 정보로 다시 등록
		if( qstWransrCrseList != null && qstWransrCrseList.size() > 0 ) {
			for( int i = 0; i < qstWransrCrseList.size(); i++ ) {
				QstWransrCrseVO qstWransrCrse = qstWransrCrseList.get(i);
				qstWransrCrse.setQstCd( qst.getQstCd() );
				qstWransrCrse.setRgtnUser( qst.getModUser() );
				
				if( i + 1 >= 10 ) {
					qstWransrCrse.setWransrTyCd("WR" + (i + 1));
				} else {
					qstWransrCrse.setWransrTyCd("WR0" + (i + 1));
				}
				
				// 필수값 검증
				this.validateOrElseThrow(qstWransrCrse, Groups.Insert.class);
				
				qstDao.insertQstWransrCrse(qstWransrCrse);
				
				// 오답원인 등록
				List<QstWransrCrseMetaVO> qstWransrCrseMetaList = qstWransrCrse.getQstWransrCrseMetaList();
				for( QstWransrCrseMetaVO qstWransrCrseMeta : qstWransrCrseMetaList ) {
					qstWransrCrseMeta.setQstCd( qst.getQstCd() );
					qstWransrCrseMeta.setRgtnUser( qst.getModUser() );
					qstWransrCrseMeta.setWransrTyCd( qstWransrCrse.getWransrTyCd() );
					
					// 필수값 검증
					this.validateOrElseThrow(qstWransrCrseMeta, Groups.Insert.class);
					
					qstDao.insertQstWransrCrseMeta(qstWransrCrseMeta);
				}
			}
		}
		
		// 저작상태 변경
		if( StringUtils.isNotEmpty(qst.getWrtnStsCd()) ) {
			QstWrtnMngtVO qstWrtnMngt = new QstWrtnMngtVO();
			qstWrtnMngt.setQstCd(qst.getQstCd());
			qstWrtnMngt.setWrtnStsCd(qst.getWrtnStsCd());   // 인자로 넘어온 상태로 변경
			qstWrtnMngt.setModUser(qst.getModUser());
			
			// 필수값 검증
			this.validateOrElseThrow(qstWrtnMngt, Groups.Update.class);
			
			// 기등록된 특정 문항의 문항저작관리정보 변경 (저작상태를 변경)
			qstDao.updateQstWrtnMngt(qstWrtnMngt);
		}
	}

	/** (OK)
	 * 기등록된 특정 문항의 문항저작관리정보 변경 (수정자 및 저작상태 변경)
	 */
	@Override
	public void updateQstWrtnMngt(QstWrtnMngtVO qstWrtnMngt) throws Exception {
		this.validateOrElseThrow(qstWrtnMngt, Groups.Update.class);
		qstDao.updateQstWrtnMngt(qstWrtnMngt);
	}
	
	/** (OK)
	 * 리스트에 있는 문항저작관리정보를 일괄 변경한다. 
	 */
	@Override
	public void updateQstWrtnMngtList(SaveVO<QstWrtnMngtVO> saveQstWrtnMngt) throws Exception {
		List<QstWrtnMngtVO> qstWrtnMngtList = saveQstWrtnMngt.getUpdateList();

		if( qstWrtnMngtList != null && qstWrtnMngtList.size() > 0 ) {
			for( QstWrtnMngtVO qstWrtnMngt : qstWrtnMngtList ) {
				// 필수 값 체크
				this.validateOrElseThrow(qstWrtnMngt, Groups.Update.class);
				// 저작 상태값 변경
				qstDao.updateQstWrtnMngt(qstWrtnMngt);
			}
		} else {
			throw this.processException("S001011");		//필수값 오류입니다.
		}
	}

	/** (OK)
	 * 특정문항의 스테이지를 일괄 변경처리한다. 
	 */
	@Override
	public int updateStgCdList(SaveVO<QstVO> saveQst) throws Exception {
		int cnt = 0;
		List<QstVO> qstList = saveQst.getUpdateList();
		
		if( qstList != null && qstList.size() > 0 ) {
			for( QstVO qst : qstList ) {
				// 특정 문항의 스테이지 정보(문항저작관리, 문항기본)를 변경한다. 
				if( StringUtils.isNotEmpty(qst.getStgCd()) && StringUtils.isNotEmpty(qst.getQstCd()) && StringUtils.isNotEmpty(qst.getModUser()) ) {
					QstWrtnMngtVO qstWrtnMngt = new QstWrtnMngtVO();
					qstWrtnMngt.setStgCd(qst.getStgCd());
					qstWrtnMngt.setQstCd(qst.getQstCd());
					qstWrtnMngt.setModUser(qst.getModUser());
					
					// 기등록된 특정 문항의 스테이지 변경 (문항저작관리)
					qstDao.updateQstWrtnMngtChngeStgCd(qstWrtnMngt);
					
					// 기등록된 특정 문항의 스테이지 변경 (문항기본)
					qstDao.updateQstChngeStgCd(qst);
					
					cnt++;
				} else {
					throw this.processException("S001011");		//필수값 오류입니다.
				}
			}
		}
		
		return cnt;
	}
}