package com.wjthinkbig.aimath.qst.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.qst.service.QstService;
import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstVO;
import com.wjthinkbig.aimath.qst.vo.QstWrtnMngtVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

/** (OK) 
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 문항관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871           최초작성
  * 2020. 11. 9.     10013871           코드검수
  * </pre>
 */
@Api(description="커리큘럼 문항정보")
@RestController
public class QstController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 문항관리 서비스
	 */
	@Resource(name = "qstService")
	private QstService qstService;
	
	
	
	/** (OK)
	  * @Method 설명 : 전체 커리큘럼 문항정보 조회
	  * @param qstSearch 검색할 조건정보를 담은 VO (스테이지코드, 언어코드)
	  * @return 검색된 문항리스트
	  * @throws Exception
	 */
	@ApiOperation(value="검색조건에 해당하는 문항 리스트를 제공한다.", tags = {"커리큘럼 문항 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/question")	
	public SingleResult<Map<String, Object>> selectQstList(@ModelAttribute QstSearchVO qstSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<>();
		List<QstVO> qstList = null;
		int totalCnt = 0;
		 
		if( StringUtils.isNotEmpty(qstSearch.getStgCd()) ) {
			qstList = qstService.selectQstList(qstSearch); 		 // 특정 언어의 문항 정보 (저작관리, 메타정보) 리스트 조회 (페이징)
			totalCnt = qstService.selectQstListCount(qstSearch); // 특정 언어의 문항 정보 (저작관리, 메타정보) 건수 조회
		} else {
			// 스테이지코드가 없으면 빈 리스트를 내려준다. (문항정보가 많으므로 제한)
			qstList = new ArrayList<QstVO>();
		}
		
		resultMap.put("qstList", qstList);
		resultMap.put("totalCnt", totalCnt);
		
		return responseService.getSingleResult(resultMap);
	}
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 정보(문항기본, 메타, 오답경로) 조회
	  * @param qst_cd 문항코드
	  * @return 검색된 문항정보 VO
	  * @throws Exception
	 */
	@ApiOperation(value="특정 문항정보 조회", tags = {"커리큘럼 문항 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/question/{question}")
	public SingleResult<QstVO> selectQstById(@ModelAttribute QstSearchVO qstSearch, @ApiParam(value = "문항 코드") @PathVariable(name="question",required=true) String qst_cd) throws Exception {
		qstSearch.setQstCd(qst_cd);
		QstVO qst = qstService.selectQstById(qstSearch);
		if(qst == null) {
			throw this.processException("S001003", qst_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(qst);
	}
	
	/** (OK)
	  * @Method 설명 : 문항코드 존재여부 조회
	  * @param qst_cd 문항코드
	  * @return Y (문항존재), N(문항없음)
	  * @throws Exception
	  */
	@ApiOperation(value="문항코드 존재여부 조회", tags = {"커리큘럼 문항 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/question/check/{question}")
	public SingleResult<String> selectQstCodeCheck(@ApiParam(value = "문항 코드") @PathVariable(name="question",required=true) String qst_cd) throws Exception {
		String result = "N";
		
		// 특정 문항의 저작정보 건수 조회 
		if( qstService.selectQstCdDplctCheck(qst_cd) > 0 ){
			result = "Y";
		}
		
		return responseService.getSingleResult(result);
	}
	
	/** (OK)
	  * @Method 설명 : 신규 문항정보 일체(문항저작관리, 문항기본, 문항메타, 문항오답경로, 문항오답경로메타)를 등록한다.
	  * @param qst 등록할 문항정보 VO
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="신규 문항정보 등록", tags = {"커리큘럼 문항 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/question")
	public CommonResult insertQst(@RequestBody(required=true) QstVO qst) throws Exception {
		// 문항코드 중복체크(특정 문항의 저작정보 건수 조회)
		if( qstService.selectQstCdDplctCheck(qst.getQstCd()) <= 0 ) {
			// 신규 문항정보 일체(문항저작관리, 문항기본, 문항메타, 문항오답경로, 문항오답경로메타)를 등록한다.
			qstService.insertQst(qst);
			return responseService.getResult(true);
		} else {
			throw this.processException("S001001"); // 이미 존재하는 데이터입니다.
		}
	}
	
	/** (OK)
	  * @Method 설명 : 등록된 문항정보(문항저작관리, 문항기본, 문항메타, 문항오답경로, 문항오답경로메타)를 변경한다.
	  * @param qst 변경할 정보를 담은 VO
	  * @param qst_cd 변경하고자 하는 문항코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "등록된 문항정보 변경", tags = {"커리큘럼 문항 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/question/{question}")
	public CommonResult updateQst(@ApiParam("변경할 정보를 담은 커리큘럼 문항 객체") @RequestBody(required=true) QstVO qst, @ApiParam("변경할 컬리큘럼 문항의 고유키") @PathVariable(name="question", required=true) String qst_cd) throws Exception {
		qst.setQstCd(qst_cd);
		// 등록된 문항정보(문항저작관리, 문항기본, 문항메타, 문항오답경로, 문항오답경로메타)를 변경한다.
		qstService.updateQst(qst);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 문항저작관리정보를 변경한다.
	  * @param qstWrtnMngt 변경할 문항저작관리정보 VO
	  * @param qst_cd 변경할 문항코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "커리큘럼 문항저작정보 변경", tags = {"커리큘럼 문항 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/question/{question}/status")
	public CommonResult updateQstWrtnMngt(@ApiParam("변경할 정보를 담은 커리큘럼 문항저작정보 객체") @RequestBody(required=true) QstWrtnMngtVO qstWrtnMngt, @ApiParam("변경할 컬리큘럼 문항의 고유키") @PathVariable(name="question", required=true) String qst_cd) throws Exception {		
		qstWrtnMngt.setQstCd(qst_cd);
		// 기등록된 특정 문항의 문항저작관리정보 변경 (수정자 및 저작상태 변경)
		qstService.updateQstWrtnMngt(qstWrtnMngt);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 복수 개의 문항저작관리정보를 일괄 변경한다.
	  * @param qstWrtnMngtList 변경할 문항코드
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value = "문항저작관리정보 일괄 변경", tags = {"커리큘럼 문항 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/question/status")
	public CommonResult updateQstWritingList(@ApiParam("변경할 정보를 담은 커리큘럼 문항저작정보 객체") @RequestBody(required=true) SaveVO<QstWrtnMngtVO> saveQstWrtnMngt) throws Exception {
		// 리스트에 있는 문항저작관리정보를 일괄 변경한다. 
		qstService.updateQstWrtnMngtList(saveQstWrtnMngt);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 문항의 스테이지 일괄 변경 
	  * @param saveQst 변경할 문항정보를 담고 있는 SaveVO
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value = "커리큘럼 문항의 소주제코드 다중 변경", tags = {"커리큘럼 문항 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/question/stage")
	public CommonResult updateStgCdList(@ApiParam("변경할 정보를 담은 커리큘럼 문항정보 객체") @RequestBody(required=true) SaveVO<QstVO> saveQst) throws Exception {
		// 특정문항의 스테이지를 일괄 변경처리한다. 
		int rows = qstService.updateStgCdList(saveQst);
		
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
}