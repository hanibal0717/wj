package com.wjthinkbig.aimath.qst.service;

import java.util.List;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstVO;
import com.wjthinkbig.aimath.qst.vo.QstWrtnMngtVO;

/** (OK) 
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 문항관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871           최초작성
  * 2020. 11. 9.     10013871           코드검수
  * </pre>
 */
public interface QstService {
	
	/** (OK)
	  * @Method 설명 : 특정 언어의 문항 정보 (저작관리, 메타정보) 리스트 조회 (페이징)
	  * @param qstSearch 검색할 조건정보를 담은 VO
	  * @return 검색된 문항리스트
	  * @throws Exception
	 */
	public List<QstVO> selectQstList(QstSearchVO qstSearch) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 특정 언어의 문항 정보 (저작관리, 메타정보) 건수 조회
	  * @param qstSearch 검색조건을 담은 VO
	  * @return 검색된 건 수
	  * @throws Exception
	 */
	public int selectQstCount(QstSearchVO qstSearch) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 특정 언어의 문항 정보 (저작관리, 메타정보) 건수 조회
	  * @param qstSearch 검색조건 객체 (스테이지코드, 저작상태, 검색어 등)
	  * @return 건 수
	  * @throws Exception
	  */
	public int selectQstListCount(QstSearchVO qstSearch) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 정보(문항기본, 메타, 오답경로)를 가져온다.
	  * @param qstCd 검색조건 VO
	  * @return 해당 문항정보 VO
	  * @throws Exception
	 */
	public QstVO selectQstById(QstSearchVO qstSearch) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 특정 문항의 저작정보 건수 조회 (문항코드 중복체크)
	  * @param qst_cd 문항 식별코드
	  * @return 건수
	  * @throws Exception
	 */
	public int selectQstCdDplctCheck(String qst_cd) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 신규 문항정보 일체(문항저작관리, 문항기본, 문항메타, 문항오답경로, 문항오답경로메타)를 등록한다.
	  * @param qst 등록할 문항정보를 담은 VO
	  * @throws Exception
	 */
	public void insertQst(QstVO qst) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 등록된 문항정보(문항저작관리, 문항기본, 문항메타, 문항오답경로, 문항오답경로메타)를 변경한다.
	  * @param qst 변경할 정보를 담고 있는 문항VO
	  * @throws Exception
	 */
	public void updateQst(QstVO qst) throws Exception;
		
	/** (OK)
	  * @Method 설명 : 기등록된 특정 문항의 문항저작관리정보 변경 (수정자 및 저작상태 변경)
	  * @param qstWrtnMngt 문항저작정보 VO
	  * @throws Exception
	 */
	public void updateQstWrtnMngt(QstWrtnMngtVO qstWrtnMngt) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 리스트에 있는 문항저작관리정보를 일괄 변경한다. 
	  * @param saveQstWrtnMngt 문항저작정보 VO
	  * @throws Exception
	 */
	public void updateQstWrtnMngtList(SaveVO<QstWrtnMngtVO> saveQstWrtnMngt) throws Exception;
	
	/** (OK)
	  * @Method 설명 : 특정문항의 스테이지를 일괄 변경처리한다. 
	  * @param saveQst 변경처리할 정보를 담은 SaveVO
	  * @return 변경처리된 건 수
	  * @throws Exception
	  */
	public int updateStgCdList(SaveVO<QstVO> saveQst) throws Exception;	
}