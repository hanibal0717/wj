package com.wjthinkbig.aimath.lrn.note.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.ApiUtil;
import com.wjthinkbig.aimath.lrn.note.service.NoteService;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAccumDataVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAnalysisVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteBstWrstVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLrnStatusVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLvlVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteMgntVO;
import com.wjthinkbig.aimath.lrn.note.vo.NotePrgsListByStgVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 20 
  * @프로그램 설명 :  NoteController.java   AI 연산 학습노트 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20     Kim Hee Seok       최초작성
  * </pre>
  */
@Slf4j
@Api(description = "학습노트")
@RestController
public class NoteController extends BaseController {
		
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 학습노트 서비스 
	 */
	@Resource(name = "noteService")
	private NoteService noteService;
	
	/**
	 * 회원 서비스 
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService;
	
	/**
	 * 외부 API 사용 유틸
	 */
	@Resource(name = "apiUtil")
	private ApiUtil apiUtil;
	
	/**
	 * @Method 설명 : selectListLvlByMbr 학습자 아이디와 언어코드로   학습한 레벨리스트  없다면 학습시작점  조회
	 * @author Kim Hee Seok [2020. 10. 23]
	 * @param learner 학습자 아이디 
	 * @param lvlVO	 
	 * @return List<NoteLvlVO> 레벨코드, 학습자 아이디, 레벨표기, 레벨주제
	 * @throws Exception
	 */
	@ApiOperation(value = "학습자 아이디와 언어코드로  학습레벨 및 리스트 /학습시작점  조회 ")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/note/level/learners/{learner}/languages/{language}")
	public SingleResult<List<NoteLvlVO>> selectListLvlByMbr(@ApiParam(value = "학습자 아이디") @PathVariable(name = "learner") String learner
			, @ApiParam(value = "언어코드 ") @PathVariable(name = "language") String language
			, @ApiParam(value = "레벨객체") NoteLvlVO lvlVO) throws Exception {
		//학습자 존재 여부 조회 
		MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
		if(mbrLrn == null) {
			throw this.processException("S002017");		// 해당 학습자가 존재하지 않습니다..
		}
		lvlVO.setLrnMbrId(learner);
		lvlVO.setLangCd(language);
		// 코스 학습이력이 없을 경우 시작점(진단학습의 bgn_stg_cd)을 찾는다. 
		List<NoteLvlVO> lvlList = noteService.selectListLvlByMbr(lvlVO);
		if(lvlList.size() == 0) {
			// 진단학습에서 적정스테이지(bgn_stg_cd) 레벨과 이름을 기져온다 
			lvlVO = noteService.selectLvlNameByStgCd(lvlVO);
			lvlList.add(lvlVO);
		}
		return responseService.getSingleResult(lvlList);
	}
	
	/**
	 * @Method 설명 : selectStgListByLvl 학습노트 진도 
	 * @author Kim Hee Seok [2020. 10. 23]
	 * @param learner 학습자 아이디 
	 * @param level 레벨
	 * @param language 언어코드 
	 * @param mgntVO  
	 * @return NoteMgntVO  레벨코드, 레벨명, 학습회원 아이디, 언어코드, 학습상태, 학습기간
	 * @throws Exception
	 */
	@ApiOperation(value = "진도 ", tags = {"학습노트","진도"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/note/magnitude/learners/{learner}/levels/{level}/languages/{language}")
	public SingleResult<NoteMgntVO> selectStgListByLvl(@ApiParam(value = "학습자 아이디") @PathVariable(name = "learner") String learner
			, @ApiParam(value = "레벨") @PathVariable(name = "level") String level
			, @ApiParam(value = "언어 코드") @PathVariable(name = "language") String language
			, @ApiParam(value = "학습노트 진도 VO") @Valid @RequestBody NoteMgntVO mgntVO) throws Exception {
		// 경로변수 체크 
		if((StringUtils.isNotBlank(mgntVO.getLrnMbrId()) && !learner.equals(mgntVO.getLrnMbrId()))
				|| (StringUtils.isNotBlank(mgntVO.getLvlCd()) && !level.equals(mgntVO.getLvlCd()))
				|| (StringUtils.isNotBlank(mgntVO.getLangCd()) && !language.equals(mgntVO.getLangCd()))) {
			throw this.processException("S002008"); // 데이터가 일치하지 않습니다.
		}
		// 회원체크 
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrLrnSrc == null) {
			throw this.processException("S002017");		// 해당 학습자가 존재하지 않습니다.
		}
		
		mgntVO = noteService.selectStgListByLvl(mgntVO);
		// 학습상태와 날짜를 셋팅한다.
		HashMap<String, String> param = new HashMap<String, String>();
		param.put("lrnMbrId", mgntVO.getLrnMbrId());
		param.put("lvlCd", mgntVO.getLvlCd());
		// 레벨과 학습자 아이디로 해당 레벨에 대한 스테이지 개수와 사용자가 기본이상 스테이지클리어한 스테이지 개수를 비교하여 학습상태를 표기한다  
		NoteLrnStatusVO lrnStatusVO = noteService.selectLrnStatus(param);  //학습회원 최종 스테일지, 최상 상태코드, 사용자 스테이지 수, 레벨 스테이지 수, 레벨 최종 스테이지, 실제 학습일 
		HashMap<String, String> status = apiUtil.converLrnStatus(lrnStatusVO); // COMPLETED-LEARNING (학습완료) NOW-LEARNING(학습진행중) 
		mgntVO.setStatus(status.get("status"));				// 학습상태			
		mgntVO.setTerm(status.get("term"));					// 학습기간
		mgntVO.setLrnDay(lrnStatusVO.getLrnDay()); 			// 실제학습기간
		return responseService.getSingleResult(mgntVO);
	}
	
	/**
	 * @Method 설명 : selectAnalysisLrn 학습노트 분석  
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param learner 학습자 아이디 
	 * @param level	레벨
	 * @param language 언어코드
	 * @param analysVO 
	 * @return NoteAnalysisVO (학습회원 아이디, 레벨코드, 레벨명, 학습상태, 학습기간, 언어코드, 푼문제수, 맞힌 문제수, 드릴다운수, 평균정답율, 총 학습일, 누적학습시간, 평균 풀이속도, 스테이지별 학습 진행 리스트, BEST 스테이지, WROST 스테이지 ,레벨 전체 누적 데이터)
	 * @throws Exception
	 */
	@ApiOperation(value = "분석 ", tags = {"학습노트","분석"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/note/analysis/learners/{learner}/levels/{level}/languages/{language}")
	public SingleResult<NoteAnalysisVO> selectAnalysisLrn(@ApiParam(value = "학습자 아이디") @PathVariable(name = "learner") String learner
			, @ApiParam(value = "레벨") @PathVariable(name = "level") String level
			, @ApiParam(value = "언어 코드") @PathVariable(name = "language") String language
			, @ApiParam(value = "학습노트 분석 객체") @Valid @RequestBody NoteAnalysisVO analysVO
			) throws Exception {
		// 경로변수 체크 
		if((StringUtils.isNotBlank(analysVO.getLrnMbrId()) && !learner.equals(analysVO.getLrnMbrId()))
				|| (StringUtils.isNotBlank(analysVO.getLvlCd()) && !level.equals(analysVO.getLvlCd()))
				|| (StringUtils.isNotBlank(analysVO.getLangCd()) && !language.equals(analysVO.getLangCd()))) {
			throw this.processException("S002008"); //데이터가 일치하지 않습니다.
		}
		// 회원체크 
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrLrnSrc == null) {
			throw this.processException("S002017");		// 해당 학습자가 존재하지 않습니다.
		}
		analysVO = noteService.selectAnalysisByLvl(analysVO);
		if(analysVO == null) {
			throw this.processException("S002006");		// 아직 학습한 스테이지가 없습니다.
		}
		// 학습상태와 날짜를 셋팅한다.
		HashMap<String, String> param = new HashMap<String, String>();
		param.put("lrnMbrId", analysVO.getLrnMbrId());
		param.put("lvlCd", analysVO.getLvlCd());
		// 레벨과 학습자 아이디로 해당 레벨에 대한 스테이지 개수와 사용자가 기본이상 스테이지클리어한 스테이지 개수를 비교하여 학습상태를 표기한다 
		NoteLrnStatusVO lrnStatusVO = noteService.selectLrnStatus(param); //학습회원 최종 스테일지, 최상 상태코드, 사용자 스테이지 수, 레벨 스테이지 수, 레벨 최종 스테이지, 실제 학습일 
		
		HashMap<String, String> status = apiUtil.converLrnStatus(lrnStatusVO);
		analysVO.setStatus(status.get("status"));  	// 학습상태
		analysVO.setTerm(status.get("term"));		// 학습기간 
		
		// 해당 레벨의 스테이지별 학습결과 리스트 (스테이지별 가장 최근 결과) (스테이지순번, 학습결과코드, 결과코드명, 완료스테이지 코드)
		List<NotePrgsListByStgVO> prgsByStgVO = noteService.selectPrgsByStg(param); 
		if(prgsByStgVO == null) {
			throw this.processException("S002006");		// 아직 학습한 스테이지가 없습니다.
		}
		analysVO.setPrgsByStgList(prgsByStgVO); // 스테이지별 학습결과 리스트
		
		// 가장 잘한 스테이지  힘든 스테이지 
		NoteBstWrstVO bstVO = noteService.selectBstStg(param); //스테이지 타입, 스테이지 코드, 학습결과점수 (정답률 + (1000-풀이속도)), 스테이지 명, 풀이속도 명, 정답률, 노력갯수,학습결과명
		analysVO.setBestStgInfo(bstVO);
		// 가장 힘든 스테이지 
		NoteBstWrstVO wrstVO = noteService.selectWrstStg(param); //스테이지 타입, 스테이지 코드, 학습결과점수 (정답률 + (1000-풀이속도)), 스테이지 명, 풀이속도 명, 정답률, 노력갯수,학습결과명
		analysVO.setWrostStgInfo(wrstVO);
		
		
		// 누적 학습기록 (시작 날짜, 누적 맞힌 문제수, 기본개수, 충분개수, 훌륭개수)
		NoteAccumDataVO accumDataVO = noteService.selectAccumData(param); 
		analysVO.setAccumtData(accumDataVO);
		return responseService.getSingleResult(analysVO);
	}
}
