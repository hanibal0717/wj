package com.wjthinkbig.aimath.lrn.note.vo;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 
  * @프로그램 설명 :  학습노트 분석 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "학습노트 분석 VO")
public class NoteAnalysisVO {
	
	/*
	 * 학습회원 아이디  
	 */
	@NotBlank
	@ApiModelProperty(value="학습회원 아이디")
	@FieldName("학습회원 아이디")
	private String lrnMbrId;
	
	/*
	 * 레벨코드
	 */
	@NotBlank
	@ApiModelProperty(value="레벨코드")
	@FieldName("레벨코드")
	private String lvlCd;
	
	/**
	 *  레벨명  
	 */
	@ApiModelProperty(value="레벨명")
	@FieldName("레벨명")
	private String lvlNm;
	
	/**
	 * 학습상태 
	 */
	@ApiModelProperty(value="학습상태")
	@FieldName("학습상태")
	private String status;
	
	/**
	 * 학습기간 
	 */
	@ApiModelProperty(value="학습기간")
	@FieldName("학습기간")
	private String term;
	
	
	/*
	 * 언어코드 
	 */
	@NotBlank
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;
	
	/*
	 * 푼문제수
	 */
	@ApiModelProperty(value="푼문제수")
	@FieldName("푼문제수")
	private int solvedQstCnt;
	
	/*
	 * 맞힌 문제수 
	 */
	@ApiModelProperty(value="맞힌 문제수")
	@FieldName("맞힌 문제수")
	private int rightQstCnt;
	
	/*
	 * 드릴다운수
	 */
	@ApiModelProperty(value="드릴다운수")
	@FieldName("드릴다운수")
	private int drillDownCnt;
	
	/*
	 * 평균정답율
	 */
	@ApiModelProperty(value="평균정답율")
	@FieldName("평균정답율")
	private String avgRightCnt;
	
	/*
	 * 총 학습일
	 */
	@ApiModelProperty(value="총 학습일")
	@FieldName("총 학습일")
	private int totalLrnDay;
	
	
	/*
	 * 누적학습시간 
	 */
	@ApiModelProperty(value="누적학습시간")
	@FieldName("누적학습시간")
	private String accoumTime;
	
	/*
	 * 평균 풀이속도 
	 */
	@ApiModelProperty(value="평균 풀이속도")
	@FieldName("평균 풀이속도")
	private String avgSolvTime;
	
	/*
	 * 스테이지별 학습 진행 리스트 
	 */
	@ApiModelProperty(value="스테이지별 학습 진행 리스트 ")
	@FieldName("스테이지별 학습 진행 리스트 ")
	private List<NotePrgsListByStgVO> prgsByStgList;
	
	/*
	 * BEST 스테이지
	 */
	@ApiModelProperty(value=" BEST 스테이지")
	@FieldName(" BEST 스테이지")
	private NoteBstWrstVO bestStgInfo;
	
	/*
	 * WROST 스테이지 
	 */
	@ApiModelProperty(value="WROST 스테이지 ")
	@FieldName("WROST 스테이지 ")
	private NoteBstWrstVO wrostStgInfo;
	
	/**
	 * 레벨 전체 누적 데이터 
	 */
	@ApiModelProperty(value="레벨 전체 누적 데이터  ")
	@FieldName("레벨 전체 누적 데이터  ")
	private NoteAccumDataVO accumtData;
	
}
