package com.wjthinkbig.aimath.lrn.note.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 학습자가 레벨 리스트 VO
  * @프로그램 설명 :  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "학습자가 레벨 리스트 VO")
public class NoteLvlVO {
	
	/*
	 * 레벨코드 
	 */
	@ApiModelProperty(value="레벨코드")
	@FieldName("레벨코드")
	private String lvlCd;
	
	/*
	 * 학습자 아이디 
	 */
	@ApiModelProperty(value="학습자 아이디 ")
	@FieldName("학습자 아이디 ")
	private String lrnMbrId;
	
	/**
	 * 레벨 표기
	 */
	@ApiModelProperty(value="레벨 표기 ")
	@FieldName("레벨 표기 ")
	private String lvlTxt;
	
	/**
	 * 레벨명  
	 */
	@ApiModelProperty(value="레벨명")
	@FieldName("레벨명")
	private String lvlNm;
	
	/**
	 * 레벨명  
	 */
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;
}
