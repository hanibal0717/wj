package com.wjthinkbig.aimath.lrn.cmn.vo;

import java.time.LocalDateTime;
import java.util.List;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 27.
  * @프로그램 설명 : 학습하기 결과 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 27.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="학습하기 결과 정보")
public class LrnCmnResVO extends BaseVO {
	
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd;						/* 소주제코드 */
	
	@ApiModelProperty(value="소주제명")
	@FieldName("소주제명")
	private String stgNm;						/* 소주제명 */
	
	@ApiModelProperty(value="학습종료일시")
	@FieldName("학습종료일시")
	private LocalDateTime lrnEndDt;				/* 학습종료일시 */
	
	@ApiModelProperty(value="학습진행 상태코드")
	@FieldName("학습진행 상태코드")
	private String lrnPrgsStsCd;				/* 학습진행 상태코드 */
	
	@ApiModelProperty(value="학습진행 상태코드명")
	@FieldName("학습진행 상태코드명")
	private String lrnPrgsStsCdNm;				/* 학습진행 상태코드명 */
	
	@ApiModelProperty(value="드릴다운 횟수")
	@FieldName("드릴다운 횟수")
	private int drilldwCt;						/* 드릴다운 횟수 */
	
	@ApiModelProperty(value="총 문항 수")
	@FieldName("총 문항 수")
	private int totQstCt;						/* 총 문항 수 */
	
	@ApiModelProperty(value="정답문항수")
	@FieldName("정답문항수")
	private int cransrQstCt;					/* 정답문항수 */
	
	@ApiModelProperty(value="오답문항수")
	@FieldName("오답문항수")
	private int wransrQstCt;					/* 오답문항수 */
	
	@ApiModelProperty(value="정답률")
	@FieldName("정답률")
	private int cransrAvg;						/* 정답률 */
	
	@ApiModelProperty(value="풀이속도코드")
	@FieldName("풀이속도코드")
	private String explSpedCd;					/* 풀이속도코드 */
	
	@ApiModelProperty(value="풀이속도코드명")
	@FieldName("풀이속도코드명")
	private String explSpedCdNm;				/* 풀이속도코드명 */
	
	@ApiModelProperty(value="풀이정확도코드")
	@FieldName("풀이정확도코드")
	private String explAcrcyCd;					/* 풀이정확도코드 */
	
	@ApiModelProperty(value="누적학습시간(초)")
	@FieldName("누적학습시간(초)")
	private int lrnTotScond;					/* 누적학습시간(초) */
	
	@ApiModelProperty(value="드릴다운 문항수")
	@FieldName("드릴다운 문항수")
	private int drilldwQstCt;					/* 드릴다운 문항수 */
	
	@ApiModelProperty(value="추천소주제코드")
	@FieldName("추천소주제코드")
	private String rcmnSbthmaCd;				/* 추천소주제코드 */
	
	@ApiModelProperty(value="추천소주제코드명")
	@FieldName("추천소주제코드명")
	private String rcmnSbthmaCdNm;				/* 추천소주제코드명 */
	
	@ApiModelProperty(value="개념메타 영상 URL")
	@FieldName("개념메타 영상 URL")
	private String cncpMeta;					/* 개념메타 영상 URL */
	
	@ApiModelProperty(value="드릴다운 개념메타 영상 URL")
	@FieldName("드릴다운 개념메타 영상 URL")
	private String drilldwCncpMeta;				/* 드릴다운 개념메타 영상 URL */
	
	@ApiModelProperty(value="다음 소주제 코드 조회")
	@FieldName("다음 소주제 코드 조회")
	private String nextStgCd;					/* 다음 소주제 코드 조회 */
	
	@ApiModelProperty(value="현재 레벨 코드")
	@FieldName("현재 레벨 코드")
	private String lvlCd;						/* 현재 레벨 코드 */
	
	@ApiModelProperty(value="이번소주제를 학습한 횟수")
	@FieldName("이번소주제를 학습한 횟수")
	private int lrnTmeSn;						/* 이번소주제를 학습한 횟수 */
	
	@ApiModelProperty(value="AI 메시지")
	@FieldName("AI 메시지")
	private String aiMsge;						/* AI 메시지 */
	
	@ApiModelProperty(value="결과 그래프 정보 리스트")
	@FieldName("결과 그래프 정보 리스트")
	private List<LrnCmnResVO> lrnCmnResList;
	
}
