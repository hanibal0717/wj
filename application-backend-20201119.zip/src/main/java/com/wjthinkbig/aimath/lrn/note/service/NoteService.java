package com.wjthinkbig.aimath.lrn.note.service;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import com.wjthinkbig.aimath.lrn.note.vo.NoteAccumDataVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAnalysisVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteBstWrstVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLrnStatusVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLvlVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteMgntVO;
import com.wjthinkbig.aimath.lrn.note.vo.NotePrgsListByStgVO;

/**
  * @Date : 2020. 10. 20 
  * @프로그램 설명 :  NoteService.java  학습노트 서비스 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20     Kim Hee Seok       최초작성
  * </pre>
  */
public interface NoteService {

	/**
	 * @Method 설명 : selectLvlListByMbr 학습자 아이디와 언어코드로  학습한 레벨 리스트 조회
	 * @author Kim Hee Seok [2020. 10. 20]
	 * @param lvlVO 레벨객체 
	 * @return List<NoteLvlVO> 레벨코드, 학습자 아이디, 레벨표기, 레벨명
	 */
	List<NoteLvlVO> selectListLvlByMbr(NoteLvlVO lvlVO) throws Exception;

	/**
	 * @Method 설명 : selectLvlNameByStgCd 특정학습자의 적정시작 레벨과 레벨명을 가져온다.
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param lvlVO 레벨객체 
	 * @return NoteLvlVO 레벨코드, 학습자 아이디, 레벨표기, 레벨명
	 * @throws Exception
	 */
	NoteLvlVO selectLvlNameByStgCd(NoteLvlVO lvlVO) throws Exception;

	/**
	 * @Method 설명 : selectStgListByLvl 사용자의  해당 레벨 진도 리스트를 ResultMap으로 받아온다 
	 * @author Kim Hee Seok [2020. 10. 22]
	 * @param mgntVO 진도 객체 (학습회원 최종 스테일지, 최상 상태코드, 사용자 스테이지 수, 레벨 스테이지 수, 레벨 최종 스테이지, 실제 학습일 )
	 * @return NoteMgntVO 레벨코드, 레벨명, 학습회원 아이디, 언어코드, 학습상태, 학습기간
	 * @throws Exception
	 */
	NoteMgntVO selectStgListByLvl(NoteMgntVO mgntVO) throws Exception;

	/**
	 * @Method 설명 : selectLrnStatus 학습상태와 학습 기간 가져온다.
	 * @author Kim Hee Seok [2020. 10. 23]
	 * @param param 학습자 아이디,레벨코드 
	 * @return NoteLrnStatusVO 학습상태 객체 
	 */
	NoteLrnStatusVO selectLrnStatus(HashMap<String, String> param) throws Exception;

	/**
	 * @Method 설명 : selectAnalysisByLvl 학습 노트 분석
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param analysVO 분석객체 
	 * @return NoteAnalysisVO ((학습회원 아이디, 레벨코드, 레벨명, 학습상태, 학습기간, 언어코드, 푼문제수, 맞힌 문제수, 드릴다운수, 평균정답율, 총 학습일, 누적학습시간, 평균 풀이속도, 스테이지별 학습 진행 리스트, BEST 스테이지, WROST 스테이지 ,레벨 전체 누적 데이터))
	 */
	NoteAnalysisVO selectAnalysisByLvl(@Valid NoteAnalysisVO analysVO) throws Exception;

	/**
	 * @Method 설명 : selectPrgsByStg 해당 레벨에 스테이지 학습상태 리스트를 가져온다.  
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param param 학습자 아이디,레벨코드 
	 * @return 해당 레벨의 스테이지 리스트와 스테이지별 학습 결과 VO ((스테이지순번, 학습결과코드, 결과코드명, 완료스테이지 코드))
	 */
	List<NotePrgsListByStgVO> selectPrgsByStg(HashMap<String, String> param) throws Exception;

	/**
	 * @Method 설명 : selectAccumData 해당 레벨의 누적 데이터를 가지고 온다 
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param param 학습자 아이디,레벨코드  
	 * @return NoteAccumDataVO 누적데이터 객체 ((시작 날짜, 누적 맞힌 문제수, 기본개수, 충분개수, 훌륭개수))
	 */
	NoteAccumDataVO selectAccumData(HashMap<String, String> param) throws Exception;

	/**
	 * @Method 설명 : selectBstStg 가장 잘한 스테이지 
	 * @author Kim Hee Seok [2020. 10. 29]
	 * @param param 학습자 아이디,레벨코드 ,언어코드 
	 * @return NoteBstWrstVO 잘한 스테이지 객체 (스테이지 타입, 스테이지 코드, 학습결과점수 (정답률 + (1000-풀이속도)), 스테이지 명, 풀이속도 명, 정답률, 노력갯수,학습결과명)
	 * @throws Exception 
	 */
	NoteBstWrstVO selectBstStg(HashMap<String, String> param) throws Exception;

	/**
	 * @Method 설명 : selectWrstStg 가장 힘든 스테이지 
	 * @author Kim Hee Seok [2020. 10. 29]
	 * @param param 학습자 아이디,레벨코드 ,언어코드 
	 * @return NoteBstWrstVO 가장 힘든 스테이지  (스테이지 타입, 스테이지 코드, 학습결과점수 (정답률 + (1000-풀이속도)), 스테이지 명, 풀이속도 명, 정답률, 노력갯수,학습결과명)
	 */
	NoteBstWrstVO selectWrstStg(HashMap<String, String> param) throws Exception;


}
