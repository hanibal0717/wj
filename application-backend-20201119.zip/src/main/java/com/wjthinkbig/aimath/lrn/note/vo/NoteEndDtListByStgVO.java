package com.wjthinkbig.aimath.lrn.note.vo;

import java.time.LocalDateTime;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 
  * @프로그램 설명 : 해당스테이지의 학습 종료 날짜 학습결과 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "해당스테이지의 학습 종료 날짜 학습결과 VO")
public class NoteEndDtListByStgVO {
	
	/**
	 * 종료날짜 
	 */
	@ApiModelProperty(value="종료날짜")
	@FieldName("종료날짜")
	private LocalDateTime lrnEndDt;
	
	/**
	 * 스테이지코드 
	 */
	@ApiModelProperty(value="스테이지코드")
	@FieldName("스테이지코드")
	private String stgCd;
	
	/**
	 * 진행 코드 
	 */
	@ApiModelProperty(value="진행 코드")
	@FieldName("진행 코드")
	private String lrnPrgsStsCd;
	
	/**
	 * 코드명 
	 */
	@ApiModelProperty(value="코드명")
	@FieldName("코드명")
	private String cdNm;
}
