package com.wjthinkbig.aimath.lrn.note.service.dao;

import java.util.HashMap;
import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAccumDataVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAnalysisVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteBstWrstVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLrnStatusVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLvlVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteMgntVO;
import com.wjthinkbig.aimath.lrn.note.vo.NotePrgsListByStgVO;

@Mapper("noteDao")
public interface NoteDao {

	/**
	 * @Method 설명 : selectLvlListByMbr 학습자 아이디와 언어코드로  학습레벨 리스트 조회
	 * @author Kim Hee Seok [2020. 10. 20]
	 * @param lvlVO 레벨객체 
	 * @return List<NoteLvlVO> 레벨객체 리스트 
	 */
	List<NoteLvlVO> selectListLvlByMbr(NoteLvlVO lvlVO);

	/**
	 * @Method 설명 : selectLvlNameByStgCd 특정학습자의 학습노트 시작 레벨과 레벨명을 가져온다.
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param lvlVO 레벨객체 
	 * @return NoteLvlVO 레벨객체 
	 * @throws Exception
	 */
	NoteLvlVO selectLvlNameByStgCd(NoteLvlVO lvlVO);

	/**
	 * @Method 설명 : selectStgListByLvl 사용자 레벨별 진도 리스트를 ResultMap으로 받아온다 
	 * @author Kim Hee Seok [2020. 10. 22]
	 * @param mgntVO 진도 객체 
	 * @return NoteMgntVO 진도 객체 
	 * @throws Exception
	 */
	NoteMgntVO selectStgListByLvl(NoteMgntVO mgntVO);

	/**
	 * @Method 설명 : selectLrnStatus 학습상태와 날짜가져온다.
	 * @author Kim Hee Seok [2020. 10. 23]
	 * @param param 학습자 아이디,레벨코드 
	 * @return NoteLrnStatusVO 학습상태 객체 
	 */
	NoteLrnStatusVO selectLrnStatus(HashMap<String, String> param);

	/**
	 * @Method 설명 : selectAnalysisByLvl 학습 노트 분석
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param analysVO 분석객체 
	 * @return NoteLrnStatusVO 학습상태 객체 
	 */
	NoteAnalysisVO selectAnalysisByLvl(NoteAnalysisVO analysVO);


	/**
	 * @Method 설명 : selectPrgsByStg 해당 레벨에 스테이지 학습상태 리스트를 가져온다.  
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param param 학습자 아이디,레벨코드 
	 * @return 해당 레벨의 스테이지 리스트와 스테이지별 학습 결과 VO
	 */
	List<NotePrgsListByStgVO> selectPrgsByStg(HashMap<String, String> param);

	/**
	 * @Method 설명 : selectAccumData 해당 레벨의 누적 데이터를 가지고 온다 
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param param 학습자 아이디,레벨코드 
	 * @return NoteAccumDataVO 누적데이터 캑체 
	 */
	NoteAccumDataVO selectAccumData(HashMap<String, String> param);

	
	/**
	 * @Method 설명 : selectWrstStg 가장 힘든  스테이지 
	 * @author Kim Hee Seok [2020. 10. 29]
	 * @param param 학습자 아이디,레벨코드 ,언어코드 
	 * @return NoteBstWrstVO BstWrst 스테이지 객체 
	 */
	NoteBstWrstVO selectWrstStg(HashMap<String, String> param);

	/**
	 * @Method 설명 : selectBstStg 가장 잘한  스테이지 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param param 학습자 아이디,레벨코드 ,언어코드 
	 * @return NoteBstWrstVO BstWrst 스테이지 객체 
	 */
	NoteBstWrstVO selectBstStg(HashMap<String, String> param);
	
}
