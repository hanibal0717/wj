package com.wjthinkbig.aimath.lrn.thma.vo;

import java.time.LocalDateTime;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 20.
  * @프로그램 설명 : 사용자 주제학습 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="사용자 주제학습 정보")
public class LrnThmaVO extends BaseVO {
	
	@ApiModelProperty(value="주제코드")
	@FieldName("주제코드")
	private String thmaCd; 						/* 주제코드 */

	@ApiModelProperty(value="주제명")
	@FieldName("주제명")
	private String thmaNm; 						/* 주제명 */

	@ApiModelProperty(value="이미지파일경로")
	@FieldName("이미지파일경로")
	private String imgFilePath; 				/* 이미지파일경로 */

	@ApiModelProperty(value="이미지파일명")
	@FieldName("이미지파일명")
	private String imgFileNm; 					/* 이미지파일명 */

	@ApiModelProperty(value="노출순서")
	@FieldName("노출순서")
	private int dspOdr; 						/* 노출순서 */

	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn; 						/* 사용여부 */
	
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd;						/* 소주제코드 */
	
	@ApiModelProperty(value="소주제 이미지 파일경로")
	@FieldName("소주제 이미지 파일경로")
	private String stgImgFilePath;				/* 소주제 이미지 파일경로 */
	
	@ApiModelProperty(value="소주제 이미지 파일명")
	@FieldName("소주제 이미지 파일명")
	private String stgImgFileNm;				/* 소주제 이미지 파일명 */
	
	@ApiModelProperty(value="소주제명")
	@FieldName("소주제명")
	private String stgNm; 						/* 소주제명 */
	
	@ApiModelProperty(value="스텝명")
	@FieldName("스텝명")
	private String stepNm; 						/* 스텝명 */
	
	@ApiModelProperty(value = "학습종료일시") 
	@FieldName("학습종료일시")
	private LocalDateTime lrnEndDt; 			/* 학습종료일시 */
	
	@ApiModelProperty(value="학습진행상태코드")
	@FieldName("학습진행상태코드")
	private String lrnPrgsStsCd; 				/* 학습진행상태코드 */
	
	@ApiModelProperty(value="마지막진행 소주제 여부")
	@FieldName("마지막진행 소주제 여부")
	private String lastStgYn; 					/* 마지막진행 소주제 여부 */
	
	@ApiModelProperty(value="하위 소주제 수")
	@FieldName("하위 소주제 수")
	private int stgCnt; 						/* 하위 소주제 수 */
	
}
