package com.wjthinkbig.aimath.lrn.cmn.vo;

import java.time.LocalDateTime;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 22.
  * @프로그램 설명 : 학습하기 공통 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 22.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="학습하기 공통 정보")
public class LrnCmnVO extends BaseVO {
	
	@ApiModelProperty(value="학습회원ID")
	@FieldName("학습회원ID")
	private String lrnMbrId;					/* 학습회원ID */
	
	@ApiModelProperty(value="예측 문항 수")
	@FieldName("예측 문항 수")
	private int aiPrdcnQstCt;					/* 예측 문항 수 */
	
	@ApiModelProperty(value="현재까지 문항 수")
	@FieldName("현재까지 문항 수")
	private int estQstNowNo;					/* 현재까지 문항 수 */
	
	@ApiModelProperty(value="예측시간")
	@FieldName("예측시간")
	private int estDiagDur;						/* 예측시간 */
	
	@ApiModelProperty(value="문제의 예측 풀이 시간 최대 값")
	@FieldName("문제의 예측 풀이 시간 최대 값")
	private long estQstDurMax;					/* 문제의 예측 풀이 시간 최대 값 */
	
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd;						/* 소주제코드 */
	
	@ApiModelProperty(value="소주제명")
	@FieldName("소주제명")
	private String stgNm;						/* 소주제명 */
	
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;						/* 문항코드 */
	
	@ApiModelProperty(value="폰트크기")
	@FieldName("폰트크기")
	private String fontSize;					/* 폰트크기 */
	
	@ApiModelProperty(value="지문내용")
	@FieldName("지문내용")
	private String textCn;						/* 지문내용 */
	
	@ApiModelProperty(value="문항내용")
	@FieldName("문항내용")
	private String qstCn;						/* 문항내용 */
	
	@ApiModelProperty(value="보기내용")
	@FieldName("보기내용")
	private String exmpCn;						/* 보기내용 */
	
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;						/* 언어코드 */
	
	@ApiModelProperty(value="문항정답")
	@FieldName("문항정답")
	private String qstCransr;					/* 문항정답 */
	
	@ApiModelProperty(value="정답유형구분코드")
	@FieldName("정답유형구분코드")
	private String cransrTyScnCd;				/* 정답유형구분코드 */
	
	@ApiModelProperty(value="개념메타URL")
	@FieldName("개념메타URL")
	private String cncpMeta;					/* 개념메타URL */
	
	@ApiModelProperty(value="키패드유형코드")
	@FieldName("키패드유형코드")
	private String kypdTyCd;					/* 키패드유형코드 */
	
	@ApiModelProperty(value="학습진입구분코드")
	@FieldName("학습진입구분코드")
	private String lrnEntyScnCd;				/* 학습진입구분코드 */
	
	@ApiModelProperty(value="맞힐수있는데 틀린문항 여부")
	@FieldName("맞힐수있는데 틀린문항 여부")
	private String corPsbleQstYn;				/* 맞힐수있는데 틀린문항 여부 */
	
	@ApiModelProperty(value="진행코드")
	@FieldName("진행코드")
	private String prgsCd;						/* 진행코드 */
	
	@ApiModelProperty(value="입력방식")
	@FieldName("입력방식")
	private String inputTy;						/* 입력방식 */
	
	@ApiModelProperty(value="시간초과여부")
	@FieldName("시간초과여부")
	private String overTmYn;					/* 시간초과여부 */
	
	@ApiModelProperty(value="개념영상 Skip 여부")
	@FieldName("개념영상 Skip 여부")
	private String movieSkipYn;					/* 개념영상 Skip 여부 */
	
	@ApiModelProperty(value="개념영상 시간")
	@FieldName("개념영상 시간")
	private String movieTm;						/* 개념영상 시간 */
	
	@ApiModelProperty(value="누적학습시간(초)")
	@FieldName("누적학습시간(초)")
	private int lrnTotScond;					/* 누적학습시간(초) */
	
	@ApiModelProperty(value="문제풀이시간")
	@FieldName("문제풀이시간")
	private long slvTime;						/* 문제풀이시간 */
	
	@ApiModelProperty(value="입력에 소요된 시간")
	@FieldName("입력에 소요된 시간")
	private long inptTime;						/* 입력에 소요된 시간 */
	
	@ApiModelProperty(value="드릴다운 횟수")
	@FieldName("드릴다운 횟수")
	private int drilldwCt;						/* 드릴다운 횟수 */
	
	@ApiModelProperty(value="드릴다운 소주제 코드")
	@FieldName("드릴다운 소주제 코드")
	private String drilldwStgCd;				/* 드릴다운 소주제 코드 */
	
	@ApiModelProperty(value="드릴다운 뎁스")
	@FieldName("드릴다운 뎁스")
	private int drilldwDepth;					/* 드릴다운 뎁스 */
	
	@ApiModelProperty(value="드릴다운으로 푼 문항수")
	@FieldName("드릴다운으로 푼 문항수")
	private int drilldwQstCt;					/* 드릴다운으로 푼 문항수 */
	
	@ApiModelProperty(value="풀이속도코드")
	@FieldName("풀이속도코드")
	private String explSpedCd;					/* 풀이속도코드 */
	
	@ApiModelProperty(value="추천소주제코드")
	@FieldName("추천소주제코드")
	private String rcmnSbthmaCd;				/* 추천소주제코드 */
	
	@ApiModelProperty(value="학습시작일시")
	@FieldName("학습시작일시")
	private LocalDateTime lrnBgnDt;				/* 학습시작일시 */
	
	@ApiModelProperty(value="학습종료일시")
	@FieldName("학습종료일시")
	private LocalDateTime lrnEndDt;				/* 학습종료일시 */
	
	@ApiModelProperty(value="정답문항수")
	@FieldName("정답문항수")
	private int cransrQstCt;					/* 정답문항수 */
	
	@ApiModelProperty(value="오답문항수")
	@FieldName("오답문항수")
	private int wransrQstCt;					/* 오답문항수 */
	
	@ApiModelProperty(value="드릴다운정답문항수")
	@FieldName("드릴다운정답문항수")
	private int drilldwCransrQstCt;				/* 드릴다운정답문항수 */
	
	@ApiModelProperty(value="드릴다운오답문항수")
	@FieldName("드릴다운오답문항수")
	private int drilldwWransrQstCt;				/* 드릴다운오답문항수 */
	
	@ApiModelProperty(value="학습진행 상태코드")
	@FieldName("학습진행 상태코드")
	private String lrnPrgsStsCd;				/* 학습진행 상태코드 */
	
	@ApiModelProperty(value="풀이정확도코드")
	@FieldName("풀이정확도코드")
	private String explAcrcyCd;					/* 풀이정확도코드 */
	
	@ApiModelProperty(value="이번소주제를 학습한 횟수")
	@FieldName("이번소주제를 학습한 횟수")
	private int lrnTmeSn;						/* 이번소주제를 학습한 횟수 */
	
	@ApiModelProperty(value="AI 메시지")
	@FieldName("AI 메시지")
	private String aiMsge;						/* AI 메시지 */
	
	@ApiModelProperty(value="총 문항 수")
	@FieldName("총 문항 수")
	private int totQstCt;						/* 총 문항 수 */
}
