package com.wjthinkbig.aimath.lrn.cous.service;

import java.util.List;
import java.util.Map;

import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousSearchVO;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousVO;

/**
  * @Date : 2020. 10. 13.
  * @프로그램 설명 : 사용자 코스학습 관련 Service
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13.     19001861            최초작성
  * </pre>
  */
public interface LrnCousService {
	
	/**
	  * @Method 설명 : 코스학습 시작 소주제 코드 조회
	  * @param lrnCousSearch
	  * @return
	  * @throws Exception
	  */
	public String selectStartStgCd(LrnCousSearchVO lrnCousSearch) throws Exception;
	
	/**
	  * @Method 설명 : 코스학습 리스트 조회
	  * @param lrnCousSearch
	  * @return
	  * @throws Exception
	  */
	public Map<String, Object> selectLrnCousList(LrnCousSearchVO lrnCousSearch) throws Exception;
	
	/**
	  * @Method 설명 : 코스학습 완료 리스트 조회
	  * @param lrnCousSearch
	  * @return
	  * @throws Exception
	  */
	public List<LrnCousVO> selectLrnCousEndList(LrnCousSearchVO lrnCousSearch) throws Exception;
	
	/**
	  * @Method 설명 : 코스학습 현재 레벨 정보 조회
	  * @param lrnCousSearch
	  * @return
	  * @throws Exception
	  */
	public LrnCousVO selectLrnCousLvlInfo(LrnCousSearchVO lrnCousSearch) throws Exception;
	
	/**
	  * @Method 설명 : 코스학습 완료 단일 정보 조회
	  * @param lrnCousSearch
	  * @return
	  * @throws Exception
	  */
	public LrnCousVO selectLrnCousEndInfo(LrnCousSearchVO lrnCousSearch) throws Exception;
	
	/**
	  * @Method 설명 : 코스학습 레벨 결과 정보 조회
	  * @param lrnCousSearch
	  * @return
	  * @throws Exception
	  */
	public LrnCousVO selectLrnCousLvlRes(LrnCousSearchVO lrnCousSearch) throws Exception;
	
	/**
	  * @Method 설명 : 코스학습 레벨 완료 이력 등록
	  * @param lrnCous
	  * @throws Exception
	  */
	public void insertLnrLvlentyHst(LrnCousVO lrnCous) throws Exception;
}
