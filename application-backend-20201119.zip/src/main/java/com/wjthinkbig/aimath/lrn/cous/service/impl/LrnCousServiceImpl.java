package com.wjthinkbig.aimath.lrn.cous.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.lrn.cous.service.LrnCousService;
import com.wjthinkbig.aimath.lrn.cous.service.dao.LrnCousDao;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousSearchVO;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousVO;
import com.wjthinkbig.aimath.msge.service.dao.MsgeDao;
import com.wjthinkbig.aimath.msge.vo.MsgeSearchVO;
import com.wjthinkbig.aimath.msge.vo.MsgeVO;

/**
  * @Date : 2020. 10. 13.
  * @프로그램 설명 : 사용자 코스학습 관련 Service
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13.     19001861            최초작성
  * </pre>
  */
@Service("lrnCousService")
public class LrnCousServiceImpl extends BaseServiceImpl implements LrnCousService {
	
	/**
	 * 사용자 코스학습 Dao
	 */
	@Resource(name = "lrnCousDao")
	private LrnCousDao lrnCousDao;
	
	/**
	 * AWS S3 도메인
	 */
	private static String domain;
	@Value("${aws.domain}")
	public void setDomain(String url) {
		domain = url;
	}
	
	/**
	 * AWS S3 bucketName 키값
	 */
	private static String bucketName;
	@Value("${aws.bucket.name}")
	public void setBucketName(String name) {
		bucketName = name;
	}
	
	/**
	 * AI 상황별 메시지 Dao
	 */
	@Resource(name = "msgeDao")
	private MsgeDao msgeDao;
	
	@Override
	public String selectStartStgCd(LrnCousSearchVO lrnCousSearch) throws Exception {
		return lrnCousDao.selectStartStgCd(lrnCousSearch);
	}

	@Override
	public Map<String, Object> selectLrnCousList(LrnCousSearchVO lrnCousSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<LrnCousVO> lrnCousList = lrnCousDao.selectLrnCousList(lrnCousSearch);
		
		if( lrnCousList != null && lrnCousList.size() > 0 ) {
			for( int i = 0; i < lrnCousList.size(); i++ ) {
				//파일 경로에 S3 도메인을 넣어준다
				if( StringUtils.isNotEmpty(lrnCousList.get(i).getStgImgFilePath()) ) {
					lrnCousList.get(i).setStgImgFilePath(domain + "/" + bucketName + lrnCousList.get(i).getStgImgFilePath());
				}
			}
			
			resultMap.put("lrnCousList", lrnCousList);
			
			/************************************************
			 * AI 메시지 조회
			 ************************************************/
			MsgeSearchVO msgeSearch = new MsgeSearchVO();
			
			if( lrnCousList.get(0).getRowNum() == 1 ) {
				//레벨 시작 후 첫번째 스테이지가 자리잡고 나서
				msgeSearch.setDspSitutCd("MSG002");
			} else if( lrnCousList.size() == 1 ) {
				//마지막 스테이지가 자리잡고 나서 - 코스학습이 하나의 코스에 1개의 스테이지만 존재할 경우는 마지막 하나의 스테이지만 남았을 경우에만 가능
				msgeSearch.setDspSitutCd("MSG001");
			}
			
			if( StringUtils.isNotEmpty(msgeSearch.getDspSitutCd()) ) {
				msgeSearch.setUseYn("Y");
				msgeSearch.setLangCd(lrnCousSearch.getLangCd());
				
				List<MsgeVO> msgeList = msgeDao.selectMsgeListByDspSitutCd(msgeSearch);
				
				if( msgeList != null && msgeList.size() > 0 ) {
					//메시지가 존재할 경우 - random 으로 하나 선택
					String msge = null;
					
					if( msgeList.size() > 1 ) {
						Random random = new Random();
						msge = msgeList.get( random.nextInt( msgeList.size() - 1 ) ).getComntCn();
					} else {
						msge = msgeList.get(0).getComntCn();
					}
					
					resultMap.put("aiMsge", msge);
				}
			}
		} else {
			resultMap.put("aiMsge", null);
			resultMap.put("lrnCousList", null);
		}
		
		return resultMap;
	}
	
	@Override
	public List<LrnCousVO> selectLrnCousEndList(LrnCousSearchVO lrnCousSearch) throws Exception {
		return lrnCousDao.selectLrnCousEndList(lrnCousSearch);
	}
	
	@Override
	public LrnCousVO selectLrnCousLvlInfo(LrnCousSearchVO lrnCousSearch) throws Exception {
		return lrnCousDao.selectLrnCousLvlInfo(lrnCousSearch);
	}

	@Override
	public LrnCousVO selectLrnCousEndInfo(LrnCousSearchVO lrnCousSearch) throws Exception {
		LrnCousVO lrnCous = lrnCousDao.selectLrnCousEndInfo(lrnCousSearch);
		
		if( lrnCous != null ) {
			//파일 경로에 S3 도메인을 넣어준다
			if( StringUtils.isNotEmpty(lrnCous.getStgImgFilePath()) ) {
				lrnCous.setStgImgFilePath(domain + "/" + bucketName + lrnCous.getStgImgFilePath());
			}
		}
		
		return lrnCous;
	}

	@Override
	public LrnCousVO selectLrnCousLvlRes(LrnCousSearchVO lrnCousSearch) throws Exception {
		LrnCousVO lrnCous = lrnCousDao.selectLrnCousLvlRes(lrnCousSearch);
		
		/************************************************
		 * AI 메시지 조회
		 ************************************************/
		if( lrnCous != null ) {
			//마지막 스테이지가 완료탭으로 사라지고 레벨완료디자인이 자리잡고 나서
			MsgeSearchVO msgeSearch = new MsgeSearchVO();
			msgeSearch.setDspSitutCd("MSG003");
			msgeSearch.setUseYn("Y");
			msgeSearch.setLangCd(lrnCousSearch.getLangCd());
			
			List<MsgeVO> msgeList = msgeDao.selectMsgeListByDspSitutCd(msgeSearch);
			
			if( msgeList != null && msgeList.size() > 0 ) {
				//메시지가 존재할 경우 - random 으로 하나 선택
				String msge = null;
				
				if( msgeList.size() > 1 ) {
					Random random = new Random();
					msge = msgeList.get( random.nextInt( msgeList.size() - 1 ) ).getComntCn();
				} else {
					msge = msgeList.get(0).getComntCn();
				}
				
				lrnCous.setAiMsge(msge);
			}
		}
		
		return lrnCous;
	}

	@Override
	public void insertLnrLvlentyHst(LrnCousVO lrnCous) throws Exception {
		lrnCousDao.insertLnrLvlentyHst(lrnCous);
	}
}
