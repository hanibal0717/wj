package com.wjthinkbig.aimath.lrn.cmn.service;

import java.util.List;

import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnResSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnResVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnWransrSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnWransrVO;

/**
  * @Date : 2020. 10. 21.
  * @프로그램 설명 : 사용자 학습하기 공통
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 21.     19001861            최초작성
  * </pre>
  */
public interface LrnCmnService {
	
	/**
	  * @Method 설명 : 학습하기 예측 문항 수, 예측 시간 API 조회
	  * @param lrnCmnSearch
	  * @return
	  * @throws Exception
	  */
	public LrnCmnVO selectAIPredictionInfo(LrnCmnSearchVO lrnCmnSearch) throws Exception;
	
	/**
	  * @Method 설명 : 학습하기 AI 예측 정보 및 문항정보 조회
	  * @param lrnCmnSearch
	  * @return
	  * @throws Exception
	  */
	public LrnCmnVO selectAIPrdcnQst(LrnCmnSearchVO lrnCmnSearch) throws Exception;
	
	/**
	  * @Method 설명 : 학습하기 정오답 체크
	  * @param lrnCmn
	  * @return
	  * @throws Exception
	  */
	public String cransrCheck(LrnCmnVO lrnCmn) throws Exception;
	
	/**
	  * @Method 설명 : 학습하기 진행 및 종료
	  * @param lrnCmn
	  * @return
	  * @throws Exception
	  */
	public LrnCmnVO procLrnCmnStudy(LrnCmnVO lrnCmn) throws Exception;
	
	/**
	  * @Method 설명 : 학습하기 결과 정보 조회
	  * @param lrnCmnSearch
	  * @return
	  * @throws Exception
	  */
	public LrnCmnResVO selectLrnCmnRes(LrnCmnResSearchVO lrnCmnResSearch) throws Exception;
	
	/**
	  * @Method 설명 : 학습하기 오답노트 리스트
	  * @param lrnWransrSearch
	  * @return
	  * @throws Exception
	  */
	public List<LrnWransrVO> selectLrnCmnWransr(LrnWransrSearchVO lrnWransrSearch) throws Exception;
}
