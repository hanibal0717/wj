package com.wjthinkbig.aimath.lrn.cous.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.lrn.cous.service.LrnCousService;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousSearchVO;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 13.
  * @프로그램 설명 : 사용자 코스학습
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="사용자 코스학습")
@RestController
public class LrnCousController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 사용자 코스학습 서비스
	 */
	@Resource(name = "lrnCousService")
	private LrnCousService lrnCousService;
	
	/**
	  * @Method 설명 : 사용자 코스학습 리스트 조회
	  * @param chn_cd
	  * @param lang_cd
	  * @param lrn_mbr_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="코스학습 리스트 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/course/channel/{channel}/language/{language}/member/{lrnMbrId}")	
	public SingleResult<Map<String, Object>> selectLrnCousList(@ApiParam(value = "채널코드") @PathVariable(name="channel",required=true) String chn_cd
			, @ApiParam(value = "언어코드") @PathVariable(name="language", required=true) String lang_cd
			, @ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id) throws Exception {
		Map<String, Object> resultMap = null;
		
		//검색 조건 셋팅
		LrnCousSearchVO lrnCousSearch = new LrnCousSearchVO();
		lrnCousSearch.setChnCd(chn_cd);
		lrnCousSearch.setLangCd(lang_cd);
		lrnCousSearch.setLrnMbrId(lrn_mbr_id);
		
		//시작 지점 소주제 조회 - 소주제가 없을 경우 진단내역이 없다고 판단 할 수 있음.
		String stgCd = lrnCousService.selectStartStgCd(lrnCousSearch);
		
		if( StringUtils.isNotEmpty(stgCd) ) {
			lrnCousSearch.setStgCd(stgCd);
			
			//현재 레벨 정보 조회
			LrnCousVO lrnCousLvl = lrnCousService.selectLrnCousLvlInfo(lrnCousSearch);
			
			if( lrnCousLvl != null ) {
				lrnCousSearch.setLvlCd(lrnCousLvl.getLvlCd());
				
				//리스트 조회
				resultMap = lrnCousService.selectLrnCousList(lrnCousSearch);
			}
		} else {
			throw this.processException("S001029");		//진단이력이 존재하지 않습니다.
		}
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 코스학습 완료 리스트 조회
	  * @param chn_cd
	  * @param lang_cd
	  * @param lrn_mbr_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="코스학습 완료 리스트 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/course/end/channel/{channel}/language/{language}/member/{lrnMbrId}")	
	public ListResult<LrnCousVO> selectLrnCousEndList(@ApiParam(value = "채널코드") @PathVariable(name="channel",required=true) String chn_cd
			, @ApiParam(value = "언어코드") @PathVariable(name="language", required=true) String lang_cd
			, @ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id) throws Exception {
		LrnCousVO lrnCousLvl = null;
		
		//검색 조건 셋팅
		LrnCousSearchVO lrnCousSearch = new LrnCousSearchVO();
		lrnCousSearch.setChnCd(chn_cd);
		lrnCousSearch.setLangCd(lang_cd);
		lrnCousSearch.setLrnMbrId(lrn_mbr_id);
		
		//시작 지점 소주제 조회 - 소주제가 없을 경우 진단내역이 없다고 판단 할 수 있음.
		String stgCd = lrnCousService.selectStartStgCd(lrnCousSearch);
		
		if( StringUtils.isNotEmpty(stgCd) ) {
			List<LrnCousVO> lrnCousList = null;
			lrnCousSearch.setStgCd(stgCd);
			
			//현재 레벨 정보 조회
			lrnCousLvl = lrnCousService.selectLrnCousLvlInfo(lrnCousSearch);
			
			if( lrnCousLvl != null ) {
				lrnCousSearch.setLvlCd(lrnCousLvl.getLvlCd());
				lrnCousList = lrnCousService.selectLrnCousEndList(lrnCousSearch);
			}

			return responseService.getListResult(lrnCousList);
		} else {
			throw this.processException("S001029");		//진단이력이 존재하지 않습니다.
		}
	}
	
	/**
	  * @Method 설명 : 코스학습 현재 레벨 조회
	  * @param chn_cd
	  * @param lang_cd
	  * @param lrn_mbr_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="코스학습 현재 레벨 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/course/level/channel/{channel}/language/{language}/member/{lrnMbrId}")	
	public SingleResult<LrnCousVO> selectLrnCousLvlInfo(@ApiParam(value = "채널코드") @PathVariable(name="channel",required=true) String chn_cd
			, @ApiParam(value = "언어코드") @PathVariable(name="language", required=true) String lang_cd
			, @ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id) throws Exception {
		LrnCousVO lrnCousLvl = null;
		
		//검색 조건 셋팅
		LrnCousSearchVO lrnCousSearch = new LrnCousSearchVO();
		lrnCousSearch.setChnCd(chn_cd);
		lrnCousSearch.setLangCd(lang_cd);
		lrnCousSearch.setLrnMbrId(lrn_mbr_id);
		
		//시작 지점 소주제 조회 - 소주제가 없을 경우 진단내역이 없다고 판단 할 수 있음.
		String stgCd = lrnCousService.selectStartStgCd(lrnCousSearch);
		
		if( StringUtils.isNotEmpty(stgCd) ) {
			lrnCousSearch.setStgCd(stgCd);
			
			//레벨 정보 조회
			lrnCousLvl = lrnCousService.selectLrnCousLvlInfo(lrnCousSearch);
		} else {
			throw this.processException("S001029");		//진단이력이 존재하지 않습니다.
		}
		
		return responseService.getSingleResult(lrnCousLvl);
	}
	
	/**
	  * @Method 설명 : 코스학습 완료 단일 정보 조회
	  * @param stg_cd
	  * @param lang_cd
	  * @param lrn_mbr_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="코스학습 완료 단일 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/course/end/channel/{channel}/language/{language}/member/{lrnMbrId}/stage/{stgCd}")	
	public SingleResult<LrnCousVO> selectLrnCousEndInfo(@ApiParam(value = "채널코드") @PathVariable(name="channel",required=true) String chn_cd
			, @ApiParam(value = "언어코드") @PathVariable(name="language", required=true) String lang_cd
			, @ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id
			, @ApiParam(value = "소주제코드") @PathVariable(name="stgCd",required=true) String stg_cd) throws Exception {
		//검색 조건 셋팅
		LrnCousSearchVO lrnCousSearch = new LrnCousSearchVO();
		lrnCousSearch.setChnCd(chn_cd);
		lrnCousSearch.setStgCd(stg_cd);
		lrnCousSearch.setLangCd(lang_cd);
		lrnCousSearch.setLrnMbrId(lrn_mbr_id);
		
		LrnCousVO lrnCous = lrnCousService.selectLrnCousEndInfo(lrnCousSearch);
		
		return responseService.getSingleResult(lrnCous);
	}
	
	/**
	  * @Method 설명 : 코스학습 레벨 결과 정보 조회
	  * @param chn_cd
	  * @param lrn_mbr_id
	  * @param lvl_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="코스학습 레벨 결과 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/course/level/result/channel/{channel}/language/{language}/member/{lrnMbrId}/level/{lvlCd}")	
	public SingleResult<LrnCousVO> selectLrnCousLvlRes(@ApiParam(value = "채널코드") @PathVariable(name="channel",required=true) String chn_cd
			, @ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id
			, @ApiParam(value = "언어코드") @PathVariable(name="language",required=true) String lang_cd
			, @ApiParam(value = "레벨코드") @PathVariable(name="lvlCd",required=true) String lvl_cd) throws Exception {
		//검색 조건 셋팅
		LrnCousSearchVO lrnCousSearch = new LrnCousSearchVO();
		lrnCousSearch.setChnCd(chn_cd);
		lrnCousSearch.setLvlCd(lvl_cd);
		lrnCousSearch.setLangCd(lang_cd);
		lrnCousSearch.setLrnMbrId(lrn_mbr_id);
		
		LrnCousVO lrnCous = lrnCousService.selectLrnCousLvlRes(lrnCousSearch);
		
		return responseService.getSingleResult(lrnCous);
	}
	
	/**
	  * @Method 설명 : 코스학습 레벨 완료 이력 등록
	  * @param lrn_mbr_id
	  * @param lvl_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="코스학습 레벨 완료 이력 등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/course/level/history/member/{lrnMbrId}/level/{lvlCd}")	
	public CommonResult insertLnrLvlentyHst(@ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id
			, @ApiParam(value = "레벨코드") @PathVariable(name="lvlCd",required=true) String lvl_cd) throws Exception {
		//검색 조건 셋팅
		LrnCousVO lrnCous = new LrnCousVO();
		lrnCous.setLvlCd(lvl_cd);
		lrnCous.setLrnMbrId(lrn_mbr_id);
		
		lrnCousService.insertLnrLvlentyHst(lrnCous);
		
		return responseService.getResult(true);
	}
}
