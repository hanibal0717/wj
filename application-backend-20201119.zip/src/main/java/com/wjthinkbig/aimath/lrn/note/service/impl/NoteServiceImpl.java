package com.wjthinkbig.aimath.lrn.note.service.impl;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.lrn.note.service.NoteService;
import com.wjthinkbig.aimath.lrn.note.service.dao.NoteDao;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAccumDataVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAnalysisVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteBstWrstVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLrnStatusVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLvlVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteMgntVO;
import com.wjthinkbig.aimath.lrn.note.vo.NotePrgsListByStgVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("noteService")
public class NoteServiceImpl extends BaseServiceImpl implements NoteService {
	
	/**
	 * 학습노트 DAO
	 */
	@Resource(name = "noteDao")
	private NoteDao noteDao;

	@Override
	public List<NoteLvlVO> selectListLvlByMbr(NoteLvlVO lvlVO) throws Exception {
		return noteDao.selectListLvlByMbr(lvlVO);
	}

	@Override
	public NoteLvlVO selectLvlNameByStgCd(NoteLvlVO lvlVO) throws Exception {
		return noteDao.selectLvlNameByStgCd(lvlVO);
	}

	@Override
	public NoteMgntVO selectStgListByLvl(NoteMgntVO mgntVO) throws Exception {
		return noteDao.selectStgListByLvl(mgntVO);
	}

	@Override
	public NoteLrnStatusVO selectLrnStatus(HashMap<String, String> param) throws Exception {
		return noteDao.selectLrnStatus(param);
	}

	@Override
	public NoteAnalysisVO selectAnalysisByLvl(NoteAnalysisVO analysVO) throws Exception{
		return noteDao.selectAnalysisByLvl(analysVO);
	}

	@Override
	public List<NotePrgsListByStgVO> selectPrgsByStg(HashMap<String, String> param) throws Exception {
		return noteDao.selectPrgsByStg(param);
	}

	@Override
	public NoteAccumDataVO selectAccumData(HashMap<String, String>param) throws Exception {
		return noteDao.selectAccumData(param);
	}

	@Override
	public NoteBstWrstVO selectBstStg(HashMap<String, String> param) throws Exception {
		return noteDao.selectBstStg(param);
	}

	@Override
	public NoteBstWrstVO selectWrstStg(HashMap<String, String> param) throws Exception {
		return noteDao.selectWrstStg(param);
	}
	
	
	
	
}
