package com.wjthinkbig.aimath.common.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.common.vo.FileVO;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.FileUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
 * @Date : 2020. 8. 19. 
 * @프로그램 설명 : 공통파일 업로드
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 8. 19.     10013871            최초작성
 * </pre>
*/
@Slf4j
@Api(description="공통 파일 업로드")
@RestController
public class FileUploadController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * AWS S3 도메인
	 */
	private static String domain;
	@Value("${aws.domain}")
	public void setDomain(String url) {
		domain = url;
	}
	
	/**
	 * AWS S3 bucketName 키값
	 */
	private static String bucketName;
	@Value("${aws.bucket.name}")
	public void setBucketName(String name) {
		bucketName = name;
	}
	
	/**
	  * @Method 설명 : 파일 단일건 업로드
	  * @param mFile 파일 객체
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="파일 업로드 단일건")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/upload")	
	public SingleResult<FileVO> fileUpload(@ApiParam("파일 객체") @RequestPart(required=true, name="mFile") MultipartFile mFile,
			@ApiParam("파일 타입") @RequestPart(required=true, name="fileType") String fileType) throws Exception {		
		FileVO file = null;
		
		if( mFile != null ) {
			//파일 경로에 S3 도메인을 넣어준다
			file = FileUtils.sendAWSS3(mFile, "common/" + fileType);
			file.setFilePath(domain + "/" + bucketName + file.getFilePath());
			
			//TODO 추후 DB 저장
		}
		
		return responseService.getSingleResult(file);
	}
	
	/**
	  * @Method 설명 : 파일 다중 업로드
	  * @param mFiles 파일 객체 리스트
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="파일 업로드 여러건")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/upload/multi")	
	public ListResult<FileVO> fileUploadMulti(@ApiParam("파일 객체") @RequestPart(required=true, name="mFiles") List<MultipartFile> mFiles,
			@ApiParam("파일 타입") @RequestPart(required=true, name="fileType") String fileType) throws Exception {		
		List<FileVO> fileList = null;
		
		if( mFiles != null && mFiles.size() > 0 ) {
			fileList = FileUtils.sendAWSS3Multiple(mFiles, "common/" + fileType);
			
			if( fileList != null && fileList.size() > 0 ) {
				for( int i = 0; i < fileList.size(); i++ ) {
					fileList.get(i).setFilePath( domain + "/" + bucketName + fileList.get(i).getFilePath() );
				}
			}
		}
		
		return responseService.getListResult(fileList);
	}
	
}
