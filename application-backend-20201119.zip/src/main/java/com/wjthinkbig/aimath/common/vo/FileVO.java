package com.wjthinkbig.aimath.common.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @FileName : FileVO.java
 * @Project : application-backend
 * @Date : 2020. 8. 19. 
 * @작성자 : 19001861
 * @프로그램 설명 : 파일 정보 VO
 * @변경이력 :
*/
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="파일 정보")
public class FileVO {
	
	@ApiModelProperty(value="파일 경로")
	@FieldName("파일 경로")
	private String filePath;					/* 파일경로 */
	
	@ApiModelProperty(value="파일 명")
	@FieldName("파일 명")
	private String fileNm;						/* 파일명 */
	
	@ApiModelProperty(value="기존 파일 명")
	@FieldName("기존 파일 명")
	private String orgFileNm;					/* 기존 파일 명 */
	
	@ApiModelProperty(value="파일 크기")
	@FieldName("파일 크기")
	private long fileSize;						/* 파일 크기 */
}
