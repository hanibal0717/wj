/**
 * 
 */
package com.wjthinkbig.aimath.common.controller;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import com.wjthinkbig.aimath.common.model.ApiError;
import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 27. 
  * @프로그램 설명 : Custom Error 컨트롤러  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 27.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
@Controller
@RequestMapping("${server.error.path}")
public class CustomErrorController extends BaseController implements ErrorController {

	@Value("${server.error.path}")
	private String errorPath;
	
	private String VIEW_PATH = "error/";
	
	@Resource(name = "errorAttributes")
	private ErrorAttributes errorAttributes;
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	@Override
	public String getErrorPath() {		
		return errorPath;
	}
	  
	/**
	 * 
	  * @Method 설명 : 브라우저 접근시 HTML 페이지로 응답
	  * @param request HttpServletRequest
	  * @param response HttpServletResponse
	  * @param model Model
	  * @return
	 * @throws IOException 
	 */
	@RequestMapping(produces = MediaType.TEXT_HTML_VALUE)
	public String handleError(HttpServletRequest request, HttpServletResponse response, Model model) throws IOException {
		Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
		String statusCode = String.valueOf(status);
		
		model.addAttribute("code", statusCode);
		model.addAttribute("msg", HttpStatus.valueOf(Integer.valueOf(statusCode)).getReasonPhrase());
		model.addAttribute("timestamp", new Date());
		
		if(statusCode.equalsIgnoreCase(String.valueOf(HttpStatus.NOT_FOUND.value()))) {		
			return VIEW_PATH + "404";			 
		} else {
			return VIEW_PATH + "500";
		}		
	}
	
	/**
	  * @Method 설명 : 디바이스 접근시 JSON으로 응답 (404 오류 발생시 여기서 처리)
	  * @param request HttpServletRequest
	  * @return 
	 */
	@RequestMapping
	public ResponseEntity<CommonResult> error(HttpServletRequest request) throws Exception {
		WebRequest webRequest = new ServletWebRequest(request);
		Map<String, Object> body = errorAttributes.getErrorAttributes(webRequest, false);
		
		HttpStatus status = getStatus(request);
		
		String msgKey = "";
		String message = "";
		if(status.value() == HttpStatus.NOT_FOUND.value()) {
			// 클라이언트가 요청한 리소스({0})가 존재하지 않습니다.
			msgKey = "E000012";
			message = messageSource.getMessage(msgKey, new String[] { body.get("path").toString() } , LocaleContextHolder.getLocale());
		} else {			
			// 알 수 없는 오류가 발생하였습니다.
			msgKey = "E999999";
			message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
		}
	    
	    // ApiError
	    ApiError error = new ApiError(status, message, message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
	    return new ResponseEntity<>(object, status);	    
	}
	
	/**
	  * @Method 설명 : HTTP Status 코드정보를 가져온다.
	  * @param request HttpServletRequest 
	  * @return Status 코드가 있으면 해당 코드를, 없으면  INTERNAL_SERVER_ERROR (500)을 반환
	 */
	protected HttpStatus getStatus(HttpServletRequest request) {
		Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
		if (statusCode == null) {
			return HttpStatus.INTERNAL_SERVER_ERROR;
		}
		try {
			return HttpStatus.valueOf(statusCode);
		}
		catch (Exception ex) {
			return HttpStatus.INTERNAL_SERVER_ERROR;
		}
	}
}