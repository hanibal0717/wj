package com.wjthinkbig.aimath.common.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ApiModel(description="API 응답모델")
public class CommonResult {
		
	@JsonIgnore
	@ApiModelProperty(value = "응답 성공여부 : true or false")	
	private boolean success;
	
	@ApiModelProperty(value = "응답 코드번호 : S000000 정상, S000001 비정상")
	private String code;
	
	@ApiModelProperty(value = "응답 메시지")
	private String msg;
}
