package com.wjthinkbig.aimath.common.service;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.model.SingleResult;

@Service("responseService")
public class ResponseService {
	
	@Autowired
	MessageSource messageSource;

	// API 결과에 대한 응답 (code)
	public enum CommonResponse {
		SUCCESS("S000000"),
		FAILURE("S000001");
		
		String code;
		
		private CommonResponse(String code) {
			this.code = code;
		}

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}		
	}
	 
	/**
	  * @Method 설명 : 단일건 결과처리 (성공)
	  * @param data 성공 응답과 함께 제공할 객체
	  * @return
	 */
	public <T> SingleResult<T> getSingleResult(T data) {
		return this.getSingleResult(data, true);
	}
	
	/**
	  * @Method 설명 : 단일건 결과처리 (성공/실패)
	  * @param data 성공/실패 응답과 함께 제공할 객체
	  * @param success 처리결과 (성공: true, 실패: false)
	  * @return
	 */
	public <T> SingleResult<T> getSingleResult(T data, boolean success) {
		String msgKey = success ? CommonResponse.SUCCESS.getCode() : CommonResponse.FAILURE.getCode();
		return this.getSingleResult(data, msgKey, null);
	}
	
	/**
	  * @Method 설명 : 단일건 결과처리, 처리결과와 함께 따로 메시지를 제공하여 결과를 처리하는 경우 사용
	  * @param data 성공/실패 응답과 함께 제공할 객체
	  * @param success 처리결과 (성공: true, 실패: false)
	  * @param message 처리결과와 함께 제공할 메시지 
	  * @return
	 */
	public <T> SingleResult<T> getSingleResult(T data, String msgKey, String message) {		
		SingleResult<T> result = new SingleResult<>();
		result.setData(data);
		this.setResult(result, msgKey, message);
		
		return result;
	}
	
	/**
	  * @Method 설명 : 다중건 결과처리 (성공)
	  * @param list 성공 응답과 함께 제공할 리스트 데이터 객체
	  * @return 
	 */
	public <T> ListResult<T> getListResult(List<T> list) {
		ListResult<T> result = new ListResult<>();
		result.setData(list);
		this.setResult(result, CommonResponse.SUCCESS.getCode());
		
		return result;
	}
	
	/**
	  * @Method 설명 : 
	  * @param success 처리결과 (성공: true, 실패: false)
	  * @return  
	 */
	public CommonResult getResult(boolean success) {
		String msgKey = success ? CommonResponse.SUCCESS.getCode() : CommonResponse.FAILURE.getCode();
		CommonResult result = new CommonResult();
		setResult(result, msgKey);
		return result;
	}
	
	// 
	
	/**
	  * @Method 설명 : (데이터 제공이 없는) 기본 응답모델을 제공한다. 코드를 통해 기본 응답의 메시지를 변경할 수 있다.
	  * @param success 처리결과 (성공: true, 실패: false)
	  * @param i8nMessageCode i18n 메시지 코드 (/resources/i18n/**.yml)
	  * @return
	 */
	public CommonResult getResult(boolean success, String i8nMessageCode) {
		CommonResult commonResult = this.getResult(success);		
		commonResult.setMsg(messageSource.getMessage(i8nMessageCode, null, LocaleContextHolder.getLocale()));
		
		return commonResult;
	}
	
	/**
	  * @Method 설명 : (데이터 제공이 없는) 기본 응답모델을 제공한다. 코드를 통해 기본 응답의 메시지를 변경할 수 있다.
	  * @param success 처리결과 (성공: true, 실패: false)
	  * @param i8nMessageCode i18n 메시지 코드 (/resources/i18n/**.yml)
	  * @param messageParameters 메시지 파라미터 (메시지에 입력매개변수 설정이 되어 있는 경우)
	  * @return
	 */
	public CommonResult getResult(boolean success, String i8nMessageCode, String... messageParameters) {
		CommonResult commonResult = this.getResult(success);		
		commonResult.setMsg(messageSource.getMessage(i8nMessageCode, messageParameters, LocaleContextHolder.getLocale()));
		
		return commonResult;
	}
	
	/**
	  * @Method 설명 : (데이터 제공이 없는) 기본 응답모델을 제공한다. 인자로 전달받은 Exception (BizException) 객체의 메시지를 기본 응답의 메시지로 제공한다. 
	  * @param exception Exception 객체 (보통 BizException)
	  * @return
	 */
//	public CommonResult getResult(Exception exception) {
//		CommonResult commonResult = new CommonResult();
//		this.setResult(commonResult, e, exception.getMessage());
//
//		return commonResult;
//	}
	
	// 결과모델에 API 요청처리 기본 데이터 세팅 (성공/실패)
	private void setResult(CommonResult commonResult, String msgKey) {		
		this.setResult(commonResult, msgKey, null);
	}
	
	// 결과모델에 API 요청처리 기본 데이터 세팅 (성공/실패)
	private void setResult(CommonResult commonResult, String msgKey, String message) {		
		
//		String code = success ? "S000000" : "S000001";
		boolean success = "S000000".equals(msgKey) ? true :false;
				
		String msg = messageSource.getMessage(msgKey, null, LocaleContextHolder.getLocale());
		
		if(StringUtils.isNotBlank(message)) {
			msg = message;
		}
		
		commonResult.setSuccess(success);
		commonResult.setCode(msgKey);
		commonResult.setMsg(msg);
	}
}