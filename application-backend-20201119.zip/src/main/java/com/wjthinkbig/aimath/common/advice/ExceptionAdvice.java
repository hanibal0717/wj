package com.wjthinkbig.aimath.common.advice;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.transaction.TransactionException;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.wjthinkbig.aimath.common.exception.AuthenticationEntryPointException;
import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.exception.BizException;
import com.wjthinkbig.aimath.core.exception.Error;
import com.wjthinkbig.aimath.core.exception.Errors;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 30. 
  * @프로그램 설명 :
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 20.     Lee Seung Hyuk     최초작성
  * 2020. 8. 30.     Lee Seung Hyuk     CustomResponseEntityExceptionHandler에서 모든 예외처리하는 것으로 변경하여 더 이상 사용하지 않음
  * </pre>
 */

//@RestControllerAdvice
@Slf4j
@Deprecated
public class ExceptionAdvice {
	
	@Autowired
	private MessageSource messageSource;
	
	@Resource(name = "responseService")
	private ResponseService responseService;

	@ExceptionHandler(Exception.class)
	public CommonResult handleException(
			HttpServletRequest request, HttpServletResponse response, Exception ex) {
		Errors errors = null;
				
		if(ex instanceof BizException) {
			// BizException
			errors = handleBizException(request, (BizException) ex);
			response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		} else if(ex instanceof MethodArgumentNotValidException) {
			// MethodArgumentNotValidException
			errors = handleMethodArgumentNotValid(request, (MethodArgumentNotValidException) ex);
			response.setStatus(HttpStatus.BAD_REQUEST.value());
		} else if(ex instanceof AuthenticationEntryPointException) {
			// AuthenticationEntryPointException
			errors = handleAuthenticationEntryPointException(request, (AuthenticationEntryPointException) ex);
			response.setStatus(HttpStatus.UNAUTHORIZED.value());
		} else if(ex instanceof AccessDeniedException) {
			// AccessDeniedException
			errors = handleAccessDeniedException(request, (AccessDeniedException) ex);
			response.setStatus(HttpStatus.FORBIDDEN.value());
		} else if(ex instanceof DataAccessException) {
			errors = handleDataAccessException((DataAccessException) ex);
			response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		} else if(ex instanceof TransactionException) {
			errors = handleTransactionException((TransactionException) ex);
			response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		} else if( ex instanceof InvocationTargetException) {
			errors = hadleInvocationException((InvocationTargetException)ex);
			response.setStatus(HttpStatus.ACCEPTED.value());
		} else if( ex instanceof ConstraintViolationException) {
			errors = handleConstraintViolationException((ConstraintViolationException) ex);
			response.setStatus(HttpStatus.BAD_REQUEST.value());		
		} else if (ex instanceof BindException) {
			errors = handleBindException((BindException) ex);
			response.setStatus(HttpStatus.BAD_REQUEST.value());			
		} else {
			ex.printStackTrace();
			errors = new Errors();						 
			errors.add(new Error("", messageSource.getMessage("S999999", new String[0], Locale.getDefault()), ex.getMessage(), ex.getClass().getSimpleName()));
			response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		}
		
		// API 응답으로는 첫번째 오류만 출력하도록 한다.
		CommonResult result = responseService.getResult(false, "S000000", errors.getErrors().get(0).getErrorMessage());
		return result;
	}
	
	/**
	  * @Method 설명 : 서비스(ServiceImpl) 단에서 Exception 발생시켜 예외처리되는 경우 
	  * @param request HttpServletRequest
	  * @param e BizException
	  * @return
	 */
	private Errors handleBizException(HttpServletRequest request, BizException e) {
		Errors errors = new Errors();

		Error error = new Error();
		error.setErrorCode(e.getMessageKey());
		error.setErrorMessage(e.getMessage());

		if (e.getWrappedException() != null) {
			error.setExceptionMessage(e.getWrappedException().getMessage());
			error.setExceptionClass(e.getWrappedException().getClass().getSimpleName());
		}

		errors.add(error);

		return errors;
	}
	
	/**
	  * @Method 설명 : @Valid 어노테이션이 있는 빈 검증에 실패했을 때 발생되는 예외(MethodArgumentNotValidException)에 대한 처리
	  *               @RequestBody, @ResponseBody 어노테이션이 있는 메서드 파라미터 검증 실패시 MethodArgumentNotValidException 발생 (RequestResponseBodyMethodProcessor) 
	  * @param request HttpServletRequest
	  * @param e MethodArgumentNotValidException
	  * @return
	 */
	private Errors handleMethodArgumentNotValid(HttpServletRequest request, Exception e) {
		BindingResult bindingResult = ((MethodArgumentNotValidException) e).getBindingResult();
		
		List<ObjectError> allErrors = bindingResult.getAllErrors();
		for (ObjectError error : allErrors) {
			String message = Arrays.stream(Objects.requireNonNull(error.getCodes()))
					.map(c -> {
						log.info("code : {}", c);
						Object[] arguments = error.getArguments();
						Locale locale = LocaleContextHolder.getLocale();
						try {
							return messageSource.getMessage(c, arguments, locale);
						} catch (NoSuchMessageException ex) {
							return null;
						}
					}).filter(Objects::nonNull)
					.findFirst()
					// 코드를 찾지 못할 경우 기본 메시지 사용.
					.orElse(error.getDefaultMessage());

			log.error("error message: {}", message);
		}
		
/*		
		// 검증에 실패한 Bean 객체(getTarget) 출력 : StageVO(stgCd=ST07, stgNm=스테이지1, dtlCn=스테이지상세내용, thmaCd=THMA01, dspTitleNm=스테이지노출타이틀, stgImgFilePath=/path/images/, stgImgFileNm=imgFile011.jpg, cncpLrnUrlPath=http://www.wjthinkbig.com/cncpLrnUrlPath, kypdTyCd=CK01, expreLrnYn=true, odr=1, useYn=false)
		log.debug("getTarget : {}", bindingResult.getTarget().toString());		
		
		List<FieldError> fieldErrors = bindingResult.getFieldErrors();
//		String errorMessage = fieldErrors.stream().map(DefaultMessageSourceResolvable::getDefaultMessage).collect(Collectors.joining(", "));
		for(FieldError error : fieldErrors) {
			// field : 빈 객체의 대상필드
			// code : 검증코드 @Email인 경우 Email, @Size인 경우 Size
			// message : 검증실패 메시지  
			log.error("빈 필드 : {}, code : @{}, message : {}", error.getField(), error.getCode(), error.getDefaultMessage());
		}
*/		
		Errors errors = new Errors();
		// 검증에 실패한 객체로부터 필드정보를 가져온다. Map<필드코드, 필드명(@FieldName 또는 핃드코드))
		Map<String, String> fieldNameMap = resolveFieldNames(bindingResult.getTarget());
//		log.info("fieldNameMap : {}", fieldNameMap.toString());
		for (FieldError error : bindingResult.getFieldErrors()) {
			errors.add(new Error(error.getCode(), resolveMessage(error, fieldNameMap), e.getMessage(), e.getClass().getSimpleName()));
		}

		return errors;
	}
	
	/**
	  * @Method 설명 : 시큐리티 인증실패시 발생하는 예외(authenticationEntryPointException)에 대한 처리
	  * @param request HttpServletRequest
	  * @param e authenticationEntryPointException
	  * @return
	 */
	private Errors handleAuthenticationEntryPointException(HttpServletRequest request, AuthenticationEntryPointException e) {
		Errors errors = new Errors();
		errors.add(new Error("",
				messageSource.getMessage("E000015", new String[0], Locale.getDefault()),
				e.getMessage(), e.getClass().getSimpleName()));

		return errors;
	}
	
	/**
	  * @Method 설명 : 스프링시큐리티 권한이 필요한 리소스 접근 시 권한이 부족한 경우 발생하는 AccessDeniedException에 대한 처리
	  * @return
	 */
	@ExceptionHandler(AccessDeniedException.class)
	@ResponseStatus(HttpStatus.FORBIDDEN)
	private Errors handleAccessDeniedException(HttpServletRequest request, AccessDeniedException e) {
		Errors errors = new Errors();
		errors.add(new Error("",
				messageSource.getMessage("E000016", new String[0], Locale.getDefault()),
				e.getMessage(), e.getClass().getSimpleName()));

		return errors;	
	}
	
	/**
	  * @Method 설명 : DB 핸들링 중 발생하는 예외(DataAccessException)에 대한 처리
	  * @param ex DataAccessException
	  * @return 
	 */
	private Errors handleDataAccessException(DataAccessException ex) {
		ex.printStackTrace();
		Errors errors = new Errors();
		errors.add(new Error("", messageSource.getMessage("E000013", new String[0], Locale.getDefault()), ex.getMessage(), ex.getClass().getSimpleName()));

		return errors;
	}
	
	/**
	  * @Method 설명 : 트랜잭션 처리 중 발생하는 예외(TransactionException)에 대한 처리
	  * @param ex TransactionException
	  * @return
	 */
	private Errors handleTransactionException(TransactionException ex) {
		Errors errors = new Errors();
		errors.add(new Error("", messageSource.getMessage("E000014", new String[0], Locale.getDefault()), ex.getMessage(), ex.getClass().getSimpleName()));

		return errors;
	}
	
	/**
	  * @Method 설명 : InvocationTargetException 예외에 대한 처리
	  * @param e InvocationTargetException
	  * @return
	 */
	private Errors hadleInvocationException(InvocationTargetException e) {
		Errors errs = new Errors();
		errs.add(new Error("", e.getCause().getMessage(), e.getMessage(), e.getCause().getClass().getSimpleName()));

		return errs;
	}
	
	/**
	  * @Method 설명 : @Validated 검증실패시 발생하는 예외에 대한 처리
	  * @param ex ConstraintViolationException
	  * @return
	 */
	private Errors handleConstraintViolationException(ConstraintViolationException ex) {
		Errors errors = new Errors();
		Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();

		if(!violations.isEmpty()) {
			Map<String, String> fieldNameMap = resolveFieldNames(violations.iterator().next().getLeafBean());

			violations.forEach(x -> {
				String fieldPath = x.getPropertyPath().toString();
				String fieldName = fieldPath.substring(fieldPath.lastIndexOf(".") + 1);

				fieldName = StringUtils.defaultString(fieldNameMap.get(fieldName), fieldName);

				errors.add(new Error(null, String.format("[%s] : %s", fieldName, x.getMessage()), ex.getMessage(), ex.getClass().getSimpleName()));
			});
		}

		return errors;
	}
	
	/**
	  * @Method 설명 : @ModelAttribut로 binding error 발생시 BindException 발생한다.
	  * @param ex BindException
	  * @return
	 */
	private Errors handleBindException(BindException e) {
		BindingResult bindingResult = ((BindException) e).getBindingResult();
		
		List<ObjectError> allErrors = bindingResult.getAllErrors();
		for (ObjectError error : allErrors) {
			String message = Arrays.stream(Objects.requireNonNull(error.getCodes()))
					.map(c -> {
						log.info("code : {}", c);
						Object[] arguments = error.getArguments();
						Locale locale = LocaleContextHolder.getLocale();
						try {
							return messageSource.getMessage(c, arguments, locale);
						} catch (NoSuchMessageException ex) {
							return null;
						}
					}).filter(Objects::nonNull)
					.findFirst()
					// 코드를 찾지 못할 경우 기본 메시지 사용.
					.orElse(error.getDefaultMessage());

			log.error("error message: {}", message);
		}
		
		Errors errors = new Errors();
		// 검증에 실패한 객체로부터 필드정보를 가져온다. Map<필드코드, 필드명(@FieldName 또는 핃드코드))
		Map<String, String> fieldNameMap = resolveFieldNames(bindingResult.getTarget());
		for (FieldError error : bindingResult.getFieldErrors()) {
			errors.add(new Error(error.getCode(), resolveMessage(error, fieldNameMap), e.getMessage(), e.getClass().getSimpleName()));
		}

		return errors;
	}
	
	/**
	  * @Method 설명 : 검증 빈 객체의 필드정보를 담은 Map<코드, 코드설명>을 반환한다. 코드설명은 필드가 @FieldName 어노테이션이 있으면 해당 어노테이션의 값을, 그렇지 않으면 필드명을 그대로 사용한다.)
	  * @param target 빈 검증대상 빈 객체
	  * @return 필드정보를 담은 Map 객체
	 */
	private Map<String, String> resolveFieldNames(Object target) {
		Class<?> clazz = null; 

//		if (target instanceof SaveVO) {
//			SaveVO<?> saveVO = (SaveVO<?>)target;
//
//			if(saveVO.getInsertList().size() > 0) {
//				clazz = saveVO.getInsertList().get(0).getClass();
//			} else if(saveVO.getUpdateList().size() > 0) {
//				clazz = saveVO.getUpdateList().get(0).getClass();
//			} else if(saveVO.getDeleteList().size() > 0) {
//				clazz = saveVO.getDeleteList().get(0).getClass();
//			}
//
//		} else {
			clazz = target.getClass();
//		}

		Map<String, String> fieldNameMap = new HashMap<String, String>();

		if (clazz != null) {
			Field[] fields = FieldUtils.getAllFields(clazz);

			for (Field field : fields) {
				// 검증대상 빈의 필드에 @FieldName 어노테이션이 있으면 해당 어노테이션의 값을 사용
				if (field.isAnnotationPresent(FieldName.class)) {
					FieldName fieldName = field.getAnnotation(FieldName.class);
					// ex) stgCd, 스테이지 코드 (@FieldName("스테이지 코드"))
					fieldNameMap.put(field.getName(), fieldName.value());
				} else {
					// ex) stgCd, stgCd
					fieldNameMap.put(field.getName(), field.getName());
				}
			}
		}

		return fieldNameMap;
	}
	
	/**
	  * @Method 설명 : 검증에 실패한 빈 필드로부터 오류 메시지를 가져온다.
	  * @param error
	  * @param fieldNameMap 검증 빈의 필드정보를 담은 Map 객체
	  * @return 빈 검증 메시지
	 */
	private String resolveMessage(FieldError error, Map<String, String> fieldNameMap) {
		if (fieldNameMap == null) {
			return error.getDefaultMessage();
		}

		String message = Arrays.stream(Objects.requireNonNull(error.getCodes()))
			.map(c -> {
				Object[] arguments = error.getArguments();
				Locale locale = LocaleContextHolder.getLocale();
				try {
					return messageSource.getMessage(c, arguments, locale);
				} catch (NoSuchMessageException e) {
					return null;
				}
			}).filter(Objects::nonNull)
			.findFirst()
			// 코드를 찾지 못할 경우 기본 메시지 사용.
			.orElse(error.getDefaultMessage());
		
		
		// 필드명만 가져오기.
		String fieldName = error.getField();
		if (fieldName.indexOf(".") > 0) {
			fieldName = fieldName.substring(fieldName.indexOf(".") + 1);
		}

		// 출력형태 - password : 반드시 최소값 6과(와) 최대값 8 사이의 크기이어야 합니다.
		if (fieldNameMap.containsKey(fieldName)) {
			return String.format("[%s] : %s", fieldNameMap.get(fieldName), message);
		}

		return error.getDefaultMessage();
	}
}