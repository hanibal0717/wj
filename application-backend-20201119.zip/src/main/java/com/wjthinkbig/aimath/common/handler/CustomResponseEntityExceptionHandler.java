/**
 * 
 */
package com.wjthinkbig.aimath.common.handler;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.annotation.Resource;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.apache.commons.lang3.reflect.FieldUtils;
import org.springframework.beans.ConversionNotSupportedException;
import org.springframework.beans.TypeMismatchException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.transaction.TransactionException;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.context.request.async.AsyncRequestTimeoutException;
import org.springframework.web.multipart.support.MissingServletRequestPartException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.wjthinkbig.aimath.common.exception.AuthenticationEntryPointException;
import com.wjthinkbig.aimath.common.model.ApiError;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.exception.BizException;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.security.exception.JwtExpiredTokenException;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 29. 
  * @프로그램 설명 : API 예외에 대한 전역처리기
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 29.     Lee Seung Hyuk     최초작성
  * </pre>
  */
@Slf4j
@RestControllerAdvice
public class CustomResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 메시지 소스
	 */
	@Autowired
	private MessageSource messageSource;


	// ex) HttpRequestMethodNotSupportedException (405) : GET으로만 선언된 API를 POST나 PUT으로 호출한 경우
	@Override
	protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		// 응답헤더 Allow에 지원되는 메소드 설정
		String methods = "";
		Set<HttpMethod> supportedMethods = ex.getSupportedHttpMethods();
		if (!CollectionUtils.isEmpty(supportedMethods)) {
			methods = org.springframework.util.StringUtils.collectionToCommaDelimitedString(supportedMethods);
			headers.set(HttpHeaders.ALLOW, methods);
		}

		// 이 요청에 {0} 메소드는 지원되지 않습니다. 지원되는 메소드는 {1} 입니다.
		String msgKey = "E000000";
	    String message = messageSource.getMessage(msgKey, new String[] {ex.getMethod(), methods} , LocaleContextHolder.getLocale());
	    
	    // ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

		return handleExceptionInternal(ex, object, headers, status, request);		
	}
	
	// HttpMessageNotReadableException : POST로 Valid 하지 않은 JSON을 전송하여 요청한 경우 등
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		// 잘못된 요청입니다. (HttpMessageNotReadableException)
		String msgKey = "E000003";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
	    // ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

		return handleExceptionInternal(ex, object, headers, status, request);
	}

	// HttpMediaTypeNotSupportedException (415) : JSON을 전송해야 하는데 바이너리 이미지를 전송한 경우
	@Override
	protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		// 응답헤더 Accept에 지원되는 Media Type을 설정		
		String mediaTypeInfo = "";
		List<MediaType> mediaTypes = ex.getSupportedMediaTypes();
		if (!CollectionUtils.isEmpty(mediaTypes)) {
			mediaTypeInfo = MediaType.toString(mediaTypes);
			headers.set(HttpHeaders.ACCEPT, mediaTypeInfo);
		}
		
		// 요청한 미디어 타입({0})은 서버에서 지원하지 않습니다. 지원되는 타입은 {1}입니다.
		String msgKey = "E000001";
	    String message = messageSource.getMessage(msgKey, new String[] {ex.getContentType().toString(), mediaTypeInfo} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
		return handleExceptionInternal(ex, object, headers, status, request);
	}	
	
	// HttpMediaTypeNotAcceptableException (406) : 클라이언트가 서버가 수행할 수 없는 Accept 헤더를 사용하여 응답을 요청했습니다.
	@Override
	protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(HttpMediaTypeNotAcceptableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		// 요청한 미디어 타입({0})은 서버에서 지원하지 않습니다. 지원되는 타입은 {1}입니다.
		String msgKey = "E000002";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
		// API 응답모델	    
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
		return handleExceptionInternal(ex, object, headers, status, request);
	}
	
	// MissingServletRequestParameterException (400) : 필수 파라미터를 전송하지 않고 요청한 경우  
	@Override
	protected ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
	    
		// {0} 매개변수의 값이 필요합니다.
		String msgKey = "E000004";
	    String message = messageSource.getMessage(msgKey, new String[] { ex.getParameterName() } , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
		return handleExceptionInternal(ex, object, headers, status, request);
	}
	
	// TypeMismatchException (400) : 입력 파라미터의 변수 타입을 틀리게 요청한 경우 (int 변수에 string 전송하여 요청)
	@Override
	protected ResponseEntity<Object> handleTypeMismatch(TypeMismatchException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		
		// {0} 매개변수의 타입은 {1}이어야 합니다.
		String msgKey = "E000005";
	    String message = messageSource.getMessage(msgKey, new String[] { ex.getValue().toString(), ex.getRequiredType().getName() } , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
		return handleExceptionInternal(ex, object, headers, status, request);
	}
	
	// MethodArgumentNotValidException (400) : @Valid, @Validated 어노테이션이 있는 빈 검증에 실패했을 때 발생되는 예외(MethodArgumentNotValidException)에 대한 처리
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		BindingResult bindingResult = ex.getBindingResult();
		
		Map<String, String> fieldNameMap = resolveFieldNames(bindingResult.getTarget());
		
		List<String> errors = new ArrayList<String>();
		for (FieldError error : bindingResult.getFieldErrors()) {
			errors.add(resolveMessage(error, fieldNameMap));
		}
	    
		// ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), errors);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, "S000001", errors.isEmpty() ? "" : errors.get(0));
		
		return handleExceptionInternal(ex, object, headers, status, request);
	}
	
	// BindException (400) : @ModelAttribut에 대해 검증실패시 BindException 발생한다.
	@Override
	protected ResponseEntity<Object> handleBindException(BindException ex, HttpHeaders headers, HttpStatus status,
			WebRequest request) {
		
		BindingResult bindingResult = ex.getBindingResult();
		
		Map<String, String> fieldNameMap = resolveFieldNames(bindingResult.getTarget());
		
		List<String> errors = new ArrayList<String>();		
		for (FieldError error : bindingResult.getFieldErrors()) {
			errors.add(resolveMessage(error, fieldNameMap));
		}
	    
		// ApiError		
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), errors);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, "S000001", errors.isEmpty() ? "" : errors.get(0));
		
		return handleExceptionInternal(ex, object, headers, status, request);
	}

	// ConstraintViolationException (400) : @Validated 검증실패시 발생하는 예외에 대한 처리 (@Min(5)인 매개변수 값으로 3을 설정하여 요청한 경우) 
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException ex) {

		List<String> errors = new ArrayList<String>();
				
		Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();

		if(!violations.isEmpty()) {
			Map<String, String> fieldNameMap = resolveFieldNames(violations.iterator().next().getLeafBean());

			violations.forEach(x -> {
				String fieldPath = x.getPropertyPath().toString();
				String fieldName = fieldPath.substring(fieldPath.lastIndexOf(".") + 1);

				fieldName = StringUtils.defaultString(fieldNameMap.get(fieldName), fieldName);

				errors.add(fieldName + ": " + x.getMessage());
			});
		}
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.BAD_REQUEST, ex.getLocalizedMessage(), errors);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, "S000001", errors.isEmpty() ? "" : errors.get(0));
		
	    // 발생한 Exception 정보출력
	 	log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	    
	    return new ResponseEntity<>(object, error.getStatus());
	}	
	
	// HttpMessageNotWritableException (500) : HttpMessageConverter에서 발생하며 write 메서드가 실패한 경우 발생
	@Override
	protected ResponseEntity<Object> handleHttpMessageNotWritable(HttpMessageNotWritableException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		// 처리 중 오류가 발생하였습니다. (HttpMessageNotWritableException)
		String msgKey = "E000006";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
		return handleExceptionInternal(ex, object, headers, status, request);	
	}	
	
	// MissingPathVariableException (500) : 핸들러가 URL에서 기대한 Path Variable을 찾지 못한 경우 발생
	@Override
	protected ResponseEntity<Object> handleMissingPathVariable(MissingPathVariableException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		
		// {0} 경로변수의 값이 필요합니다.
		String msgKey = "E000007";
	    String message = messageSource.getMessage(msgKey, new String[] { ex.getVariableName() } , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
		return handleExceptionInternal(ex, object, headers, status, request);
	}
	
	// ServletRequestBindingException (400) : Filter 등의 Servlet Resource에서 던지기 쉽도록 ServletException을 상속하고 있음
	@Override
	protected ResponseEntity<Object> handleServletRequestBindingException(ServletRequestBindingException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		// 잘못된 요청입니다. (ServletRequestBindingException)
		String msgKey = "E000008";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
	    // ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

		return handleExceptionInternal(ex, object, headers, status, request);
	}
	
	// ConversionNotSupportedException (500) : Bean property로 요청 내용을 변경하기 위한 editor 혹은 converter를 찾지 못한 경우 발생
	@Override
	protected ResponseEntity<Object> handleConversionNotSupported(ConversionNotSupportedException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		// 처리 중 오류가 발생하였습니다. (ConversionNotSupportedException)
		String msgKey = "E000009";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
		return handleExceptionInternal(ex, object, headers, status, request);	
	}
	
	// MissingServletRequestPartException (400) : multipart/form-data 요청의 일부가 손실(can’t be found)되었을 때 발생
	@Override
	protected ResponseEntity<Object> handleMissingServletRequestPart(MissingServletRequestPartException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		
		// 잘못된 요청입니다. (MissingServletRequestPartException)
		String msgKey = "E000010";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
	    // ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

		return handleExceptionInternal(ex, object, headers, status, request);
	}

	// AsyncRequestTimeoutException (503) : 비동기 요청의 응답시간이 초과될 때 발생 
	@Override
	protected ResponseEntity<Object> handleAsyncRequestTimeoutException(AsyncRequestTimeoutException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {

		// 비동기 요청의 응답시간이 초과되었습니다. (AsyncRequestTimeoutException)
		String msgKey = "E000011";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
	    // ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

		return handleExceptionInternal(ex, object, headers, status, request);
	}

	// NoHandlerFoundException (404) : Dispatcher Servlet에서 핸들러를 찾지 못한 경우 기본적으로 404 응답을 내리지만 Dispatcher Servlet의 throwExceptionIfNoHandlerFound 값이 true인 경우 해당 예외를 발생시키므로 여기서 처리가능
	@Override
	protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		
		// 클라이언트가 요청한 리소스({0})가 존재하지 않습니다.
		String msgKey = "E000012";
	    String message = messageSource.getMessage(msgKey, new String[] { ex.getRequestURL() } , LocaleContextHolder.getLocale());
	    
	    // ApiError
	    ApiError error = new ApiError(status, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

		return handleExceptionInternal(ex, object, headers, status, request);
	}
	
	/**
	  * @Method 설명 : 서비스(ServiceImpl) 단에서 Exception 발생시켜 예외처리되는 경우 
	  * @param ex 서비스단에서 발생하는 비즈니스 예외 (BizException)
	  * @return
	 */
	@ExceptionHandler(BizException.class)
	private ResponseEntity<Object> handleBizException(BizException ex) {
		
		// 메시지키
		String msgKey = ex.getMessageKey();
		
	    // ApiError
	    ApiError error = new ApiError(HttpStatus.OK, ex.getLocalizedMessage(), ex.getMessage());
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, ex.getMessage());

	    // 발생한 Exception 정보출력
	 	log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	 				
	 	return new ResponseEntity<>(object, error.getStatus());				
	}
	
	/** 
	  * @Method 설명 : 시큐리티 인증실패시 발생하는 예외(authenticationEntryPointException)에 대한 처리
	  * @param ex AuthenticationEntryPointException
	  * @return
	 */
	@ExceptionHandler(AuthenticationEntryPointException.class)
	private ResponseEntity<Object> handleAuthenticationEntryPointException(AuthenticationEntryPointException ex) {
		
		// 해당 리소스에 접근하기 위한 권한이 없습니다.
		String msgKey = "E000015";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.UNAUTHORIZED, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

	    // 발생한 Exception 정보출력	 	
	 	log.info("시큐리티 인증실패 예외 ({}) : {}", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	 				
	 	return new ResponseEntity<>(object, error.getStatus());
	}
	
	/**
	  * @Method 설명 : 스프링시큐리티 권한이 필요한 리소스 접근 시 권한이 부족한 경우 발생하는 AccessDeniedException에 대한 처리
	  * @param ex AccessDeniedException
	  * @return
	 */
	@ExceptionHandler(AccessDeniedException.class)
	private ResponseEntity<Object> handleAccessDeniedException(AccessDeniedException ex) {

		// 클라이언트가 요청한 리소스({0})가 존재하지 않습니다.
		String msgKey = "E000016";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.FORBIDDEN, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

	    // 발생한 Exception 정보출력
	 	log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	 				
	 	return new ResponseEntity<>(object, error.getStatus());
	}
	
	/**
	  * @Method 설명 : DB 핸들링 중 발생하는 예외(DataAccessException)에 대한 처리
	  * @param ex
	  * @return
	 */
	@ExceptionHandler(DataAccessException.class)
	private ResponseEntity<Object> handleDataAccessException(DataAccessException ex) {
		
		// 데이터 처리 중 문제가 발생되었습니다.
		String msgKey = "E000013";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

	    // 발생한 Exception 정보출력
	 	log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	 				
	 	return new ResponseEntity<>(object, error.getStatus());
	}
	
	/**
	  * @Method 설명 : 트랜잭션 처리 중 발생하는 예외(TransactionException)에 대한 처리
	  * @param ex TransactionException
	  * @return
	 */
	@ExceptionHandler(TransactionException.class)
	private ResponseEntity<Object> handleTransactionException(TransactionException ex) {
		
		// 트랜잭션 처리 중 문제가 발생되었습니다.
		String msgKey = "E000014";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

	    // 발생한 Exception 정보출력
	 	log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	 				
	 	return new ResponseEntity<>(object, error.getStatus());	 	
	}
	
	/**
	  * @Method 설명 : InvocationTargetException 예외에 대한 처리
	  * @param e InvocationTargetException
	  * @return
	 */
	@ExceptionHandler(InvocationTargetException.class)
	private ResponseEntity<Object> hadleInvocationException(InvocationTargetException ex) {
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ex.getLocalizedMessage(), ex.getClass().getSimpleName());
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, "S000001", ex.getLocalizedMessage());

	    // 발생한 Exception 정보출력
	 	log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	 				
	 	return new ResponseEntity<>(object, error.getStatus());
	}
	
	/**
	  * @Method 설명 : UsernameNotFoundException 예외에 대한 처리
	  * @param e UsernameNotFoundException (Spring Security)
	  * @return
	 */
	@ExceptionHandler(UsernameNotFoundException.class)
	private ResponseEntity<Object> hadleUsernameNotFoundException(UsernameNotFoundException ex) {
	    
		// 사용자를 찾을 수 없거나 사용자에게 부여된 권한이 없습니다.
		String msgKey = "E000017";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.UNAUTHORIZED, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

	    // 발생한 Exception 정보출력
	 	log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	 				
	 	return new ResponseEntity<>(object, error.getStatus());
	}
	
	/** 
	  * @Method 설명 : JWT 토큰만료시 발생하는 예외에 대한 처리
	  * @param ex JwtExpiredTokenException
	  * @return
	 */
	@ExceptionHandler(JwtExpiredTokenException.class)
	private ResponseEntity<Object> handleJwtExpiredTokenException(JwtExpiredTokenException ex) {
		
		// 토큰이 만료되었습니다.
		String msgKey = "E000018";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.UNAUTHORIZED, ex.getLocalizedMessage(), message);
	    
	    // API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);

	    // 발생한 Exception 정보출력	 	
	 	log.info("시큐리티 인증실패 예외 ({}) : {}", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
	 				
	 	return new ResponseEntity<>(object, error.getStatus());
	}
	
	// 정의되지 않은 나머지 모든 Exception에 대한 처리
	@ExceptionHandler(Exception.class)
	private ResponseEntity<Object> handleAll(Exception ex, WebRequest request) {
		
		// 알 수 없는 오류가 발생하였습니다.
		String msgKey = "E999999";
	    String message = messageSource.getMessage(msgKey, new String[] {} , LocaleContextHolder.getLocale());
	    
		// ApiError
	    ApiError error = new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ex.getLocalizedMessage(), message);
	    
		// API 응답모델
	    SingleResult<ApiError> object = responseService.getSingleResult(error, msgKey, message);
		
		// 발생한 Exception 정보출력
		log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
				
		return new ResponseEntity<>(object, error.getStatus());				
	}
	
	// 전송된 객체를 포함한 API 응답모델을 반환한다. (A single place to customize the response body of all exception types)
	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
			HttpStatus status, WebRequest request) {

		// 발생한 Exception 정보출력
		log.info("Exception : {} ({})", ex.getClass().getSimpleName(), ex.getLocalizedMessage());
		
		return new ResponseEntity<>(body, headers, status);
	}
	
	/**
	  * @Method 설명 : 검증 빈 객체의 필드정보를 담은 Map<코드, 코드설명>을 반환한다. 코드설명은 필드가 @FieldName 어노테이션이 있으면 해당 어노테이션의 값을, 그렇지 않으면 필드명을 그대로 사용한다.)
	  * @param target 빈 검증대상 빈 객체
	  * @return 필드정보를 담은 Map 객체
	 */
	private Map<String, String> resolveFieldNames(Object target) {
		Class<?> clazz = null; 

		if (target instanceof SaveVO) {
			SaveVO<?> saveVO = (SaveVO<?>)target;

			if(saveVO.getInsertList().size() > 0) {
				clazz = saveVO.getInsertList().get(0).getClass();
			} else if(saveVO.getUpdateList().size() > 0) {
				clazz = saveVO.getUpdateList().get(0).getClass();
			} else if(saveVO.getDeleteList().size() > 0) {
				clazz = saveVO.getDeleteList().get(0).getClass();
			}

		} else {
			clazz = target.getClass();
		}

		Map<String, String> fieldNameMap = new HashMap<String, String>();

		if (clazz != null) {
			Field[] fields = FieldUtils.getAllFields(clazz);

			for (Field field : fields) {
				// 검증대상 빈의 필드에 @FieldName 어노테이션이 있으면 해당 어노테이션의 값을 사용
				if (field.isAnnotationPresent(FieldName.class)) {
					FieldName fieldName = field.getAnnotation(FieldName.class);
					// ex) stgCd, 스테이지 코드 (@FieldName("스테이지 코드"))
					fieldNameMap.put(field.getName(), fieldName.value());
				} else {
					// ex) stgCd, stgCd
					fieldNameMap.put(field.getName(), field.getName());
				}
			}
		}

		return fieldNameMap;
	}
	
	/**
	  * @Method 설명 : 검증에 실패한 빈 필드로부터 오류 메시지를 가져온다.
	  * @param error FieldError 객체
	  * @param fieldNameMap 검증 빈의 필드정보를 담은 Map 객체
	  * @return 빈 검증 메시지
	 */
	private String resolveMessage(FieldError error, Map<String, String> fieldNameMap) {
		if (fieldNameMap == null) {
			return error.getDefaultMessage();
		}

		String message = Arrays.stream(Objects.requireNonNull(error.getCodes()))
			.map(c -> {
				log.info("code : {}", c);
				try {
					return messageSource.getMessage(c, error.getArguments(), LocaleContextHolder.getLocale());
				} catch (NoSuchMessageException e) {
					return null;
				}
			})
			.filter(Objects::nonNull)
			.findFirst()			
			.orElse(error.getDefaultMessage());		// 코드를 찾지 못할 경우 기본 메시지 사용.	
		
		log.error("error message: {}", message);		
		
		// 필드명만 가져오기.
		String fieldName = error.getField();
		if (fieldName.indexOf(".") > 0) {
			fieldName = fieldName.substring(fieldName.indexOf(".") + 1);
		}

		// 출력형태 - password : 반드시 최소값 6과(와) 최대값 8 사이의 크기이어야 합니다.
		if (fieldNameMap.containsKey(fieldName)) {
			return String.format("[%s]: %s", fieldNameMap.get(fieldName), message);
		}

		return error.getDefaultMessage();
	}	
}