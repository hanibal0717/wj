package com.wjthinkbig.aimath.mbrsp.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.Arrays;
import java.util.Base64;
import java.util.Base64.Encoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.configurationprocessor.json.JSONArray;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrLogVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.mbrsp.service.MbrspService;
import com.wjthinkbig.aimath.mbrsp.vo.MbrspVO;
import com.wjthinkbig.aimath.security.config.JwtSettings;
import com.wjthinkbig.aimath.security.model.token.JwtToken;
import com.wjthinkbig.aimath.security.model.token.JwtTokenFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/** (OK)
  * @Date : 2020. 11. 9. 
  * @프로그램 설명 : 북패드 연계 인증처리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 9.     안두리                                  최초작성
  * 2020. 11. 9.     10013871           코드검수  
  * </pre>
  */
@Slf4j
@Api(description = "북패드(스마트올 연동) 연계 인증처리")
@RestController
public class MbrspController extends BaseController {
	
	private final int CONNECT_TIMEOUT = 5000;
	private final int READ_TIMEOUT = 5000;

	// 북패드 회원정보 조회를 위한 API URL
	@Value("${mbsp.api-url}")
	private String apiUrl;
	
	// 북패드 회원정보 조회 API 사용을 위한 인증토큰 
	@Value("${mbsp.auth-token}")
	private String authToken;
	
	// 북패드 회원정보 조회를 위한 서비스구분코드
	@Value("${mbsp.service-name}")
	private String serviceName;

	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 회원서비스
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService; 
	
	/**
	 * 북패드연계 서비스
	 */
	@Resource(name = "mbrspService")
	private MbrspService mbrspService; 
	
	/**
	 * Redis Template
	 */
	@Resource(name = "redisTemplate")
	private RedisTemplate<String, Object> redisTemplate;
	
	@Autowired
	private JwtSettings jwtSettings;
	
	@Autowired
	private JwtTokenFactory tokenFactory;
	

	
	/** (OK)
	  * @Method 설명 : 북패드 연계 인증처리
	  *  - 북패드 API(계약번호, 부모 및 자녀의 ME 계약번호)를 통해 패드의 회원정보를 가져온다.  
	  *  - API를 통해 가져온 부모 및 자녀가 AI연산 회원으로 등록되어 있지 않으면 신규등록한다. (가입자 - 부모 고객번호/계약번호를 저장, 학습자 - 자녀의 고객번호를 저장)
	  *  - AI연산 서비스회원으로 등록처리 후 로그인 인증 토큰을 발급한다.
	  *  - 계약번호를 포함한 로그인 이력을 남긴다.  
	  * @param mbrspVo 북패드연계정보 VO
	  * @return 토큰
	  * @throws Exception
	 */
	@ApiOperation(value = "북패드연계 인증처리", tags = {"인증"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/mbrsp/login")
	public SingleResult<HashMap<String, String>> login(@ApiParam(value = "북패드 회원정보 인증을 위한 계약정보") @Valid @RequestBody MbrspVO mbrspVo, HttpServletRequest request) throws Exception {
		
		// [1] 부모와 자녀 고객번호를 Base64로 인코딩(bodyEnc)하여 POST로 전송
		Encoder encoder = Base64.getEncoder();
		String body = "{\"CHILD_MEMBER_CODE\":\"" + mbrspVo.getParentMemberCode() + "\",\"PARENT_MEMBER_CODE\":\"" + mbrspVo.getChildMemberCode() + "\"}";
		String bodyEnc = new String(encoder.encode(body.getBytes()));
				
		JSONObject jsonObj=new JSONObject();
		JSONArray jsonAry=new JSONArray();
		try {
			URL url = new URL(apiUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(CONNECT_TIMEOUT); // 서버에 연결되는 Timeout 시간 설정
			con.setReadTimeout(READ_TIMEOUT); 		// InputStream 읽어 오는 Timeout 시간 설정
			con.setRequestMethod("POST");
			con.setRequestProperty("Content-Type", "application/json");
			con.addRequestProperty("Auth-Token", authToken);					// Header 입력값 : 토큰 
			con.addRequestProperty("Service-Name", serviceName);				// Header 입력값 : 서비스명
			con.addRequestProperty("Contract-Number", mbrspVo.getCntrtNo());	// Header 입력값 : 계약번호
			
			con.setDoInput(true);
			con.setDoOutput(true);
			con.setUseCaches(false);
			con.setDefaultUseCaches(false);

			OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
			wr.write(bodyEnc);
			wr.flush();

			StringBuilder sb = new StringBuilder();
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), "utf-8"));
				String line;
				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				log.info("북패드 API : {}", sb.toString());
				jsonObj = new JSONObject(sb.toString());
				jsonAry = (JSONArray)((JSONObject)jsonObj.get("RESP_RESULT")).get("MEMBER_INFO_LIST");
			} else {
				throw this.processException("S000001");
			}
		} catch (SocketTimeoutException e) {
			e.printStackTrace();
			throw this.processException("S000003", e.getMessage()); // 서비스 응답이 없습니다.			
		} catch (Exception e){
			e.printStackTrace();
			throw this.processException("S000001"); // 처리 중 문제가 발생하였습니다.
		}

		// [2] 미등록 북패드 회원인 경우 회원가입 처리
		Map<String, Object> paramMapMbr = new HashMap<>(); // 기가입여부 확인을 위한 가입회원 검색조건
		Map<String, Object> paramMapLrn = new HashMap<>(); // 기가입여부 확인을 위한 학습회원 검색조건
		
		MbrVO mbr = new MbrVO();			// 가입회원 VO
		MbrLrnVO mbrLrn = new MbrLrnVO();	// 학습회원 VO
		
		for ( int i = 0 ; i < jsonAry.length() ; i++ ) {
			JSONObject data = jsonAry.getJSONObject(i); // 회원리스트
			
			if ( data.getString("MEMBER_TP") != null && "P".equals(data.getString("MEMBER_TP")) ) {
				// 리스트의 회원정보가 부모정보인 경우
				mbr.setChnCd(mbrspVo.getChnCd());
				mbr.setCntrtNo(mbrspVo.getCntrtNo());
				mbr.setCstmrNo(data.getString("CUSTOMER_NUMBER")); 				// SAP 고객번호
				
				// 기가입여부 확인을 위한 가입회원 검색조건
				paramMapMbr.put("chnCd", mbrspVo.getChnCd());
				paramMapMbr.put("cstmrNo", data.getString("CUSTOMER_NUMBER"));
			} else if ( data.getString("MEMBER_TP") != null && "C".equals(data.getString("MEMBER_TP")) ) {
				// 리스트의 회원정보가 자녀정보인 경우
				mbrLrn.setCstmrNo(data.getString("CUSTOMER_NUMBER")); 			// SAP 고객번호
				mbrLrn.setMbrNm(data.getString("MEMBER_NAME")); 				// 이름
				mbrLrn.setBrthmt(data.getString("BIRTHDATE").substring(0,6)); 	// 생년월
				mbrLrn.setSxdnCd(data.getString("GENDER")); 					// 성별
				
				// 기가입여부 확인을 위한 학습회원 검색조건
				paramMapLrn.put("chnCd", mbrspVo.getChnCd());				
				paramMapLrn.put("cstmrNo", data.getString("CUSTOMER_NUMBER"));
			}
		}

		// 부모정보가 등록되어 있는지 확인 후 없으면 가입처리하고 있으면 해당 정보를 가져온다.   
		MbrVO mbrVo = mbrspService.selectMbrByCstmrNo(paramMapMbr);
		if ( mbrVo == null) {
			// 이 채널에 해당 SAP 고객번호를 가진 회원이 없으면 가입회원으로 신규등록 및 약관동의처리
			mbr = mbrspService.insertMbr(mbr);
		} else {
			mbr = mbrVo;
		}		
		
		paramMapLrn.put("mbrId", mbr.getMbrId());
		mbrLrn.setSbsceMbrId(mbr.getMbrId());
		
		// 자녀정보가 등록되어 있는지 확인 후 없으면 해당 부모의 자녀로 등록처리
		MbrLrnVO mbrLrnVo = mbrspService.selectMbrLrnByCstmrNo(paramMapLrn);
		if ( mbrLrnVo == null) {
			// 이 채널에 해당 부모의 자녀로 해당 SAP 고객번호를 가진 회원이 없으면 학습회원으로 신규등록한다. 
			mbrLrn = mbrspService.insertMbrLrn(mbrLrn);
		} else {
			mbrLrn = mbrLrnVo;
		}

		// [3] 자동로그인을 위한 인증처리 : 로그인 인증처리 및 토큰발급, 로그인 이력
		MbrVO mbrVO = new MbrVO();
		mbrVO.setMbrId(mbr.getMbrId());
		mbrVO.setPw("");
		mbrVO.setEmailAdrs(mbr.getEmailAdrs());
		mbrVO.setRoles(Arrays.asList("ROLE_USER"));
		
		User user = new MbrAccount(mbrVO);
		
		// 로그인
		Authentication authentication = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
		
		log.debug("authentication : {}", authentication.isAuthenticated());
		
        SecurityContext securityContext = SecurityContextHolder.getContext();
	    securityContext.setAuthentication(authentication);
	    
	    // 로그인 됐으면 로그를 쌓는다.
	    log.debug("LoginUtils.isLogin() : {}", String.valueOf(LoginUtils.isLogin()));
	    if(LoginUtils.isLogin()) {
    		MbrLogVO logVO = new  MbrLogVO();
    		logVO.setSbsceMbrId(((MbrAccount)user).getUserId());
    		logVO.setCntrtNo(mbrspVo.getCntrtNo());
			mbrService.insertLog(logVO, request);
		}
	    
	    // 토큰발급
	    HashMap<String, String> additionalClaims = new HashMap<String, String>();
	    additionalClaims.put("mbr", ((MbrAccount)user).getUserId());
	    additionalClaims.put("chn", mbrspVo.getChnCd()); // 채널정보를 토큰에 추가한다.

	    JwtToken accessToken = tokenFactory.createAccessJwtToken(user, additionalClaims);
	    
	    // Redis에 액세스토큰 저장
        ValueOperations<String, Object> vop = redisTemplate.opsForValue();
        String redisKey = "token:refresh:" + mbrspVo.getChnCd() + ":" + mbr.getMbrId();
        vop.set(redisKey,accessToken.getToken(), jwtSettings.getAccessTokenExpirationTime(), TimeUnit.MINUTES);

        // 응답
        HashMap<String, String> data = new HashMap<>();
        data.put("accessToken", accessToken.getToken());
        data.put("sbsceMbrId", mbr.getMbrId());
        data.put("lrnMbrId", mbrLrn.getMbrId());
        

		return responseService.getSingleResult(data);
	}
}