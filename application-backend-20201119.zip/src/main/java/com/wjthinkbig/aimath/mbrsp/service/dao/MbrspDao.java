package com.wjthinkbig.aimath.mbrsp.service.dao;

import java.util.Map;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;

/** (OK)
  * @Date : 2020. 11. 12. 
  * @프로그램 설명 : 북패드 연계관리 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 12.    Lee Seung Hyuk     최초작성
  * </pre>
 */
@Mapper("mbrspDao")
public interface MbrspDao {
	
	/** (OK)
	  * @Method 설명 : (특정 채널에 특정 SAP 고객번호를 가진) 가입회원을 검색하여 가져온다.  
	  * @param paramMapMbr 회원 검색조건 (채널, SAP 고객번호)
	  * @return 가입회원 정보
	 */
	MbrVO selectMbrByCstmrNo(Map<String,Object> paramMapMbr);
	
	/** (OK)
	  * @Method 설명 : (특정 가입회원의 자녀로 특정 SAP 고객번호를 가진) 학습회원을 검색하여 가져온다.
	  * @param paramMapLrn 회원 검색조건 (채널, SAP 고객번호, 가입회원ID)
	  * @return 학습회원 정보
	 */
	MbrLrnVO selectMbrLrnByCstmrNo(Map<String,Object> paramMapLrn);	
}