package com.wjthinkbig.aimath.mbrsp.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/** (OK)
  * @Date : 2020. 11. 11. 
  * @프로그램 설명 : 북패드(스마트올) 회원정보 인증을 위한 계약정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 11.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "북패드(스마트올) 회원정보 인증을 위한 계약정보")
public class MbrspVO {	
	/**
	 * 채널코드 
	 */
	@NotBlank
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;

	/**
	 * SAP 계약번호(Contract Number)
	 */
	@NotBlank
	@ApiModelProperty(value = "계약번호")
	@FieldName("계약번호")
	private String cntrtNo;

	/**
	 * 부모 회원 코드  (ME 고객번호)
	 */
	@NotBlank
	@ApiModelProperty(value="부모 회원 코드")
	@FieldName("부모 회원 코드")
	private String parentMemberCode;

	/**
	 * 자녀 회원 코드 (ME 고객번호)
	 */
	@NotBlank
	@ApiModelProperty(value="자녀 회원 코드")
	@FieldName("자녀 회원 코드")
	private String childMemberCode;
}