package com.wjthinkbig.aimath.mbrsp.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.mbr.service.dao.MbrDao;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrTermsVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.mbrsp.service.MbrspService;
import com.wjthinkbig.aimath.mbrsp.service.dao.MbrspDao;
import com.wjthinkbig.aimath.terms.service.dao.TermsDao;
import com.wjthinkbig.aimath.terms.vo.TermsHstSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsHstVO;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import lombok.extern.slf4j.Slf4j;

/** (OK)
  * @Date : 2020. 11. 12. 
  * @프로그램 설명 : 북패드(스마트올 연동) 연계 인증처리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 11.     Lee Seung Hyuk    최초작성
  * 2020. 11. 12.     Lee Seung Hyuk    코드검수
  * </pre>
 */
@Slf4j
@Service("mbrspService")
public class MbrspServiceImpl extends BaseServiceImpl implements MbrspService {
	
	// 가입회원 신규등록시 사용할 이메일 도메인  
	private final String EMAIL_DOMAIN = "wjthinkbig.co.kr";

	/**
	 * 회원서비스 Dao
	 */
	@Resource(name = "mbrDao")
	private MbrDao mbrDao;
	
	/**
	 * 북패드 연계서비스 Dao
	 */
	@Resource(name = "mbrspDao")
	private MbrspDao mbrspDao;

	/**
	 * 이용약관 Dao
	 */
	@Resource(name = "termsDao")
	private TermsDao termsDao;
	
	/**
	 * 회원ID 신규생성 서비스
	 */
	@Resource(name = "mbrIdGenService")
	private EgovIdGnrService mbrIdGenService;
	
	/**
	 * 학습 회원ID 신규생성 서비스
	 */
	@Resource(name = "lrnIdGenService")
	private EgovIdGnrService lrnIdGenService;
	
	
	/** (OK)
	 * 북패드회원 가입회원 등록 및 약관동의처리 
	 *  - 채널, 계약번호, 고객번호, 이메일을 가지고 있음. 
	 *  - 비밀번호 업음 (별도 로그인은 못하게 차단)
	 *  - 가입시 약관동의 처리함.
	 */
	@Override
	public MbrVO insertMbr(MbrVO mbr) throws Exception {
		// 회원ID 채번
		String newMbrId = mbrIdGenService.getNextStringId();		
		mbr.setMbrId(newMbrId);
		
		// 이메일 : 북패드로부터 수신된 이메일을 사용하지 않을것이므로 채번된 회원ID@도메인으로 내부처리함. 
		String email = newMbrId + "@" + EMAIL_DOMAIN;
		mbr.setEmailAdrs(email);
		mbr.getEmailAdrsEn();
		
		// 가입할 이메일이 이미 등록되어 있는지 확인
		if(mbrDao.isExistsByEmail(mbr.getEmailAdrs())) {
			throw this.processException("S001015"); // 해당 이메일은 이미 등록되어 있습니다.
		}
		
		// 비밀번호 변경일시 (비밀번호가 없으므로 변경일시 지정하지 않음)
		/*mbr.setPwChngeDt(LocalDateTime.now());*/
		
		// 이메일 인증여부 : 북패드 연계의 경우 인증(Y)
		mbr.setEmailCertYn("Y");
		
		// 가입을 위한 세션 아이디 채번
		/*mbr.setSessionId(gstIdGenService.getNextStringId());*/
		
		// 회원 탈퇴여부
		mbr.setDelYn("N");
		
		// 등록 및 수정자 정보
		mbr.setLoginUser(newMbrId);
		
		// 이 채널의 약관정보를 VO에 세팅 (for validation only)
		List<MbrTermsVO> mbrTermsList = new ArrayList<MbrTermsVO>();
		
		// 이 채널에 등록된 한국어 약관을 검색하여 
		TermsHstSearchVO termsHstSearch = new TermsHstSearchVO();
		termsHstSearch.setChnCd(mbr.getChnCd());
		termsHstSearch.setLangCd("KO");
		
		// 이용약관 리스트에 세팅
		List<TermsHstVO> termsHstList = termsDao.selectTermsChannelsList(termsHstSearch);		
		if(termsHstList != null) {
			for(TermsHstVO vo : termsHstList) {
				MbrTermsVO termsVO = new MbrTermsVO();
				termsVO.setSbsceMbrId(newMbrId);		// 가입회원ID
				termsVO.setTermsId(vo.getTermsId());	// 약관ID
				termsVO.setAgrmtYn("Y");				// 동의여부 (Y)								
				mbrTermsList.add(termsVO);
			}
		}
		mbr.setMbrTermsList(mbrTermsList);
		
		// 가입회원 입력값 검증 (신규등록시)	
//		this.validateOrElseThrow(mbr, Groups.Insert.class);
				
		// 검증에 문제없을 경우 가입회원 신규등록 처리
		mbrDao.insertMbr(mbr);		
			
		// 해당 채널에 대해 약관동의 처리한다. 
		for(MbrTermsVO vo : mbr.getMbrTermsList()) {
			this.validateOrElseThrow(vo, Groups.Insert.class);
			mbrDao.insertMbrTerms(vo);			
		}
		
		return mbr;
	}

	/** (OK)
	 * 북패드회원 학습회원 등록처리 
	 *  - 고객번호, 이름, 성별, 생년월, 부모회원ID 정보를 가지고 있음.
	 */
	@Override
	public MbrLrnVO insertMbrLrn(MbrLrnVO mbrLrn) throws Exception {
		// 학습회원ID 채번
		String newMbrLrnId = lrnIdGenService.getNextStringId();
		mbrLrn.setMbrId(newMbrLrnId);
		
		// 이모티콘일련번호 
		mbrLrn.setEmotcSno(1);
		
		// 삭제여부
		mbrLrn.setDelYn("N");
		
		// 등록 및 수정자 정보
		mbrLrn.setLoginUser(newMbrLrnId);
		
		// 학습회원 입력값 검증 (신규등록시)
		this.validateOrElseThrow(mbrLrn, Groups.Insert.class);
		
		// 검증에 문제없을 경우 학습회원 신규등록 처리
		mbrDao.insertMbrLrn(mbrLrn);
		
		return mbrLrn;
	}	

	/** (OK)
	 * (특정 채널에 특정 SAP 고객번호를 가진) 가입회원을 검색하여 가져온다.   
	 */
	@Override
	public MbrVO selectMbrByCstmrNo(Map<String,Object> paramMapMbr) throws Exception {
		return mbrspDao.selectMbrByCstmrNo(paramMapMbr);
	}
	
	/** (OK)
	 * (특정 가입회원의 자녀로 특정 SAP 고객번호를 가진) 학습회원을 검색하여 가져온다.
	 */
	@Override
	public MbrLrnVO selectMbrLrnByCstmrNo(Map<String,Object> paramMapLrn) throws Exception {		
		return mbrspDao.selectMbrLrnByCstmrNo(paramMapLrn);
	}
}