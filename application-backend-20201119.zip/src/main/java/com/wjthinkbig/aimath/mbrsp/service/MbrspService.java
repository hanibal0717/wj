package com.wjthinkbig.aimath.mbrsp.service;

import java.util.Map;

import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;

/** (OK)
  * @Date : 2020. 11. 12. 
  * @프로그램 설명 : 북패드(스마트올 연동) 연계 인증처리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 12.     Lee Seung Hyuk    최초작성
  * 2020. 11. 12.     Lee Seung Hyuk    코드검수
  * </pre>
 */
public interface MbrspService {

	/**
	  * @Method 설명 : 북패드회원 가입회원 등록 및 약관동의처리 
	 *  - 채널, 계약번호, 고객번호, 이메일을 가지고 있음. 
	 *  - 비밀번호 업음 (별도 로그인은 못하게 차단)
	 *  - 가입시 약관동의 처리함.
	  * @param mbr 신규등록할 회원정보를 담고 있는 가입회원 VO
	  * @return 가입자 정보
	  * @throws Exception
	 */
	public MbrVO insertMbr(MbrVO mbr) throws Exception;

	/**
	  * @Method 설명 : 북패드회원 학습회원 등록처리 
	 *  - 고객번호, 이름, 성별, 생년월, 부모회원ID 정보를 가지고 있음.
	  * @param mbrLrn 신규등록할 회원정보를 담고 있는 학습회원 VO
	  * @return 가입자 정보
	  * @throws Exception
	 */
	public MbrLrnVO insertMbrLrn(MbrLrnVO mbrLrn) throws Exception;

	/**
	  * @Method 설명 : (특정 채널에 특정 SAP 고객번호를 가진) 가입회원을 검색하여 가져온다.   
	  * @param paramMapMbr 회원 검색조건 (채널, SAP 고객번호)
	  * @return 가입회원정보
	  * @throws Exception
	 */
	public MbrVO selectMbrByCstmrNo(Map<String,Object> paramMapMbr) throws Exception;

	/**
	  * @Method 설명 : (특정 가입회원의 자녀로 특정 SAP 고객번호를 가진) 학습회원을 검색하여 가져온다.
	  * @param paramMapLrn 회원 검색조건 (채널, SAP 고객번호, 가입회원ID)
	  * @return 학습회원정보
	  * @throws Exception
	 */
	public MbrLrnVO selectMbrLrnByCstmrNo(Map<String,Object> paramMapLrn) throws Exception;
}