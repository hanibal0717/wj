/**
 * 
 */
package com.wjthinkbig.aimath.thma.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.common.vo.FileVO;
import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.FileUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.stg.service.dao.StgDao;
import com.wjthinkbig.aimath.stg.vo.StgSearchVO;
import com.wjthinkbig.aimath.thma.service.ThmaService;
import com.wjthinkbig.aimath.thma.service.dao.ThmaDao;
import com.wjthinkbig.aimath.thma.vo.ThmaSearchVO;
import com.wjthinkbig.aimath.thma.vo.ThmaVO;

import lombok.extern.slf4j.Slf4j;

/** (OK)
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 주제정보 관리서비스 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * 2020. 11. 5.     10013871            코드검수
  * </pre>
 */
@Slf4j
@Service("thmaService")
public class ThmaServiceImpl extends BaseServiceImpl implements ThmaService {
	
	/**
	 * AWS S3 도메인
	 */
	private static String domain;
	@Value("${aws.domain}")
	public void setDomain(String url) {
		domain = url;
	}
	
	/**
	 * AWS S3 bucketName 키값
	 */
	private static String bucketName;
	@Value("${aws.bucket.name}")
	public void setBucketName(String name) {
		bucketName = name;
	}
	
	/**
	 * 대주제관리 Dao
	 */
	@Resource(name = "thmaDao")
	private ThmaDao thmaDao;

	/**
	 * 소주제관리 Dao
	 */
	@Resource(name = "stgDao")
	private StgDao stgDao;
	

	/** (OK)
	 * 검색조건에 맞는 대주제 리스트를 가져온다. 
	 *  - 이미지 파일 경로를 AWS S3 기준 전체 경로로 가공하여 제공 
	 */
	@Override
	public List<ThmaVO> selectThmaList(ThmaSearchVO thmaSearch) throws Exception {
		List<ThmaVO> thmaList = thmaDao.selectThmaList(thmaSearch);
		List<ThmaVO> resultList = new ArrayList<ThmaVO>();
		
		if( thmaList != null && thmaList.size() > 0 ) {
			// 파일 경로에 S3 도메인을 넣어준다
			for( ThmaVO thma : thmaList ) {
				if( StringUtils.isNotEmpty(thma.getImgFilePath()) ) {
					thma.setImgFilePath(domain + "/" + bucketName + thma.getImgFilePath());
				}
				
				resultList.add(thma);
			}
		}
		return resultList;
	}

	/** (OK)
	 * 대주제 전체 건수를 가져온다.
	 */
	@Override 
	public int selectThmaListCnt(ThmaSearchVO thmaSearch) throws Exception {
		return thmaDao.selectThmaListCnt(thmaSearch);
	}
	
	/** (OK)
	 * 대주제 단일정보 조회
	 *  - 이미지 파일 경로를 AWS S3 기준 전체 경로로 가공하여 제공 
	 */
	@Override
	public ThmaVO selectThmaById(String thma_cd) throws Exception {
		ThmaVO thma = thmaDao.selectThmaById(thma_cd);
		
		if(thma != null) {
			//파일 경로에 S3 도메인을 넣어준다
			if( StringUtils.isNotEmpty(thma.getImgFilePath()) ) {
				thma.setImgFilePath(domain + "/" + bucketName + thma.getImgFilePath());
			}
		}
		
		return thma;
	}

	/** (OK)
	 * 대주제 단일정보 신규등록
	 */
	@Override
	public void insertThma(ThmaVO thma) throws Exception {
		// 동일한 이름의 대주제명이 있는지 중복 체크
		ThmaSearchVO thmaSearch = new ThmaSearchVO();
		thmaSearch.setThmaNm(thma.getThmaNm());
		
		int thmaNmDplCt = thmaDao.selectThmaNmDplctCheck(thmaSearch);
		if(thmaNmDplCt == 0) {
			// 새로운 대주제코드 채번하여 생성
			thma.setThmaCd(thmaDao.selectNewThmaCd());
			
			// 정렬순서 생성
			thma.setDspOdr(thmaDao.selectLastDspOrd());
			
			// 첨부파일 확인 후 등록
			MultipartFile mFile = thma.getMFile();
			
			if( mFile != null && !mFile.isEmpty() ) {
				FileVO file = FileUtils.sendAWSS3(mFile, "thema");				
				if( file != null ) {
					// 업로드 파일정보 저장
					thma.setImgFilePath(file.getFilePath());
					thma.setImgFileNm(file.getFileNm());
				}
			}
			
			// Insert Group에 대한 빈 검증 (신규등록 시의 검증, 파일업로드 이후 파일첨부 필수여부 확인) 
			this.validateOrElseThrow(thma, Groups.Insert.class);
			
			thmaDao.insertThma(thma);	
		} else {
			throw this.processException("S001001");		// 이미 존재하는 데이터입니다.
		}	
	}

	/** (OK)
	 * 대주제 단일정보 변경
	 *  - 변경하려는 대주제명이 이미 다른 코드의 이름으로 등록되어 있으면 변경할 수 없다.
	 */
	@Override
	public void updateThma(ThmaVO thma) throws Exception {
		// 대주제 명 중복 체크 (이 코드를 제외한 다른 대주제코드에서 이 대주제명을 쓰고 있는지 체크) 
		ThmaSearchVO thmaSearch = new ThmaSearchVO();
		thmaSearch.setThmaNm(thma.getThmaNm());
		thmaSearch.setThmaCd(thma.getThmaCd());
		
		// 커리큘럼 대주제 중복 건수 조회 (대주제명만으로 건수 또는 코드가 있는 경우 해당 코드를 제외한 다른 코드에서 사용하고 있는 건수)
		int thmaNmDplCt = thmaDao.selectThmaNmDplctCheck(thmaSearch);		
		if(thmaNmDplCt == 0) {
			// 첨부파일 확인 후 등록
			MultipartFile mFile = thma.getMFile();			
			if( mFile != null && !mFile.isEmpty() ) {
				// 파일이 첨부되어 있으면 기존 파일 경로를 가져와 파일 삭제 후 재 업로드 한다.
				ThmaVO tmp = thmaDao.selectThmaById(thma.getThmaCd());				
				if( FileUtils.deleteAWSS3(tmp.getImgFilePath(), tmp.getImgFileNm()) ) {
					//파일 업로드
					FileVO file = FileUtils.sendAWSS3(mFile, "thema");
					
					if( file != null ) {
						//객체 저장
						thma.setImgFilePath(file.getFilePath());
						thma.setImgFileNm(file.getFileNm());
					}
				}
			}
			
			// Update Group에 대한 빈 검증 
			this.validateOrElseThrow(thma, Groups.Update.class);
			
			thmaDao.updateThma(thma);
		} else {
			throw this.processException("S001001");		// 이미 존재하는 데이터입니다. (이미 다른 코드에서 사용중인 대주제명)
		}
	}

	/** (OK)
	 * 하위에 소주제가 없는 대주제를 삭제, 업로드된 파일이 있을 경우 해당 파일도 S3에서 삭제처리 
	 */
	@Override
	public int deleteThma(String thma_cd) throws Exception {
		StgSearchVO stgSearch = new StgSearchVO();
		stgSearch.setThmaCd(thma_cd);
		
		// 이 대주제 밑으로 하위 소주제가 있으면 삭제할 수 없음
		if( stgDao.selectStgCnt(stgSearch) == 0 ) {
			int rows = 0;
			
			// 기존 파일 경로를 가져와 파일 삭제
			ThmaVO tmp = thmaDao.selectThmaById(thma_cd);
			
			if( tmp != null ) {
				// 업로드된 파일이 있을 경우 파일 삭제
				if( StringUtils.isNotEmpty(tmp.getImgFilePath()) && StringUtils.isNotEmpty(tmp.getImgFileNm()) ) {
					FileUtils.deleteAWSS3(tmp.getImgFilePath(), tmp.getImgFileNm());
				}
			
				// 조건없이 해당 대주제코드로 삭제
				rows = thmaDao.deleteThma(thma_cd);
			}
			return rows;
		} else {
			throw this.processException("S001014");		// 하위 소주제가 존재할 경우 삭제가 불가능합니다.
		}
	}
}