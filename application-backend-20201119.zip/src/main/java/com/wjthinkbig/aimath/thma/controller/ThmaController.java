/**
 * 
 */
package com.wjthinkbig.aimath.thma.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.thma.service.ThmaService;
import com.wjthinkbig.aimath.thma.vo.ThmaSearchVO;
import com.wjthinkbig.aimath.thma.vo.ThmaVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 주제정보관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Slf4j
@Api(description="커리큘럼 주제정보")
@RestController
public class ThmaController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 주제정보관리 서비스
	 */
	@Resource(name = "thmaService")
	private ThmaService thmaService;
	
	
	
	/** (OK)
	  * @Method 설명 : 검색조건에 따른 대주제정보 (리스트 및 전체 건수)를 제공한다.
	  * @param thmaSearch 검색조건 (ThmaSearchVO) 
	  * @return 대주제 리스트
	  * @throws Exception
	 */
	@ApiOperation(value="검색조건에 따른 대주제정보 (리스트 및 전체 건수)를 제공한다.", tags = {"커리큘럼 대주제 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/thema")
	public SingleResult<Map<String, Object>> selectThmaList(@ApiParam(value = "대주제 검색조건 VO") @ModelAttribute ThmaSearchVO thmaSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<>();
		
		List<ThmaVO> thmaList = thmaService.selectThmaList(thmaSearch);
		int thmaCnt = thmaService.selectThmaListCnt(thmaSearch);
		
		resultMap.put("thmaList", thmaList);
		resultMap.put("totalCnt", thmaCnt);
		
		return responseService.getSingleResult(resultMap); 
	}
	
	/** (OK)
	  * @Method 설명 : 단일 대주제 정보를 제공한다.
	  * @param thma_cd 조회할 대주제 코드
	  * @return 단일 대주제 정보 
	  * @throws Exception
	 */
	@ApiOperation(value="단일 대주제 정보를 제공한다.", tags = {"커리큘럼 대주제 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/thema/{thema}")
	public SingleResult<ThmaVO> selectThmaById(@ApiParam(value = "대주제코드") @PathVariable(name="thema",required=true) String thma_cd) throws Exception {
		ThmaVO thma = thmaService.selectThmaById(thma_cd);
		if(thma == null) {
			throw this.processException("S001003", thma_cd);		// 해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(thma);
	}
	
	/** (OK)
	  * @Method 설명 : 신규 대주제 정보를 등록한다.
	  * @param thma 등록할 정보를 담은 대주제정보 VO
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="신규 대주제 정보를 등록한다.", tags = {"커리큘럼 대주제 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/thema")
	public CommonResult insertThma(@ApiParam("등록할 정보를 담은 커리큘럼 주제 객체") @ModelAttribute ThmaVO thma) throws Exception {		
		thmaService.insertThma(thma);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 단일 대주제정보를 변경한다.
	  * @param thma 변경할 주제정보를 담은 VO
	  * @param thma_cd 변경할 주제정보의 식별코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "커리큘럼 주제정보 변경", tags = {"커리큘럼 대주제 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/thema/{thema}")
	public CommonResult updateThma(@ApiParam("변경할 정보를 담은 대주제 객체") @ModelAttribute ThmaVO thma, @ApiParam("변경할 대주제 코드") @PathVariable(name="thema", required=true) String thma_cd) throws Exception {		
		thma.setThmaCd(thma_cd);
		
		// 대주제명이 이미 다른 코드에 이미 등록되어 있는지 체크하여 없을 경우에만 변경처리 
		thmaService.updateThma(thma);
		return responseService.getResult(true);								
	}
	
	/**
	  * @Method 설명 : 등록된 대주제정보를 삭제한다.
	  * @param thma_cd 삭제대상 대주제코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="등록된 커리큘럼 주제 삭제", tags = {"커리큘럼 대주제 관리"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/thema/{thema}")	
	public CommonResult deleteThma(@ApiParam("삭제대상 주제정보의 고유키") @PathVariable("thema") String thma_cd) throws Exception {
		int rows = thmaService.deleteThma(thma_cd);
		if(rows == 0) {			
			throw this.processException("S001002", thma_cd); // 처리된 데이터가 없습니다.
		}
		return responseService.getResult(true);
	}
}