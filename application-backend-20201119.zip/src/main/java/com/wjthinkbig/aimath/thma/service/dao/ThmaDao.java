/**
 * 
 */
package com.wjthinkbig.aimath.thma.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.thma.vo.ThmaSearchVO;
import com.wjthinkbig.aimath.thma.vo.ThmaVO;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 대주제정보 관리 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Mapper("thmaDao")
public interface ThmaDao {

	/** (OK)
	  * @Method 설명 : 검색조건에 맞는 대주제 리스트를 가져온다. 
	  * @return 주제 전체리스트
	  * @param thmaSearch 대주제 검색조건 VO
	 */
	List<ThmaVO> selectThmaList(ThmaSearchVO thmaSearch);
	
	/** (OK)
	  * @Method 설명 : 대주제 전체 건수를 가져온다.
	  * @param thmaSearch 대주제 검색조건 VO
	  * @return 전체 등록 건수
	  */
	int selectThmaListCnt(ThmaSearchVO thmaSearch);
	
	/** (OK)
	  * @Method 설명 : 대주제 단일정보 조회  
	  * @param thma_cd 대주제코드
	  * @return 해당 대주제정보 
	 */
	ThmaVO selectThmaById(String thma_cd);
	
	/** (OK)
	  * @Method 설명 : 새로운 대주제 신규등록시 주제코드 채번
	  * @return 신규 주제코드
	  */
	String selectNewThmaCd();
	
	/** (OK)
	  * @Method 설명 : 새로운 대주제 신규등록시 정렬순번을 채번하여 가져온다 ( max(dsp_odr) + 1 )
	  * @return 신규 정렬순번
	  */
	int selectLastDspOrd();
	
	/** (OK)
	  * @Method 설명 : 커리큘럼 대주제 중복 건수 조회 (대주제명만으로 건수 또는 코드가 있는 경우 해당 코드를 제외한 다른 코드에서 사용하고 있는 건수)
	  * @param thmaSearch 검색조건 VO
	  * @return 일치하는 대주제 건 수
	 */
	int selectThmaNmDplctCheck(ThmaSearchVO thmaSearch);
	
	/** (OK)
	  * @Method 설명 : 신규 대주제 정보를 등록한다.
	  * @param thma 등록할 대주제 정보를 담은 VO 객체
	 */
	void insertThma(ThmaVO thma);

	/** (OK)
	  * @Method 설명 : 대주제 정보 변경
	  * @param thma 변경할 정보를 담은 주제 VO객체
	 */
	void updateThma(ThmaVO thma);

	/** (OK)
	  * @Method 설명 : 대주제 삭제 (조건없이 해당 대주제코드로 삭제)
	  * @param thma_cd 대주제코드 
	  * @return 삭제된 데이터 건 수
	 */
	int deleteThma(String thma_cd);
}