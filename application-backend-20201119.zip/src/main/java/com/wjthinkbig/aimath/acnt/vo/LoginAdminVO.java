/**
 * 
 */
package com.wjthinkbig.aimath.acnt.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.constraints.UserID;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.ToString;

/**
  * @Date : 2020. 9. 4. 
  * @프로그램 설명 : 로그인에 필요한 정보를 담고 있는 관리자 로그인 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@ApiModel(value = "로그인 VO", description = "로그인에 필요한 정보를 담고 있는 VO")

@ToString
public class LoginAdminVO {
	
	/**
	 * 아이디  
	 */
	@NotBlank
	@UserID
	@ApiModelProperty(value = "아이디")
	@FieldName("아이디")
	private String mngtUserId;
	
	/**
	 * 비밀번호
	 */
	@NotBlank
	@JsonProperty(access = Access.WRITE_ONLY)
	@ApiModelProperty(value = "비밀번호")
	@FieldName("비밀번호")
	private String pw;
	
	/**
	 * 로그인 유지 (Y/N)
	 */
	@Pattern(regexp = "Y|N")
	@ApiModelProperty(value = "로그인 유지여부")
	@FieldName("로그인 유지여부")
	private String rememberMe;

	public String getMngtUserId() {
		return mngtUserId;
	}

	public void setMngtUserId(String mngtUserId) {
		this.mngtUserId = mngtUserId;
	}

	public String getPw() {
		return pw;
	}

	public void setPw(String pw) {
		this.pw = pw;
	}

	public String getRememberMe() {
		return rememberMe;
	}

	public void setRememberMe(String rememberMe) {
		this.rememberMe = rememberMe;
	}	
}