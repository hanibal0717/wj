package com.wjthinkbig.aimath.acnt.vo;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.wjthinkbig.aimath.security.UserContext;

/**
  * @Date : 2020. 9. 11. 
  * @프로그램 설명 : 스프링시큐리티가 제공하는 User 객체에 대한 관리자 UserContext 객체
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk            최초작성
  * </pre>
 */
public class AdminAccount extends org.springframework.security.core.userdetails.User implements UserContext {
	
	private static final long serialVersionUID = -7495793419409636738L;
	
	// 실제 서비스용 AcntVO 객체
	private AcntVO user;

	/**
	 * @param user 인증받은 관리자의 AcntVO 객체
	 */
	public AdminAccount(AcntVO user) {		
		super(user.getMngtUserId(), user.getPw(), getAuthorities(user));		
		this.user = user;
	}
	 
	/**
	  * @Method 설명 : 인증받은 관리자의 AcntVO 객체를 가져온다.
	  * @return
	 */
	public AcntVO getUserInfo() {		
		return this.user;		
	}
	
	/**
	 * 인증된 객체의 식별아이디 (관리자ID)
	 */	
	@Override
	public String getUserId() {
		return this.user.getMngtUserId();
	}

	/**
	  * @Method 설명 : AcntVO 객체의 Role 정보로부터 인증된 사용자의 권한을 세팅
	  * @param user AcntVO 객체
	  * @return
	 */
	private static Collection<SimpleGrantedAuthority> getAuthorities(AcntVO user){
		Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        for(String authority : user.getRoles()) {
        	authorities.add(new SimpleGrantedAuthority(authority));
        }
        return authorities;
    }
}