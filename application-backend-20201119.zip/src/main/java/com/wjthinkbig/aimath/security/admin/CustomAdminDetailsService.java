package com.wjthinkbig.aimath.security.admin;

import java.util.Arrays;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.acnt.service.dao.AcntDao;
import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.acnt.vo.AcntVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 4. 
  * @프로그램 설명 : 관리자 인증을 위한 UserDetailsService 구현체  
  *  - 프로바이더(AjaxAdminAuthenticationProvider)에서 인증(authenticate)시 호출
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 4.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Slf4j
@Service("adminDetailsService")
public class CustomAdminDetailsService implements UserDetailsService {
	
	/**
	 * 관리자서비스 Dao
	 */
	@Resource(name = "acntDao")
	private AcntDao acntDao;
	
	/**
	 * 메시지 소스
	 */
	@Autowired
	private MessageSource messageSource;
	
	
	/**
	 * @throws UsernameNotFoundException
	 */
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		AcntVO userVO = acntDao.selectAcntById(username);
		if(userVO == null) {
			throw new UsernameNotFoundException(messageSource.getMessage("S001006", null, LocaleContextHolder.getLocale())); // 계정이 존재하지 않거나 계정정보가 올바르지 않습니다.
		} else {
			// 관리자에 대한 권한부여
			userVO.setRoles(Arrays.asList("ROLE_ADMIN", "ROLE_" + userVO.getAuthCd()));
		}

		log.debug("검색된 관리자객체 (loadUser) 정보 : {}", userVO);
		return new AdminAccount(userVO);
	}
}