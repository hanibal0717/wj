/**
 * 
 */
package com.wjthinkbig.aimath.security.model.token;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.jsonwebtoken.Claims;

/**
  * @Date : 2020. 10. 14. 
  * @프로그램 설명 : 토큰 문자열과 클레임정보를 가지는 토큰 객체 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public final class AccessJwtToken implements JwtToken {
	private final String rawToken;
	@JsonIgnore
	private Claims claims;
	
	public AccessJwtToken(final String rawToken, Claims claims) {
		this.rawToken = rawToken;
		this.claims = claims;
	}

	@Override
	public String getToken() {
		return this.rawToken;
	}

	public Claims getClaims() {
		return claims;
	}
}