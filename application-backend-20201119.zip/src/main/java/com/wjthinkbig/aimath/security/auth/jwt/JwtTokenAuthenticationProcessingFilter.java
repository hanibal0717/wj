/**
 * 
 */
package com.wjthinkbig.aimath.security.auth.jwt;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.util.matcher.RequestMatcher;

import com.wjthinkbig.aimath.config.WebSecurityConfig;
import com.wjthinkbig.aimath.security.auth.JwtAuthenticationToken;
import com.wjthinkbig.aimath.security.auth.jwt.extractor.TokenExtractor;
import com.wjthinkbig.aimath.security.model.token.RawAccessJwtToken;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 15. 
  * @프로그램 설명 : JWT 토큰인증처리 필터
  * 
  * 이 필터는 request 요청을 가로채서 만일 요청경로가 인증이 필요한 경로이면 인증을 시도한다. (requiresAuthenticationrequiresAuthentication)
  * 인증은 attemptAuthentication 메소드에서 수행
  *  - 인증성공시 그 결과로 인증된 Authentication 객체를 SecurityContext에 세팅 (successfulAuthentication)
  *  - 인증실패시 AuthenticationFailureHandler에게 그 처리를 위임한다. (unsuccessfulAuthentication)
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 15.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
public class JwtTokenAuthenticationProcessingFilter extends AbstractAuthenticationProcessingFilter {
	private final AuthenticationFailureHandler failureHandler;
	private final TokenExtractor tokenExtractor;
	
	/**
	 * @param failureHandler 인증실패시 처리기
	 * @param extractor 토큰추출 처리기
	 * @param matcher 인증필요여부를 판별하기 위한 전략
	 */
	@Autowired
	public JwtTokenAuthenticationProcessingFilter(AuthenticationFailureHandler failureHandler, TokenExtractor extractor, RequestMatcher matcher) {
		super(matcher); // 인증이 필요한 요청경로인지 여부 판별(SkipPathRequestMatcher)
		this.failureHandler = failureHandler;	
		this.tokenExtractor = extractor;		
	}

	/**
	 * 인증을 시도하여 인증된 사용자에 대해서는 인증토큰 객체를 반환한다. 인증이 진행중이면 null을, 실패하면 AuthenticationException을 반환한다.
	 */
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response)
			throws AuthenticationException, IOException, ServletException {
		
		// Authorization 헤더에서  Bearer 토큰을 추출하여 인증용 토큰(JwtAuthenticationToken)을 생성
		String headerPayload = request.getHeader(WebSecurityConfig.AUTHENTICATION_HEADER_NAME);
		RawAccessJwtToken token = new RawAccessJwtToken(tokenExtractor.extract(headerPayload));
		
		JwtAuthenticationToken jwtAuthentication = new JwtAuthenticationToken(token); // 인증전 객체
		
		// 생성한 토큰을 처리할 수 있는 Provider(JwtAuthenticationProvider)에서 인증처리 (authenticate)
		return getAuthenticationManager().authenticate(jwtAuthentication);
	}	

	/**
	 * 필터(doFilter)에서 인증성공시 호출되며 인증된 객체를 SecurityContext에 세팅한다.
	 */
	@Override
	protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain,
			Authentication authResult) throws IOException, ServletException {
		SecurityContext context = SecurityContextHolder.createEmptyContext();
		context.setAuthentication(authResult);		
		SecurityContextHolder.setContext(context);
		chain.doFilter(request, response);
	}

	/**
	 * 필터(doFilter)에서 인증처리(attemptAuthentication) 중 예외(AuthenticationException)가 발생했을 때 호출
	 *  - BadCredentialsException  : JWT 토큰의 유효성에 문제가 있는 모든 경우
	 *  - JwtExpiredTokenException : 토큰이 만료된 경우
	 *  - AuthMethodNotSupportedException : 토큰 추출을 위한 헤더 정보가 유효하지 않은 경우
	 */
	@Override
	protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, 
			AuthenticationException failed) throws IOException, ServletException {
		SecurityContextHolder.clearContext();
		failureHandler.onAuthenticationFailure(request, response, failed);
	}
}