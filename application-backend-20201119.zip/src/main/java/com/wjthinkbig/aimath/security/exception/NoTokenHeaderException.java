/**
 * 
 */
package com.wjthinkbig.aimath.security.exception;

import org.springframework.security.core.AuthenticationException;

/**
  * @Date : 2020. 10. 20. 
  * @프로그램 설명 : 토큰헤더가 없는 경우 발생하는 Exception
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class NoTokenHeaderException extends AuthenticationException {
	private static final long serialVersionUID = 322628664308641401L;

	public NoTokenHeaderException(String msg) {
		super(msg);
	}
	
	public NoTokenHeaderException(String msg, Throwable t) {
		super(msg, t);
	}
}