package com.wjthinkbig.aimath.security.exception;

import org.springframework.security.core.AuthenticationException;

/**
  * @Date : 2020. 11. 4 
  * @프로그램 설명 :  사용자가 이메일 인증을 하지않은 경우 발생하는 Exception 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 4      Kim Hee Seok       최초작성
  * </pre>
  */
public class NoEmailVerificationException extends AuthenticationException {
	private static final long serialVersionUID = 2625791355687859269L;

	public NoEmailVerificationException(String msg) {
		super(msg);
	}
	
	public NoEmailVerificationException(String msg, Throwable t) {
		super(msg, t);
	}
}
