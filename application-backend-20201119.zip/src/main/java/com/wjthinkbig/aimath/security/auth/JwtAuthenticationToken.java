/**
 * 
 */
package com.wjthinkbig.aimath.security.auth;

import java.util.Collection;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;

import com.wjthinkbig.aimath.security.model.token.RawAccessJwtToken;

/**
  * @Date : 2020. 9. 11. 
  * @프로그램 설명 : (회원/관리자) 인증토큰
  *  - 인증이 정상처리되면 회원용 또는 관리자용 어댑터클래스를 갖는다. 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk     최초작성
  * </pre>
  */
public class JwtAuthenticationToken extends AbstractAuthenticationToken {
	private static final long serialVersionUID = 436793318460549302L;

	private RawAccessJwtToken rawAccessJwtToken;	// API 호출시 (헤더를 통해) 전송된 토큰정보
	private User userContext;						// 사용자 어댑터 클래스 (MbrAccount/AdminAccount)
	
	/**
	 * 생성자 - 인증처리 전 상태의 AuthenticationToken을 생성하는 생성자 
	 * @param unsafeToken JWT 토큰 (필터에서 넘어오는 값)
	 */
	public JwtAuthenticationToken(RawAccessJwtToken unsafeToken) {
		super(null);
		this.rawAccessJwtToken = unsafeToken;
		this.setAuthenticated(false); // 인증되지 않은 상태
	}
	
	/**
	 * 생성자 - 인증처리된 상태의 AuthenticationToken을 생성하는 생성자로 AuthenticationManager 또는 AuthenticationProvider에서만 사용되어야 한다.
	 * @param rawAccessJwtToken JWT 토큰
	 * @param authorities
	 */
	public JwtAuthenticationToken(User userContext, Collection<? extends GrantedAuthority> authorities) {
		super(authorities);
		eraseCredentials();
		this.userContext = userContext;
		super.setAuthenticated(true); // must use super, as we override		
	}

	@Override
	public void setAuthenticated(boolean isAuthenticated) {
		if (isAuthenticated) {
			throw new IllegalArgumentException("Cannot set this token to trusted - use constructor which takes a GrantedAuthority list instead");
		}

		super.setAuthenticated(false);
	}
		
	@Override
	public Object getCredentials() {
		return this.rawAccessJwtToken;
	}
	
	@Override
	public Object getPrincipal() {
		return this.userContext;
	}

	@Override
	public void eraseCredentials() {
		super.eraseCredentials();
		this.rawAccessJwtToken = null;
	}
}