/**
 * 
 */
package com.wjthinkbig.aimath.security.auth.ajax;

import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wjthinkbig.aimath.acnt.service.AcntService;
import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService.CommonResponse;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrLogVO;
import com.wjthinkbig.aimath.security.config.JwtSettings;
import com.wjthinkbig.aimath.security.model.token.JwtToken;
import com.wjthinkbig.aimath.security.model.token.JwtTokenFactory;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 16. 
  * @프로그램 설명 : 인증성공시 처리핸들러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 16.    Lee Seung Hyuk     최초작성
  * 2020. 11. 05.	 Lee Seung Hyuk     토큰 2개에서 액세스 토큰 1개만 발급하여 주기적으로 서버에서 재발급하는 것으로 변경
  * </pre>
  */
@Slf4j
@Component("ajaxAwareAuthenticationSuccessHandler")
public class AjaxAwareAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
	private final JwtTokenFactory tokenFactory;
	private final ObjectMapper mapper;
	
	@Autowired
	public AjaxAwareAuthenticationSuccessHandler(JwtTokenFactory tokenFactory, ObjectMapper mapper) {
		this.tokenFactory = tokenFactory;
		this.mapper = mapper;
	}
	
	@Autowired
	private JwtSettings jwtSettings;

	@Autowired
	private MbrService mbrService;
	
	@Autowired
	private AcntService acntService;
	
	/**
	 * 채널구분코드
	 */
	@Value("${systemId}")
	String sysScnCd;
	
	/**
	 * Redis Template
	 */
	@Resource(name = "redisTemplate")
	private RedisTemplate<String, Object> redisTemplate;

	/**
	 * 인증성공시 인증된 객체(a fully populated Authentication object)로 토큰을 발급한다. 
	 */
	@Override
	public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
		log.debug("정상인증된 객체 (including granted authorities) : " + authentication.toString());
		
		// 토큰에 추가할 정보 
		HashMap<String, String> additionalClaims = new HashMap<String, String>();
		additionalClaims.put("chn", sysScnCd); // 채널정보를 토큰에 추가한다.
		
		User user = null;
		String userId = null;
		if(authentication.getPrincipal() instanceof MbrAccount) {
			user = (MbrAccount) authentication.getPrincipal();	
			userId = ((MbrAccount)user).getUserId();
			additionalClaims.put("mbr", ((MbrAccount)user).getUserId()); // 가입회원의  회원 아이디를 토큰에 추가한다.			
		} else if(authentication.getPrincipal() instanceof AdminAccount) {
			user = (AdminAccount) authentication.getPrincipal();
			userId = ((AdminAccount)user).getUserId();
		}
		
		// 사용자/관리자별 인증객체로 액세스 토큰과 리프레시 토큰을 발급한다.
		JwtToken accessToken = tokenFactory.createAccessJwtToken(user, additionalClaims);
//		JwtToken refreshToken = tokenFactory.createRefreshToken(user, additionalClaims);  // 토큰정책변경

		// Redis에 리프레시 토큰을 저장
        ValueOperations<String, Object> vop = redisTemplate.opsForValue();
        
        String redisKey = "token:refresh:" + sysScnCd + ":" + userId;
//        vop.set(redisKey, refreshToken.getToken(), jwtSettings.getRefreshTokenExpirationTime(), TimeUnit.MINUTES);  // 토큰정책변경
        vop.set(redisKey,accessToken.getToken(), jwtSettings.getAccessTokenExpirationTime(), TimeUnit.MINUTES);
        
        HashMap<String, String> data = new HashMap<>();
        data.put("accessToken", accessToken.getToken());
//      data.put("refreshToken", refreshToken.getToken()); // 토큰정책변경
        
        if(authentication.getPrincipal() instanceof MbrAccount) {
        	//최근 비밀번호 변경일로부터의 경과일수가 6개월(180일)을 초과시 변경대상자 표시
    		String isNeedToChange = "N";
			try {
				long elapsedDays = mbrService.selectPassedDaysFromChangeDt(userId);
				log.info("비밀번호 최근 변경일로부터 {}일 경과", elapsedDays);
	    		if(elapsedDays > 180) {
	    			isNeedToChange = "Y";
	    		}
			} catch (Exception e) {
				e.printStackTrace();
			}			
			data.put("isNeedToChange", isNeedToChange);
    		
        	// 회원 접속 로그를 쌓는다.
            try {
            	MbrLogVO logVO = new  MbrLogVO();
            	logVO.setSbsceMbrId(((MbrAccount)user).getUserId());
    			mbrService.insertLog(logVO, request);
    		} catch (Exception e) {    			
    			e.printStackTrace();
    		}
        } else if(authentication.getPrincipal() instanceof AdminAccount) {
        	// 최근 비밀번호 변경일로부터의 경과일수가 6개월(180일)을 초과시 변경대상자 표시
    		String isNeedToChange = "N";
			try {
				long elapsedDays = acntService.selectPassedDaysFromChangeDt(userId);
				log.info("비밀번호 최근 변경일로부터 {}일 경과", elapsedDays);
	    		if(elapsedDays > 180) {
	    			isNeedToChange = "Y";
	    		}
			} catch (Exception e) {				
				e.printStackTrace();
			}
			data.put("isNeedToChange", isNeedToChange);
    		    		
    		// 최종로그인일시 갱신
    		try {
				acntService.updateLastLoginDt(userId);
			} catch (Exception e) {
				e.printStackTrace();
			}
        }
        
		// 응답객체
//		Token token = new Token(userId, accessToken.getToken(), refreshToken.getToken());
		
		// API 응답
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.OK.value());
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);

		SingleResult<HashMap<String, String>> result = new SingleResult<HashMap<String, String>>();
		result.setMsg("It has been processed successfully.");
		result.setCode(CommonResponse.SUCCESS.getCode());
		result.setData(data);		
		
		mapper.writeValue(response.getWriter(), result);		
	}
}