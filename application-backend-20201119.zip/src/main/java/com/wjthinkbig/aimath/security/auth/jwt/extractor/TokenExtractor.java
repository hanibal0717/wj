/**
 * 
 */
package com.wjthinkbig.aimath.security.auth.jwt.extractor;

/**
  * @Date : 2020. 10. 14. 
  * @프로그램 설명 : JWT 토큰을 가져오는 Extractor 인터페이스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public interface TokenExtractor {

	/**
	  * @Method 설명 : 전송된 데이터(payLoad)로부터 실제 토큰문자열을 꺼낸다.
	  * @param payLoad (Http 헤더 또는 기타 전송수단의 전송값)
	  * @return 토큰문자열
	 */
	public String extract(String payLoad);
}