/**
 * 
 */
package com.wjthinkbig.aimath.security.auth.jwt.verifier;

/**
  * @Date : 2020. 10. 14. 
  * @프로그램 설명 : 토큰검증 인터페이스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public interface TokenVerifier {
	
	/**
	  * @Method 설명 : 토큰이 유효한지 여부를 검증한다.
	  * @param jti 
	  * @return true/false
	 */
	public boolean verify(String jti);
}