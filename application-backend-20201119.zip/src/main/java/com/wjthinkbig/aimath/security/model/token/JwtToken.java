/**
 * 
 */
package com.wjthinkbig.aimath.security.model.token;

/**
  * @Date : 2020. 10. 14. 
  * @프로그램 설명 : JWT 토큰 인터페이스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public interface JwtToken {
	/**
	  * @Method 설명 : 토큰값을 반환한다.
	  * @return JWT 토큰문자열
	 */
	String getToken();
}