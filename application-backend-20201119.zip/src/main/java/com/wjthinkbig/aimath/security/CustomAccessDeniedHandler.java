package com.wjthinkbig.aimath.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.stereotype.Component;

/**
  * @Date : 2020. 9. 10. 
  * @프로그램 설명 : AccessDenied 핸들러 (권한부족시의 처리 핸들러)
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 10.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Component("accessDeniedHandler")
public class CustomAccessDeniedHandler implements AccessDeniedHandler {

	@Override
	public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException accessDeniedException) throws IOException, ServletException {
		response.sendRedirect("/exception/accessdenied");
	}
}