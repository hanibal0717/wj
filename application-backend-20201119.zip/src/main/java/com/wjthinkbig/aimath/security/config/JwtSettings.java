package com.wjthinkbig.aimath.security.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

/**
  * @Date : 2020. 10. 9. 
  * @프로그램 설명 : 토큰 설정 클래스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 9.     Lee Seung Hyuk     최초작성
  * </pre>
 */
@Configuration
@ConfigurationProperties(prefix = "security.jwt")
@Setter
@Getter
public class JwtSettings {

    /**
     * Access Token 유효 시간(분)
     */
    private Integer accessTokenExpirationTime;

    /**
     * Refresh Token 유효 시간(분)
     */
    private Integer refreshTokenExpirationTime;
    
    /**
     * 토큰 발행자
     */
    private String tokenIssuer;

    /**
     * 서명키
     */
    private String tokenSigningKey;
    
    /**
     * 토큰 재발급 기준시간(분) : 토큰만료 전까지 남은 유효 시간이 여기서 설정한 시간 안에 들어오면  토큰을 재발급한다.
     */
    private Integer accessTokenRefreshTime;
}