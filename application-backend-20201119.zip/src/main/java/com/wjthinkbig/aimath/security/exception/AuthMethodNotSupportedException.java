/**
 * 
 */
package com.wjthinkbig.aimath.security.exception;

import org.springframework.security.authentication.AuthenticationServiceException;

/**
  * @Date : 2020. 10. 16. 
  * @프로그램 설명 : 지원하지 않는 인증 요청 메소드 에러
  *  - JwtHeaderTokenExtractor에서 헤더정보가 유효하지 않을 경우 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 16.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class AuthMethodNotSupportedException extends AuthenticationServiceException {
	private static final long serialVersionUID = -47617807588974654L;

	public AuthMethodNotSupportedException(String msg) {
		super(msg);
	}
}