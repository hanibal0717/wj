package com.wjthinkbig.aimath.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 9. 
  * @프로그램 설명 : 인증에 실패하였을 경우의 처리
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 9.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Component("authenticationEntryPoint")
@Slf4j
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint {

	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
		log.error("authenticationEntryPoint exception : {}", authException.getClass().getSimpleName());
		response.sendRedirect("/exception/entrypoint");		
	}
}