package com.wjthinkbig.aimath.config;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.annotation.Resource;
import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import egovframework.rte.fdl.idgnr.impl.EgovTableIdGnrServiceImpl;
import egovframework.rte.fdl.idgnr.impl.strategy.EgovIdGnrStrategyImpl;

/**
  * @Date : 2020. 9. 3. 
  * @프로그램 설명 : ID생성서비스 설정 클래스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 3.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Configuration
public class CommonIdGnrConfig {

	@Resource(name = "defaultDataSource")
	DataSource dataSource;

	/**
	 * 가입 회원ID 생성 서비스
	 * @return
	 */
	@Bean(name = "mbrIdGenService")
	public EgovIdGnrService mbrIdGenService() {
		// 아이디 생성을 위한 룰을 등록하고 룰에 맞는 아이디를 생성하기 위한 전략
		EgovIdGnrStrategyImpl idGnrStrategy = new EgovIdGnrStrategyImpl();
		String nowYmd = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHH"));
		idGnrStrategy.setPrefix("MBR" + nowYmd); // 아이디의 앞에 고정적으로 붙이고자 하는 설정값 지정
		idGnrStrategy.setFillChar('0'); // 0을 대신하여 표현되는 문자 (기본은 '0')
		idGnrStrategy.setCipers(7);    // prefix를 제외한 아이디의 길이 지정 (디폴트는 5자리)
		
		EgovTableIdGnrServiceImpl tableIdGenService = new EgovTableIdGnrServiceImpl();
		tableIdGenService.setDataSource(dataSource);
		tableIdGenService.setStrategy(idGnrStrategy);
		tableIdGenService.setBlockSize(1);				// Id Generation 내부적으로 사용하는 정보로 ID 요청시마다 DB접속을 하지 않기 위한 정보(지정한 횟수 마다 DB 접속 처리)
		tableIdGenService.setTable("brs.tb_cmn_seq");   // 생성하는 테이블 정보로 사용처에서 테이블명 변경 가능
		tableIdGenService.setTableName("mbr_id");		// 사용하고자 하는 아이디 개별 인식을 위한 키 값(대개의 경우는 테이블 별로 아이디가 필요하기에 tableName이라고 지정함)

		return tableIdGenService;
	}
	
	/**
	 * 학습 회원ID 생성 서비스
	 * @return
	 */
	@Bean(name = "lrnIdGenService")
	public EgovIdGnrService lrnIdGenService() {
		// 아이디 생성을 위한 룰을 등록하고 룰에 맞는 아이디를 생성하기 위한 전략
		EgovIdGnrStrategyImpl idGnrStrategy = new EgovIdGnrStrategyImpl();
		String nowYmd = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHH"));
		idGnrStrategy.setPrefix("LRN" + nowYmd); // 아이디의 앞에 고정적으로 붙이고자 하는 설정값 지정
		idGnrStrategy.setFillChar('0'); // 0을 대신하여 표현되는 문자 (기본은 '0')
		idGnrStrategy.setCipers(7);    // prefix를 제외한 아이디의 길이 지정 (디폴트는 5자리)
		
		EgovTableIdGnrServiceImpl tableIdGenService = new EgovTableIdGnrServiceImpl();
		tableIdGenService.setDataSource(dataSource);
		tableIdGenService.setStrategy(idGnrStrategy);
		tableIdGenService.setBlockSize(1);				
		tableIdGenService.setTable("brs.tb_cmn_seq");  
		tableIdGenService.setTableName("lrn_id");		

		return tableIdGenService;
	}
	
	/**
	 * 비회원 ID 생성 서비스
	 * @return
	 */
	@Bean(name = "gstIdGenService")
	public EgovIdGnrService gstIdGenService() {
		// 아이디 생성을 위한 룰을 등록하고 룰에 맞는 아이디를 생성하기 위한 전략
		EgovIdGnrStrategyImpl idGnrStrategy = new EgovIdGnrStrategyImpl();
		String nowYmd = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHH"));
		idGnrStrategy.setPrefix("GST" + nowYmd); // 아이디의 앞에 고정적으로 붙이고자 하는 설정값 지정
		idGnrStrategy.setFillChar('0'); // 0을 대신하여 표현되는 문자 (기본은 '0')
		idGnrStrategy.setCipers(7);    // prefix를 제외한 아이디의 길이 지정 (디폴트는 5자리)
		
		EgovTableIdGnrServiceImpl tableIdGenService = new EgovTableIdGnrServiceImpl();
		tableIdGenService.setDataSource(dataSource);
		tableIdGenService.setStrategy(idGnrStrategy);
		tableIdGenService.setBlockSize(1);				
		tableIdGenService.setTable("brs.tb_cmn_seq");   
		tableIdGenService.setTableName("gst_id");		

		return tableIdGenService;
	}
}