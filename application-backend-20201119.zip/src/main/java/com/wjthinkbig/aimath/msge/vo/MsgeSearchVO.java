package com.wjthinkbig.aimath.msge.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 11. 10.
  * @프로그램 설명 : AI 상황별 메시지 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 10.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="AI 상황별 메시지 검색 정보")
public class MsgeSearchVO {
	
	@ApiModelProperty(value="노출상황코드")
	@FieldName("노출상황코드")
	private String dspSitutCd;
	
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;
	
	@ApiModelProperty(value="풀이정확도코드")
	@FieldName("풀이정확도코드")
	private String explAcrcyCd;

	@ApiModelProperty(value="풀이속도코드")
	@FieldName("풀이속도코드")
	private String explSpedCd;
	
	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn;
	
}
