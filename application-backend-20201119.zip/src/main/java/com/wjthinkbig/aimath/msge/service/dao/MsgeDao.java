package com.wjthinkbig.aimath.msge.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.msge.vo.MsgeSearchVO;
import com.wjthinkbig.aimath.msge.vo.MsgeVO;

/**
  * @Date : 2020. 11. 10.
  * @프로그램 설명 : AI 메시지 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 10.     19001861            최초작성
  * </pre>
  */
@Mapper("msgeDao")
public interface MsgeDao {
	
	/**
	  * @Method 설명 : 사용자 AI 상황별 메시지 리스트 조회
	  * @param msgeSearch
	  * @return
	  */
	List<MsgeVO> selectMsgeListByDspSitutCd(MsgeSearchVO msgeSearch);
	
}
