package com.wjthinkbig.aimath.msge.vo;

import java.time.LocalDateTime;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 11. 10.
  * @프로그램 설명 : AI 상황별 메시지 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 11. 10.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="AI 상황별 메시지 정보")
public class MsgeVO extends BaseVO {

	@ApiModelProperty(value="노출상황코드")
	@FieldName("노출상황코드")
	private String dspSitutCd;

	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;

	@ApiModelProperty(value="메시지순번")
	@FieldName("메시지순번")
	private int msgeSn;

	@ApiModelProperty(value="풀이정확도코드")
	@FieldName("풀이정확도코드")
	private String explAcrcyCd;

	@ApiModelProperty(value="풀이속도코드")
	@FieldName("풀이속도코드")
	private String explSpedCd;

	@ApiModelProperty(value="코멘트내용")
	@FieldName("코멘트내용")
	private String comntCn;

	@ApiModelProperty(value="상황내용")
	@FieldName("상황내용")
	private String situtCn;

	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn;	
}
