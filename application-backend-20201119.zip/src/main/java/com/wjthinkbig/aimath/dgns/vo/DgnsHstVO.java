package com.wjthinkbig.aimath.dgns.vo;

import java.time.LocalDateTime;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/** (OK)
  * @Date : 2020. 10. 19 
  * @프로그램 설명 :  진단테스트 이력 VO 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 19     Kim Hee Seok       최초작성
  * 2020. 11. 18     10013871			코드검수
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "진단테스트 이력 VO ")
public class DgnsHstVO extends BaseVO {
	
	/**
	 * 학습회원ID
	 */
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="학습회원id")
	@FieldName("학습회원id")
	private String lrnMbrId; 
	
	/**
	 * 채널코드
	 */
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd; 
	
	/**
	 * 진단시작일시
	 */
	@NotNull(groups = {Groups.Update.class})
	@ApiModelProperty(value="진단시작일시")
	@FieldName("진단시작일시")
	private LocalDateTime dgnsBgnDt;
	
	/**
	 * 진단종료일시
	 */
	@NotNull(groups = {Groups.Update.class})
	@ApiModelProperty(value="진단종료일시 ")
	@FieldName("진단종료일시")
	private LocalDateTime dgnsEndDt;  
	
	/**
	 * 진단대상 생년월
	 */
	@Pattern(regexp = "(19|20)\\d{2}(0[1-9]|1[012])")
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="진단대상생년월")
	@FieldName("진단대상생년월")
	private String dgnsTargtBrthmt;
	
	/**
	 * 진단대상 성별코드
	 */
	@Pattern(regexp = "M|F")
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="진단대상성별코드")
	@FieldName("진단대상성별코드")
	private String dgnsTargtSxdnCd;  
	
	/**
	 * 진단대상 학년코드
	 */
	@Pattern(regexp = "GR10|GR11|GR12|GR13|GR14|GR15|GR16")
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="진단대상학년코드")
	@FieldName("진단대상학년코드")
	private String dgnsTargtGradeCd;       
	
	/**
	 * 시작 레벨코드
	 */
	@NotBlank(groups = {Groups.Update.class})
	@ApiModelProperty(value="시작 레벨코드 ")
	@FieldName("시작 레벨코드 ")
	private String bgnLvlCd;
	
	/**
	 * 시작스테이지코드 
	 */
	@NotBlank(groups = {Groups.Update.class})
	@ApiModelProperty(value="시작스테이지코드")
	@FieldName("시작스테이지코드")
	private String bgnStgCd;
	
	/**
	 * 완료스테이지코드  
	 */
	@NotBlank(groups = {Groups.Update.class})
	@ApiModelProperty(value="완료스테이지코드")
	@FieldName("완료스테이지코드")
	private String compStgCd;
	
 	/**
 	 * 진단결과확인여부
 	 */
	@Pattern(regexp = "Y|N")
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="진단결과확인여부")
	@FieldName("진단결과확인여부")
	private String dgnsRsltCnfmYn;                    
}