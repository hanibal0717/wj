package com.wjthinkbig.aimath.dgns.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 14 
  * @프로그램 설명 : 진단테스트 신청 응답 VO 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "진단테스트 신청 응답 VO")
public class DgnsPropsResVO {
	
	/**
	 * 학습회원 아이디  
	 */
	@NotBlank
	@ApiModelProperty(value="학습회원 아이디")
	@FieldName("학습회원")
	private String mbrLrnId;
	
	
	/**
	 * 문항 예측값 (진단하는 동안 풀게될 문항 수 예측값)
	 */
	@NotNull
	@ApiModelProperty(value="문항개수값")
	@FieldName("문항개수값")
	private int estQstNo;
	
	/**
	 * 풀이소요시간 (진단하는데 소요될 시간 예측값)
	 */
	@NotNull
	@ApiModelProperty(value="예측 풀이시간")
	@FieldName("예측 풀이시간")
	private int estDiagDur;
	
	
	/**
	 * 문항코드
	 */
	@NotBlank
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;
	
}
