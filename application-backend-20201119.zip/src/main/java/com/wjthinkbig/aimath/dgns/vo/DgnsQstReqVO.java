package com.wjthinkbig.aimath.dgns.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 19 
  * @프로그램 설명 :  정답여부를 알기위한 요청 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 19     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "정답여부를 알기위한 요청 VO")
public class DgnsQstReqVO {
	
	/**
	 * 문항코드 
	 */
	@NotBlank
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;
	
	/**
	 * 사용자답안
	 */
	@ApiModelProperty(value="사용자답안")
	@FieldName("사용자답안")
	private String userAnsr;
}
