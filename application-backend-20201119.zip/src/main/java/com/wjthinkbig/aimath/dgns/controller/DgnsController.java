package com.wjthinkbig.aimath.dgns.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;

import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.ApiUtil;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.utils.WebUtil;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.dgns.service.DgnsService;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstReqVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsHstVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPrgsResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPrgsReqVO;

import com.wjthinkbig.aimath.dgns.vo.DgnsPropsReqVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsStgDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsTrnsMbrVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 13 
  * @프로그램 설명 : DgnsController.java : AI연산 진단테스트  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13          Kim Hee Seok       최초작성
  * </pre>
  */
@Slf4j
@Api(description = "진단테스트")
@RestController
public class DgnsController extends BaseController {
	
	/**
	 * 도메인 명 
	 */
	@Value("${ai-model.api-url}")
	private String apiUrl;
	
	/**
	 * setting api 경로
	 */
	@Value("${ai-model.diagnosis-setting-path}")
	private String diagnosisSettingPath;
	
	/**
	 *  progress api 진행 경로 
	 */
	@Value("${ai-model.diagnosis-progress-path}")
	private String diagnosisProgressPath;
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 진단 테스트 서비스 
	 */
	@Resource(name = "dgnsService")
	private DgnsService dgnsService;
	
	/**
	 * 회원 서비스 
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService;
	
	/**
	 * 비회원 (guest) 아이디 신규생성 서비스
	 */
	@Resource(name = "gstIdGenService")
	private EgovIdGnrService gstIdGenService;
	
	/**
	 * 외부 API 사용 유틸
	 */
	@Resource(name = "apiUtil")
	private ApiUtil apiUtil;
	
	/**
	 * 날짜 포맷 
	 */
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	
	
	/**
	 * @Method 설명 : getGuestId
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @return HashMap<String, String> {"guestId": "GST**********"}
	 * @throws Exception
	 */
	@ApiOperation(value = "비회원 세션 아이디 생성", tags = {"진단테스트"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/diagnosis/guestid")
	public SingleResult<HashMap<String, String>> getGuestId() throws Exception {
		// 비회원ID (guest) 채번
		HashMap<String, String> data =new HashMap<String, String>();
		// 비회원아이디를 채번한다. 
		data.put("guestId", gstIdGenService.getNextStringId());
		return responseService.getSingleResult(data);
	}
	
	/**
	 * @Method 설명 : insertDgnsProposal 학습회원(비회원 포함)의 진단 신청 정보를  AI 모델서버에 요청하여 응답을 받는다 
	 * @author Kim Hee Seok [2020. 10. 15]
	 * @param learner 학습자 아이디 
	 * @param channel 채널코드 
	 * @param propsReqVO 진단신청 요청 데이터를 담은 VO (학습회원 아이디, 성별, 출생년월, 학년, 채널코드)
	 * @param request
	 * @return resData (예상 문항수, 에상 시간 (ms), 최초 문항코드 담은 HashMap )
	 * @throws Exception
	 */
	@ApiOperation(value = "진단을 위한 신청 데이터 교환", tags = {"진단테스트"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/diagnosis/proposal/channels/{channel}/learners/{learner}")
	public SingleResult<HashMap<String, Object>> insertDgnsProposal(@ApiParam(value = "학습자 아이디") @PathVariable(name = "learner", required = true) String learner
			, @ApiParam(value = "채널 코드") @PathVariable(name = "channel", required = true) String channel
			, @ApiParam(value = "진단 요청 객체") @Valid @RequestBody DgnsPropsReqVO propsReqVO
			, HttpServletRequest request) throws Exception {
		// @RequestBody를 통해 전송된 데이터에 학습자 ID가 경로변수의 가입자 ID와 일치해야 한다.
		if((StringUtils.isNotBlank(propsReqVO.getLrnMbrId()) && !learner.equals(propsReqVO.getLrnMbrId()))
				|| (StringUtils.isNotBlank(propsReqVO.getChnCd()) && !channel.equals(propsReqVO.getChnCd()))) {
			throw this.processException("S002000"); // 학습자 정보가 일치하지 않습니다. 
		}
		// 로그인한 사용자의 학습회원 존재 여부 판단 
		if(LoginUtils.isLogin()) {
			MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
			if(mbrLrn == null) {
				throw this.processException("S002012");				// 해당 가입자가 존재하지 않습니다.
			}
		}
		// AI 서버에 보내는 데이터 
		MultiValueMap<String, Object> map= new LinkedMultiValueMap<String, Object>();
		map.add("lrnMbrId",propsReqVO.getLrnMbrId());  				// 학습회원아이디
		map.add("deviceScnCd",WebUtil.getDeviceKind(request));		// 디바이스 종류
		map.add("osScnCd",WebUtil.getOsKind(request));				// OS 종류
		
		// API 통신 틸에 url  과 MultiValueMap (요청데이터를 담은 map)으로 요청 데이터를 응답맵 (resResult) 에 받는다.  
		HashMap<String, Object> resResult = apiUtil.externalApi(apiUrl+diagnosisSettingPath, map); 
		
		// 응답데이터에서 필요 데이터만 넣을 맵 
		HashMap<String, Object> resData = new HashMap<String, Object>();
		
		// 응답 코드가 S000000일경우 필수데이터만 답고 S000000가 이닐경우 AI 모델의 에러를 그대로 resData에 셋팅한다 
		if(resResult.get("code").equals("S000000")) {
			resData = (HashMap<String, Object>) resResult.get("data");
			// 최초 진단 이력을 담을 이력 객체를 생성한다.
			DgnsHstVO hstVO = new DgnsHstVO();
			hstVO.setLrnMbrId(propsReqVO.getLrnMbrId()); 		// (응답값) 학습회원 아이디
			hstVO.setChnCd(propsReqVO.getChnCd());				// (요청값) 채널코드 
			hstVO.setDgnsTargtBrthmt(propsReqVO.getBrthmt());	// (요청값) 출생년월    
			hstVO.setDgnsTargtSxdnCd(propsReqVO.getSxdnCd());   // (요청값) 성별 (M |F) 
			hstVO.setDgnsTargtGradeCd(propsReqVO.getGrade()); 	// (요청값) 학년
	       	hstVO.setDgnsRsltCnfmYn("N");						// 진단결과 확인 여부 (옵션, 로직에서 결정)  
			hstVO.setLoginUser(propsReqVO.getLrnMbrId());		// 등록자, 등록일자, 수정자, 수정일자 셋팅 
			// 최초 등록할 진단 이력을 검증한다.
			this.validateOrElseThrow(hstVO, Groups.Insert.class);
			// 요청한 학습자의 아이디로 진단 이력이 있는지 판단한다.
			DgnsHstVO isVO = dgnsService.selectDgnsHstById(propsReqVO.getLrnMbrId());
			if(isVO != null) {
				// 진단 이력이 있을 경우 진단 결과 확인여부(N) 이거나 진단 종료 일자가 없고 완료 스테이지가 null 이면 완료하지 않은 이력으로 판단
				if(isVO.getDgnsRsltCnfmYn().equals("N") || (isVO.getDgnsEndDt() == null&&isVO.getCompStgCd() == null)) {
					// 완료가 않된 진단 테스트 삭제 
					int rows = dgnsService.deleteDgnsById(propsReqVO.getLrnMbrId());
					if(rows == 0) {
						throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
					}
				}else {
					throw this.processException("S002007"); // 이미진단 이력이 존재합니다.
				}
				
			}
			dgnsService.insertDgnsHst(hstVO);
		} else {
			resData = resResult;
		}
		return responseService.getSingleResult(resData);
	}
	
	/**
	 * @Method 설명 : selectQstById 문항코드로 문항 상세 정보 (응답받은 문항코드로 문항을 상세 정보를 가져온다 ) 
	 * @author Kim Hee Seok [2020. 10. 15]
	 * @param question 문항코드 
	 * @param language 언어코드 
	 * @param qstDtlVO 문항상세 VO 
	 * @return DgnsQstDtlVO (문항 코드, 스테이지, 폰트크기, 키보드유형, 문항내용, 지문내용, 보기내용)
	 * @throws Exception
	 */
	@ApiOperation(value = "단순 문항 정보" , tags = {"진단테스트"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/diagnosis/questions/{question}/languages/{language}")
	public SingleResult<DgnsQstDtlVO> selectQstById(@ApiParam(value = "문항코드") @PathVariable(name = "question", required = true) String question
			, @ApiParam(value = "언어 코드") @PathVariable(name = "language", required = true) String language
			, @ApiParam(value = "문항 객체") DgnsQstDtlVO qstDtlVO) throws Exception {
		qstDtlVO.setQstCd(question);
		qstDtlVO.setLangCd(language);
		// (검수를 마치고 오픈한[WS05] ) 문항 조회
		qstDtlVO = dgnsService.selectQstById(qstDtlVO);
		if(qstDtlVO == null) {
			throw this.processException("S002005"); //해당 문항이 존제하지 않습니다. 
		}
		return responseService.getSingleResult(qstDtlVO);
	}
	
	/**
	 * @Method 설명 : insertDgnsPrgrs  진단 테스트 진행중일때 요청/응답 메소드 (요청 : (사용자 입력한 정답) 반복 API/응답 dgnsPrsCd 이 E 일때 까지 반복 호출 )
	 * @author Kim Hee Seok 2020. 10. 15]
	 * @param question 문항코드 
	 * @param learner 학습자 아이디 
	 * @param language 언어코드 
	 * @param prgsReqVO 진행 요청 데이터 
	 * @return HashMap<String, Object> 
	 * @throws Exception
	 */
	@ApiOperation(value = "진단 진행을 위한 테이터 교환" , tags = {"진단테스트"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/diagnosis/progress/questions/{question}/learners/{learner}/languages/{language}")
	public SingleResult<HashMap<String, Object>> insertDgnsPrgrs(@ApiParam(value = "문항코드") @PathVariable(name = "question", required = true) String question
			, @ApiParam(value = "회원 코드") @PathVariable(name = "learner", required = true) String learner
			, @ApiParam(value = "언어 코드") @PathVariable(name = "language", required = true) String language
			, @ApiParam(value = "진단문항 진행요청 객체") @RequestBody DgnsPrgsReqVO prgsReqVO) throws Exception{ 
		// @RequestBody를 통해 전송된 데이터에 학습자 ID가 경로변수의 가입자 ID와 일치해야 한다.
		if((StringUtils.isNotBlank(prgsReqVO.getLrnMbrId()) && !learner.equals(prgsReqVO.getLrnMbrId()))
				&& (StringUtils.isNotBlank(prgsReqVO.getQstCd()) && !question.equals(prgsReqVO.getQstCd()))) {
			throw this.processException("S002014");		// 경로변수 값이 일치하지 않습니다. 
		}
		// 로그인한 사용자의 학습회원 존재 여부 판단 
		if(LoginUtils.isLogin()) {
			MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
			if(mbrLrn == null) {
				throw this.processException("S002017"); // 해당 학습자가 존재하지 않습니다.
			}
		}
		// (검수를 마치고 오픈한[WS05] ) 문항 조회
		int count = dgnsService.getQstCntById(question);
		if(count == 0) {
			throw this.processException("S002005"); // 해당 문항이 존제하지 않습니다. 
		}
		
		// 문항코드로 문항에대한 정답과 정답유형을 DgnsQstResVO 담는다.
		DgnsQstResVO  qstResVO = dgnsService.selectQstAns(question); 
		// 정답을 정답을 체크(apiUtil.jugeAnswer("사용자 입력답","문항정답","정답유형") 하여 ansrCw 에 Y|N 값으로 변경하여 넣는다  
		String ansrCwYn = apiUtil.jugeAnswer(prgsReqVO.getAnsrCw(),qstResVO.getQstCransr(),qstResVO.getCransrTyScnCd());
		// AI 서버에 보내는 데이터 
		MultiValueMap<String, Object> map= new LinkedMultiValueMap<String, Object>();
		map.add("accmTime", prgsReqVO.getAccmTime());					// 누적학습시간 (S)
		map.add("ansrCw", prgsReqVO.getAnsrCw());						// 사용자 입력답
		map.add("ansrCwYn", prgsReqVO.getAnsrCwYn());					// 정오답 여부 (Y|N)
		map.add("blkYn", prgsReqVO.getBlkYn());							// 빈칸여부 (Y|N)
		map.add("cnAnsrYn", prgsReqVO.getCnAnsrYn());					// 빈칸여부 (Y|N)
		map.add("dgnsPrsCd", prgsReqVO.getDgnsPrsCd());					// 진행코드 (W|U)
		map.add("inptTime", prgsReqVO.getInptTime());					// 입력에 소요된 시간 (ms)
		map.add("inputTy", prgsReqVO.getInputTy());						// 입력방식 INP_KPD : 키패드 INP_PEN : 필기 INP_KBD : 키보드
		map.add("lrnMbrId", prgsReqVO.getLrnMbrId());					// 학습자 아이디
		map.add("qstCd", prgsReqVO.getQstCd());							// 현재 문제 문항코드 
		map.add("slvTime",prgsReqVO.getSlvTime());						// 문제 풀이시간 (ms)
		// 빈칸여부와 정답여부가 B 거나 E 이면 빈칸여부는 Y 이고 정오답 여부는 N 으로 셋팅한다.
		if(StringUtils.isBlank(prgsReqVO.getAnsrCw())||ansrCwYn.equals("B")||ansrCwYn.equals("E")) {
			prgsReqVO.setBlkYn("Y");
			prgsReqVO.setAnsrCwYn("N");
		}
		// 값을 검증한다 .
		this.validateOrElseThrow(prgsReqVO);
		
		// API 통신 틸에 url  과 MultiValueMap (요청데이터를 담은 map)으로 요청 데이터를 응답맵 (resResult) 에 받는다.  
		HashMap<String, Object> resResult = apiUtil.externalApi(apiUrl+diagnosisProgressPath, map); 
		// 응답데이터에서 필요 데이터만 넣을 맵 
		HashMap<String, Object> resData = new HashMap<String, Object>();
		// 응답 코드가 S000000일경우 필수데이터만 답고 S000000가 이닐경우 AI 모델의 에러를 그대로 resData에 셋팅한다 
		if(resResult.get("code").equals("S000000")) {
			resData = (HashMap<String, Object>) resResult.get("data");
			DgnsPrgsResVO prgsResVO = new DgnsPrgsResVO();
			prgsResVO.setMbrLrnId(learner);								// 학습회원 아이디
			prgsResVO.setDgnsPrsCd((String)resData.get("dgnsPrsCd"));	// 진행코드
			prgsResVO.setAccuracy((int)resData.get("accuracy"));		// 정확도 (%)
			prgsResVO.setCnAnsCnt((int)resData.get("cnAnsCnt"));		// 모름 횟수
			prgsResVO.setQstCd((String)resData.get("qstCd"));			// 다음 문제 문항코드 
			// 진행코드 W일때  응답받은 데이터를 검증한다  
			if(prgsResVO.getDgnsPrsCd().equals("W")) {
				this.validateOrElseThrow(prgsResVO);
			}
			
			// 응답 진행코드 E 이고 다음문항이 null응답일 때는 나머지 값을 셋팅하고 진단 이력을 업데이트 한다.
			if(resData.get("dgnsPrsCd").equals("E") && resData.get("qstCd") == null) {
				prgsResVO.setDgnsBgnDt(LocalDateTime.parse((String)resData.get("dgnsBgnDt"),formatter));			// 진단 시작일시 
				prgsResVO.setDgnsEndDt(LocalDateTime.parse((String)resData.get("dgnsEndDt"),formatter)); 			// 진단 종료일시
				prgsResVO.setEstLastStgCd((String)resData.get("estLastStgCd")); 									// 학습 완료로 진단된 스테이지 코드
				
				// 스테이지 코드로 스테이지 명을 얻어온다 
				DgnsStgDtlVO lastStgNm = dgnsService.selectStgNm(prgsResVO.getEstLastStgCd(), language);			
				prgsResVO.setEstLastStgNm(lastStgNm.getStgNm());													// 학습 완료로 진단된 스테이지 명
				prgsResVO.setEstPreLvlCd((String)resData.get("estPreLvlCd")); 										// 적정 시작 지점의 레벨 코드
				prgsResVO.setEstPreStgCd((String)resData.get("estPreStgCd"));										// 적정 시작 지점의 스테이지 코드
				
				// 스테이지 코드로 스테이지 명과 스테이지 상세를 조회한다 
				DgnsStgDtlVO preStgNm = dgnsService.selectStgNm(prgsResVO.getEstPreStgCd(), language);
				prgsResVO.setEstPreStgNm(preStgNm.getStgNm());														// 적정 시작 지점의 스테이지 명 
				prgsResVO.setEstPreStgDtl(preStgNm.getStgDtl());													// 적정 시작 지점의 스테이지 상세 
				prgsResVO.setLrnMbrNm("GUEST");																		// 학습회원 명을 GUEST로 초기화 한다 

				// 로그인 회원일 경우 회원 아이디로 회원 명을 얻어 온다 
				if(LoginUtils.isLogin()) {
					MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(prgsReqVO.getLrnMbrId());
					prgsResVO.setLrnMbrNm(mbrLrn.getMbrNm());														// 회원명 
				}
				/*모든 응답을 받으면 tb_lnr_dgns_hst 진단 이력을 쌓는다.*/
				DgnsHstVO hstVO = new DgnsHstVO();
				hstVO.setLrnMbrId(prgsResVO.getMbrLrnId());    														// 학습회원 아이디       
				hstVO.setDgnsBgnDt(prgsResVO.getDgnsBgnDt());          												// 진단 시작 일시
				hstVO.setDgnsEndDt(prgsResVO.getDgnsEndDt());          												// 진단 종료 일시
				hstVO.setBgnLvlCd(prgsResVO.getEstPreLvlCd());														// 시작레벨 코드
				hstVO.setBgnStgCd(prgsResVO.getEstPreStgCd());														// 시작스테이지 코드 
				hstVO.setCompStgCd(prgsResVO.getEstLastStgCd());													// 학습완료 스테이지 코드 
				hstVO.setModUser(prgsResVO.getMbrLrnId());															// 수정자
				hstVO.setModDt(LocalDateTime.now());																// 수정일시 
				hstVO.setDgnsRsltCnfmYn("N");
				// 로그인한 회원일 경우 바로 진단 결과를 확인 하기 때문에 확인 여부를 Y 롤 셋팅한다 
				if(LoginUtils.isLogin()) {
					hstVO.setDgnsRsltCnfmYn("Y");
				}
				// 진단 이력을 업데이트 검증한다 
				this.validateOrElseThrow(hstVO, Groups.Update.class);
				int rows = dgnsService.updateDgnsHst(hstVO);
				if(rows == 0) {
					throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
				}
				// 진단 결과 페이지에 표시할 나머지 데이터를 셋팅한다.
				resData.put("lrnMbrNm", prgsResVO.getLrnMbrNm()); 													// 회원 명
				resData.put("estLastStgNm", prgsResVO.getEstLastStgNm());											// 완료 스테이지 명 
				resData.put("estPreStgNm", prgsResVO.getEstPreStgNm());												// 적정 시작 스테이지 명
				resData.put("estPreStgDtl", prgsResVO.getEstPreStgDtl());											// 적정 시작 스테이지 상세명 
			}
			
		} else {
			resData = resResult;
		}
		return responseService.getSingleResult(resData);
	}
	
	
	/**
	 * @Method 설명 : 문항의 정답확인  (프론트 페이지 정답확인 )
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @param question 문항코드 
	 * @param qstReqVO 문항 정답황인 요청 데이터 
	 * @return HashMap 정답결과 (문항정답,정답유형)
	 * @throws Exception
	 */
	@ApiOperation(value = "정답 확인" , tags = {"진단테스트"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/diagnosis/questions/{question}")
	public SingleResult<HashMap<String, String>> selectAnswrYn(@ApiParam(value = "문항코드") @PathVariable(name = "question", required = true) String question
			,@ApiParam(value = "정답판단 객체") @Valid @RequestBody  DgnsQstReqVO qstReqVO) throws Exception {
		if(!question.equals(qstReqVO.getQstCd())) {
			throw this.processException("S002014"); // 경로변수 값이 일치하지 않습니다.
		}
		// (검수를 마치고 오픈한[WS05] ) 문항 조회
		int count = dgnsService.getQstCntById(question);
		if(count == 0) {
			throw this.processException("S002005"); // 해당 문항이 존제하지 않습니다. 
		}
		// 문항코드로 문항에대한 정답과 정답유형을 DgnsQstResVO 담는다.
		DgnsQstResVO qstResVO = dgnsService.selectQstAns(question);
		// 정답을 정답을 체크(apiUtil.jugeAnswer("사용자 입력답","문항정답","정답유형") 하여 ansrCw 에 Y|N 값으로 변경하여 넣는다  
		String ansrCwYn = apiUtil.jugeAnswer(qstReqVO.getUserAnsr(), qstResVO.getQstCransr(), qstResVO.getCransrTyScnCd());
		
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("ansrCwYn", ansrCwYn);
		return responseService.getSingleResult(data);
	}
	
	/**
	 * @Method 설명 : updateRsltCnfm 진단결과 확인 업데이트 (비 회원일 경우 회원 가입후 진단 이력 회원 전환을 하고  진단학습 결과를 확인한다)
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @param guest 비회원 아이디
	 * @param learner 전환할 회원 가입 학습 아이디 
	 * @param language 언어코드
	 * @param trnsMbrVO 회원 전환 객체 
	 * @return DgnsPrgsResVO 진단테스트 결과 객체 
	 * @throws Exception
	 */
	@ApiOperation(value = "회원 전환 및 진단결과 확인 업데이트" , tags = {"진단테스트"})
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/diagnosis/confirm/guests/{guest}/learners/{learner}/languages/{language}")
	public SingleResult<DgnsPrgsResVO> updateRsltCnfm(@ApiParam(value = "게스트 아이디") @PathVariable(name = "guest", required = true) String guest
			, @ApiParam(value = "로그인 아이디") @PathVariable(name = "learner") String learner
			, @ApiParam(value = "언어코드") @PathVariable(name = "language") String language
			, @Valid @RequestBody @ApiParam(value = "회원전환객체 ") DgnsTrnsMbrVO trnsMbrVO) throws Exception {
		if(StringUtils.isBlank(learner) 
				|| !learner.equals(trnsMbrVO.getMbrLrnId())
				|| StringUtils.isBlank(guest)
				|| !guest.equals(trnsMbrVO.getGuestId())) {
			throw this.processException("S002014"); // 경로변수 값이 일치하지 않습니다.
		}
		// 학습자 존재 여부 
		MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
		if(mbrLrn == null) {
			throw this.processException("S002017");		// 해당 학습자가 존재하지 않습니다.
		}
		// 학습자 진단이력 존제 여부 (이미 로그인 회원 아이디로 진단학습 완료한 경우 )
		DgnsHstVO lrnHstVO = dgnsService.selectDgnsHstById(learner);
		if(lrnHstVO != null) {
			throw this.processException("S002007"); 	// 진단이력이 이미 존재합니다.
		}
		// 진단 이력 데이터  확인  (비회원 아이디로 진단 이력이 있는지 확인)
		DgnsHstVO gsthstVO = dgnsService.selectDgnsHstById(guest);
		if(gsthstVO == null) {
			throw this.processException("S001029"); 	// 진단이력이 존재하지 않습니다. 
		}
		trnsMbrVO.setModUser(learner);					// 수정자 
		trnsMbrVO.setModDt(LocalDateTime.now());		// 수정일 
		int rows = dgnsService.updateRsltCnfm(trnsMbrVO); // 진단 확인을 Y 로 업데이트 한다 
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		// 해당 회원의 진단 이력을 가져온다 
		DgnsHstVO rstHstVO = dgnsService.selectDgnsHstById(learner);
		
		// 가져온 진단이력 데이터로 진단 확인 VO에 값을 넣는다.
		DgnsPrgsResVO prgsResVO = new DgnsPrgsResVO();
		prgsResVO.setMbrLrnId(rstHstVO.getLrnMbrId());											// 학습회원 아이디 
		prgsResVO.setLrnMbrNm(mbrLrn.getMbrNm());												// 학습회원 이름
		prgsResVO.setEstLastStgCd(rstHstVO.getCompStgCd());										// 완료 스테이지 코드 
		// 완료 스테이지 코드로 완료 스테이지 명을 얻어온다 
		DgnsStgDtlVO lastStgNm = dgnsService.selectStgNm(rstHstVO.getCompStgCd(), language);	 
		prgsResVO.setEstLastStgNm(lastStgNm.getStgNm());										// 완료 스테이지 명 					
		
		prgsResVO.setEstPreLvlCd(rstHstVO.getBgnLvlCd());										// 적정 레벨 코드 
		prgsResVO.setEstPreStgCd(rstHstVO.getBgnStgCd());										// 적정 스테이지 코드 
		// 적정 스테이지 코드로 스테이지 명과 상세명을 얻어온다.
		DgnsStgDtlVO preStgNm = dgnsService.selectStgNm(rstHstVO.getBgnStgCd(), language);			
		prgsResVO.setEstPreStgNm(preStgNm.getStgNm());											// 적정 스테이지 명
		prgsResVO.setEstPreStgDtl(preStgNm.getStgDtl());										// 정정 스테이지 상세명 
		return responseService.getSingleResult(prgsResVO);
	}
}























