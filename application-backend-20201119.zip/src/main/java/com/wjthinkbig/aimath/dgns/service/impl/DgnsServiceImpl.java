package com.wjthinkbig.aimath.dgns.service.impl;

import java.util.HashMap;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.dgns.service.DgnsService;
import com.wjthinkbig.aimath.dgns.service.dao.DgnsDao;
import com.wjthinkbig.aimath.dgns.vo.DgnsHstVO;

import com.wjthinkbig.aimath.dgns.vo.DgnsQstResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsStgDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsTrnsMbrVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 13 
  * @프로그램 설명 : DgnsServiceImpl.java 진단테스트 서비스 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13     Kim Hee Seok       최초작성
  * </pre>
  */

@Slf4j
@Service("dgnsService")
public class DgnsServiceImpl extends BaseServiceImpl implements DgnsService {
	
	/**
	 * 진단테스트 서비스 Dao
	 */
	@Resource(name = "dgnsDao")
	private DgnsDao dgnsDao;

	@Override
	public DgnsQstDtlVO selectQstById(DgnsQstDtlVO qstDtlVO) throws Exception {
		return dgnsDao.selectQstById(qstDtlVO);
	}

	@Override
	public int getQstCntById(String qstCd) throws Exception {
		int count = dgnsDao.getQstCntById(qstCd);
		return count;
	}

	@Override
	public DgnsQstResVO selectQstAns(String qstCd) throws Exception {
		return dgnsDao.selectQstAns(qstCd);
	}

	@Override
	public void insertDgnsHst(DgnsHstVO hstVO) throws Exception {
		dgnsDao.insertDgnsHst(hstVO);
	}

	@Override
	public DgnsHstVO selectDgnsHstById(String guest) throws Exception {
		return dgnsDao.selectDgnsHstById(guest);
	}

	@Override
	public int updateRsltCnfm(DgnsTrnsMbrVO trnsMbrVO) throws Exception {
		return dgnsDao.updateRsltCnfm(trnsMbrVO);
	}

	@Override
	public int deleteDgnsById(String mbrLrnId) throws Exception {
		return dgnsDao.deleteDgnsById(mbrLrnId);
	}

	@Override
	public int updateDgnsHst(DgnsHstVO hstVO) throws Exception {
		return dgnsDao.updateDgnsHst(hstVO);
	}

	@Override
	public DgnsStgDtlVO selectStgNm(String stgCd, String langCd) throws Exception {
		HashMap<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("stgCd", stgCd);
		paramMap.put("langCd", langCd );
		return dgnsDao.selectStgNm(paramMap);
	}
}
