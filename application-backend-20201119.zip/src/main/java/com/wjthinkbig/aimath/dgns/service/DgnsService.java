package com.wjthinkbig.aimath.dgns.service;

import com.wjthinkbig.aimath.dgns.vo.DgnsHstVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsStgDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsTrnsMbrVO;

/**
  * @Date : 2020. 10. 13 
  * @프로그램 설명 : DgnsService.java 진단테스트 서비스 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13     Kim Hee Seok       최초작성
  * </pre>
  */
public interface DgnsService {

	/**
	 * @Method 설명 : selectQstById 문항 코드로 문항 상세를 불러온다 
	 * @author Kim Hee Seok [2020. 11. 16]
	 * @param qstDtlVO 문항상세 객체
	 * @return DgnsQstDtlVO 문항상세 객체 
	 * @throws Exception
	 */
	public DgnsQstDtlVO selectQstById(DgnsQstDtlVO qstDtlVO) throws Exception;

	/**
	 * @Method 설명 : getQstCountById 문항 코드로 문항수를 판단힌다 .
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param question 문항코드 
	 * @return int
	 * @throws Exception
	 */
	public int getQstCntById(String question) throws Exception;

	/**
	 * @Method 설명 : selectQstAns 문항코드로 정답과 정답 유형을 불러온다 
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param question 문항코드 
	 * @return DgnsQstAnsVO (정답과 정담유형 객체 )
	 * @throws Exception
	 */
	public DgnsQstResVO selectQstAns(String question) throws Exception;

	
	/**
	 * @Method 설명 : insertDgnsHst 진단이력을 입력한다
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param hstVO 진단 이력  객체 
	 * @throws Exception
	 */
	public void insertDgnsHst(DgnsHstVO hstVO) throws Exception;

	/**
	 * @Method 설명 : selectHstById 임시 회원아이디의 진단이력 조회
	 * @author Kim Hee Seok [2020. 10. 19]
	 * @param guest 임시 회원 아이디 
	 * @return DgnsHstVO 진단이력 객체 
	 * @throws Exception
	 */
	public DgnsHstVO selectDgnsHstById(String guest) throws Exception;

	/**
	 * @Method 설명 : updateRsltCnfm 진단 이력을 확인여부와 임시아이디를 학습회원 아이디로 전환한다.
	 * @author Kim Hee Seok [2020. 10. 19]
	 * @param trnsMbrVO 임시 아이디와 회원 가입 아이디 
	 * @return int
	 * @throws Exception
	 */
	public int updateRsltCnfm(DgnsTrnsMbrVO trnsMbrVO) throws Exception;

	/**
	 * @Method 설명 : deleteDgnsById 해당 회원의 진단 이력을 지운다. 
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param mbrLrnId 학습자 아이디 
	 * @return int
	 */
	public int deleteDgnsById(String mbrLrnId) throws Exception;

	/**
	 * @Method 설명 : updateDgnsHst 해당 진단 종료시  이력을 업데이트 한다 
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param hstVO 이력객체 
	 * @return int
	 * @throws Exception
	 */
	public int updateDgnsHst(DgnsHstVO hstVO) throws Exception;

	/**
	 * @Method 설명 : selectStgNm 스테이지 코드로 스테이지 명을 가져온다 
	 * @author Kim Hee Seok [2020. 10. 27]
	 * @param language 언어코드 
	 * @param stgCd 스테이지 코드 
	 * @return DgnsStgDtlVO 스테이지 상세 객체 
	 * @throws Exception
	 */
	public DgnsStgDtlVO selectStgNm(String stgCd, String language) throws Exception;

}
