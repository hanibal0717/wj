/**
 * 
 */
package com.wjthinkbig.aimath.stg.vo;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;

/**
  * @Date : 2020. 8. 25. 
  * @프로그램 설명 :
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 25.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class StgSaveVO extends SaveVO<StgVO> {
	
	private static final long serialVersionUID = 8096591804346765964L;

}
