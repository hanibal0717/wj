package com.wjthinkbig.aimath.acnt.service;

import java.util.List;

import javax.validation.Valid;

import com.wjthinkbig.aimath.acnt.vo.LoginAdminVO;
import com.wjthinkbig.aimath.acnt.vo.AcntSearchVO;
import com.wjthinkbig.aimath.acnt.vo.AcntVO;

/**
  * @Date : 2020. 9. 7.
  * @프로그램 설명 : 관리자 정보 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 7.     19001861            최초작성
  * </pre>
  */
public interface AcntService {
	
	/**
	  * @Method 설명 : 검색조건에 맞는 관리자 정보 전체 리스트를 가져온다.
	  * @param acntSearch 검색할 정보를 담은 관리자 VO
	  * @return 검색된 관리자 정보 리스트
	  * @throws Exception
	 */
	public List<AcntVO> selectAcntList(AcntSearchVO acntSearch) throws Exception;
	
	/**
	  * @Method 설명 : 검색조건에 맞는 관리자 정보 전체 리스트 수를 가져온다.
	  * @param acntSearch 검색할 정보를 담은 관리자 VO
	  * @return 검색된 관리자 정보 리스트 수
	  * @throws Exception
	  */
	public int selectAcntCnt(AcntSearchVO acntSearch) throws Exception;
	
	/**
	  * @Method 설명 : 관리자 정보 단일 조회
	  * @param mngt_user_id
	  * @return
	  * @throws Exception
	  */
	public AcntVO selectAcntById(String mngt_user_id) throws Exception;
	
	/**
	  * @Method 설명 : 관리자ID 중복체크
	  * @param mngt_user_id
	  * @return
	  * @throws Exception
	  */
	public int selectUserIdDplctCeck(String mngt_user_id) throws Exception;
	
	/**
	  * @Method 설명 : 관리자 비밀번호 확인
	  * @param acnt
	  * @return
	  * @throws Exception
	  */
	public boolean selectPasswordCeck(AcntVO acnt) throws Exception;
	
	/**
	  * @Method 설명 : 신규 관리자 정보 등록
	  * @param acnt
	  * @throws Exception
	  */
	public void insertAcnt(AcntVO acnt) throws Exception;
	
	/**
	  * @Method 설명 : 관리자 정보 수정
	  * @param acnt
	  * @throws Exception
	  */
	public void updateAcnt(AcntVO acnt) throws Exception;
	
	/**
	  * @Method 설명 : 관리자 정보 삭제
	  * @param mngt_user_id
	  * @return
	  * @throws Exception
	  */
	public int deleteAcnt(String mngt_user_id) throws Exception;

	/**
	  * @Method 설명 : 관리자 로그인
	  * @param user 로그인 VO
	  * @return 인증토큰
	  */
	public String signin(@Valid LoginAdminVO user) throws Exception;

	/**
	  * @Method 설명 : 관리자의 비밀번호 변경일시로부터의 경과일수
	  * @param mngtUserId 관리자 ID
	  * @return 경과일수 (변경한 이력이 없거나 해당 회원이 없을 경우 0을 반환) 
	  * @throws Exception
	 */
	public long selectPassedDaysFromChangeDt(String mngtUserId) throws Exception;
	
	/**
	  * @Method 설명 : 로그인 시 최종 로그인일시 갱
	  * @param mngt_user_id 관리자ID
	  * @return 갱신된 건 수
	  * @throws Exception
	 */
	public int updateLastLoginDt(String mngt_user_id) throws Exception;
	
	/**
	  * @Method 설명 : 최종비밀번호변경일자를 기준일로부터 5개월전으로 갱신 (1개월후에 비밀번호 변경도래)
	  * @param mngt_user_id 관리자 ID
	  * @return
	  * @throws Exception
	 */
	public int updatePasswordChangeDate (String mngt_user_id) throws Exception;
}
