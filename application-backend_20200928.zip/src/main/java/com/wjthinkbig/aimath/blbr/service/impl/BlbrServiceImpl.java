package com.wjthinkbig.aimath.blbr.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.blbr.service.BlbrService;
import com.wjthinkbig.aimath.blbr.service.dao.BlbrDao;
import com.wjthinkbig.aimath.blbr.vo.BlbrSearchVO;
import com.wjthinkbig.aimath.blbr.vo.BlbrVO;
import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.validator.groups.Groups;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 23.
  * @프로그램 설명 : 게시판 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 23.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Service("blbrService")
public class BlbrServiceImpl extends BaseServiceImpl implements BlbrService {
	
	/**
	 * 게시판 관리 Dao
	 */
	@Resource(name = "blbrDao")
	private BlbrDao blbrDao;
	
	@Override
	public List<BlbrVO> selectBlbrList(BlbrSearchVO blbrSearch) throws Exception {
		if( blbrSearch.getRowCnt() <= 0 ) blbrSearch.setRowCnt(10);
		if( blbrSearch.getCurrentPage() <= 0 ) blbrSearch.setCurrentPage(1);
		
		this.validateOrElseThrow(blbrSearch);
		
		return blbrDao.selectBlbrList(blbrSearch);
	}

	@Override
	public BlbrVO selectBlbrById(BlbrSearchVO blbrSearch) throws Exception {
		this.validateOrElseThrow(blbrSearch);
		return blbrDao.selectBlbrById(blbrSearch);
	}

	@Override
	public void insertBlbr(BlbrVO blbr) throws Exception {
		this.validateOrElseThrow(blbr, Groups.Insert.class);
		blbrDao.insertBlbr(blbr);
	}

	@Override
	public void updateBlbr(BlbrVO blbr) throws Exception {
		this.validateOrElseThrow(blbr, Groups.Update.class);
		blbrDao.updateBlbr(blbr);
	}

	@Override
	public int deleteBlbr(BlbrVO blbr) throws Exception {
		this.validateOrElseThrow(blbr, Groups.Delete.class);
		return blbrDao.deleteBlbr(blbr);
	}

}
