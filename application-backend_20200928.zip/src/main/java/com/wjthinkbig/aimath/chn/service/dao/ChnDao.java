package com.wjthinkbig.aimath.chn.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.chn.vo.ChnSearchVO;
import com.wjthinkbig.aimath.chn.vo.ChnVO;
import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;

/**
  * @Date : 2020. 9. 21.
  * @프로그램 설명 : 채널 관리 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 21.     19001861            최초작성
  * </pre>
  */
@Mapper("chnDao")
public interface ChnDao {
	
	/**
	  * @Method 설명 : 채널 전체 리스트 조회
	  * @param chnSearch
	  * @return
	  */
	List<ChnVO> selectChnList(ChnSearchVO chnSearch);
	
	/**
	  * @Method 설명 : 채널 정보 단일 조회
	  * @param chn_cd
	  * @return
	  */
	ChnVO selectChnById(String chn_cd);
	
	/**
	  * @Method 설명 : 채널코드 중복 체크
	  * @param chn_cd
	  * @return
	  */
	int selectChnCdDplctCeck(String chn_cd);
	
	/**
	  * @Method 설명 : 신규 채널 정보 등록
	  * @param chn
	  */
	void insertChn(ChnVO chn);
	
	/**
	  * @Method 설명 : 채널 정보 수정
	  * @param chn
	  */
	void updateChn(ChnVO chn);
	
	/**
	  * @Method 설명 : 채널 정보 삭제
	  * @param chn_cd
	  * @return
	  */
	int deleteChn(String chn_cd);
	
}
