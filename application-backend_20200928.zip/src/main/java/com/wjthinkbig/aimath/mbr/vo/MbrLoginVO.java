/**
 * 
 */
package com.wjthinkbig.aimath.mbr.vo;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.configurationprocessor.json.JSONObject;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.wjthinkbig.aimath.core.utils.WpinUtils;
import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
  * @Date : 2020. 9. 4. 
  * @프로그램 설명 : 로그인에 필요한 정보를 담고 있는 사용자 로그인 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 4.     Lee Seung Hyuk            최초작성
  * 2020. 9. 24.    Kim Hee Seok              수정
  * </pre>
  */
@Getter
@Setter
@ApiModel(value = "로그인 VO", description = "로그인에 필요한 정보를 담고 있는 VO")
public class MbrLoginVO {
	
	/**
	 * 이메일주소  
	 */
	@NotBlank
	@Email
	@ApiModelProperty(value = "이메일주소")
	@FieldName("이메일주소")
	private String emailAdrs;
	
	/**
	 * 비밀번호
	 */
	@NotBlank
	@JsonProperty(access = Access.WRITE_ONLY)
	@ApiModelProperty(value = "비밀번호")
	@FieldName("비밀번호")
	private String pw;
	
	
	@ApiModelProperty(value = "회원아이디")
	@FieldName("회원아이디")
	private String mbrId;
	/**
	 * 로그인 유지 (Y/N)
	 */
	@Pattern(regexp = "Y|N")
	@ApiModelProperty(value = "로그인 유지여부")
	@FieldName("로그인 유지여부")
	private String rememberMe;
	
	/**
	  * @Method 설명 : 이메일 Wpin 암호화 작업
	  * @param email
	  */
	public String getEmailAdrsEn() throws Exception {
		//이메일 암호화 작업
		if( StringUtils.isNotEmpty( this.emailAdrs ) ) {
			JSONObject obj = WpinUtils.wpinEncryption("E", this.emailAdrs);
			if( "Y".equals(obj.getString("rtnCode")) ) {
				this.emailAdrs = obj.getString("rtnVal");
			}
		}
		
		return this.emailAdrs;
	}
}