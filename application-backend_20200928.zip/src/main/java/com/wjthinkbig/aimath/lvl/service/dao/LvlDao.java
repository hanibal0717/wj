package com.wjthinkbig.aimath.lvl.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.lvl.vo.LvlMetaVO;
import com.wjthinkbig.aimath.lvl.vo.LvlSearchVO;
import com.wjthinkbig.aimath.lvl.vo.LvlStgSearchVO;
import com.wjthinkbig.aimath.lvl.vo.LvlStgVO;
import com.wjthinkbig.aimath.lvl.vo.LvlVO;

/**
  * @Date : 2020. 8. 28.
  * @프로그램 설명 : 코스학습 레벨 dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 28.     19001861            최초작성
  * </pre>
  */
@Mapper("lvlDao")
public interface LvlDao {
	
	/**
	  * @Method 설명 : 코스학습 레벨 전체 리스트를 가져온다.
	  * @param lvlSearch 검색 조건 VO
	  * @return 검색된 레벨리스트
	  * @throws Exception
	 */
	List<LvlVO> selectLvlList(LvlSearchVO lvlSearch);
	
	/**
	  * @Method 설명 : 코스학습 레벨 전체 리스트를 가져온다.(언어코드 필수)
	  * @param lvlSearch
	  * @return
	  */
	List<LvlVO> selectLvlListByLangCd(LvlSearchVO lvlSearch);
	
	/**
	  * @Method 설명 : 코스학습 레벨 단일 정보를 가져온다.
	  * @param lvlSearch 검색 조건 VO
	  * @return 검색된 레벨 단일 정보
	  * @throws Exception
	 */
	LvlVO selectLvlById(LvlSearchVO lvlSearch);
	
	/**
	  * @Method 설명 : 코스학습 레벨 단일 정보를 가져온다.(언어코드 필수)
	  * @param lvlSearch 검색 조건 VO
	  * @return
	  */
	LvlVO selectLvl(LvlSearchVO lvlSearch);
	
	/**
	  * @Method 설명 : 코스학습 레벨 메타 정보 리스트 조회
	  * @param lvl_cd
	  * @return
	  */
	List<LvlMetaVO> selectLvlMetaList(String lvl_cd);
	
	/**
	  * @Method 설명 : 신규등록시 사용할 레벨 코드 채번
	  * @return lvlCd 신규 채번
	  * @throws Exception
	  */
	String selectNewLvlCd();
	
	/**
	  * @Method 설명 : 신규 레벨 정보를 등록한다.
	  * @param lvl 등록할 레벨 정보 객체
	  * @throws Exception
	  */
	void insertLvl(LvlVO lvl);
	
	/**
	  * @Method 설명 : 신규 레벨 메타 정보를 등록한다.
	  * @param lvlMeta
	  */
	void insertLvlMeta(LvlMetaVO lvlMeta);
	
	/**
	  * @Method 설명 : 특정 레벨 정보를 수정한다.
	  * @param lvl 수정할 레벨 정보 객체
	  * @throws Exception
	  */
	void updateLvl(LvlVO lvl);
	
	/**
	  * @Method 설명 : 특정 레벨의 정렬순서가 변경 될 경우 다른 정렬 순서도 변경
	  * @param lvl 수정할 레벨 정보 객체
	  * @throws Exception
	  */
	void updateLvlOdr(LvlVO lvl);
	
	/**
	  * @Method 설명 : 레벨 삭제
	  * @param lvl_cd
	  * @return
	  * @throws Exception
	  */
	int deleteLvl(String lvl_cd);
	
	/**
	  * @Method 설명 : 레벨 메타 삭제
	  * @param lvl_cd
	  * @return
	  */
	int deleteLvlMeta(String lvl_cd);
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 등록 여부 판단
	  * @param lvlStgSearch
	  * @return
	  * @throws Exception
	  */
	int selectLvlStgCeck(LvlStgSearchVO lvlStgSearch);
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 리스트 조회
	  * @param lvlStgSearch
	  * @return
	  * @throws Exception
	  */
	List<LvlStgVO> selectLvlStgList(LvlStgSearchVO lvlStgSearch);
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 단일 조회
	  * @param lvlStgSearch
	  * @return
	  * @throws Exception
	  */
	LvlStgVO selectLvlStgById(LvlStgSearchVO lvlStgSearch);
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 신규 등록
	  * @param lvlStg
	  * @throws Exception
	  */
	void insertLvlStg(LvlStgVO lvlStg);
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 수정
	  * @param lvlStg
	  * @throws Exception
	  */
	void updateLvlStg(LvlStgVO lvlStg);
	
	/**
	  * @Method 설명 : 레벨 하위 스테이지 삭제
	  * @param lvlStg
	  * @return
	  * @throws Exception
	  */
	int deleteLvlStg(LvlStgVO lvlStg);
	
	/**
	  * @Method 설명 : 코스학습 레벨 전체 조회 및 하위 스테이지까지 포함 조회
	  * @param lvlSearch
	  * @return
	  */
	List<LvlVO> selectLvlAllList(LvlSearchVO lvlSearch);
	
}
