package com.wjthinkbig.aimath.thma.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.PositiveOrZero;

import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 커리큘럼 주제 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 주제 정보")
public class ThmaVO extends BaseVO {	
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="주제코드")
	@FieldName("주제코드")
	private String thmaCd; 			/* 주제코드 */

	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="주제명")
	@FieldName("주제명")
	private String thmaNm; 			/* 주제명 */

	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="이미지파일경로")
	@FieldName("이미지파일경로")
	private String imgFilePath; 	/* 이미지파일경로 */

	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="이미지파일명")
	@FieldName("이미지파일명")
	private String imgFileNm; 		/* 이미지파일명 */

	@PositiveOrZero(groups = {Groups.Insert.class})
	@ApiModelProperty(value="노출순서")
	@FieldName("노출순서")
	private int dspOdr; 			/* 노출순서 */

	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)") 
	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn; 			/* 사용여부 */
	
	@ApiModelProperty(value="이미지 첨부파일")
	@FieldName("이미지 첨부파일")
	private MultipartFile mFile;	/* 이미지 첨부파일 */
}