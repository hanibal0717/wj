package com.wjthinkbig.aimath.common.model;

import java.util.Arrays;
import java.util.List;

import org.springframework.http.HttpStatus;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Getter;

@ApiModel(value = "API 에러모델", description = "API 응답오류 시 응답모델")
@AllArgsConstructor
@Getter
public class ApiError {
	
	@ApiModelProperty(value = "the HTTP status code")
	private HttpStatus status;
	
	@ApiModelProperty(value = "the error message associated with exception")
    private String message;
	
	@ApiModelProperty(value = "List of constructed error messages")
    private List<String> errors;
    
    public ApiError(HttpStatus status, String message, String error) {
    	this.status = status;
    	this.message = message;
    	this.errors = Arrays.asList(error);
    }
}