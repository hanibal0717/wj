package com.wjthinkbig.aimath.common.service.impl;

import java.util.Iterator;

import javax.annotation.Resource;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.common.service.ExcelReadService;
import com.wjthinkbig.aimath.common.service.dao.ExcelReadDao;
import com.wjthinkbig.aimath.common.vo.ExcelQuestionVO;
import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;

/**
  * @Date : 2020. 9. 10.
  * @프로그램 설명 : 엑셀파일을 읽어서 처리하는 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 10.     19001861            최초작성
  * </pre>
  */
@Service("excelReadService")
public class ExcelReadServiceImpl extends BaseServiceImpl implements ExcelReadService {
	
	/**
	 * 엑셀파일 처리 Dao
	 */
	@Resource(name = "excelReadDao")
	private ExcelReadDao excelReadDao;
	
	private String laTexType1 = "#A + #B = #C";				//더하기 - 가로
	private String laTexType2 = "#A - #B = #C";				//빼기 - 가로
	private String laTexType3 = "#A \\times #B = #C";			//곱하기 - 가로
	private String laTexType4 = "\\begin{align} #A \\\\ + ~~~ #B \\\\ \\hline #C \\\\ \\end{align}";			//더하기 - 세로
	private String laTexType5 = "\\begin{align} #A \\\\ - ~~~ #B \\\\ \\hline #C \\\\ \\end{align}";			//빼기 - 세로
	private String laTexType6 = "\\begin{align} #A \\\\ \\times ~~~ #B \\\\ \\hline #C \\\\ \\end{align}";		//곱하기 - 세로
	private String laTexBox = "\\boxed{\\phantom{0}}";
	
	@Override
	public void createExcelQuestion(MultipartFile mFile) throws Exception {
		//엑셀파일 로드
		Workbook workbook = WorkbookFactory.create(mFile.getInputStream());
		
		if( workbook != null && workbook.getNumberOfSheets() > 0 ) {
			ScriptEngineManager sManager = new ScriptEngineManager();
			ScriptEngine engine = sManager.getEngineByName("js");
			
			for( int shCnt = 0; shCnt < workbook.getNumberOfSheets(); shCnt++ ) {
				//시트 로드
				Sheet sheet = workbook.getSheetAt(shCnt);
				Iterator<Row> rowItr = sheet.iterator();
				int qstCdNum = 0;
				
				if( rowItr != null ) {
					String stgCd = "";
					
					//행만큼 반복
					while( rowItr.hasNext() ) {
						Row row = rowItr.next();
						
						//2번째까지는 처리하지 않는다
						if( row.getRowNum() < 2 ) continue;
						
						ExcelQuestionVO question = new ExcelQuestionVO();
						
						//소주제 코드
						String sbthmaCd = (String)this.getValueFromCell(row.getCell(0));
						question.setSbthmaCd(sbthmaCd);
						
						//선행학습 소주제코드
						question.setPreSbthmaCd((String)this.getValueFromCell(row.getCell(11)));
						
						//국문 지시문
						question.setTextCn((String)this.getValueFromCell(row.getCell(13)));
						
						//영문 지시문
						question.setEngTextCn((String)this.getValueFromCell(row.getCell(14)));
						
						//대표문항 여부
						if( row.getCell(15) != null && "○".equals((String)this.getValueFromCell(row.getCell(15))) ) question.setEsntlQstYn("Y");
						else question.setEsntlQstYn("N");
						
						//등록자
						question.setRgtnUser("19001861");
						
						//사용여부
						question.setUseYn("Y");
						
						String aCdn = (String)this.getValueFromCell(row.getCell(8));			//A변수값 조건
						String bCdn = (String)this.getValueFromCell(row.getCell(9));			//B변수값 조건
						String cCdn = (String)this.getValueFromCell(row.getCell(10));			//C변수값 조건
						String qst = (String)this.getValueFromCell(row.getCell(3));				//문항 형태
						String laTexType = (String)this.getValueFromCell(row.getCell(2));		//문항 타입
						String laTexCd = "";
						
						int aMin = 0;
						int aMax = 0;
						int bMin = 0;
						int bMax = 0;
						int cMin = 0;
						int cMax = 0;
						
						//필요없는 문장 제거
						if( StringUtils.isNotEmpty(aCdn) ) aCdn = aCdn.replace(" 인 수 中 랜덤 출력", "");
						if( StringUtils.isNotEmpty(bCdn) ) bCdn = bCdn.replace(" 인 수 中 랜덤 출력", "");
						if( StringUtils.isNotEmpty(cCdn) ) cCdn = cCdn.replace(" 인 수 中 랜덤 출력", "");
						
						if( StringUtils.isNotEmpty(aCdn) && StringUtils.isNotEmpty(bCdn) && StringUtils.isNotEmpty(cCdn) ) {
							//조건 3개 A, B, C
							String[] aArray = null;
							String[] bArray = null;
							String[] cArray = null;
							
							if( aCdn.indexOf("=") > -1 ) {
								//A변수 고정 값
								aArray = aCdn.split("=")[1].split(",");
								if( aArray != null && aArray.length == 1 ) {
									//A변수 고정값이 하나일경우
									aMin = Integer.parseInt(aArray[0]);
									aMax = Integer.parseInt(aArray[0]);
								} else {
									//A변수 고장값이 하나 이상일 경우
									aMin = 0;
									aMax = aArray.length - 1;
								}
							} else {
								//A변수 값이 랜덤인 값의 조건
								String[] aStrArray = aCdn.split(" ≤ ");
								String aStr1 = aStrArray[0];
								String aStr2 = aStrArray[2];
								
								aMin = Integer.parseInt(aStr1);
								aMax = Integer.parseInt(aStr2);
							}
							
							for( int k = aMin; k <= aMax; k++ ) {
								String qstTmp = qst;
								
								if( aArray != null && aArray.length > 1 ) {
									qstTmp = qstTmp.replace("A", aArray[k].trim());
								} else {
									qstTmp = qstTmp.replace("A", Integer.toString(k));
								}
								
								//C변수 조건에 수식이 들어갈 경우
								if( bCdn.indexOf("=") > -1 ) {
									//B변수 고정 값
									bArray = bCdn.split("=")[1].split(",");
									if( bArray != null && bArray.length == 1 ) {
										//B변수 고정값이 하나일경우
										bMin = Integer.parseInt(bArray[0]);
										bMax = Integer.parseInt(bArray[0]);
									} else {
										//B변수 고장값이 하나 이상일 경우
										bMin = 0;
										bMax = bArray.length - 1;
									}
								} else {
									//B변수 값이 랜덤인 값의 조건
									String[] bStrArray = bCdn.split(" ≤ ");
									String bStr1 = bStrArray[0];
									String bStr2 = bStrArray[2];
									
									bMin = Integer.parseInt(bStr1);
									bMax = Integer.parseInt(bStr2);
								}
								
								for( int i = bMin; i <= bMax; i++ ) {
									String qstTmp1 = "";
									String bVal = "";
									if( bArray != null && bArray.length > 1 ) {
										qstTmp1 = qstTmp.replace("B", bArray[i].trim());
										bVal = bArray[i].trim();
									} else {
										qstTmp1 = qstTmp.replace("B", Integer.toString(i));
										bVal = Integer.toString(i);
									}
									
									//C변수 값이 랜덤인 값의 조건
									String[] cStrArray = cCdn.split(" ≤ ");
									String cStr1 = cStrArray[0];
									String cStr2 = cStrArray[2];
									
									if( cStr1.indexOf("B") > -1 ) {
										cStr1 = cStr1.replace("B", bVal);
										cMin = (Integer) engine.eval(cStr1);
									} else {
										cMin = Integer.parseInt(cStr1);
									}
									
									if( cStr2.indexOf("B") > -1 ) {
										cStr2 = cStr2.replace("B", bVal);
										cMax = (Integer) engine.eval(cStr2);
									} else {
										cMax = Integer.parseInt(cStr2);
									}
									
									for( int j = cMin; j <= cMax; j++ ) {
										String qstTmp2 = "";
										if( cArray != null && cArray.length > 1 ) {
											qstTmp2 = qstTmp1.replace("C", cArray[j]);
										} else {
											qstTmp2 = qstTmp1.replace("C", Integer.toString(j));
										}
										
										if( "1".equals(laTexType) ) laTexCd = laTexType1;
										else if( "2".equals(laTexType) )  laTexCd = laTexType2;
										else if( "3".equals(laTexType) )  laTexCd = laTexType3;
										else if( "4".equals(laTexType) )  laTexCd = laTexType4;
										else if( "5".equals(laTexType) )  laTexCd = laTexType5;
										else if( "6".equals(laTexType) )  laTexCd = laTexType6;
										
										String[] qstTmpArray = qstTmp2.split(" ");
										laTexCd = laTexCd.replace("#A", !"□".equals(qstTmpArray[0]) ? qstTmpArray[0] : laTexBox);
										laTexCd = laTexCd.replace("#B", !"□".equals(qstTmpArray[2]) ? qstTmpArray[2] : laTexBox);
										laTexCd = laTexCd.replace("#C", !"□".equals(qstTmpArray[4]) ? qstTmpArray[4] : laTexBox);
										
										//문항코드 생성
										if( !StringUtils.isNotEmpty(stgCd) || stgCd.equals(sbthmaCd) ) {
											qstCdNum++;
										} else {
											qstCdNum = 1;
										}
										
										String autoQstCd = sbthmaCd.replaceAll("_", "") + String.format("%04d", qstCdNum);
										question.setAutoQstCd(autoQstCd);
										stgCd = sbthmaCd;
										
										//정답
										question.setQstCransr(engine.eval((qstTmp2.split(" = ")[0]).replace("'×", "*")).toString());
										question.setQstCn(laTexCd);
//										System.out.println("question =========== " + question.toString());
//										System.out.println("조건3개 문항코드 : " + autoQstCd + " / 문항 : " + qstTmp2 + " / LaTex : " + laTexCd + " / 정답 : " + (Integer)engine.eval((qstTmp2.split(" = ")[0]).replace("'×", "*")));
										
										System.out.println(autoQstCd + " / " + qstTmp2 + " / " + engine.eval((qstTmp2.split(" = ")[0]).replace("×", "*")));
										
//										excelReadDao.insertAutoQst(question);
									}
								}
							}
							
						} else if( StringUtils.isNotEmpty(aCdn) && StringUtils.isNotEmpty(bCdn) ) {
							//조건 2개 A, B
							String[] aArray = null;
							String[] bArray = null;
							
							if( aCdn.indexOf("B") > -1 ) {
								//A변수 조건에 수식이 들어갈 경우
								if( bCdn.indexOf("=") > -1 ) {
									//B변수 고정 값
									bArray = bCdn.split("=")[1].split(",");
									if( bArray != null && bArray.length == 1 ) {
										//B변수 고정값이 하나일경우
										bMin = Integer.parseInt(bArray[0]);
										bMax = Integer.parseInt(bArray[0]);
									} else {
										//B변수 고장값이 하나 이상일 경우
										bMin = 0;
										bMax = bArray.length - 1;
									}
								} else {
									//B변수 값이 랜덤인 값의 조건
									String[] bStrArray = bCdn.split(" ≤ ");
									String bStr1 = bStrArray[0];
									String bStr2 = bStrArray[2];
									
									bMin = Integer.parseInt(bStr1);
									bMax = Integer.parseInt(bStr2);
								}
								
								for( int i = bMin; i <= bMax; i++ ) {
									String qstTmp = qst;
									String bVal = "";
									if( bArray != null && bArray.length > 1 ) {
										qstTmp = qstTmp.replace("B", bArray[i].trim());
										bVal = bArray[i].trim();
									} else {
										qstTmp = qstTmp.replace("B", Integer.toString(i));
										bVal = Integer.toString(i);
									}
									
									//A변수 값이 랜덤인 값의 조건
									String[] aStrArray = aCdn.split(" ≤ ");
									String aStr1 = aStrArray[0];
									String aStr2 = aStrArray[2];
									
									if( aStr1.indexOf("B") > -1 ) {
										aStr1 = aStr1.replace("B", bVal);
										aMin = (Integer) engine.eval(aStr1);
									} else {
										aMin = Integer.parseInt(aStr1);
									}
									
									if( aStr2.indexOf("B") > -1 ) {
										aStr2 = aStr2.replace("B", bVal);
										aMax = (Integer) engine.eval(aStr2);
									} else {
										aMax = Integer.parseInt(aStr2);
									}
									
									for( int j = aMin; j <= aMax; j++ ) {
										String qstTmp2 = "";
										if( aArray != null && aArray.length > 1 ) {
											qstTmp2 = qstTmp.replace("A", aArray[j]);
										} else {
											qstTmp2 = qstTmp.replace("A", Integer.toString(j));
										}
										
										if( "1".equals(laTexType) ) laTexCd = laTexType1;
										else if( "2".equals(laTexType) )  laTexCd = laTexType2;
										else if( "3".equals(laTexType) )  laTexCd = laTexType3;
										else if( "4".equals(laTexType) )  laTexCd = laTexType4;
										else if( "5".equals(laTexType) )  laTexCd = laTexType5;
										else if( "6".equals(laTexType) )  laTexCd = laTexType6;
										
										String[] qstTmpArray = qstTmp2.split(" ");
										laTexCd = laTexCd.replace("#A", !"□".equals(qstTmpArray[0]) ? qstTmpArray[0] : laTexBox);
										laTexCd = laTexCd.replace("#B", !"□".equals(qstTmpArray[2]) ? qstTmpArray[2] : laTexBox);
										laTexCd = laTexCd.replace("#C", !"□".equals(qstTmpArray[4]) ? qstTmpArray[4] : laTexBox);
										
										//문항코드 생성
										if( !StringUtils.isNotEmpty(stgCd) || stgCd.equals(sbthmaCd) ) {
											qstCdNum++;
										} else {
											qstCdNum = 1;
										}
										
										String autoQstCd = sbthmaCd.replaceAll("_", "") + String.format("%04d", qstCdNum);
										question.setAutoQstCd(autoQstCd);
										stgCd = sbthmaCd;
										
										//정답
										question.setQstCransr(engine.eval((qstTmp2.split(" = ")[0]).replace("'×", "*")).toString());
										question.setQstCn(laTexCd);
//										System.out.println("question =========== " + question.toString());
//										System.out.println("조건2개 문항코드 : " + autoQstCd + " / 문항 : " + qstTmp2 + " / LaTex : " + laTexCd + " / 정답 : " + (Integer)engine.eval((qstTmp2.split(" = ")[0]).replace("'×", "*")));
										
										System.out.println(autoQstCd + " / " + qstTmp2 + " / " + engine.eval((qstTmp2.split(" = ")[0]).replace("×", "*")));
										
//										excelReadDao.insertAutoQst(question);
									}
								}
							} else if( bCdn.indexOf("A") > -1 ) {
								//B변수 조건에 수식이 들어갈 경우
								if( aCdn.indexOf("=") > -1 ) {
									//A변수 고정 값
									aArray = aCdn.split("=")[1].split(",");
									if( aArray != null && aArray.length == 1 ) {
										//A변수 고정값이 하나일경우
										aMin = Integer.parseInt(aArray[0]);
										aMax = Integer.parseInt(aArray[0]);
									} else {
										//A변수 고장값이 하나 이상일 경우
										aMin = 0;
										aMax = aArray.length - 1;
									}
								} else {
									//A변수 값이 랜덤인 값의 조건
									String[] aStrArray = bCdn.split(" ≤ ");
									String aStr1 = aStrArray[0];
									String aStr2 = aStrArray[2];
									
									aMin = Integer.parseInt(aStr1);
									aMax = Integer.parseInt(aStr2);
								}
								
								for( int i = aMin; i <= aMax; i++ ) {
									String qstTmp = qst;
									String aVal = "";
									if( aArray != null && aArray.length > 1 ) {
										qstTmp = qstTmp.replace("A", aArray[i].trim());
										aVal = aArray[i].trim();
									} else {
										qstTmp = qstTmp.replace("A", Integer.toString(i));
										aVal = Integer.toString(i);
									}
									
									//B변수 값이 랜덤인 값의 조건
									String[] bStrArray = bCdn.split(" ≤ ");
									String bStr1 = bStrArray[0];
									String bStr2 = bStrArray[2];
									
									if( bStr1.indexOf("A") > -1 ) {
										bStr1 = bStr1.replace("A", aVal);
										bMin = (Integer) engine.eval(bStr1);
									} else {
										bMin = Integer.parseInt(bStr1);
									}
									
									if( bStr2.indexOf("A") > -1 ) {
										bStr2 = bStr2.replace("A", aVal);
										bMax = (Integer) engine.eval(bStr2);
									} else {
										bMax = Integer.parseInt(bStr2);
									}
									
									for( int j = bMin; j <= bMax; j++ ) {
										String qstTmp2 = "";
										if( bArray != null && bArray.length > 1 ) {
											qstTmp2 = qstTmp.replace("B", bArray[j]);
										} else {
											qstTmp2 = qstTmp.replace("B", Integer.toString(j));
										}
										
										if( "1".equals(laTexType) ) laTexCd = laTexType1;
										else if( "2".equals(laTexType) )  laTexCd = laTexType2;
										else if( "3".equals(laTexType) )  laTexCd = laTexType3;
										else if( "4".equals(laTexType) )  laTexCd = laTexType4;
										else if( "5".equals(laTexType) )  laTexCd = laTexType5;
										else if( "6".equals(laTexType) )  laTexCd = laTexType6;
										
										String[] qstTmpArray = qstTmp2.split(" ");
										laTexCd = laTexCd.replace("#A", !"□".equals(qstTmpArray[0]) ? qstTmpArray[0] : laTexBox);
										laTexCd = laTexCd.replace("#B", !"□".equals(qstTmpArray[2]) ? qstTmpArray[2] : laTexBox);
										laTexCd = laTexCd.replace("#C", !"□".equals(qstTmpArray[4]) ? qstTmpArray[4] : laTexBox);
										
										//문항코드 생성
										if( !StringUtils.isNotEmpty(stgCd) || stgCd.equals(sbthmaCd) ) {
											qstCdNum++;
										} else {
											qstCdNum = 1;
										}
										
										String autoQstCd = sbthmaCd.replaceAll("_", "") + String.format("%04d", qstCdNum);
										question.setAutoQstCd(autoQstCd);
										stgCd = sbthmaCd;
										
										//정답
										question.setQstCransr(engine.eval((qstTmp2.split(" = ")[0]).replace("'×", "*")).toString());
										question.setQstCn(laTexCd);
//										System.out.println("question =========== " + question.toString());
//										System.out.println("조건2개 문항코드 : " + autoQstCd + " / 문항 : " + qstTmp2 + " / LaTex : " + laTexCd + " / 정답 : " + (Integer)engine.eval((qstTmp2.split(" = ")[0]).replace("'×", "*")));
										
										System.out.println(autoQstCd + " / " + qstTmp2 + " / " + engine.eval((qstTmp2.split(" = ")[0]).replace("×", "*")));
										
//										excelReadDao.insertAutoQst(question);
									}
								}
							} else {
								//변수 조건에 수식이 들어가지 않을 경우
							}
						} else if( StringUtils.isNotEmpty(aCdn) ) {
							//조건 1개 A
							String[] aArray = null;
							if( aCdn.indexOf("=") > -1 ) {
								//A변수 고정 값
								aArray = aCdn.split("=")[1].split(",");
								if( aArray != null && aArray.length == 1 ) {
									//A변수 고정값이 하나일경우
									aMin = Integer.parseInt(aArray[0]);
									aMax = Integer.parseInt(aArray[0]);
								} else {
									//A변수 고장값이 하나 이상일 경우
									aMin = 0;
									aMax = aArray.length - 1;
								}
							} else {
								//A변수 값이 랜덤인 값의 조건
								String[] aStrArray = aCdn.split(" ≤ ");
								String aStr1 = aStrArray[0];
								String aStr2 = aStrArray[2];
								
								aMin = Integer.parseInt(aStr1);
								aMax = Integer.parseInt(aStr2);
							}
							
							for( int i = aMin; i <= aMax; i++ ) {
								String qstTmp = qst;
								if( aArray != null && aArray.length > 1 ) {
									qstTmp = qstTmp.replace("A", aArray[i]);
								} else {
									qstTmp = qstTmp.replace("A", Integer.toString(i));
								}
								
								if( "1".equals(laTexType) ) laTexCd = laTexType1;
								else if( "2".equals(laTexType) )  laTexCd = laTexType2;
								else if( "3".equals(laTexType) )  laTexCd = laTexType3;
								else if( "4".equals(laTexType) )  laTexCd = laTexType4;
								else if( "5".equals(laTexType) )  laTexCd = laTexType5;
								else if( "6".equals(laTexType) )  laTexCd = laTexType6;
								
								String[] qstTmpArray = qstTmp.split(" ");
								laTexCd = laTexCd.replace("#A", !"□".equals(qstTmpArray[0]) ? qstTmpArray[0] : laTexBox);
								laTexCd = laTexCd.replace("#B", !"□".equals(qstTmpArray[2]) ? qstTmpArray[2] : laTexBox);
								laTexCd = laTexCd.replace("#C", !"□".equals(qstTmpArray[4]) ? qstTmpArray[4] : laTexBox);
								
								//문항코드 생성
								if( !StringUtils.isNotEmpty(stgCd) || stgCd.equals(sbthmaCd) ) {
									qstCdNum++;
								} else {
									qstCdNum = 1;
								}
								
								String autoQstCd = sbthmaCd.replaceAll("_", "") + String.format("%04d", qstCdNum);
								question.setAutoQstCd(autoQstCd);
								stgCd = sbthmaCd;
								
								//정답
								question.setQstCransr(engine.eval((qstTmp.split(" = ")[0]).replace("×", "*")).toString());
								question.setQstCn(laTexCd);
//								System.out.println("question =========== " + question.toString());
//								System.out.println("조건1개 문항코드 : " + autoQstCd + " / 문항 : " + qstTmp + " / LaTex : " + laTexCd + " / 정답 : " + (Integer)engine.eval((qstTmp.split(" = ")[0]).replace("×", "*")));
								
								System.out.println(autoQstCd + " / " + qstTmp + " / " + engine.eval((qstTmp.split(" = ")[0]).replace("×", "*")));
								
//								excelReadDao.insertAutoQst(question);
							}
						}
					}
				}
			}
		}
	}
	
//	public void createExcelQuestion(MultipartFile mFile) throws Exception {
//		//엑셀파일 로드
//		Workbook workbook = WorkbookFactory.create(mFile.getInputStream());
//		
//		if( workbook != null && workbook.getNumberOfSheets() > 0 ) {
//			for( int shCnt = 0; shCnt < workbook.getNumberOfSheets(); shCnt++ ) {
//				//시트 로드
//				Sheet sheet = workbook.getSheetAt(shCnt);
//				Iterator<Row> rowItr = sheet.iterator();
//				int qstCdNum = 0;
//				
//				if( rowItr != null ) {
//					String stgCd = "";
//					
//					//행만큼 반복
//					while( rowItr.hasNext() ) {
//						Row row = rowItr.next();
//						
//						//2번째까지는 처리하지 않는다
//						if( row.getRowNum() < 2 ) continue;
//						
//						ExcelQuestionVO question = new ExcelQuestionVO();
//						String laTexCd = "";
//						String sbthmaCd = "";
//						
//						//소주제 코드
//						sbthmaCd = (String)this.getValueFromCell(row.getCell(0));
//						question.setSbthmaCd(sbthmaCd);
//						
//						//선행학습 소주제코드
//						question.setPreSbthmaCd((String)this.getValueFromCell(row.getCell(11)));
//						
//						//국문 지시문
//						question.setTextCn((String)this.getValueFromCell(row.getCell(13)));
//						
//						//영문 지시문
//						question.setEngTextCn((String)this.getValueFromCell(row.getCell(14)));
//						
//						//대표문항 여부
//						if( row.getCell(15) != null && "○".equals((String)this.getValueFromCell(row.getCell(15))) ) question.setEsntlQstYn("Y");
//						else question.setEsntlQstYn("N");
//						
//						//사용여부
//						question.setUseYn("Y");
//						
//						//문항 수식
//						String qst = (String)this.getValueFromCell(row.getCell(3));
//						String aCdn = (String)this.getValueFromCell(row.getCell(8));			//A변수값 조건
//						String bCdn = (String)this.getValueFromCell(row.getCell(9));			//B변수값 조건
//						String cCdn = (String)this.getValueFromCell(row.getCell(10));			//C변수값 조건
//						int aMin = 0;
//						int aMax = 0;
//						int bMin = 0;
//						int bMax = 0;
//						int cMin = 0;
//						int cMax = 0;
//						String[] aArray = null;
//						String[] bArray = null;
//						String[] cArray = null;
//						
//						if( StringUtils.isNotEmpty(aCdn) ) {
//							aCdn = aCdn.replace(" 인 수 中 랜덤 출력", "");
//							
//							if( aCdn.indexOf("=") > -1 ) {
//								//A변수 값이 고정값 또는 지정된 여러개의 값
//								aArray = aCdn.split("=")[1].split(",");
//								if( aArray != null && aArray.length == 1 ) {
//									//A변수 고정값이 하나일경우
//									aMin = Integer.parseInt(aArray[0]);
//									aMax = Integer.parseInt(aArray[0]);
//								} else {
//									//A변수 고장값이 하나 이상일 경우
//									aMin = 0;
//									aMax = aArray.length - 1;
//								}
//							} else {
//								//A변수 값이 랜덤인 값의 조건
//								String[] aStrArray = aCdn.split(" ≤ ");
//								String aStr1 = aStrArray[0];
//								String aStr2 = aStrArray[2];
//								
//								if( aStr1.indexOf("A") > -1 || aStr1.indexOf("B") > -1 || aStr1.indexOf("C") > -1 ) {
//									//조건에 수식이 있을 경우
//									if( aStr1.indexOf("B") > -1 && aStr1.indexOf("C") < 0 ) {
//										//수식에 B 조건만 들어갈 경우
//									} else if( aStr1.indexOf("B") > -1 && aStr1.indexOf("C") > -1 ) {
//										//수식에 B, C 조건이 다 들어 갈 경우
//									}
//								} else {
//									aMin = Integer.parseInt(aStr1);
//								}
//								
//								if( aStr2.indexOf("A") > -1 || aStr2.indexOf("B") > -1 || aStr2.indexOf("C") > -1 ) {
//									//조건에 수식이 있을 경우
//									if( aStr1.indexOf("B") > -1 && aStr1.indexOf("C") < 0 ) {
//										//수식에 B 조건만 들어갈 경우
//									} else if( aStr1.indexOf("B") > -1 && aStr1.indexOf("C") > -1 ) {
//										//수식에 B, C 조건이 다 들어 갈 경우
//									}
//								} else {
//									aMax = Integer.parseInt(aStr2);
//								}
//							}
//						}
//						
//						for( int i = aMin; i <= aMax; i++ ) {
//							String qstTmp = qst;
//							if( aArray != null && aArray.length > 1 ) {
//								qstTmp = qstTmp.replace("A", aArray[i]);
//							} else {
//								qstTmp = qstTmp.replace("A", Integer.toString(i));
//							}
//							
//							System.out.println("qstTmp ========== " + qstTmp);
//						}
//						
//						
//						//LaText 코드 타입
//						String typeCd = (String)this.getValueFromCell(row.getCell(2));
//						
//						if( "1".equals(typeCd) ){
//							laTexCd = laTexType1;
//						} else if( "2".equals(typeCd) ) {
//							laTexCd = laTexType2;
//						} else if( "3".equals(typeCd) ) {
//							laTexCd = laTexType3;
//						} else if( "4".equals(typeCd) ) {
//							laTexCd = laTexType4;
//						} else if( "5".equals(typeCd) ) {
//							laTexCd = laTexType5;
//						} else if( "6".equals(typeCd) ) {
//							laTexCd = laTexType6;
//						}
//						
//						
//						//문항코드 생성
//						if( !StringUtils.isNotEmpty(stgCd) || stgCd.equals(sbthmaCd) ) {
//							qstCdNum++;
//						} else {
//							qstCdNum = 1;
//						}
//						
//						question.setAutoQstCd(sbthmaCd.replaceAll("_", "") + String.format("%04d", qstCdNum));
//						stgCd = sbthmaCd;
//						
//						
//						
////						//문항형태
////						String qst = (String)this.getValueFromCell(row.getCell(3));
////						String[] qstArray = qst.split(" ");
////						String aNum = qstArray[0];			//첫번째 문항이 변수인지 숫자인지 박스인지 판단을 위해 사용
////						String bNum = qstArray[2];			//두번째 문항이 변수인지 숫자인지 박스인지 판단을 위해 사용
////						String cNum = qstArray[4];			//세번째 문항이 변수인지 숫자인지 박스인지 판단을 위해 사용
////						
////						//숫자 또는 상자일 경우 LaTex 코드에서 치환
////						if( !"A".equals(aNum) && !"B".equals(aNum) && !"C".equals(aNum) ) {
////							laTexCd = laTexCd.replace("#A", !"□".equals(aNum) ? aNum : laTexBox);
////							cnText = cnText.replace("A", aNum);
////						}
////						if( !"A".equals(bNum) && !"B".equals(bNum) && !"C".equals(bNum) ) {
////							laTexCd = laTexCd.replace("#B", !"□".equals(bNum) ? bNum : laTexBox);
////							cnText = cnText.replace("B", bNum);
////						}
////						if( !"A".equals(cNum) && !"B".equals(cNum) && !"C".equals(cNum) ) {
////							laTexCd = laTexCd.replace("#C", !"□".equals(cNum) ? cNum : laTexBox);
////							cnText = cnText.replace("C", cNum);
////						}
////						
////						System.out.println("LaTextCode ========== " + laTexCd);
////						System.out.println("cnText1 ========== " + cnText);
////						
////						String aCdn = (String)this.getValueFromCell(row.getCell(8));			//A변수값 조건
////						String bCdn = (String)this.getValueFromCell(row.getCell(9));			//B변수값 조건
////						String cCdn = (String)this.getValueFromCell(row.getCell(10));			//C변수값 조건
////						int aMin = 0;
////						int aMax = 0;
////						int bMin = 0;
////						int bMax = 0;
////						int cMin = 0;
////						int cMax = 0;
////						String[] aArray = null;
////						String[] bArray = null;
////						String[] cArray = null;
////						boolean nomFrmFlag = false;
////						
////						if( StringUtils.isNotEmpty(aCdn) ) {
////							aCdn = aCdn.replace(" 인 수 中 랜덤 출력", "");
////							
////							if( aCdn.indexOf("=") > -1 ) {
////								//A변수 값이 고정값 또는 지정된 여러개의 값
////								aArray = aCdn.split("=")[1].split(",");
////								if( aArray != null && aArray.length == 1 ) {
////									//A변수 고정값이 하나일경우
////									aMin = Integer.parseInt(aArray[0]);
////									aMax = Integer.parseInt(aArray[0]);
////								} else {
////									//A변수 고장값이 하나 이상일 경우
////									aMin = 1;
////									aMax = aArray.length;
////								}
////							} else {
////								//A변수 값이 랜덤인 값의 조건
////								String[] aStrArray = aCdn.split(" ≤ ");
////								String aStr1 = aStrArray[0];
////								String aStr2 = aStrArray[2];
////								
////								if( aStr1.indexOf("A") > -1 || aStr1.indexOf("B") > -1 || aStr1.indexOf("C") > -1 ) {
////									//조건에 수식이 있을 경우
////									if( aStr1.indexOf("B") > -1 && aStr1.indexOf("C") < 0 ) {
////										//수식에 B 조건만 들어갈 경우
////									} else if( aStr1.indexOf("B") > -1 && aStr1.indexOf("C") > -1 ) {
////										//수식에 B, C 조건이 다 들어 갈 경우
////									}
////								} else {
////									aMin = Integer.parseInt(aStr1);
////								}
////								
////								if( aStr2.indexOf("A") > -1 || aStr2.indexOf("B") > -1 || aStr2.indexOf("C") > -1 ) {
////									//조건에 수식이 있을 경우
////									if( aStr1.indexOf("B") > -1 && aStr1.indexOf("C") < 0 ) {
////										//수식에 B 조건만 들어갈 경우
////									} else if( aStr1.indexOf("B") > -1 && aStr1.indexOf("C") > -1 ) {
////										//수식에 B, C 조건이 다 들어 갈 경우
////									}
////								} else {
////									aMax = Integer.parseInt(aStr2);
////								}
////							}
////						}
////						if( StringUtils.isNotEmpty(bCdn) ) bCdn = bCdn.replace(" 인 수 中 랜덤 출력", "");
////						if( StringUtils.isNotEmpty(cCdn) ) cCdn = cCdn.replace(" 인 수 中 랜덤 출력", "");
////						
////						for( int i = aMin; i <= aMax; i++ ) {
////							String tmp = "";
////							if( aArray != null && aArray.length > 0 ) {
////								tmp = cnText.replace("A", aArray[i]);
////							} else {
////								tmp = cnText.replace("A", Integer.toString(i));
////							}
////							
////							System.out.println("cnText2 ========== " + tmp);
////						}
//						
//						//question.setQstCn(cnText);
//						System.out.println("question ======= " + question.toString());
//					}
//				}
//			}
//		}
//	}
	
	// 셀서식에 맞게 값 읽기
	private Object getValueFromCell(Cell cell) {
		switch(cell.getCellType()) {
			case STRING:
				return cell.getStringCellValue();
			case BOOLEAN:
				return cell.getBooleanCellValue();
			case NUMERIC:
				if(DateUtil.isCellDateFormatted(cell)) {
					return cell.getDateCellValue();
				}
				
				return cell.getNumericCellValue();
			case FORMULA:
				return cell.getCellFormula();
			case BLANK:
				return "";
			default: return "";
		}
	}


}
