package com.wjthinkbig.aimath.common.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.service.ExcelReadService;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 10.
  * @프로그램 설명 : 엑셀 파일을 읽어서 처리하는 Controller
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 10.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="엑셀 파일을 읽어서 처리")
@RestController
public class ExcelReadController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 엑셀파일 처리 서비스
	 */
	@Resource(name = "excelReadService")
	private ExcelReadService excelReadService;
	
	@ApiOperation(value="엑셀파일 업로드 후 조건에 맞는 문항을 만든다")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/excel/question")	
	public CommonResult createExcelQuestion(@ApiParam("파일 객체") @RequestPart(required=true, name="mFile") MultipartFile mFile) throws Exception {		
		
		excelReadService.createExcelQuestion(mFile);
		
		return responseService.getResult(true);
	}
	
}
