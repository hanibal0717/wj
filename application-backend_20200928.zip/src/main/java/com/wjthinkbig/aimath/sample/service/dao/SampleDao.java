package com.wjthinkbig.aimath.sample.service.dao;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;

/**
  * @Date : 2020. 8. 26. 
  * @프로그램 설명 : 샘플 제공을 위한 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 26.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Mapper("sampleDao")
public interface SampleDao {
	
}