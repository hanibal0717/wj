package com.wjthinkbig.aimath.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 8. 
  * @프로그램 설명 : JWT 토큰처리 필터 (We should use OncePerRequestFilter since we are doing a database call, there is no point in doing this more than once)
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 8.      Lee Seung Hyuk            최초작성
  * </pre>
 */
@Slf4j
@Deprecated
public class JwtTokenFilter extends OncePerRequestFilter {

	// 프로바이더에 토큰처리를 위임 
	private final JwtTokenProvider jwtTokenProvider;

	public JwtTokenFilter(JwtTokenProvider jwtTokenProvider) {
		this.jwtTokenProvider = jwtTokenProvider;
	}

	/**
	 * Request로 들어오는 JWT 토큰의 유효성을 검증하는 Filter를 securityFilterChain에 등록한다.
	 * Authorization 헤더가 있는지 검사하여 토큰 프로바이더에 그 인증처리를 위임한다.
	 * 토큰 프로바이더의 인증처리결과에 따라 성공/실패 전략을 호출한다.
	 */
	@Override	
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		
		// 요청 헤더에 담긴 JWT 토큰을 가져온다. 없으면 Null
		String token = jwtTokenProvider.resolveToken(request);
		
		boolean isValidated = false;
		if(token != null) {
			isValidated = jwtTokenProvider.validateToken(token);
		}
		 
		log.debug("2) JwtTokenFilter => 토큰유효성 :{}, 인증 토큰 : {}", isValidated, token);		
		
		// 유효한 토큰이 존재하면 Security Context에 Authentication을 보관
		if(token != null && isValidated) {
			// 토큰프로바이더가 실제 인증을 수행하여 인증된 Authentication 객체를 반환하고 
			Authentication authentication = jwtTokenProvider.getAuthentication(token);
			
			// 인증컨텐스트에 저장
			SecurityContextHolder.getContext().setAuthentication(authentication);
		}

		filterChain.doFilter(request, response);
	}
}