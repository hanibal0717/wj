/**
 * 
 */
package com.wjthinkbig.aimath.security.admin;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.wjthinkbig.aimath.security.JwtUtils;

/**
  * @Date : 2020. 9. 10. 
  * @프로그램 설명 : 관리자 로그인용 인증 프로바이더
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 10.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Component("adminCustomAuthenticationProvider") 
public class AdminCustomAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider {

	/**
	 * 단방향 암호화 처리기
	 */
	@Autowired
	@Qualifier("passwordEncoder")
	private PasswordEncoder passwordEncoder;	
	
	/**
	 * 관리자 조회를 위한 UserDetailsService 구현체
	 */
	@Resource(name = "adminDetailsService")
	private UserDetailsService userDetailsService;
	
	/**
	 * JWT Utility
	 */
	@Resource(name = "jwtUtils")
	private JwtUtils jwtUtils;
		
	@Override
	protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
		
		if (authentication.getCredentials() == null) {
			throw new BadCredentialsException(messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
		}

		String presentedPassword = authentication.getCredentials().toString();

		if (!passwordEncoder.matches(presentedPassword, userDetails.getPassword())) {
			throw new BadCredentialsException(messages.getMessage(
					"AbstractUserDetailsAuthenticationProvider.badCredentials",
					"Bad credentials"));
		}
	}

	@Override
	protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {
		return userDetailsService.loadUserByUsername(username);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return (AdminAuthenticationToken.class.isAssignableFrom(authentication));		
	}
	
	/**
     * @Method 설명 : JWT 토큰으로 인증정보를 가져온다.
     * @param token JWT 토큰
     * @return UserDetails 객체
    */
	public Authentication getAuthentication(String token) {
		UserDetails userDetails = userDetailsService.loadUserByUsername(jwtUtils.getUsername(token));
		return new AdminAuthenticationToken(userDetails, "", userDetails.getAuthorities());
    }
}