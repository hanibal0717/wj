/**
 * 
 */
package com.wjthinkbig.aimath.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import com.wjthinkbig.aimath.security.admin.AdminCustomAuthenticationProvider;
import com.wjthinkbig.aimath.security.user.UserCustomAuthenticationProvider;

import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 11. 
  * @프로그램 설명 : JWT 인증 필터
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	
	/**
	 * JWT Utility
	 */
	private final JwtUtils jwtUtils;
	
	/**
	 * 관리자용 인증프로바이더
	 */
	private final AdminCustomAuthenticationProvider adminCustomAuthenticationProvider;

	/**
	 * 회원용 인증프로바이더
	 */
	private final UserCustomAuthenticationProvider userCustomAuthenticationProvider;
	
	@Autowired
	public JwtAuthenticationFilter(JwtUtils jwtUtils, AdminCustomAuthenticationProvider adminCustomAuthenticationProvider, UserCustomAuthenticationProvider userCustomAuthenticationProvider) {
		this.jwtUtils = jwtUtils;
		this.adminCustomAuthenticationProvider = adminCustomAuthenticationProvider;
		this.userCustomAuthenticationProvider = userCustomAuthenticationProvider;
	}
	
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		
		// 요청 헤더에 담긴 JWT 토큰을 가져온다. 없으면 Null
		String token = jwtUtils.resolveToken(request);
		
		boolean isValidated = false;
		if(token != null) {
			isValidated = jwtUtils.validateToken(token);
		}
		 
		log.debug("2) JwtTokenFilter => 토큰유효성 :{}, 인증 토큰 : {}", isValidated, token);		
		
		// 유효한 토큰이 존재하면 Security Context에 Authentication을 보관
		if(token != null && isValidated) {
			// 토큰에서 데이터를 가져와 사용자/관리자 토큰을 구분한다. 
			Claims claims = jwtUtils.getClaims(token);
			
			String username = (String) claims.get("sub");		
			List<String> ath = (ArrayList<String>) claims.get("ath");
			
			boolean isUser = ath.contains("ROLE_USER");
			boolean isAdmin = ath.contains("ROLE_ADMIN");
			
			log.info("전송된 토큰 구분 : 사용자({}), 관리자({})", isUser, isAdmin);		
			
			// 토큰에 있는 사용자로(username)부터 해당 사용자정보(UserDetails)를 가져온다. 
			Authentication authentication = null;
			if(isUser) {
				authentication = userCustomAuthenticationProvider.getAuthentication(token);
			} else if(isAdmin) {
				authentication = adminCustomAuthenticationProvider.getAuthentication(token);
			}
			
			// 인증컨텐스트에 저장
			SecurityContextHolder.getContext().setAuthentication(authentication);
		}

		filterChain.doFilter(request, response);
	}
	
	/**
	  * @Method 설명 : 토큰에서 가져온 사용자정보로 인증하고 인증된 객체(UsernamePasswordAuthenticationToken)를 반환한다. 
	  * @param token
	  * @return 인증처리된 객체
	 */
	private Authentication getAuthentication(String token) {
		Set<GrantedAuthority> roles = new HashSet<>();
		
		Claims claims = jwtUtils.getClaims(token);
		List<String> ath = (ArrayList<String>) claims.get("ath");		
		for(String role : ath) {
			roles.add(new SimpleGrantedAuthority(role));	
		}
				
		return new UsernamePasswordAuthenticationToken(claims, null, roles);
	}
}