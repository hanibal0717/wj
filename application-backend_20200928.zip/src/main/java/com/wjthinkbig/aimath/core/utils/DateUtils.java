package com.wjthinkbig.aimath.core.utils;

import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.TextStyle;
import java.time.temporal.ChronoField;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAdjusters;
import java.time.temporal.TemporalUnit;
import java.time.temporal.WeekFields;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * <pre>
 * Date 관련 유틸리티의 정보를 제공한다.
 * </pre>
 *
 * @author Sung Hu Kim
 * @version 1.0
 * @since
 * <pre>
 * since			author			 description
 * =============	===============	===========================
 * 2019. 07. 31.	Sung Hu Kim		최초 생성
 * 2019. 08. 07.	Kang Seok Han	  기능 추가
 * </pre>
 */
public class DateUtils {

	static final Logger log = LoggerFactory.getLogger(DateUtils.class);

	/**
	 * yyyyMM
	 */
	public static String PATTERN_MONTH = "yyyyMM";

	/**
	 * yyyyMMdd
	 */
	public static String PATTERN_DATE = "yyyyMMdd";

	/**
	 * HHmmss
	 */
	public static String PATTERN_HMS = "HHmmss";

	/**
	 * yyyy-MM-dd
	 */
	public static String PATTERN_DATE_DASH = "yyyy-MM-dd";

	/**
	 * yyyyMMddHHmmss
	 */
	public static String PATTERN_DATETIME = "yyyyMMddHHmmss";


	/**
	 * <p>
	 * 현재 일시에 해당하는 날짜시간을 yyyyMMddHHmmss 포맷으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.format() = 20190807180301
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @return
	 */
	public static String format() {
		return format(PATTERN_DATETIME);
	}

	/**
	 * <p>
	 * 현재 일시에 해당하는 날짜시간을 주어진 포맷으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.format("yyyy-MM-dd") = 2019-08-07
	 * DateUtils.format("yyyyMM") = 201908
	 * DateUtils.format("yyyy-MM-dd HH:mm:ss") = 2019-08-07 18:06:13
	 * </pre>
	 *
	 * @param dateFormat 날짜 포맷
	 * @author Kang Seok Han
	 * @return
	 */
	public static String format(String dateFormat) {
		return format(LocalDateTime.now(), dateFormat);
	}

	/**
	 * 날짜 문자열을 주어진 포멧을 변환한다.
	 * @param dateStr 변경대상 날짜
	 * @param dateFormat 변경대상의 포멧
	 * @param convertFormat 변경 포멧
	 * @return
	 */
	public static String format(String dateStr, String dateFormat, String convertFormat) {
		try {
			return LocalDate.parse(dateStr, DateTimeFormatter.ofPattern(dateFormat)).format(DateTimeFormatter.ofPattern(convertFormat));
		} catch (Exception e) {
			return dateStr;
		}

	}

	/**
	 * <p>
	 * 주어진 일시에 해당하는 날짜시간을 yyyyMMddHHmmss 포맷으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.format(LocalDateTime.now()) = 20190807180301
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param dateTime 기준일시
	 * @return
	 */
	public static String format(LocalDateTime dateTime) {
		return format(dateTime, PATTERN_DATETIME);
	}

	/**
	 * <p>
	 * 주어진 일시에 해당하는 날짜시간을 주어진 포맷으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.format(LocalDateTime.now(), "yyyyMMddHHmmss") = 20190807180301
	 * DateUtils.format(LocalDateTime.now(), "yyyyMM") = 201908
	 * DateUtils.format(LocalDateTime.now(), "yyyy-MM-dd HH:mm:ss") = 2019-08-07 18:06:13
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param dateTime 기준일시
	 * @return
	 */
	public static String format(LocalDateTime dateTime, String dateFormat) {
		return dateTime.format(DateTimeFormatter.ofPattern(dateFormat));
	}

	/**
	 * <p>
	 * 주어진 날짜 시간 문자열로 날짜 시간을 생성한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.parse("2019-01-01")
	 * DateUtils.parse("01-02-2019")
	 * DateUtils.parse("2007-12-03T10:15:30")
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDateTime#parse(CharSequence)
	 * @param date 날짜 시간 문자열
	 * @return
	 */
	public static LocalDateTime parse(String date) {
		return LocalDateTime.parse(date);
	}

	/**
	 * <p>
	 * 주어진 날짜 시간 문자열로 주어진 날짜 포맷을 적용하여 날짜 시간을 생성한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.parse("2019-01-01", "yyyy-MM-dd")
	 * DateUtils.parse("01-02-2019", "dd-MM-yyyy")
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDateTime#parse(CharSequence, DateTimeFormatter)
	 * @param date 날짜 시간 문자열
	 * @param dateFormat 날짜 시간 포맷
	 * @return
	 */
	public static LocalDateTime parse(String date, String dateFormat) {
		return parse(date, dateFormat, Locale.getDefault());
	}

	/**
	 * <p>
	 * 주어진 날짜 시간 문자열로 주어진 날짜 포맷을 적용하여 날짜 시간을 생성한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.parse("2019-01-01", "yyyy-MM-dd", Locale.getDefault())
	 * DateUtils.parse("01-02-2019", "dd-MM-yyyy", Locale.US)
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDateTime#parse(CharSequence, DateTimeFormatter)
	 * @see DateTimeFormatter#ofPattern(String, Locale)
	 * @param date 날짜 시간 문자열
	 * @param dateFormat 날짜 시간 포맷
	 * @param locale 로케일
	 * @return
	 */
	public static LocalDateTime parse(String date, String dateFormat, Locale locale) {

		if(date == null) {
			return null;
		}

		DateTimeFormatter formatter = new DateTimeFormatterBuilder()
				.appendPattern(dateFormat)
				.parseDefaulting(ChronoField.MONTH_OF_YEAR, 1)
				.parseDefaulting(ChronoField.DAY_OF_MONTH, 1)
				.parseDefaulting(ChronoField.HOUR_OF_DAY, 1)
				.parseDefaulting(ChronoField.MINUTE_OF_HOUR, 1)
				.parseDefaulting(ChronoField.SECOND_OF_MINUTE, 1)
				.toFormatter(locale);

		return LocalDateTime.parse(date, formatter);
	}

	/**
	 * <p>
	 * 현재 일시를 기준으로 주어진 날짜시간 필드에 주어진 값 만큼 더한 일시를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * 현재 일시가 2019-08-07 12:01:01 인 경우
	 * DateUtils.add(ChronoUnit.YEARS, 1) = 2020-08-07 12:01:01
	 * DateUtils.add(ChronoUnit.MONTHS, 1) =  2019-09-07 12:01:01
	 * DateUtils.add(ChronoUnit.MONTHS, -1) =  2019-07-07 12:01:01
	 * DateUtils.add(ChronoUnit.DAYS, 1) =  2019-08-08 12:01:01
	 * DateUtils.add(ChronoUnit.DAYS, -1) =  2019-08-06 12:01:01
	 * DateUtils.add(ChronoUnit.HOURS, 1) =  2019-08-07 13:01:01
	 * DateUtils.add(ChronoUnit.HOURS, -1) =  2019-08-07 11:01:01
	 * DateUtils.add(ChronoUnit.MINUTES, 1) =  2019-08-07 12:02:01
	 * DateUtils.add(ChronoUnit.MINUTES, -1) =  2019-08-07 12:00:01
	 * DateUtils.add(ChronoUnit.SECONDS, 1) =  2019-08-07 12:01:02
	 * DateUtils.add(ChronoUnit.SECONDS, -1) =  2019-08-07 12:01:00
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDateTime#plus(long, java.time.temporal.TemporalUnit)
	 * @see LocalDateTime#minus(long, java.time.temporal.TemporalUnit)
	 * @see ChronoUnit
	 * @param field 날짜시간 필드
	 * @param amountToAdd 추가
	 * @return
	 */
	public static LocalDateTime add(TemporalUnit field, long amountToAdd) {
		return add(LocalDateTime.now(), field, amountToAdd);
	}

	/**
	 * <p>
	 * 주어진 일시를 기준으로 주어진 날짜시간 필드에 주어진 값 만큼 더한 일시를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * 현재 일시가 2019-08-07 인 경우
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.YEARS, 1) = 2020-08-07 12:01:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.MONTHS, 1) =  2019-09-07 12:01:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.MONTHS, -1) =  2019-07-07 12:01:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.DAYS, 1) =  2019-08-08 12:01:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.DAYS, -1) =  2019-08-06 12:01:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.HOURS, 1) =  2019-08-07 13:01:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.HOURS, -1) =  2019-08-07 11:01:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.MINUTES, 1) =  2019-08-07 12:02:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.MINUTES, -1) =  2019-08-07 12:00:01
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.SECONDS, 1) =  2019-08-07 12:01:02
	 * DateUtils.add(LocalDateTime.now(), ChronoUnit.SECONDS, -1) =  2019-08-07 12:01:00
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDateTime#plus(long, java.time.temporal.TemporalUnit)
	 * @see LocalDateTime#minus(long, java.time.temporal.TemporalUnit)
	 * @see ChronoUnit
	 * @param field 날짜시간 필드
	 * @param amountToAdd 추가
	 * @return
	 */
	public static LocalDateTime add(LocalDateTime dateTime, TemporalUnit field, long amountToAdd) {
		if(amountToAdd >= 0) {
			return dateTime.plus(amountToAdd, field);
		}

		return dateTime.minus(Math.abs(amountToAdd), field);
	}

	/**
	 * <p>
	 * 현재 시간을 기준으로 날짜시간 필드에 주어진 값 만큼 더한 일시를 구하고 주어진 문자열 날짜 시간 포맷으로 반환 한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.parseToFormat("yyyyMM", ChronoUnit.MONTHS, 1) = 201902
	 * DateUtils.parseToFormat("yyyyMMdd", ChronoUnit.MONTHS, 1) = 20190201
	 * DateUtils.parseToFormat("yyyyMMdd", ChronoUnit.DAYS, 1) = 20190102
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param dateFormat 문자열 날짜 시간 포맷
	 * @param field 날짜시간 필드
	 * @param amountToAdd 추가
	 * @return
	 */
	public static String parseToFormat(String dateFormat, TemporalUnit field, int amountToAdd) {
		return parseToFormat(format(dateFormat), dateFormat, field, amountToAdd);
	}

	/**
	 * <p>
	 * 주어진 문자열 날짜 시간에 날짜시간 필드에 주어진 값 만큼 더한 일시를 구하고 주어진 문자열 날짜 시간 포맷으로 반환 한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.parseToFormat("201901", "yyyyMM", ChronoUnit.MONTHS, 1) = 201902
	 * DateUtils.parseToFormat("20190101", "yyyyMMdd", ChronoUnit.MONTHS, 1) = 20190201
	 * DateUtils.parseToFormat("20190101", "yyyyMMdd", ChronoUnit.DAYS, 1) = 20190102
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param date 문자열 날짜 시간
	 * @param dateFormat 문자열 날짜 시간 포맷
	 * @param field 날짜시간 필드
	 * @param amountToAdd 추가
	 * @return
	 */
	public static String parseToFormat(String date, String dateFormat, TemporalUnit field, int amountToAdd) {
		return parseToFormat(date, dateFormat, dateFormat, field, amountToAdd);
	}

	/**
	 * <p>
	 * 주어진 문자열 날짜 시간에 날짜시간 필드에 주어진 값 만큼 더한 일시를 구하고 주어진 반환 날짜 시간 포맷으로 반환 한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.parseToFormat("201901", "yyyyMM", ChronoUnit.MONTHS, 1) = 201902
	 * DateUtils.parseToFormat("20190101", "yyyyMMdd", ChronoUnit.MONTHS, 1) = 20190201
	 * DateUtils.parseToFormat("20190101", "yyyyMMdd", ChronoUnit.DAYS, 1) = 20190102
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param date 문자열 날짜 시간
	 * @param dateFormat 문자열 날짜 시간 포맷
	 * @param destDateFormat 반환 날짜 시간 포맷
	 * @param field 날짜시간 필드
	 * @param amountToAdd 추가
	 * @return
	 */
	public static String parseToFormat(String date, String dateFormat, String destDateFormat, TemporalUnit field, int amountToAdd) {
		return format(add(parse(date, dateFormat), field, amountToAdd), destDateFormat);
	}

	/**
	 * <p>
	 * 현재 날짜에 해당하는 주의 요일을 숫자로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getDayOfWeek() = 1 :월요일
	 * DateUtils.getDayOfWeek() = 7 :일요일
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfWeek()
	 * @see DayOfWeek#getValue()
	 * @return
	 */
	public static int getDayOfWeek() {
		return getDayOfWeek(LocalDate.now());
	}

	/**
	 * <p>
	 * 주어진 날짜에 해당하는 주의 요일을 숫자로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getDayOfWeek(LocalDate.now()) = 1 :월요일
	 * DateUtils.getDayOfWeek(LocalDate.now().plusDays(1)) = 2 :화요일
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfWeek()
	 * @see DayOfWeek#getValue()
	 * @param date 기준일자
	 * @return
	 */
	public static int getDayOfWeek(LocalDate date) {
		return date.getDayOfWeek().getValue();
	}

	/**
	 * <p>
	 * 현재 날짜에 해당하는 주의 요일을 명칭으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getDayOfWeekName() = 월요일
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfWeek()
	 * @see DayOfWeek#getDisplayName(TextStyle, Locale)
	 * @return
	 */
	public static String getDayOfWeekName() {
		return getDayOfWeekName(LocalDate.now());
	}

	/**
	 * <p>
	 * 주어진 날짜에 해당하는 주의 요일을 명칭으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getDayOfWeekName(LocalDate.now()) = 월요일
	 * DateUtils.getDayOfWeekName(LocalDate.now().plusDays(1)) = 화요일
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfWeek()
	 * @see DayOfWeek#getDisplayName(TextStyle, Locale)
	 * @param date 기준일자
	 * @return
	 */
	public static String getDayOfWeekName(LocalDate date) {
		return getDayOfWeekName(date, Locale.getDefault());
	}

	/**
	 * <p>
	 * 주어진 날짜에 해당하는 주의 요일을 명칭으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getDayOfWeekName(LocalDate.now(), Locale.getDefault()) = 월요일
	 * DateUtils.getDayOfWeekName(LocalDate.now(), Locale.KOREA) = 월요일
	 * DateUtils.getDayOfWeekName(LocalDate.now(), Locale.US) = Mon
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfWeek()
	 * @see DayOfWeek#getDisplayName(TextStyle, Locale)
	 * @param date 기준일자
	 * @param locale 로케일
	 * @return
	 */
	public static String getDayOfWeekName(LocalDate date, Locale locale) {
		return getDayOfWeekName(date, TextStyle.FULL, locale);
	}

	/**
	 * <p>
	 * 주어진 날짜에 해당하는 주의 요일을 명칭으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getDayOfWeekName(LocalDate.now(), TextStyle.SHORT) = 월
	 * DateUtils.getDayOfWeekName(LocalDate.now(), TextStyle.FULL) = 월요일
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfWeek()
	 * @see DayOfWeek#getDisplayName(TextStyle, Locale)
	 * @param date 기준일자
	 * @param style 명칭 표현 유형
	 * @return
	 */
	public static String getDayOfWeekName(LocalDate date, TextStyle style) {
		return getDayOfWeekName(date, style, Locale.getDefault());
	}

	/**
	 * <p>
	 * 주어진 날짜에 해당하는 주의 요일을 명칭으로 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getDayOfWeekName(LocalDate.now(), TextStyle.SHORT, Locale.getDefault()) = 월
	 * DateUtils.getDayOfWeekName(LocalDate.now(), TextStyle.FULL, Locale.getDefault()) = 월요일
	 * DateUtils.getDayOfWeekName(LocalDate.now(), TextStyle.SHORT, Locale.US) = Mon
	 * DateUtils.getDayOfWeekName(LocalDate.now(), TextStyle.FULL, Locale.US) = Monday
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfWeek()
	 * @see DayOfWeek#getDisplayName(TextStyle, Locale)
	 * @param date 기준일자
	 * @param style 명칭 표현 유형
	 * @param locale 로케일
	 * @return
	 */
	public static String getDayOfWeekName(LocalDate date, TextStyle style, Locale locale) {
		return date.getDayOfWeek().getDisplayName(style, locale);
	}

	/**
	 * <p>
	 * 현재 날짜에 해당하는 월의 마지막 일자(1-31)를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * 현재 날짜가 2019-06-01 인 경우
	 * Dateutils.getDayOfMonth() = 30
	 *
	 * 현재 날자가 2019-07-01 인 경우
	 * Dateutils.getDayOfMonth() = 31
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfMonth();
	 * @see TemporalAdjusters#lastDayOfMonth()
	 * @return
	 */
	public static int getDayOfMonth() {
		return getDayOfMonth(LocalDate.now().with(TemporalAdjusters.lastDayOfMonth()));
	}

	/**
	 * <p>
	 * 주어진 날짜에 해당하는 월의 마지막 일자(1-31)를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * 현재 날짜가 2019-06-01 인 경우
	 * Dateutils.getDayOfMonth(LocalDate.now()) = 30
	 * Dateutils.getDayOfMonth(LocalDate.now().plusMonths(1)) = 31
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see LocalDate#getDayOfMonth();
	 * @see TemporalAdjusters#lastDayOfMonth()
	 * @param date 기준일자
	 * @return
	 */
	public static int getDayOfMonth(LocalDate date) {
		return date.getDayOfMonth();
	}

	/**
	 * <p>
	 * 현재 날짜에 해당하는 주차를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * 기준 일자가 2019-08-07 인 경우
	 * DateUtils.getWeekOfYear(LocalDate.now()) = 32
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see WeekFields#of(Locale)
	 * @return
	 */
	public static int getWeekOfYear() {
		return getWeekOfYear(LocalDate.now());
	}

	/**
	 * <p>
	 * 주어진 날짜에 해당하는 주차를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * 기준 일자가 2019-08-07 인 경우
	 * DateUtils.getWeekOfYear(LocalDate.now()) = 32
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see WeekFields#of(Locale)
	 * @param date 기준일자
	 * @return
	 */
	public static int getWeekOfYear(LocalDate date) {
		return getWeekOfYear(date, Locale.getDefault());
	}

	/**
	 * <p>
	 * 주어진 날짜를 기준으로 주어진 로케일에 해당하는 주차를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * 기준 일자가 2019-08-07 인 경우
	 * DateUtils.getWeekOfYear(LocalDate.now(), Locale.getDefault()) = 32
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @see WeekFields#of(Locale)
	 * @param date 기준일자
	 * @param locale 로케일
	 * @return
	 */
	public static int getWeekOfYear(LocalDate date, Locale locale) {
		return date.get(WeekFields.of(locale).weekOfWeekBasedYear());
	}

	/**
	 * <p>
	 * 주어진 날짜를 기준으로 주어진 로케일에 해당하는 주차를 반환한다. (월기준)
	 * </p>
	 * @return
	 */
	public static int getWeekOfMonth() {
		return getWeekOfMonth(LocalDate.now());
	}

	/**
	 * <p>
	 * 주어진 날짜를 기준으로 주어진 로케일에 해당하는 주차를 반환한다. (월기준)
	 * </p>
	 * @return
	 */
	public static int getWeekOfMonth(LocalDate date) {
		return getWeekOfMonth(date, Locale.getDefault());
	}

	/**
	 * <p>
	 * 주어진 날짜를 기준으로 주어진 로케일에 해당하는 주차를 반환한다. (월기준)
	 * </p>
	 * @return
	 */
	public static int getWeekOfMonth(LocalDate date, Locale locale) {
		return date.get(WeekFields.of(locale).weekOfMonth());
	}

	/**
	 * <p>
	 * 주어진 문자열 시작일시 종료일시 간의 년수 차이를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.betweenYears("20190101", "20200101", "yyyyMMdd") = 1
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param fromDate 시작일시
	 * @param toDate 종료일시
	 * @param dateFormat 날짜시간 포맷
	 * @return
	 */
	public static long betweenYears(String fromDate, String toDate, String dateFormat) {
		return between(fromDate, toDate, dateFormat, ChronoUnit.YEARS);
	}

	/**
	 * <p>
	 * 주어진 시작일시 종료일시 간의 년수 차이를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.betweenYears(LocalDateTime.now(), LocalDateTime.now().plusYears(1)) = 1
	 * DateUtils.betweenYears(LocalDateTime.now(), LocalDateTime.now().plusYears(2)) = 2
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param fromDate 시작일시
	 * @param toDate 종료일시
	 * @return
	 */
	public static long betweenYears(LocalDateTime fromDate, LocalDateTime toDate) {
		return between(fromDate, toDate, ChronoUnit.YEARS);
	}

	/**
	 * <p>
	 * 주어진 문자열 시작일시 종료일시 간의 월수 차이를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.betweenMonths("20190101", "20190203", "yyyyMMdd") = 1
	 * DateUtils.betweenMonths("20190101", "20200203", "yyyyMMdd") = 13
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param fromDate 시작일시
	 * @param toDate 종료일시
	 * @param dateFormat 날짜시간 포맷
	 * @return
	 */
	public static long betweenMonths(String fromDate, String toDate, String dateFormat) {
		return between(fromDate, toDate, dateFormat, ChronoUnit.MONTHS);
	}

	/**
	 * <p>
	 * 주어진 시작일시 종료일시 간의 월수 차이를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.betweenMonths(LocalDateTime.now(), LocalDateTime.now().plusMonths(1)) = 1
	 * DateUtils.betweenMonths(LocalDateTime.now(), LocalDateTime.now().plusMonths(2)) = 2
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param fromDate 시작일시
	 * @param toDate 종료일시
	 * @return
	 */
	public static long betweenMonths(LocalDateTime fromDate, LocalDateTime toDate) {
		return between(fromDate, toDate, ChronoUnit.MONTHS);
	}

	/**
	 * <p>
	 * 주어진 문자열 시작일시 종료일시 간의 일수 차이를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.betweenDays("20190101", "20190102", "yyyyMMdd") = 1
	 * DateUtils.betweenDays("20190101", "20190201", "yyyyMMdd") = 31
	 * DateUtils.betweenDays("20190201", "20190301", "yyyyMMdd") = 28
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param fromDate 시작일시
	 * @param toDate 종료일시
	 * @param dateFormat 날짜시간 포맷
	 * @return
	 */
	public static long betweenDays(String fromDate, String toDate, String dateFormat) {
		return between(fromDate, toDate, dateFormat, ChronoUnit.DAYS);
	}

	/**
	 * <p>
	 * 주어진 시작일시 종료일시 간의 일수 차이를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.betweenDays(LocalDateTime.now(), LocalDateTime.now().plusDays(1)) = 1
	 * DateUtils.betweenDays(LocalDateTime.now(), LocalDateTime.now().plusDays(2)) = 2
	 * DateUtils.betweenDays(LocalDateTime.now(), LocalDateTime.now().plusDays(28)) = 28
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param fromDate 시작일시
	 * @param toDate 종료일시
	 * @return
	 */
	public static long betweenDays(LocalDateTime fromDate, LocalDateTime toDate) {
		return between(fromDate, toDate, ChronoUnit.DAYS);
	}

	/**
	 * <p>
	 * 주어진 문자열 시작일시 종료일시 간의 날짜시간 유형의 차이를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.between("20190101", "20200101", "yyyyMMdd", ChronoUnit.YEARS) = 1
	 * DateUtils.between("20190101", "20190201", "yyyyMMdd", ChronoUnit.MONTHS) = 1
	 * DateUtils.between("20190201", "20190301", "yyyyMMdd", ChronoUnit.DAYS) = 28
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param fromDate 시작일시
	 * @param toDate 종료일시
	 * @param dateFormat 날짜시간 포맷
	 * @param field 날짜시간 유형
	 * @return
	 */
	public static long between(String fromDate, String toDate, String dateFormat, TemporalUnit field) {
		return between(parse(fromDate, dateFormat), parse(toDate, dateFormat), field);
	}

	/**
	 * <p>
	 * 주어진 시작일시 종료일시 간의 날짜시간 유형의 차이를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.between(LocalDateTime.now(), LocalDateTime.now().plusYears(1), ChronoUnit.YEARS) = 1
	 * DateUtils.between(LocalDateTime.now(), LocalDateTime.now().plusMonths(1), ChronoUnit.MONTHS) = 1
	 * DateUtils.between(LocalDateTime.now(), LocalDateTime.now().plusDays(28), ChronoUnit.DAYS) = 28
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param fromDate 시작일시
	 * @param toDate 종료일시
	 * @param field 날짜시간 유형
	 * @return
	 */
	public static long between(LocalDateTime fromDate, LocalDateTime toDate, TemporalUnit field) {
		return field.between(fromDate, toDate);
	}

	/**
	 * <p>
	 * 주어진 특정일의 달의 마지막 날짜를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getLastDay("20190101")
	 * </pre>
	 *
	 * @param String
	 * @return
	 */
	public static LocalDateTime getLastDay(String date) {
		return  getLastDay(parse(date));
	}

	/**
	 * <p>
	 * 주어진 특정일의 달의 마지막 날짜를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getLastDay(LocalDateTime.now())
	 * </pre>
	 *
	 * @param date
	 * @return
	 */
	public static LocalDateTime getLastDay(LocalDateTime date) {
		LocalDate localDate = date.toLocalDate();
		return localDate.withDayOfMonth(localDate.lengthOfMonth()).atTime(LocalTime.of(date.getHour(), date.getMinute(), date.getSecond()));
	}


	/**
	 * <p>
	 * 주어진 특정일의 달의 첫째 날짜를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getFirstDay(LocalDateTime.now())
	 * </pre>
	 *
	 * @param date
	 * @return
	 */
	public static LocalDateTime getFirstDay(LocalDateTime date) {
		LocalDate localDate = date.toLocalDate();
		return localDate.withDayOfMonth(1).atTime(LocalTime.of(date.getHour(), date.getMinute(), date.getSecond()));
	}

	/**
	 * <p>
	 * 주어진 특정일의 달의 마지막 날짜를 포멧을 적용하여 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getLastDay(LocalDateTime.now(), "yyyyMMdd")
	 * </pre>
	 *
	 * @param date
	 * @param dateFormat
	 * @return
	 */
	public static String getLastDay(LocalDateTime date, String dateFormat) {
		return format(getLastDay(date), dateFormat);
	}

	/**
	 * <p>
	 * 주어진 특정일의 달의 마지막 날짜를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getLastDay("20190101", "yyyyMMdd");
	 * </pre>
	 *
	 * @param date
	 * @param dateFormat
	 * @return
	 */
	public static String getLastDay(String date, String dateFormat) {
		return  format(getLastDay(parse(date, dateFormat)), dateFormat);
	}

	/**
	 * <p>
	 * 주어진 특정일의 달의 첫째 날짜를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.getFirstDay("20190101", "yyyyMMdd");
	 * </pre>
	 *
	 * @param date
	 * @param dateFormat
	 * @return
	 */
	public static String getFirstDay(String date, String dateFormat) {
		return  format(getFirstDay(parse(date, dateFormat)), dateFormat);
	}


	/**
	 * 현재일자가 1일 인지롤 반환 한다.
	 * @return
	 */
	public static boolean isFirstDay() {
		return isFirstDay(LocalDate.now());
	}

	/**
	 * 기준일자가 1일 인지롤 반환 한다.
	 * @param date 기준일자
	 * @return
	 */
	public static boolean isFirstDay(LocalDate date) {
		return date.get(ChronoField.DAY_OF_MONTH) == 1;
	}

	/**
	 * 현재일자가 해당월의 마지막 일인지 여부를 반환 한다.
	 * @return
	 */
	public static boolean isLastDay() {
		return isLastDay(LocalDate.now());
	}

	/**
	 * 기준일자가 해당월의 마지막 일인지 여부를 반환 한다.
	 * @param date 기준일자
	 * @return
	 */
	public static boolean isLastDay(LocalDate date) {
		return date.get(ChronoField.DAY_OF_MONTH) == date.lengthOfMonth();
	}

	/**
	 * 주어진 현재시간이 시작시간과 종료시간 안에 포함 되는지 여부를 반환하낟.
	 *
	 * @param begin 시작시간
	 * @param end 종료시간
	 * @return
	 */
	public static boolean isWithinPeriod(LocalDateTime begin, LocalDateTime end) {
		return isWithinPeriod(LocalDateTime.now(), begin, end);
	}

	/**
	 * 주어진 기준시간이 시작시간과 종료시간 안에 포함 되는지 여부를 반환하낟.
	 *
	 * @param src 기준시간
	 * @param begin 시작시간
	 * @param end 종료시간
	 * @return
	 */
	public static boolean isWithinPeriod(LocalDateTime src, LocalDateTime begin, LocalDateTime end) {
		if(src.isBefore(begin)) {
			return false;
		} else if(src.isAfter(end)) {
			return false;
		}

		return true;
	}

	/**
	 * date1이 date2보다 클경우
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static Boolean greaterThen(String date1, String date2) {
		try {
			LocalDate parseDate1 = parse(StringUtils.rightPad(date1, 8, "01"), PATTERN_DATE).toLocalDate();
			LocalDate parseDate2 = parse(StringUtils.rightPad(date2, 8, "01"), PATTERN_DATE).toLocalDate();
			return parseDate1.isAfter(parseDate2);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * date1이 date2보다 크거나 같을 경우
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static Boolean greaterEquals(String date1, String date2) {
		try {
			LocalDate parseDate1 = parse(StringUtils.rightPad(date1, 8, "01"), PATTERN_DATE).toLocalDate();
			LocalDate parseDate2 = parse(StringUtils.rightPad(date2, 8, "01"), PATTERN_DATE).toLocalDate();
			return parseDate1.isAfter(parseDate2) || parseDate1.equals(parseDate2);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * date1이 date2보다 크거나 같을 경우
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static Boolean eqauls(String date1, String date2) {
		try {
			LocalDate parseDate1 = parse(StringUtils.rightPad(date1, 8, "01"), PATTERN_DATE).toLocalDate();
			LocalDate parseDate2 = parse(StringUtils.rightPad(date2, 8, "01"), PATTERN_DATE).toLocalDate();
			return parseDate1.equals(parseDate2);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * date1이 현재날짜와 같을 경우
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static Boolean eqaulsNow(String date1) {

		try {
			LocalDate parseDate1 = parse(StringUtils.rightPad(date1, 8, "01"), PATTERN_DATE).toLocalDate();
			LocalDate parseDate2 = LocalDateTime.now().toLocalDate();
			return parseDate1.equals(parseDate2);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * date1이 date2보다 작을 경우
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static Boolean lessThen(String date1, String date2) {
		try {
			LocalDate parseDate1 = parse(StringUtils.rightPad(date1, 8, "01"), PATTERN_DATE).toLocalDate();
			LocalDate parseDate2 = parse(StringUtils.rightPad(date2, 8, "01"), PATTERN_DATE).toLocalDate();
			return parseDate1.isBefore(parseDate2);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * date1이 현재날짜보다 작을 경우
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static Boolean lessThenNow(String date1) {
		try {
			LocalDate parseDate1 = parse(StringUtils.rightPad(date1, 8, "01"), PATTERN_DATE).toLocalDate();
			LocalDate parseDate2 = LocalDateTime.now().toLocalDate();
			return parseDate1.isBefore(parseDate2);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * date1이 date2보다 작거나 같을 경우
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static Boolean lessEquals(String date1, String date2) {
		try {
			LocalDate parseDate1 = parse(StringUtils.rightPad(date1, 8, "01"), PATTERN_DATE).toLocalDate();
			LocalDate parseDate2 = parse(StringUtils.rightPad(date2, 8, "01"), PATTERN_DATE).toLocalDate();
			return parseDate1.isBefore(parseDate2) || parseDate1.equals(parseDate2);
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * <p>
	 * 주어진 기준시간이 시작시간과 종료시간 안에 포함 되는지 여부를 반환한다.
	 * </p>
	 *
	 * <pre>
	 * DateUtils.isWithinPeriod("20190102", "20190101", "20190131", "yyyyMMdd")
	 * </pre>
	 *
	 * @param src 기준시간
	 * @param begin 시작시간
	 * @param end 종료시간
	 * @param dateFormat
	 * @return
	 */
	public static boolean isWithinPeriod(String src, String begin, String end, String dateFormat) {

		if(StringUtils.isAnyBlank(src, begin, end)) {
			return false;
		}

		return isWithinPeriod(parse(src, dateFormat), parse(begin, dateFormat), parse(end, dateFormat));
	}


	/**
	 * 날짜의 차이값을 반환
	 * @param date1
	 * @param date2
	 * @return
	 */
	public static Duration getBetweenDuration(String date1, String date2) {
		Duration duration =  Duration.between(parse(date1, DateUtils.PATTERN_DATETIME), parse(date2, DateUtils.PATTERN_DATETIME));
		return duration;
	}

}
