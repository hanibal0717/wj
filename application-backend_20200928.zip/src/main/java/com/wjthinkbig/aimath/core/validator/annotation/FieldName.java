/**
 * 
 */
package com.wjthinkbig.aimath.core.validator.annotation;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * @Date : 2020. 8. 21. 
 * @작성자 : Lee Seung Hyuk
 * @프로그램 설명 : @FieldName 어노테이션, 검증 대상 빈 객체의 필드에 이름을 부여하면 검증메시지에서 영문필드명 대신 이 어노테이션의 값이 출력된다.  
* <pre>
* since            author             description
* =============    ===============    ===========================
* 2020. 8. 21.     seung              최초작성
* </pre>
 */
@Documented
@Retention(RUNTIME)
@Target(ElementType.FIELD)
@Inherited
public @interface FieldName {
	String value() default "";
}