package com.wjthinkbig.aimath.core.web.bind;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.groups.ConvertGroup;

import com.wjthinkbig.aimath.core.validator.groups.Groups;

import lombok.Getter;
import lombok.Setter;

/**
 * <pre>
 * 일괄 적용(등록/수정/삭제)을 처리 하기 위한 기본 클래스로 Validation(JSR380)을 적용하기 위한 기본 설정 제공한다.
 * </pre>
 *
 * @author Kang Seok Han
 * @version 1.0
 * @since
 * <pre>
 * since			author				description
 * =============	===============		===========================
 * 2019. 05. 28.	Kang Seok Han		최초 생성
 * </pre>
 */
@Getter
@Setter
public class SaveVO<T extends BaseVO> implements Serializable {

	private static final long serialVersionUID = 1900561543294585920L;

	/**
	 * 추가 할 목록
	 */
	private List<@ConvertGroup(to = Groups.Insert.class) @Valid T> insertList = new ArrayList<T>();

	/**
	 * 수정 할 목록
	 */
	private List<@ConvertGroup(to = Groups.Update.class) @Valid T> updateList = new ArrayList<T>();

	/**
	 * 삭제 할 목록
	 */
	private List<@ConvertGroup(to = Groups.Delete.class) @Valid T> deleteList = new ArrayList<T>();

	public void setUserId(String userId) {
		
		insertList.stream().forEach(x -> {
			x.setRgtnUser(userId);
			x.setRgtnDt(LocalDateTime.now());
		});

		updateList.stream().forEach(x -> {
			x.setModUser(userId);
			x.setModDt(LocalDateTime.now());
		});

		deleteList.stream().forEach(x -> {
			x.setModUser(userId);
			x.setModDt(LocalDateTime.now());
		});
	}
}