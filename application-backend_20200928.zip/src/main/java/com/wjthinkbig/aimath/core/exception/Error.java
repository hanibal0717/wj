package com.wjthinkbig.aimath.core.exception;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;



/**
 * @Date : 2020. 8. 22. 
 * @작성자 : Lee Seung Hyuk
 * @프로그램 설명 : 예외처리 핸들러에서 처리할 에러 정보를 저장하기 위한 클래스
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 8. 22.     seung              최초작성
 * </pre>
*/
@Setter
@Getter
@AllArgsConstructor
public class Error implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 6638083915890538212L;

	/**
	 * 에러코드
	 */
	private String errorCode;

	/**
	 * 에러메시지
	 */
	private String errorMessage;

	/**
	 * 예외메시지
	 */
	private String exceptionMessage;

	/**
	 * 예외클래스
	 */
	private String exceptionClass;

	public Error() {

	}

	public Error(String errorCode) {
		this(errorCode, null, null, null);
	}

	public Error(String errorCode, String errorMessage) {
		this(errorCode, errorMessage, null, null);
	}

	public Error(String errorCode, String errorMessage, String exceptionMessage) {
		this(errorCode, errorMessage, exceptionMessage, null);
	}
}
