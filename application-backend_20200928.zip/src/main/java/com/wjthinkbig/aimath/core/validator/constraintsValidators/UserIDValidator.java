/**
 * 
 */
package com.wjthinkbig.aimath.core.validator.constraintsValidators;

import java.util.regex.Pattern;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.wjthinkbig.aimath.core.validator.constraints.UserID;

/**
  * @Date : 2020. 9. 8. 
  * @프로그램 설명 : 아이디 검증을 위한 Custom Validator 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 8.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class UserIDValidator implements ConstraintValidator<UserID, String> {
	
	// 아이디 검증패턴		
	private final String REGEX_PATTERN = "^[A-Za-z[0-9]]{6,10}$";
	
	public Pattern pattern = Pattern.compile(REGEX_PATTERN);
	
	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		
		if(value == null) {
			return true;
		} else {
			return pattern.matcher(value).matches();
		}
	}
}