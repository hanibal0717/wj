package com.wjthinkbig.aimath.qst.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.qst.vo.QstMetaVO;
import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseMetaVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstWransrCrseVO;
import com.wjthinkbig.aimath.qst.vo.QstWrtnMngtVO;

/**
 * @FileName : QstDao.java
 * @Project : application-backend
 * @Date : 2020. 8. 14. 
 * @작성자 : 19001861
 * @프로그램 설명 :
 * @변경이력 :
 */
@Mapper("qstDao")
public interface QstDao {
	
	/**
	  * @Method 설명 : 커리큘럼 문항 전체 리스트를 가져온다.
	  * @param qstSearch
	  * @return
	  * @throws Exception
	  */
	List<QstVO> selectQstList(QstSearchVO qstSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 문항 전체 리스트 수를 가져온다.
	  * @param qstSearch
	  * @return
	  * @throws Exception
	  */
	int selectQstCount(QstSearchVO qstSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 특정 문항정보를 가져온다. (언어코드 필수)
	  * @param qstSearch
	  * @return
	  * @throws Exception
	  */
	QstVO selectQst(QstSearchVO qstSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 특정 문항정보를 가져온다.
	  * @param qstCd
	  * @return
	  */
	QstVO selectQstById(String qstCd);
	
	/**
	  * @Method 설명 : 커리큘럼 특정 문항 메타 정보 리스트를 가져온다.
	  * @param qstCd
	  * @return
	  */
	List<QstMetaVO> selectQstMetaList(String qstCd);
	
	/**
	  * @Method 설명 : 커리큘럼 문항 오답 리스트를 가져온다.
	  * @param qst_cd
	  * @return
	  * @throws Exception
	  */
	List<QstWransrCrseVO> selectQstWransrCrseList(QstWransrCrseSearchVO qstWransrCrseSearch);
	
	/**
	  * @Method 설명 : 특정키로 커리큘럼 문항 오답 리스트를 가져온다.
	  * @param qstCd
	  * @return
	  */
	List<QstWransrCrseVO> selectQstWransrCrseListById(String qstCd);
	
	/**
	  * @Method 설명 : 커리큘럼 문항 오답 메타 리스트를 가져온다.
	  * @param qstWransrCrseSearch
	  * @return
	  */
	List<QstWransrCrseMetaVO> selectQstWransrCrseMetaList(QstWransrCrseSearchVO qstWransrCrseSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 문항코드 중복체크.
	  * @param qst_cd
	  * @return
	  * @throws Exception
	  */
	int selectQstCdDplctCeck(String qst_cd);
	
	/**
	  * @Method 설명 : 커리큘럼 문항코드 중복체크. tb_cmn_qst 테이블에서 확인
	  * @param qst_cd
	  * @return
	  */
	int selectQstCdDplctCeckByQst(String qst_cd);
	
	/**
	  * @Method 설명 : 신규 문항정보를 등록한다.
	  * @param qst
	  */
	void insertQst(QstVO qst);
	
	/**
	  * @Method 설명 : 신규 문항 메타 정보를 등록한다.
	  * @param qstMeta
	  */
	void insertQstMeta(QstMetaVO qstMeta);
	
	/**
	  * @Method 설명 : 신규 오답정보를 등록한다.
	  * @param qstWransrCrse
	  */
	void insertQstWransrCrse(QstWransrCrseVO qstWransrCrse);
	
	/**
	  * @Method 설명 : 신규 문항저작정보를 등록한다.
	  * @param qstWrtnMngt
	  */
	void insertQstWrtnMngt(QstWrtnMngtVO qstWrtnMngt);
	
	/**
	  * @Method 설명 : 신규 오답 원인 정보를 등록한다.
	  * @param qstWransrCrseMeta
	  */
	void insertQstWransrCrseMeta(QstWransrCrseMetaVO qstWransrCrseMeta);
	
	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 문항정보를 변경한다.
	  * @param qst
	  */
	void updateQst(QstVO qst);
	
	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 문항저작정보를 변경한다.
	  * @param qstWrtnMngt
	  */
	void updateQstWrtnMngt(QstWrtnMngtVO qstWrtnMngt);
	
	/**
	  * @Method 설명 : 특정 키를 갖는 오답 정보를 삭제한다.
	  * @param qst_cd
	  * @return
	  */
	int deleteQstWransrCrse(String qst_cd);
	
	/**
	  * @Method 설명 : 특정 키를 갖는 오답 메타 정보를 삭제한다.
	  * @param qst_cd
	  * @return
	  */
	int deleteQstWransrCrseMeta(String qst_cd);
	
	/**
	  * @Method 설명 : 특정 키를 갖는 문항 메타 정보를 삭제한다.
	  * @param qst_cd
	  * @return
	  */
	int deleteQstMeta(String qst_cd);
	
	/**
	  * @Method 설명 : 특정 키를 갖는 문항 정보를 삭제한다.
	  * @param qst
	  * @return
	  */
	int deleteQst(QstVO qst);
	
	/**
	  * @Method 설명 : 특정 키를 갖는 문항 저작관리 정보를 삭제한다.
	  * @param qst_cd
	  * @return
	  */
	int deleteQstWrtnMngt(String qst_cd);
		
}
