package com.wjthinkbig.aimath.qst.vo;

import java.util.List;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @FileName : QstVO.java
 * @Project : application-backend
 * @Date : 2020. 8. 14. 
 * @작성자 : 19001861
 * @프로그램 설명 : 커리큘럼 문항 VO
 * @변경이력 :
*/
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 문항 정보")
public class QstVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;						/* 문항코드 */
	
	@NotBlank(groups = Groups.Insert.class)
	@ApiModelProperty(value="스테이지코드")
	@FieldName("스테이지코드")
	private String stgCd;						/* 스테이지코드 */
	
	@ApiModelProperty(value="문항내용")
	@FieldName("문항내용")
	private String qstCn;						/* 문항내용 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="문항정답")
	@FieldName("문항정답")
	private String qstCransr;					/* 문항정답 */
	
	@ApiModelProperty(value="보기내용")
	@FieldName("보기내용")
	private String exmpCn;						/* 보기내용 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="필수문항여부")
	@FieldName("필수문항여부")
	private String esntlQstYn;					/* 필수문항여부 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="오답유형구분코드")
	@FieldName("오답유형구분코드")
	private String wransrTyScnCd;				/* 오답유형구분코드 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="정답유형구분코드")
	@FieldName("정답유형구분코드")
	private String cransrTyScnCd;				/* 정답유형구분코드 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn;						/* 사용여부 */
	
	@ApiModelProperty(value="저작상태코드")
	@FieldName("저작상태코드")
	private String wrtnStsCd;					/* 저작상태코드 */
	
	@ApiModelProperty(value="저작상태코드명")
	@FieldName("저작상태코드명")
	private String wrtnStsNm;					/* 저작상태코드명 */
	
	@ApiModelProperty(value="지문내용")
	@FieldName("지문내용")
	private String textCn;						/* 지문내용 */
	
	@Min(value = 1, groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="폰트크기")
	@FieldName("폰트크기")
	private int fontSize;						/* 폰트크기 */
	
	@ApiModelProperty(value="등록언어")
	@FieldName("등록언어")
	private String langText;					/* 등록언어 */
	
	@ApiModelProperty(value="문항메타리스트")
	@FieldName("문항메타리스트")
	private List<QstMetaVO> qstMetaList;		/* 문항메타리스트 */
	
	@ApiModelProperty(value="문항오답리스트")
	@FieldName("문항오답리스트")
	private List<QstWransrCrseVO> qstWransrCrseList;		/* 문항오답리스트 */
}
