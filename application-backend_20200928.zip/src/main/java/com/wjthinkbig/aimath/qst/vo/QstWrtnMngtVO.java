package com.wjthinkbig.aimath.qst.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @FileName : QstWrtnMngtVO.java
 * @Project : application-backend
 * @Date : 2020. 8. 14. 
 * @작성자 : 19001861
 * @프로그램 설명 : 커리큘럼 문항 저작정보 VO
 * @변경이력 :
*/
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 문항저작정보 정보")
public class QstWrtnMngtVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;						/* 문항코드 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="스테이지코드")
	@FieldName("스테이지코드")
	private String stgCd;						/* 스테이지코드 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="저작상태코드")
	@FieldName("저작상태코드")
	private String wrtnStsCd;					/* 저작상태코드 */
	
	@ApiModelProperty(value="저작자")
	@FieldName("저작자")
	private String wrtnUser;					/* 저작자 */
	
	@ApiModelProperty(value="저작일시")
	@FieldName("저작일시")
	private String wrtnDt;						/* 저작일시 */
	
	@ApiModelProperty(value="1차검수자")
	@FieldName("1차검수자")
	private String firstIspUser;				/* 1차검수자 */
	
	@ApiModelProperty(value="1차검수일시")
	@FieldName("1차검수일시")
	private String firstIspDt;					/* 1차검수일시 */
	
	@ApiModelProperty(value="1차검수내용")
	@FieldName("1차검수내용")
	private String firstIspCn;					/* 1차검수내용 */
	
	@ApiModelProperty(value="2차검수자")
	@FieldName("2차검수자")
	private String scndIspUser;					/* 2차검수자 */
	
	@ApiModelProperty(value="2차검수일시")
	@FieldName("2차검수일시")
	private String scndIspDt;					/* 2차검수일시 */
	
	@ApiModelProperty(value="2차검수내용")
	@FieldName("2차검수내용")
	private String scndIspCn;					/* 2차검수내용 */
	
	@ApiModelProperty(value="3차검수자")
	@FieldName("3차검수자")
	private String thrdIspUser;					/* 3차검수자 */
	
	@ApiModelProperty(value="3차검수일시")
	@FieldName("3차검수일시")
	private String thrdIspDt;					/* 3차검수일시 */
	
	@ApiModelProperty(value="3차검수내용")
	@FieldName("3차검수내용")
	private String thrdIspCn;					/* 3차검수내용 */
}
