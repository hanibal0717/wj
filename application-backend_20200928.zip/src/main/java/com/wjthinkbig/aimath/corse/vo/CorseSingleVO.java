package com.wjthinkbig.aimath.corse.vo;

import java.util.List;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 3.
  * @프로그램 설명 : 교육과정 관리 단일 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 3.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="교육과정 관리 단일 정보")
public class CorseSingleVO extends BaseVO {
	
	@ApiModelProperty(value="주제코드")
	@FieldName("주제코드")
	private String thmaCd;			/* 주제코드 */
	
	@ApiModelProperty(value="주제명")
	@FieldName("주제명")
	private String thmaNm;			/* 주제명 */
	
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd; 			/* 소주제코드(스테이지코드) */
	
	@ApiModelProperty(value="스테이지명")
	@FieldName("스테이지명")
	private String stgNm; 			/* 스테이지명 */
	
	@ApiModelProperty(value="교육과정 리스트")
	@FieldName("교육과정 리스트")
	private List<CorseVO> corseList;	/* 교육과정리스트 */
	
}
