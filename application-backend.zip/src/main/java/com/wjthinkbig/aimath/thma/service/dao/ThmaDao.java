/**
 * 
 */
package com.wjthinkbig.aimath.thma.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.thma.vo.ThmaSearchVO;
import com.wjthinkbig.aimath.thma.vo.ThmaVO;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 주제정보관리 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Mapper("thmaDao")
public interface ThmaDao {

	/**
	  * @Method 설명 : 커리큘럼 테마 전체 리스트를 가져온다.
	  * @return 주제 전체리스트
	  * @param thmaSearch 검색 param 객체
	 */
	List<ThmaVO> selectThmaList(ThmaSearchVO thmaSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 테마 전체 리스트 수를 가져온다.
	  * @param thmaSearch
	  * @return
	  */
	int selectThmaListCnt(ThmaSearchVO thmaSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 특정 주제정보를 가져온다. 
	  * @param thma_cd 가져올 주제정보의 식별코드
	  * @return 해당 주제정보 VO
	 */
	ThmaVO selectThmaById(String thma_cd);
	
	/**
	  * @Method 설명 : 새로운 주제 코드 생성
	  * @return
	  */
	String selectNewThmaCd();
	
	/**
	  * @Method 설명 : 마지막 순서 번호를 가져온다 ( max(dsp_odr) + 1 )
	  * @return
	  */
	int selectLastDspOrd();
	
	/**
	  * @Method 설명 : 신규 주제정보를 등록한다.
	  * @param thma 등록할 주제정보를 담은 VO 객체
	 */
	void insertThma(ThmaVO thma);

	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 주제정보를 변경한다.
	  * @param thma 변경할 정보를 담은 주제 VO객체
	 */
	void updateThma(ThmaVO thma);

	/**
	 * 
	  * @Method 설명 : 특정 키를 갖는 커리큘럼 정보를 삭제한다.
	  * @param thma_cd 삭제할 대상 주제의 식별키 
	  * @return 삭제된 데이터 건 수
	 */
	int deleteThma(String thma_cd);
}