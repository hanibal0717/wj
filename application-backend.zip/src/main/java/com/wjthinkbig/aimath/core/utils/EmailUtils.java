package com.wjthinkbig.aimath.core.utils;

import java.util.Date;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;


/**
  * @Date : 2020. 9. 23 
  * @프로그램 설명 : 이메일인증 및 비밀번호 찾기 이메일 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 23          Kim Hee Seok       최초작성
  * </pre>
  */
@Slf4j
@Component
public class EmailUtils {
	String toEmail;
	String fromEmail;
	String title;
	String message;
	
	// 구글 SMTP ID
	@Value("${email.accountId}")
	private String accountId;
	
	// 구글 SMTP PASSWORD
	@Value("${email.accountPw}")
	private String accountPw;
	
	// 구객응대 이메일 
	@Value("${email.clientEmail}")
	private String clientEmail;
	
	/**
	  * @Method 설명 : mailSample - 이메일 테스트 용
	  * @작성일 : 2020. 9. 25
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	*/
	@Async
	public void mailSample() {
		toEmail="hanibal0717@gmail.com";
		fromEmail=clientEmail;
		title="TEST TITLE";
		message="TEST MESSAGE";
		sendEmail(toEmail,fromEmail,title,message);
	}
	
	/**
	  * @Method 설명 : mailAuth - 이메일 인증 
	  * @작성일 : 2020. 9. 25
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	*/
	@Async
	public void mailAuth(String seedUrl,String toEmail) {
		fromEmail=clientEmail;
		title="회원가입 에메일 주소 인증";
		message="안녕하세요<br>";
		message+="계정 보호를 위해 이메일 주소 인증이 필요합니다.<br>";
		message+="아래 버튼을 눌러 인증을 완료해 주세요.<br>";
		message+="<a href='http://10.145.163.49:8080/api/members/email/verification/"+seedUrl+"'><button>인증하기(http://localhost:8080/api/members/email-auth/"+seedUrl+")</button></a>";
		log.info(message);
		sendEmail(toEmail,fromEmail,title,message);
	}
	
	/**
	  * @Method 설명 : findPw
	  * @작성일 : 2020. 9. 25
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	*/
	@Async
	public void findPw(String tmpPw,String toEmail) {
		fromEmail=clientEmail;
		title="회원님의 임시 비밀번호 입니다.";
		message="회원님의 임시 비밀번호는 "+tmpPw+" 입니다.";
		sendEmail(toEmail,fromEmail,title,message);
	}
	
	
	
	public void sendEmail(String toEmail,String fromEmail,String title,String message) {
		Properties p = System.getProperties();
	    p.put("mail.smtp.starttls.enable", "true");     // gmail은 무조건 true 고정
	    p.put("mail.smtp.host", "smtp.gmail.com");      // smtp 서버 주소
	    p.put("mail.smtp.ssl.trust", "smtp.gmail.com"); //ssl 관련
	    p.put("mail.smtp.auth","true");                 // gmail은 무조건 true 고정
	    p.put("mail.smtp.port", "587");
	    Authenticator auth = new MailAuthConfig(accountId,accountPw);
	
	    //session 생성 및  MimeMessage생성
	    Session session = Session.getInstance(p, auth);
	    MimeMessage msg = new MimeMessage(session);
	    try{
	        //편지보낸시간
	        msg.setSentDate(new Date());
	        InternetAddress from = new InternetAddress() ;
	        from = new InternetAddress(toEmail+"<"+fromEmail+">");
	         // 이메일 발신자
	        msg.setFrom(from);
	         // 이메일 수신자
	        InternetAddress to = new InternetAddress(toEmail);
	        msg.setRecipient(Message.RecipientType.TO, to);
	
	        // 이메일 제목
	        msg.setSubject(title, "UTF-8");
	
	        // 이메일 헤더
	        msg.setHeader("content-Type", "text/html");
	        msg.setContent(message, "text/html; charset=euc-kr");
	        //메일보내기
	        javax.mail.Transport.send(msg);
	    }catch (AddressException addr_e) {
	        addr_e.printStackTrace();
	    }catch (MessagingException msg_e) {
	        msg_e.printStackTrace();
	    }
	    
	}
	public String getTempPw(int length) {
		char[] charaters = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','0','1','2','3','4','5','6','7','8','9'};
		StringBuilder sb = new StringBuilder("");
		Random rn = new Random();
		  for( int i = 0 ; i < length ; i++ ){
	            sb.append( charaters[ rn.nextInt( charaters.length ) ] );
	        }
	        return sb.toString();
	}
	
	static class MailAuthConfig extends Authenticator{
		PasswordAuthentication pa;
		public MailAuthConfig(String id,String pw){
	        // ID와 비밀번호를 입력한다.
	        pa = new PasswordAuthentication(id, pw);
	    }
		// 시스템에서 사용하는 인증정보
	    public PasswordAuthentication getPasswordAuthentication() {
	        return pa;
	    }
	}
}

