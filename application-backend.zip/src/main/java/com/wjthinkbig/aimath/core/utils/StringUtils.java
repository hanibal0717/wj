package com.wjthinkbig.aimath.core.utils;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetDecoder;
import java.nio.charset.CodingErrorAction;
import java.text.DecimalFormat;

import org.apache.commons.lang3.ArrayUtils;

/**
 * <pre>
 * String 관련 유틸리티의 정보를 제공한다.
 * </pre>
 *
 * @author Kang Seok Han
 * @version 1.0
 * @since
 * <pre>
 * since			author			 description
 * =============	===============	===========================
 * 2019. 08. 00.	Kang Seok Han	  기능 추가
 * </pre>
 */
public class StringUtils extends org.apache.commons.lang3.StringUtils {

	public static final String DEFAULT_CHAR_SET = "EUC_KR";

	/**
	 * <p>
	 * 문자열을 주어진 length byte 수 만큼 문자열을 잘라서 반환한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtils.byteSubstring("UTF-8", "서울2가", 3)) = 서
	 * StringUtils.byteSubstring("UTF-8", "서울2가", 5)) = 서
	 * StringUtils.byteSubstring("EUC-KR", "서울2가", 5)) = 서울2
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param charsetName
	 * @param data 문자열
	 * @param length byte수
	 * @return
	 */
	public static String byteSubstring(String charsetName, String data, int length) {
		Charset charset = Charset.forName(charsetName);
		CharsetDecoder decoder = charset.newDecoder();

		ByteBuffer byteBuf = ByteBuffer.wrap(data.getBytes(charset), 0, length);
		CharBuffer charBuf = CharBuffer.allocate(length);

		decoder.onMalformedInput(CodingErrorAction.IGNORE);
		decoder.decode(byteBuf, charBuf, true);
		decoder.flush(charBuf);

		return new String(charBuf.array(), 0, charBuf.position());
	}

	/**
	 * <p>
	 * 주어진 문자열을 start부터 length byte 수 만큼 문자열을 잘라서 반환한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtils.byteSubstring("UTF-8", "서울특별시2가", 3, 6)  = 울특
	 * StringUtils.byteSubstring("UTF-8", "서울특별시2가", 3, 15) = 울특별시2
	 * StringUtils.byteSubstring("EUC-KR", "서울특별시2가", 2, 9) = 울특별시2
	 * </pre>
	 *
	 * @author Kang Seok Han
	 * @param charsetName
	 * @param data 문자열
	 * @param length byte수
	 * @return
	 */
	public static String byteSubstring(String charsetName, String data,int start, int length) {
		Charset charset = Charset.forName(charsetName);
		CharsetDecoder decoder = charset.newDecoder();

		ByteBuffer byteBuf = ByteBuffer.wrap(data.getBytes(charset), start, length);
		CharBuffer charBuf = CharBuffer.allocate(length);

		decoder.onMalformedInput(CodingErrorAction.IGNORE);
		decoder.decode(byteBuf, charBuf, true);
		decoder.flush(charBuf);

		return new String(charBuf.array(), 0, charBuf.position());
	}

	/**
	 * <p>
	 * 문자열이 비교대상 문자열보다 큰지 여부를 반환한다.
	 * </p>
	 *
	 * @param org 문자열
	 * @param comp 비교대상 문자열
	 * @return 문자열이 비교대상 문자열보다 크다면 true를 반환하고 그렇지 않다면 false를 반환한다.
	 */
	public static boolean greater(String org, String comp) {
		return compare(org, comp) > 0 ? true:false;
	}

	/**
	 * <p>
	 * 문자열이 비교대상 문자열보다 크거나 같은지 여부를 반환한다.
	 * </p>
	 *
	 * @param org 문자열
	 * @param comp 비교대상 문자열
	 * @return 문자열이 비교대상 문자열보다 크거나 같다면 true를 반환하고 그렇지 않다면 false를 반환한다.
	 */
	public static boolean greaterThen(String org, String comp) {
		return compare(org, comp) >= 0 ? true:false;
	}

	/**
	 * <p>
	 * 문자열이 비교대상 문자열보다 작은지 여부를 반환한다.
	 * </p>
	 *
	 * @param org 문자열
	 * @param comp 비교대상 문자열
	 * @return 문자열이 비교대상 문자열보다 작다면 true를 반환하고 그렇지 않다면 false를 반환한다.
	 */
	public static boolean less(String org, String comp) {
		return compare(org, comp) < 0 ? true:false;
	}

	/**
	 * <p>
	 * 문자열이 비교대상 문자열보다 작거나 같은지 여부를 반환한다.
	 * </p>
	 *
	 * @param org 문자열
	 * @param comp 비교대상 문자열
	 * @return 문자열이 비교대상 문자열보다 작거나 같다면 true를 반환하고 그렇지 않다면 false를 반환한다.
	 */
	public static boolean lessThen(String org, String comp) {
		return compare(org, comp) <= 0 ? true:false;
	}

	/**
	 * <p>
	 * Object를 String으로 변환해 준다. 삭제예정
	 * null의 경우는 blank를 반환한다.
	 * </p>
	 * @param obj 문자열
	 * @return Object를 변환한 String 값
	 */
	public static String defaultString(Object obj) {
		return (null == obj) ? "" : obj.toString();
	}

	/**
	 * <p>
	 * Object를 String으로 변환해 준다.
	 * null의 경우는 blank를 반환한다.
	 * </p>
	 * @param obj 문자열
	 * @return Object를 변환한 String 값
	 */
	public static String objectToString(Object obj) {
		return (null == obj) ? "" : obj.toString();
	}

	/**
	 * <pre>
	 * 인자 문자열을 트림 후 빈값 또는 null인지 확인한다.
	 * </pre>
	 * @param chars 비교할 문자열
	 * @return null이 아니고 빈값이 아니면 true를 반환한다.
	 * @author 이주황
	 * @since 2019.11.05
	 * */
	public static boolean isTrimToNotEmpty(String chars) {
		return chars != null ? !isEmpty(trim(chars)) : false;
	}

	/**
	 * <pre>
	 * 인자 문자열을 트림 후 빈값 또는 null인지 확인한다.
	 * </pre>
	 * @param chars 비교할 문자열
	 * @return null 또는 빈값이면 true를 반환한다.
	 * @author 이주황
	 * @since 2019.11.05
	 * */
	public static boolean isTrimToEmpty(String chars) {
		return chars == null || isEmpty(trim(chars));
	}

	/**
	 * 문자열을 전화번호 포멧으로 변경한다.
	 * @param source
	 * @return
	 */
	public static String formatTel(String source) {
		String result = "";
		try {
			int len = source.replaceAll("\\D", "").length();

			if(len == 9) {
				result = String.join("", source.substring(0, 2),"-", source.substring(2, source.length()-4), "-", source.substring(source.length()-4));
			} else {
				result = String.join("", source.substring(0, 3), "-", source.substring(3, source.length()-4), "-", source.substring(source.length()-4));
			}
		} catch (Exception e) {
			result = source;
		}

		return result;
	}

	/**
	 * 문자열을 금액 포멧으로 변경한다(3자리 콤마(,)처리)
	 * @param source
	 * @return
	 */
	public static String formatMoney(String source) {
		try {
			DecimalFormat formatter = new DecimalFormat("###,###");

			return formatter.format(new BigDecimal(source));
		} catch (Exception e) {
			return source;
		}
	}

	/**
	 * 문자열을 금액 포멧으로 변경한다(3자리 콤마(,)처리)
	 * @param source
	 * @return
	 */
	public static String formatMoneyForNoZero(String source) {
		try {

			if (StringUtils.startsWith(source, "-")) {
				return "0";
			} else {
				return StringUtils.formatMoney(source);
			}
		} catch (Exception e) {
			return source;
		}
	}

	/**
	 * 문자열을 숫자 포멧으로 변경한다
	 * @param source
	 * @return
	 */
	public static String formatNumber(String source, String format) {
		try {
			DecimalFormat formatter = new DecimalFormat(format);

			return formatter.format(new BigDecimal(source));
		} catch (Exception e) {
			return source;
		}
	}
	/**
	 * 문자열의 앞자리 '0' 제거
	 * @param source
	 * @return
	 */
	public static String removeZero(String source) {
		try {
			return source.replaceAll("(^0+)", "");
		} catch (Exception e) {
			return source;
		}
	}

	/**
	 * 검색문자열에 전체일치하는 캐릭터 조회
	 * @param chars
	 * @param searchChars
	 * @return
	 */
	public static boolean containsEquals(final String chars,  final String... searchChars) {
		 if (isEmpty(chars) || ArrayUtils.isEmpty(searchChars)) {
				return false;
		 }
		 for( int i = 0; i < searchChars.length; i++) {
			 if( chars.contentEquals(searchChars[i])) return true;
		 }
		 return false;
	}

	/**
	 * 검색문자열에 전체일치하는 캐릭터 조회
	 * @param chars
	 * @param searchChars
	 * @return
	 */
	public static boolean containsIgnoreEquals(final String chars,  final String... searchChars) {
		 if (isEmpty(chars) || ArrayUtils.isEmpty(searchChars)) {
				return false;
		 }
		 for( int i = 0; i < searchChars.length; i++) {
			 if( chars.equalsIgnoreCase(searchChars[i])) return true;
		 }
		 return false;
	}

	/**
	 * <p>
	 * 주어진 문자열(camelcase String)을 snakecase로 변환한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtils.formatSnakeCase("abcDefGhi",TRUE)  = ABC_DEF_GHI
	 * StringUtils.formatSnakeCase("abcDefGhi",FALSE) = abc_def_ghi

	 * </pre>
	 *
	 * @author Kim Sung Hu with Kim Hyong joon
	 * @param data 문자열
	 * @param 대소문자여부
	 * @return
	 */
	public static String formatSnakeCase(String value, boolean upperCase) {

		if(value == null) {
			return null;
		}

		String[] strings = StringUtils.splitByCharacterTypeCamelCase(value);

		String rtnStr = StringUtils.join(strings,"_");

		return upperCase ? rtnStr.toUpperCase() : rtnStr.toLowerCase();
	}

	/**
	 * <p>
	 * 주어진 문자열(snakecase String)을 camelcase로 변환한다.
	 * </p>
	 *
	 * <pre>
	 * StringUtils.formatCamelCase("ABC_DEF_GHI",TRUE)  = AbcDefGhi
	 * StringUtils.formatCamelCase("ABC_DEF_GHI",FALSE) = abcDefGhi
	 * </pre>
	 *
	 * @author Kim Sung Hu with Kim Hyong joon
	 * @param snakeTail String 값
	 * @param 대/소문자 여부
	 * @return
	 */
	public static String formatCamelCase(String value, boolean upperCase) {

		if(value == null) {
			return null;
		}

		String[] strings = StringUtils.split(value.toLowerCase(),"_");
		for(int i = upperCase ? 0 : 1; i < strings.length; i++ ) {
			strings[i] = StringUtils.capitalize(strings[i]);
		}
		return StringUtils.join(strings);
	}

	/**
	 * 주어진 문자열을 시간포멧으로 변경한다.
	 * @param timeStr
	 * @return
	 */
	public static String formatTime(String timeStr) {
		try {
			return timeStr.replaceAll("(\\d{2})(\\d{2})(\\d{2})", "$1:$2:$3");
		} catch (Exception e) {
			return timeStr;
		}
	}

	/**
	 * 파일사이즈를 KB,MB,GB로 표출한다.
	 * @param size
	 * @return
	 */
	public static String formatFileSize(String size) {
		try {
			double dSize = Double.parseDouble(size);

			if (dSize < 1024) {
				return size + " bytes";
			} else if (dSize < 1024 * 1024) {
				return Math.round(dSize / 1024.0) + " KB";
			} else if (dSize < 1024 * 1024 * 1024) {
				return Math.round(dSize / 1024.0 / 1024.0 *10)/10.0 + " MB";
			} else {
				return Math.round(dSize / 1024.0 / 1024.0 / 1024.0 *10)/10.0 + " GB";
			}
		} catch (Exception e) {
			return size;
		}
	}

	/**
	 * 알파벳이 포함되어있는지 체크
	 * StringUtils.isContainAlpah("ABC"); // true
	 * StringUtils.isContainAlpah("123"); // false
	 * StringUtils.isContainAlpah("1ab"); // true
	 * StringUtils.isContainAlpah("#$^"); // false
	 * @param s
	 * @return
	 */
	public static boolean isContainAlpah(String s) {
		return s != null && s.matches(".[a-zA-Z].");
	}

	/**
	 * 문자열의 바이트 길이를 반환한다.
	 * @param s
	 * @param charsetName
	 * @return
	 */
	public static int getByteLength(String s, String charsetName) {
		if( isEmpty(s)) return 0;
		return toByteArray(s, charsetName).length;
	}

	/**
	 * 문자열을 바이트 배열로 반환 한다.
	 * @param str 문자열
	 * @return
	 */
	public static byte[] toByteArray(String str) {
		return toByteArray(str, DEFAULT_CHAR_SET);
	}

	/**
	 * 문자열을 바이트 배열로 반환 한다.
	 * @param str 문자열
	 * @param charsetName 캐릭터셋명
	 * @return
	 */
	public static byte[] toByteArray(String str, String charsetName) {
		try {
			return str.getBytes(charsetName);
		} catch (UnsupportedEncodingException e) {
		}

		return str.getBytes();
	}

	public static String byteLeftPad(String str, int size, char paddChar) {
		return byteLeftPad(str, size, paddChar, Charset.forName(StringUtils.DEFAULT_CHAR_SET));
	}

	public static String byteLeftPad(String str, int size, char paddChar, Charset charset) {
		byte[] chars = str.getBytes(charset);
		byte[] paddChars = String.valueOf(paddChar).getBytes(charset);

		if(chars.length == size) {
			return str;
		} else if(chars.length > size) {
			return new String(chars, 0, size);
		} else {
			return repeat(paddChar, (size - chars.length)/paddChars.length).concat(str);
		}
	}

	public static String byteRightPad(String str, int size, char paddChar) {
		return byteRightPad(str, size, paddChar, Charset.forName(StringUtils.DEFAULT_CHAR_SET));
	}

	public static String byteRightPad(String str, int size, char paddChar, Charset charset) {
		byte[] chars = str.getBytes(charset);
		byte[] paddChars = String.valueOf(paddChar).getBytes(charset);

		if(chars.length == size) {
			return str;
		} else if(chars.length > size) {
			return new String(chars, chars.length - size, size);
		} else {
			return str.concat(repeat(paddChar, (size - chars.length)/paddChars.length));
		}
	}

	/**
	 * 반각문자를 전각문자로 변환 한다.
	 * @param str 문자열
	 * @return
	 */
	public static String toFullChar(String src) {
		if(src == null) {
			return null;
		}

		StringBuffer sb = new StringBuffer();

		for(char chr : src.toCharArray()) {

			//영문알파벳 또는 특수 문자 인 경우
			if(chr >= 0x21 && chr <= 0x7e) {
				chr += 0xfee0;

			//공백 인 경우
			} else if(chr == 0x20) {
				chr = 0x3000;
			}

			sb.append(chr);
		}

		return sb.toString();
	}
}
