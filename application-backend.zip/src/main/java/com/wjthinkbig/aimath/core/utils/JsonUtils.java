package com.wjthinkbig.aimath.core.utils;

import java.io.IOException;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUtils {

	/**
	 * Object List를 JsonArray String으로 변환
	 * @param list
	 * @return
	 * @throws JsonProcessingException
	 */
	public static <T> String convertListToJsonArray(List<T> list) throws JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(list);
	}

	public static <T> T readValue(String value, Class<T> clazz) throws IOException {
		if( value == null) return null;
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(value, clazz);
	}

	public static String convertObjectToJson(Object object) throws JsonProcessingException {

		if (object == null) {
			return null;
		}

		ObjectMapper mapper = new ObjectMapper();
		return mapper.writeValueAsString(object);
	}
}
