package com.wjthinkbig.aimath.core.support.mybatis.annotation;

import java.beans.Introspector;
import java.util.Set;

import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanNameGenerator;
import org.springframework.core.annotation.AnnotationAttributes;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

/**
 * @FileName : MapperBeanNameGenerator.java
 * @Project : ai-math
 * @Date : 2020. 8. 16. 
 * @작성자 : biscuit
 * @프로그램 설명 : Mapper 클래스에 선언한 어노테이션에 지정한 이름을 빈을 생성한다.
 * @변경이력 :
*/
public class MapperBeanNameGenerator implements BeanNameGenerator {

	@Override
	public String generateBeanName(BeanDefinition definition, BeanDefinitionRegistry registry) {
		// 어노테이션 빈인 경우 value로 지정한 값을 빈 이름으로 한다.
		if (definition instanceof AnnotatedBeanDefinition) {
			String beanName = determineBeanNameFromAnnotation((AnnotatedBeanDefinition) definition);
			if (StringUtils.hasText(beanName)) {
				return beanName;
			}
		}

		// 그 외의 경우는 클래스명 기준으로
		return buildDefaultBeanName(definition);
	}

	// @MyMapper("myBean")과 같은 어노테이션일 경우 "myBean"을 생성할 빈의 이름으로 반환한다.  
	private String determineBeanNameFromAnnotation(AnnotatedBeanDefinition annotatedDef) {
		AnnotationMetadata amd = annotatedDef.getMetadata();
		Set<String> types = amd.getAnnotationTypes();
		String beanName = null;
		for (String type : types) {
			AnnotationAttributes attributes = AnnotationAttributes.fromMap(amd.getAnnotationAttributes(type, false));
			if (attributes != null && attributes.containsKey("value")) {
				Object value = attributes.get("value");
				if (value instanceof String) {
					String strVal = (String) value;
					if (StringUtils.hasLength(strVal)) {
						beanName = strVal;
					}
				}
			}
		}
		return beanName;
	}

	private String buildDefaultBeanName(BeanDefinition definition) {
		String beanClassName = definition.getBeanClassName();
		Assert.state(beanClassName != null, "ID가 정의 되지 않았습니다.");
		String shortClassName = ClassUtils.getShortName(beanClassName);
		return Introspector.decapitalize(shortClassName);
	}
}