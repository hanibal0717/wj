package com.wjthinkbig.aimath;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
@EnableAsync
@SpringBootApplication
public class AimathApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AimathApiApplication.class, args);
	}

}
