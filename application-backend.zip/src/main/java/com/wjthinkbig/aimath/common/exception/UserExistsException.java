package com.wjthinkbig.aimath.common.exception;

@Deprecated
public class UserExistsException extends RuntimeException {
	
	public UserExistsException(String msg, Throwable t) {
		super(msg, t);
	}
	
	public UserExistsException(String msg) {
		super(msg);
	}
	
	public UserExistsException() {
		super();
	}
}