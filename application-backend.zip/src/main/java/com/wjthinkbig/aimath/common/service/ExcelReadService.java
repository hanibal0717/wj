package com.wjthinkbig.aimath.common.service;

import org.springframework.web.multipart.MultipartFile;

/**
  * @Date : 2020. 9. 10.
  * @프로그램 설명 : 엑셀파일을 읽어서 처리하는 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 10.     19001861            최초작성
  * </pre>
  */
public interface ExcelReadService {
	
	/**
	  * @Method 설명 : 엑셀파일을 읽어서 조건에 맞는 문항을 만든 후 임시 DB에 저장
	  * @param mFile
	  * @throws Exception
	  */
	public void createExcelQuestion(MultipartFile mFile) throws Exception;
	
}
