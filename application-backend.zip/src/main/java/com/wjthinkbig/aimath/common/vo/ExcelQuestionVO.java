package com.wjthinkbig.aimath.common.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 11.
  * @프로그램 설명 : 무한출제 문항등록 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="무한출제 문항등록 VO")
public class ExcelQuestionVO extends BaseVO {
	
	@ApiModelProperty(value="자동문항코드")
	@FieldName("자동문항코드")
	private String autoQstCd; 			/* 자동문항코드 */
	
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String sbthmaCd; 			/* 소주제코드 */
	
	@ApiModelProperty(value="문항내용")
	@FieldName("문항내용")
	private String qstCn;	 			/* 문항내용 */
	
	@ApiModelProperty(value="문항정답")
	@FieldName("문항정답")
	private String qstCransr;	 		/* 문항정답 */
	
	@ApiModelProperty(value="선행소주제코드")
	@FieldName("선행소주제코드")
	private String preSbthmaCd;	 		/* 선행소주제코드 */
	
	@ApiModelProperty(value="지문내용")
	@FieldName("지문내용")
	private String textCn;	 			/* 지문내용 */
	
	@ApiModelProperty(value="영문지문내용")
	@FieldName("영문지문내용")
	private String engTextCn;	 		/* 영문지문내용 */
	
	@ApiModelProperty(value="필수문항여부")
	@FieldName("필수문항여부")
	private String esntlQstYn; 			/* 필수문항여부 */
	
	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn;	 			/* 사용여부 */
	
}
