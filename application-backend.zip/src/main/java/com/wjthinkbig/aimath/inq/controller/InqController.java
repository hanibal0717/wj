package com.wjthinkbig.aimath.inq.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.inq.service.InqService;
import com.wjthinkbig.aimath.inq.vo.InqRplVO;
import com.wjthinkbig.aimath.inq.vo.InqSearchVO;
import com.wjthinkbig.aimath.inq.vo.InqVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 22.
  * @프로그램 설명 : 1:1문의 관리
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 22.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="1:1문의 정보")
@RestController
public class InqController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 1:1문의 관리 서비스
	 */
	@Resource(name = "inqService")
	private InqService inqService;
	
	/**
	  * @Method 설명 : 1:1문의 전체 리스트 정보 조회
	  * @param inqSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="1:1문의 전체 리스트 정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/inquiry")
	public SingleResult<Map<String, Object>> selectInqList(@ModelAttribute InqSearchVO inqSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<InqVO> inqList = inqService.selectInqList(inqSearch);
		
		resultMap.put("inqList", inqList);
		resultMap.put("totalCnt", inqService.selectInqListCnt(inqSearch));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 전체 1:1문의 리스트 수 정보 조회
	  * @param inqSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="전체 1:1문의 리스트 수 정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/inquiry/cnt")
	public SingleResult<Integer> selectInqCnt(@ModelAttribute InqSearchVO inqSearch) throws Exception {
		int cnt = inqService.selectInqCnt(inqSearch);
		return responseService.getSingleResult(cnt);
	}
	
	/**
	  * @Method 설명 : 1:1문의 단일 정보 조회
	  * @param inqSearch
	  * @param mbrInqSno
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="1:1문의 단일 정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/inquiry/{inquiry}")
	public SingleResult<InqVO> selectInqById(@ModelAttribute InqSearchVO inqSearch, @ApiParam("1:1문의 고유키") @PathVariable(name="inquiry", required=true) int mbrInqSno) throws Exception {
		inqSearch.setMbrInqSno(mbrInqSno);
		InqVO inq = inqService.selectInqById(inqSearch);
		
		return responseService.getSingleResult(inq);
	}
	
	/**
	  * @Method 설명 : 1:1문의 질문 등록
	  * @param inq
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="1:1문의 질문 등록")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/inquiry")
	public CommonResult insertInq(@ApiParam("등록할 정보를 담은 1:1문의 객체") @RequestBody(required=true) InqVO inq) throws Exception {
		inqService.insertInq(inq);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 1:1문의 질문 변경
	  * @param inq
	  * @param mbrInqSno
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="1:1문의 질문 변경")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PutMapping("/api/inquiry/{inquiry}")
	public CommonResult updateInq(@ApiParam("수정할 정보를 담은 1:1문의 객체") @RequestBody(required=true) InqVO inq, @ApiParam("변경할 1:1문의 고유키") @PathVariable(name="inquiry", required=true) int mbrInqSno) throws Exception {
		inq.setMbrInqSno(mbrInqSno);
		inqService.updateInq(inq);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 1:1문의 질문 삭제
	  * @param inq
	  * @param mbrInqSno
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="1:1문의 질문 삭제")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@DeleteMapping("/api/inquiry/{inquiry}")
	public CommonResult deleteInq(@ApiParam("삭제할 정보를 담은 1:1문의 객체") @RequestBody(required=true) InqVO inq, @ApiParam("삭제할 1:1문의 고유키") @PathVariable(name="inquiry", required=true) int mbrInqSno) throws Exception {
		inq.setMbrInqSno(mbrInqSno);
		inqService.deleteInq(inq);
		return responseService.getResult(true);
	}
	
	@ApiOperation(value="1:1문의 답변 등록/수정")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/inquiry/{inquiry}/reply")
	public CommonResult saveInqRpl(@ApiParam("등록할 정보를 담은 1:1문의 답변 객체") @RequestBody(required=true) InqRplVO inqRpl, @ApiParam("삭제할 1:1문의 고유키") @PathVariable(name="inquiry", required=true) int mbrInqSno) throws Exception {
		inqRpl.setMbrInqSno(mbrInqSno);
		inqService.saveInqRpl(inqRpl);
		return responseService.getResult(true);
	}
}
