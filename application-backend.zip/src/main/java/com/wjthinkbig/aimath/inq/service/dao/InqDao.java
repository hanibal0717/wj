package com.wjthinkbig.aimath.inq.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.inq.vo.InqRplVO;
import com.wjthinkbig.aimath.inq.vo.InqSearchVO;
import com.wjthinkbig.aimath.inq.vo.InqVO;

/**
  * @Date : 2020. 9. 22.
  * @프로그램 설명 : 1:1문의 관리
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 22.     19001861            최초작성
  * </pre>
  */
@Mapper("inqDao")
public interface InqDao {
	
	/**
	  * @Method 설명 : 1:1문의 리스트 조회
	  * @param inqSearch
	  * @return
	  */
	List<InqVO> selectInqList(InqSearchVO inqSearch);
	
	/**
	  * @Method 설명 : 1:1문의 리스트 수 조회
	  * @param inqSearch
	  * @return
	  */
	int selectInqCnt(InqSearchVO inqSearch);
	
	/**
	  * @Method 설명 : 1:1문의 리스트 수 조회 (검색 조건 적용)
	  * @param inqSearch
	  * @return
	  */
	int selectInqListCnt(InqSearchVO inqSearch);
	
	/**
	  * @Method 설명 : 1:1문의 단일 정보 조회
	  * @param inqSearch
	  * @return
	  */
	InqVO selectInqById(InqSearchVO inqSearch);
	
	/**
	  * @Method 설명 : 1:1문의 질문 신규 등록
	  * @param inq
	  */
	void insertInq(InqVO inq);
	
	/**
	  * @Method 설명 : 1:1문의 답변 신규 등록
	  * @param inqRpl
	  */
	void insertInqRpl(InqRplVO inqRpl);
	
	/**
	  * @Method 설명 : 1:1문의 질문 변경
	  * @param inq
	  */
	void updateInq(InqVO inq);
	
	/**
	  * @Method 설명 : 1:1문의 답변상태코드 변경
	  * @param inq
	  */
	void updateInqRplStsCd(InqVO inq);
	
	/**
	  * @Method 설명 : 1:1문의 답변 변경
	  * @param inqRpl
	  */
	void updateInqRpl(InqRplVO inqRpl);
	
	/**
	  * @Method 설명 : 1:1문의 삭제
	  * @param inq
	  * @return
	  */
	int deleteInq(InqVO inq);
}
