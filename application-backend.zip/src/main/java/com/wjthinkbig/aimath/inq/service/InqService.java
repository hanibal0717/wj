package com.wjthinkbig.aimath.inq.service;

import java.util.List;

import com.wjthinkbig.aimath.inq.vo.InqRplVO;
import com.wjthinkbig.aimath.inq.vo.InqSearchVO;
import com.wjthinkbig.aimath.inq.vo.InqVO;

/**
  * @Date : 2020. 9. 22.
  * @프로그램 설명 : 1:1문의 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 22.     19001861            최초작성
  * </pre>
  */
public interface InqService {
	
	/**
	  * @Method 설명 : 1:1문의 리스트 조회
	  * @param inqSearch
	  * @return
	  * @throws Exception
	  */
	public List<InqVO> selectInqList(InqSearchVO inqSearch) throws Exception;
	
	/**
	  * @Method 설명 : 1:1문의 리스트 수 조회
	  * @param inqSearch
	  * @return
	  * @throws Exception
	  */
	public int selectInqCnt(InqSearchVO inqSearch) throws Exception;
	
	/**
	  * @Method 설명 : 1:1문의 리스트 수 조회 (검색 조건 적용)
	  * @param inqSearch
	  * @return
	  * @throws Exception
	  */
	public int selectInqListCnt(InqSearchVO inqSearch) throws Exception;
	
	/**
	  * @Method 설명 : 1:1문의 단일 정보 조회
	  * @param inqSearch
	  * @return
	  * @throws Exception
	  */
	public InqVO selectInqById(InqSearchVO inqSearch) throws Exception;
	
	/**
	  * @Method 설명 : 1:1문의 질문 신규 등록
	  * @param inq
	  * @throws Exception
	  */
	public void insertInq(InqVO inq) throws Exception;
	
	/**
	  * @Method 설명 : 1:1문의 질문 변경
	  * @param inq
	  * @throws Exception
	  */
	public void updateInq(InqVO inq) throws Exception;
	
	/**
	  * @Method 설명 : 1:1문의 답변 등록/수정
	  * @param inqRpl
	  * @throws Exception
	  */
	public void saveInqRpl(InqRplVO inqRpl) throws Exception;
	
	/**
	  * @Method 설명 : 1:1문의 삭제
	  * @param inq
	  * @return
	  * @throws Exception
	  */
	public int deleteInq(InqVO inq) throws Exception;
	
}
