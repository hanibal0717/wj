package com.wjthinkbig.aimath.sample.service.impl;

import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.service.dao.MbrDao;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.sample.service.SampleService;
import com.wjthinkbig.aimath.sample.service.dao.SampleDao;
import com.wjthinkbig.aimath.stg.service.dao.StgDao;
import com.wjthinkbig.aimath.stg.vo.StgVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 소주제(스테이지) 관리서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Slf4j
@Service("sampleService")
public class SampleServiceImpl extends BaseServiceImpl implements SampleService {

	/**
	 * 샘플서비스 Dao
	 */
	@Resource(name = "sampleDao")
	private SampleDao sampleDao;
	
	/**
	 * 스테이지 관리 Dao
	 */
	@Resource(name = "stgDao")
	private StgDao stgDao;
	
	/**
	 * 회원서비스 Dao
	 */
	@Resource(name = "")
	private MbrDao mbrDao;
	
	@Override
	public void stgInfoBatchProcess(@Valid SaveVO<StgVO> stgSaveVO) throws Exception {
		
		// 등록 및 수정시 사용자ID를 지정 (추후 로그인아이디로 변경)
		//stgSaveVO.setUserId("SYSTEM");
		
		List<StgVO> insertList = stgSaveVO.getInsertList();
		List<StgVO> updateList = stgSaveVO.getUpdateList();
		List<StgVO> deleteList = stgSaveVO.getDeleteList();
		
		// 등록대상 스테이지에 대한 처리
		int insertCnt = 0;
		for(StgVO stg : insertList) {
			log.info("등록할 스테이지 정보 : {}", stg.toString());
			
			// 이미 존재하는지 확인
			StgVO oldStgVO;
			try {
				oldStgVO = stgDao.selectStgById(stg.getStgCd());
				if(oldStgVO != null) {
					throw this.processException("S001001");
				}				
				
				// 해당 스테이지 신규 등록
				stgDao.insertStg(stg);
				insertCnt++;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			log.info("등록 건수 : {}건", insertCnt);
		}
				
		// 변경대상 스테이지에 대한 처리
		int updateCnt = 0;
		for(StgVO stg : updateList) {
			log.info("변경할 스테이지 정보 : {}", stg.toString());
			
			try {
				stgDao.updateStg(stg);
				updateCnt++;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			log.info("변경 건수 : {}건", updateCnt);	
		};
		
		// 삭제할 스테이지에 대한 처리
		int deleteCnt = 0;
		for(StgVO stg : deleteList) {	
			log.info("삭제대상 스테이지 정보 : {}", stg.toString());
			
			try {
				stgDao.deleteStg(stg.getStgCd());
				deleteCnt++;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			log.info("삭제 건수 : {}", deleteCnt);
		};
	}

	/* 
	 * @see com.wjthinkbig.aimath.sample.service.SampleService#learnersUpdate(com.wjthinkbig.aimath.core.web.bind.SaveVO)
	 */
	@Override
	public void learnersUpdate(@Valid SaveVO<MbrLrnVO> mbrLrnSaveVO) {
		
		List<MbrLrnVO> insertList = mbrLrnSaveVO.getInsertList();
		List<MbrLrnVO> updateList = mbrLrnSaveVO.getUpdateList();
		List<MbrLrnVO> deleteList = mbrLrnSaveVO.getDeleteList();
		
		// 등록대상 스테이지에 대한 처리
		int insertCnt = 0;
		for(MbrLrnVO vo : insertList) {
			log.info("등록할 학습자 정보 : {}", vo.toString());
			
			// 이미 존재하는지 확인
			MbrLrnVO oldVO;
			try {
				oldVO = mbrDao.selectMbrLrnById(vo.getMbrId());
				if(oldVO != null) {
					throw this.processException("S001001");
				}				
				
				// 해당 스테이지 신규 등록
				mbrDao.insertMbrLrn(vo);
				insertCnt++;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
			log.info("등록 건수 : {}건", insertCnt);
		}
				
		// 변경대상 스테이지에 대한 처리
		int updateCnt = 0;
		for(MbrLrnVO vo : updateList) {
			log.info("변경할 학습자 정보 : {}", vo.toString());
			
			try {
				mbrDao.updateMbrLrn(vo);
				updateCnt++;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			log.info("변경 건수 : {}건", updateCnt);	
		};
		
		// 삭제할 스테이지에 대한 처리
		int deleteCnt = 0;
		for(MbrLrnVO vo : deleteList) {	
			log.info("삭제대상 학습자 정보 : {}", vo.toString());
			
			try {
				mbrDao.deleteMbrLrn(vo);
				deleteCnt++;
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			log.info("삭제 건수 : {}", deleteCnt);
		};
		
	}
}