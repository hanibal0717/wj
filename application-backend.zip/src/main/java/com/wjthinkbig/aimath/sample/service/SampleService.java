package com.wjthinkbig.aimath.sample.service;

import javax.validation.Valid;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;

/**
  * @Date : 2020. 8. 26. 
  * @프로그램 설명 : 샘플 예제 제공을 위한 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 26.     Lee Seung Hyuk            최초작성
  * </pre>
 */
public interface SampleService {

	/**
	  * @Method 설명 : StgVO 빈에 대해 일괄 업무처리(등록/수정/삭제) 및 검증을 수행한다.
	  * @param stgSaveVO 일괄 처리할 VO 리스트를 담고 있는 객체
	  */
	public void stgInfoBatchProcess(@Valid SaveVO<StgVO> stgSaveVO) throws Exception;

	/**
	  * @Method 설명 : MbrLrnVO 빈에 대해 일괄 업무처리(등록/수정/삭제) 및 검증을 수행한다.
	  * @param mbrLrnSaveVO
	  */
	public void learnersUpdate(@Valid SaveVO<MbrLrnVO> mbrLrnSaveVO);
}