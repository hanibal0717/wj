package com.wjthinkbig.aimath.security.admin;

import java.util.Arrays;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.acnt.service.dao.AcntDao;
import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.acnt.vo.AcntVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 4. 
  * @프로그램 설명 : 관리자 인증을 위한 UserDetailsService 구현체  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 4.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Slf4j
@Service("adminDetailsService")
public class CustomAdminDetailsService implements UserDetailsService {
	
	/**
	 * 관리자계정서비스 Dao
	 */
	@Resource(name = "acntDao")
	private AcntDao acntDao;
	
	/**
	 * 메시지 소스
	 */
	@Autowired
	private MessageSource messageSource;
	
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		AcntVO userVO = acntDao.selectAcntById(username);
		if(userVO == null) {
			throw new UsernameNotFoundException(messageSource.getMessage("S001005", null, LocaleContextHolder.getLocale()));
		} else {
			// DB 권한테이블이 있다면 해당 테이블에서 이 회원의 권한을 조회하여 세팅, 현재는 기본(ROLE_USER) 외에 추가로 회원분류코드값을 ROLE로 추가부여
			userVO.setRoles(Arrays.asList("ROLE_ADMIN", "ROLE_" + userVO.getAuthCd()));
		}

		log.debug("검색된 관리자객체 (loadUser) 정보 : {}", userVO);
		return new AdminAccount(userVO);
	}
}