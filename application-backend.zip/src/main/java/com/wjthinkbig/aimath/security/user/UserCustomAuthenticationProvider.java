/**
 * 
 */
package com.wjthinkbig.aimath.security.user;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.dao.AbstractUserDetailsAuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.wjthinkbig.aimath.security.JwtUtils;

/**
  * @Date : 2020. 9. 10. 
  * @프로그램 설명 : 회원로그인용 인증 프로바이더
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 10.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Component("userCustomAuthenticationProvider")
public class UserCustomAuthenticationProvider extends AbstractUserDetailsAuthenticationProvider {
	
	/**
	 * 단방향 암호화 처리기
	 */
	@Autowired
	@Qualifier("passwordEncoder")
	private PasswordEncoder passwordEncoder;
	
	/**
	 * 사용자 조회를 위한 UserDetailsService 구현체
	 */
	@Resource(name = "userDetailsService")
	private UserDetailsService userDetailsService;
	
	/**
	 * JWT Utility
	 */
	@Resource(name = "jwtUtils")
	private JwtUtils jwtUtils;
		
	/**
	  * @Method 설명 : DB에서 가져온 사용자의 비밀번호를 검증한다.
	  * @param userDetails retrieveUser가 반환하는 사용자 UserDetails 객체
	  * @param authentication 인증요청 토큰
	  * @throws AuthenticationException
	 */
	@Override
	protected void additionalAuthenticationChecks(UserDetails userDetails, UsernamePasswordAuthenticationToken authentication) throws AuthenticationException {		
		if (authentication.getCredentials() == null) {
			throw new BadCredentialsException(messages.getMessage("AbstractUserDetailsAuthenticationProvider.badCredentials", "Bad credentials"));
		}

		String presentedPassword = authentication.getCredentials().toString();

		if (!passwordEncoder.matches(presentedPassword, userDetails.getPassword())) {
			throw new BadCredentialsException(messages.getMessage(
					"AbstractUserDetailsAuthenticationProvider.badCredentials",
					"Bad credentials"));
		}
	}

	@Override
	protected UserDetails retrieveUser(String username, UsernamePasswordAuthenticationToken authentication)
			throws AuthenticationException {
		return userDetailsService.loadUserByUsername(username);
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return (UserAuthenticationToken.class.isAssignableFrom(authentication));
	}
	
	/**
     * @Method 설명 : JWT 토큰으로 인증정보를 가져온다.
     * @param token JWT 토큰
     * @return UserDetails 객체
    */
	public Authentication getAuthentication(String token) {
		UserDetails userDetails = userDetailsService.loadUserByUsername(jwtUtils.getUsername(token));
		return new UserAuthenticationToken(userDetails, "", userDetails.getAuthorities());
    }
}