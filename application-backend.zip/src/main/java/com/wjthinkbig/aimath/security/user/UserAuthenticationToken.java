/**
 * 
 */
package com.wjthinkbig.aimath.security.user;

import java.util.Collection;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;

/**
  * @Date : 2020. 9. 11. 
  * @프로그램 설명 : 회원용 인증토큰
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class UserAuthenticationToken extends UsernamePasswordAuthenticationToken {

	private static final long serialVersionUID = 436793318460549302L;

	/**
	 * @param principal
	 * @param credentials
	 */
	public UserAuthenticationToken(Object principal, Object credentials) {
		super(principal, credentials);
	}

	/**
	 * @param principal
	 * @param credentials
	 * @param authorities
	 */
	public UserAuthenticationToken(Object principal, Object credentials, Collection<? extends GrantedAuthority> authorities) {
		super(principal, credentials, authorities);
	}	
}