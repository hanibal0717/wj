package com.wjthinkbig.aimath.blbr.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.blbr.service.BlbrService;
import com.wjthinkbig.aimath.blbr.vo.BlbrSearchVO;
import com.wjthinkbig.aimath.blbr.vo.BlbrVO;
import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 23.
  * @프로그램 설명 : 게시판 정보 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 24.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="게시판 정보")
@RestController
public class BlbrController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 게시판 관리 서비스
	 */
	@Resource(name = "blbrService")
	private BlbrService blbrService;
	
	/**
	  * @Method 설명 : 전체 게시물 리스트 정보 조회
	  * @param blbrSearch
	  * @param blbr_sno
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="전체 게시물 리스트 정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/board/{board}")
	public SingleResult<Map<String, Object>> selectBlbrList(@ModelAttribute BlbrSearchVO blbrSearch, @ApiParam(value = "게시판 일련번호") @PathVariable(name="board",required=true) int blbr_sno) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		
		blbrSearch.setBlbrSno(blbr_sno);
		List<BlbrVO> blbrList = blbrService.selectBlbrList(blbrSearch);
		
		resultMap.put("blbrList", blbrList);
		resultMap.put("totalCnt", blbrService.selectBlbrListCnt(blbrSearch));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 게시물 단일 정보 조회
	  * @param blbrSearch
	  * @param blbr_sno
	  * @param bltn_seq
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="게시물 단일 정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/board/{board}/{bltn}")
	public SingleResult<BlbrVO> selectBlbrById(@ModelAttribute BlbrSearchVO blbrSearch
			, @ApiParam(value = "게시판 일련번호") @PathVariable(name="board",required=true) int blbr_sno
			, @ApiParam(value = "게시물 일련번호") @PathVariable(name="bltn",required=true) int bltn_seq) throws Exception {
		blbrSearch.setBlbrSno(blbr_sno);
		blbrSearch.setBltnSeq(bltn_seq);
		BlbrVO blbr = blbrService.selectBlbrById(blbrSearch);
		return responseService.getSingleResult(blbr);
	}
	
	/**
	  * @Method 설명 : 게시물 신규 등록
	  * @param blbr
	  * @param blbr_sno
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="게시물 신규 등록")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/board/{board}")
	public CommonResult insertBlbr(@RequestBody(required=true) BlbrVO blbr, @ApiParam(value = "게시판 일련번호") @PathVariable(name="board",required=true) int blbr_sno) throws Exception {
		blbr.setBlbrSno(blbr_sno);
		blbrService.insertBlbr(blbr);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 게시물 수정
	  * @param blbr
	  * @param blbr_sno
	  * @param bltn_seq
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="게시물 수정")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PutMapping("/api/board/{board}/{bltn}")
	public CommonResult updateBlbr(@RequestBody(required=true) BlbrVO blbr
			, @ApiParam(value = "게시판 일련번호") @PathVariable(name="board",required=true) int blbr_sno
			, @ApiParam(value = "게시물 일련번호") @PathVariable(name="bltn",required=true) int bltn_seq) throws Exception {
		blbr.setBlbrSno(blbr_sno);
		blbr.setBltnSeq(bltn_seq);
		blbrService.updateBlbr(blbr);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 게시물 삭제
	  * @param blbr_sno
	  * @param bltn_seq
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="게시물 삭제")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@DeleteMapping("/api/board/{board}/{bltn}")	
	public CommonResult deleteBlbr(@ApiParam(value = "게시판 일련번호") @PathVariable(name="board",required=true) int blbr_sno
			, @ApiParam(value = "게시물 일련번호") @PathVariable(name="bltn",required=true) int bltn_seq) throws Exception {
		BlbrVO blbr = new BlbrVO();
		blbr.setBlbrSno(blbr_sno);
		blbr.setBltnSeq(bltn_seq);
		
		int rows = blbrService.deleteBlbr(blbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
}
