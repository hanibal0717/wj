package com.wjthinkbig.aimath.qst.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.qst.service.QstService;
import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.qst.vo.QstVO;
import com.wjthinkbig.aimath.qst.vo.QstWrtnMngtVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 문항관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Slf4j
@Api(description="커리큘럼 문항정보")
@RestController
public class QstController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 문항관리 서비스
	 */
	@Resource(name = "qstService")
	private QstService qstService;
	
	/**
	  * @Method 설명 : 전체 커리큘럼 문항정보 조회
	  * @param qstSearch 검색할 조건정보를 담은 VO
	  * @return 검색된 문항리스트
	  * @throws Exception
	 */
	@ApiOperation(value="전체 커리큘럼 문항정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/question")	
	public SingleResult<Map<String, Object>> selectQstList(@ModelAttribute QstSearchVO qstSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<>();
		List<QstVO> qstList = null;
		int totalCnt = 0;
		
		//소주제 코드가 없을 경우 
		if( StringUtils.isNotEmpty(qstSearch.getStgCd()) ) {
			qstList = qstService.selectQstList(qstSearch);
			totalCnt = qstService.selectQstListCount(qstSearch);
		} else {
			//소주제 코드가 없을 경우 null이 아닌 빈 배열을 내려준다.
			qstList = new ArrayList<QstVO>();
		}
		
		resultMap.put("qstList", qstList);
		resultMap.put("totalCnt", totalCnt);
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 특정 코드의 문항정보 조회
	  * @param qst_cd 문항 식별코드
	  * @return 검색된 문항정보 VO
	  * @throws Exception
	 */
	@ApiOperation(value="특정 코드의 문항정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/question/{question}")
	public SingleResult<QstVO> selectQstById(@ModelAttribute QstSearchVO qstSearch, @ApiParam(value = "문항 코드") @PathVariable(name="question",required=true) String qst_cd) throws Exception {
		qstSearch.setQstCd(qst_cd);
		QstVO qst = qstService.selectQstById(qstSearch);
		if(qst == null) {
			throw this.processException("S001003", qst_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(qst);
	}
	
	/**
	  * @Method 설명 : 문항코드 중복체크
	  * @param qst_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="문항코드 중복체크")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/question/check/{question}")
	public SingleResult<String> selectQstCodeCheck(@ApiParam(value = "문항 코드") @PathVariable(name="question",required=true) String qst_cd) throws Exception {
		String result = "N";
		
		if( qstService.selectQstCdDplctCeck(qst_cd) > 0 ){
			result = "Y";
		}
		
		return responseService.getSingleResult(result);
	}
	
	/**
	  * @Method 설명 : 신규 문항정보를 등록한다.
	  * @param qst 등록할 문항정보 VO
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="신규 문항정보 등록")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/question")
	public CommonResult insertQst(@RequestBody(required=true) QstVO qst) throws Exception {
		//문항코드 중복체크
		if( qstService.selectQstCdDplctCeck(qst.getQstCd()) <= 0 ) {
			qstService.insertQst(qst);
			return responseService.getResult(true);
		} else {
			throw this.processException("S001001"); // 이미 존재하는 데이터입니다.
		}
	}
	
	/**
	  * @Method 설명 : 커리큘럼 문항정보를 변경한다.
	  * @param qst 변경할 정보를 담은 VO
	  * @param qst_cd 변경하고자 하는 문항정보의 식별코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "커리큘럼 문항정보 변경")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PutMapping("/api/question/{question}")
	public CommonResult updateQst(@ApiParam("변경할 정보를 담은 커리큘럼 문항 객체") @RequestBody(required=true) QstVO qst, @ApiParam("변경할 컬리큘럼 문항의 고유키") @PathVariable(name="question", required=true) String qst_cd) throws Exception {
		qst.setQstCd(qst_cd);
		qstService.updateQst(qst);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 문항저작정보를 변경한다.
	  * @param qstWrtnMngt 변경할 문항저작정보 VO
	  * @param qst_cd 변경할 문항식별코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "커리큘럼 문항저작정보 변경")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PutMapping("/api/question/{question}/status")
	public CommonResult updateQstWrtnMngt(@ApiParam("변경할 정보를 담은 커리큘럼 문항저작정보 객체") @RequestBody(required=true) QstWrtnMngtVO qstWrtnMngt, @ApiParam("변경할 컬리큘럼 문항의 고유키") @PathVariable(name="question", required=true) String qst_cd) throws Exception {		
		qstWrtnMngt.setQstCd(qst_cd);
		qstService.updateQstWrtnMngt(qstWrtnMngt);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 문항저작정보를 변경한다.
	  * @param qstWrtnMngtList 변경할 문항식별코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "커리큘럼 문항저작정보 다중 변경")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PutMapping("/api/question/status")
	public CommonResult updateQstWritingList(@ApiParam("변경할 정보를 담은 커리큘럼 문항저작정보 객체") @RequestBody(required=true) SaveVO<QstWrtnMngtVO> saveQstWrtnMngt) throws Exception {
		qstService.updateQstWrtnMngtList(saveQstWrtnMngt);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 문항의 소주제 코드를 다중 변경한다.
	  * @param saveQst
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value = "커리큘럼 문항의 소주제코드 다중 변경")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PutMapping("/api/question/stage")
	public CommonResult updateStgCdList(@ApiParam("변경할 정보를 담은 커리큘럼 문항정보 객체") @RequestBody(required=true) SaveVO<QstVO> saveQst) throws Exception {
		int rows = qstService.updateStgCdList(saveQst);
		
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
}