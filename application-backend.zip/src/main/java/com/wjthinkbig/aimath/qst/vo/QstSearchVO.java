package com.wjthinkbig.aimath.qst.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @FileName : QstSearchVO.java
 * @Project : application-backend
 * @Date : 2020. 8. 14. 
 * @작성자 : 19001861
 * @프로그램 설명 : 커리큘럼 문항 Search VO
 * @변경이력 :
*/
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 문항 검색 정보")
public class QstSearchVO {
	
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;						/* 문항코드 */
	
	@ApiModelProperty(value="스테이지코드")
	@FieldName("스테이지코드")
	private String stgCd;						/* 스테이지코드 */
	
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;	 					/* 언어코드 */
	
	@ApiModelProperty(value="검색타입")
	@FieldName("검색타입")
	private String srchTy;						/* 검색타입 */
	
	@ApiModelProperty(value="검색어")
	@FieldName("검색어")
	private String srchTxt;						/* 검색어 */
	
	@ApiModelProperty(value="문항저작상태코드")
	@FieldName("문항저작상태코드")
	private String wrtnStsCd;					/* 문항저작상태코드 */
	
	@ApiModelProperty(value="현재 페이지")
	@FieldName("현재 페이지")
	private int currentPage;					/* 현재 페이지 */
	
	@ApiModelProperty(value="페이지에 노출될 리스트 수")
	@FieldName("페이지에 노출될 리스트 수")
	private int rowCnt;							/* 페이지에 노출될 리스트 수 */
}
