package com.wjthinkbig.aimath.qst.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 17.
  * @프로그램 설명 : 커리큘럼 문항 오답 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 17.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 문항 오답 검색 정보")
public class QstWransrCrseSearchVO {
	
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;						/* 문항코드 */
	
	@NotBlank
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;	 					/* 언어코드 */
	
	@ApiModelProperty(value="오답유형코드")
	@FieldName("오답유형코드")
	private String wransrTyCd;					/* 오답유형코드 */
	
}
