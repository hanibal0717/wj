package com.wjthinkbig.aimath.terms.service;

import java.util.List;

import com.wjthinkbig.aimath.terms.vo.TermsHstSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsHstVO;
import com.wjthinkbig.aimath.terms.vo.TermsSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsVO;

/**
  * @Date : 2020. 9. 24.
  * @프로그램 설명 : 이용약관 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 24.     19001861            최초작성
  * </pre>
  */
public interface TermsService {
	
	/**
	  * @Method 설명 : 이용약관 설정 전체 리스트 조회
	  * @param termsSearch
	  * @return
	  * @throws Exception
	  */
	public List<TermsVO> selectTermsList(TermsSearchVO termsSearch) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 설정 전체 리스트 수 조회 (검색 조건 적용)
	  * @param termsSearch
	  * @return
	  * @throws Exception
	  */
	public int selectTermsListCnt(TermsSearchVO termsSearch) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 설정 단일 조회
	  * @param terms_id
	  * @return
	  * @throws Exception
	  */
	public TermsVO selectTermsById(String terms_id) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 설정 등록
	  * @param terms
	  * @throws Exception
	  */
	public void insertTerms(TermsVO terms) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 설정 수정
	  * @param terms
	  * @throws Exception
	  */
	public void updateTerms(TermsVO terms) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 설정 삭제
	  * @param terms_id
	  * @return
	  * @throws Exception
	  */
	public int deleteTerms(String terms_id) throws Exception;
	
	/*******************************************
	 * 이용약관 이력
	 *******************************************/
	
	/**
	  * @Method 설명 : 이용약관 이력 전체 리스트 조회
	  * @param termsHstSearch
	  * @return
	  * @throws Exception
	  */
	public List<TermsHstVO> selectTermsHstList(TermsHstSearchVO termsHstSearch) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 이력 전체 리스트 수 조회 (검색 조건 적용)
	  * @param termsHstSearch
	  * @return
	  * @throws Exception
	  */
	public int selectTermsHstListCnt(TermsHstSearchVO termsHstSearch) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 이력 단일 조회
	  * @param termsHstSearch
	  * @return
	  * @throws Exception
	  */
	public TermsHstVO selectTermsHstById(TermsHstSearchVO termsHstSearch) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 이력 등록
	  * @param termsHst
	  * @throws Exception
	  */
	public void insertTermsHst(TermsHstVO termsHst) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 이력 수정
	  * @param termsHst
	  * @throws Exception
	  */
	public void updateTermsHst(TermsHstVO termsHst) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 이력 삭제
	  * @param termsHst
	  * @return
	  * @throws Exception
	  */
	public int deleteTermsHst(TermsHstVO termsHst) throws Exception;
	
	/******************************************************************
	 * 사용자 
	 ******************************************************************/
	
	/**
	  * @Method 설명 : 사용자 회원 가입 시 이용약관 리스트
	  * @param termsHstSearch
	  * @return
	  * @throws Exception
	  */
	public List<TermsHstVO> selectTermsChannelsList(TermsHstSearchVO termsHstSearch) throws Exception;
	
	/**
	  * @Method 설명 : 이용약관 이력 약관ID별 리스트 조회
	  * @param termsHstSearch
	  * @return
	  * @throws Exception
	  */
	public List<TermsHstVO> selectTermsHstListByTermsId(TermsHstSearchVO termsHstSearch) throws Exception;
}
