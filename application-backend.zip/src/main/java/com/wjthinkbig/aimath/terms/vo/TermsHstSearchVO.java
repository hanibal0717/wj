package com.wjthinkbig.aimath.terms.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 24.
  * @프로그램 설명 : 이용약관 이력 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 24.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="이용약관 이력 검색 정보")
public class TermsHstSearchVO {
	@ApiModelProperty(value="페이징 처리 여부")
	
	@FieldName("페이징 처리 여부")
	private String pagingYn;					/* 페이징 처리 여부 */
	
	@ApiModelProperty(value="현재 페이지")
	@FieldName("현재 페이지")
	private int currentPage;					/* 현재 페이지 */
	
	@ApiModelProperty(value="페이지에 노출될 리스트 수")
	@FieldName("페이지에 노출될 리스트 수")
	private int rowCnt;							/* 페이지에 노출될 리스트 수 */
	
	@ApiModelProperty(value="이용약관ID")
	@FieldName("이용약관ID")
	private String termsId; 					/* 이용약관ID */
	
	@ApiModelProperty(value="약관이력일련번호")
	@FieldName("약관이력일련번호")
	private int termsHstSno; 					/* 약관이력일련번호 */
	
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;		 				/* 언어코드 */
	
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;	 					/* 채널코드 */
	
}
