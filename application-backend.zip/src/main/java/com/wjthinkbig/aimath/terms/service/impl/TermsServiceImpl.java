package com.wjthinkbig.aimath.terms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.terms.service.TermsService;
import com.wjthinkbig.aimath.terms.service.dao.TermsDao;
import com.wjthinkbig.aimath.terms.vo.TermsHstSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsHstVO;
import com.wjthinkbig.aimath.terms.vo.TermsMetaVO;
import com.wjthinkbig.aimath.terms.vo.TermsSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service("termsService")
public class TermsServiceImpl extends BaseServiceImpl implements TermsService {
	
	/**
	 * 이용약관 Dao
	 */
	@Resource(name = "termsDao")
	private TermsDao termsDao;
	
	@Override
	public List<TermsVO> selectTermsList(TermsSearchVO termsSearch) throws Exception {
		return termsDao.selectTermsList(termsSearch);
	}

	@Override
	public int selectTermsListCnt(TermsSearchVO termsSearch) throws Exception {
		return termsDao.selectTermsListCnt(termsSearch);
	}
	
	@Override
	public TermsVO selectTermsById(String terms_id) throws Exception {
		return termsDao.selectTermsById(terms_id);
	}

	@Override
	public void insertTerms(TermsVO terms) throws Exception {
		String termsId = termsDao.selectNewTermsId();
		terms.setTermsId(termsId);
		
		this.validateOrElseThrow(terms, Groups.Insert.class);
		
		termsDao.insertTerms(terms);
	}

	@Override
	public void updateTerms(TermsVO terms) throws Exception {
		this.validateOrElseThrow(terms, Groups.Update.class);
		termsDao.updateTerms(terms);
	}

	@Override
	public int deleteTerms(String terms_id) throws Exception {
		int rows = 0;
		TermsHstSearchVO termsHstSearch = new TermsHstSearchVO();
		termsHstSearch.setTermsId(terms_id);
		
		int cnt = termsDao.selectTermsHstCnt(termsHstSearch);
		if( cnt == 0 ) {
			//하위에 등록된 이용약관이 없을 경우 삭제 가능
			rows = termsDao.deleteTerms(terms_id);
		} else {
			throw this.processException("S001022");		//하위 이용약관이 존재할 경우 삭제가 불가능합니다.
		}
		
		return rows;
	}

	/*******************************************
	 * 이용약관 이력
	 *******************************************/
	
	@Override
	public List<TermsHstVO> selectTermsHstList(TermsHstSearchVO termsHstSearch) throws Exception {
		List<TermsHstVO> termsHstList = termsDao.selectTermsHstList(termsHstSearch);
		return termsHstList;
	}
	
	@Override
	public int selectTermsHstListCnt(TermsHstSearchVO termsHstSearch) throws Exception {
		return termsDao.selectTermsHstListCnt(termsHstSearch);
	}
	
	@Override
	public TermsHstVO selectTermsHstById(TermsHstSearchVO termsHstSearch) throws Exception {
		TermsHstVO termsHst = null;
		
		if( StringUtils.isNotEmpty(termsHstSearch.getLangCd()) ) {
			//언어 코드가 존재할 경우
			termsHst = termsDao.selectTermsHst(termsHstSearch);
		} else {
			//언어 코드가 존재하지 않을 경우
			termsHst = termsDao.selectTermsHstById(termsHstSearch);
			
			if( termsHst != null ) {
				//메타 정보 리스트 조회
				termsHst.setTermsMetaList(termsDao.selectTermsMetaList(termsHstSearch));
			}
		}
		return termsHst;
	}

	@Override
	public void insertTermsHst(TermsHstVO termsHst) throws Exception {
		//필수값 체크
		this.validateOrElseThrow(termsHst, Groups.Insert.class);
		//이용약관 이력 등록
		termsDao.insertTermsHst(termsHst);
		
		//이용약관 메타 등록
		List<TermsMetaVO> termsMetaList = termsHst.getTermsMetaList();
		if( termsMetaList != null && termsMetaList.size() > 0 ) {
			for( TermsMetaVO termsMeta : termsMetaList ) {
				termsMeta.setChnCd(termsHst.getChnCd());
				termsMeta.setTermsId(termsHst.getTermsId());
				termsMeta.setTermsHstSno(termsHst.getTermsHstSno());
				termsMeta.setRgtnUser(termsHst.getRgtnUser());
				
				this.validateOrElseThrow(termsMeta, Groups.Insert.class);
				termsDao.insertTermsMeta(termsMeta);
			}
		} else {
			throw this.processException("S001011");		//필수값 오류입니다.
		}
	}

	@Override
	public void updateTermsHst(TermsHstVO termsHst) throws Exception {
		//필수값 체크
		this.validateOrElseThrow(termsHst, Groups.Update.class);
		//이용약관 이력 수정
		termsDao.updateTermsHst(termsHst);
		
		//이용약관 메타 삭제
		TermsMetaVO delTermsMeta = new TermsMetaVO();
		delTermsMeta.setTermsHstSno(termsHst.getTermsHstSno());
		
		if( termsDao.deleteTermsMeta(delTermsMeta) > 0 ) {
			//이용약관 메타 등록
			List<TermsMetaVO> termsMetaList = termsHst.getTermsMetaList();
			if( termsMetaList != null && termsMetaList.size() > 0 ) {
				for( TermsMetaVO termsMeta : termsMetaList ) {
					termsMeta.setChnCd(termsHst.getChnCd());
					termsMeta.setTermsId(termsHst.getTermsId());
					termsMeta.setTermsHstSno(termsHst.getTermsHstSno());
					termsMeta.setRgtnUser(termsHst.getModUser());
					
					this.validateOrElseThrow(termsMeta, Groups.Insert.class);
					termsDao.insertTermsMeta(termsMeta);
				}
			} else {
				throw this.processException("S001011");		//필수값 오류입니다.
			}
		} else {
			throw this.processException("S001002");			//처리된 데이터가 없습니다.
		}
	}

	@Override
	public int deleteTermsHst(TermsHstVO termsHst) throws Exception {
		int rows = 0;
		
		//필수값 체크
		this.validateOrElseThrow(termsHst, Groups.Delete.class);
		//이용약관 이력 삭제
		rows = termsDao.deleteTermsHst(termsHst);
		
		if( rows > 0 ) {
			//이용약관 메타 삭제
			TermsMetaVO delTermsMeta = new TermsMetaVO();
			delTermsMeta.setTermsHstSno(termsHst.getTermsHstSno());
			
			//필수값 체크
			this.validateOrElseThrow(delTermsMeta, Groups.Delete.class);
			termsDao.deleteTermsMeta(delTermsMeta);
		}
		
		return rows;
	}

	/******************************************************************
	 * 사용자 
	 ******************************************************************/
	
	@Override
	public List<TermsHstVO> selectTermsChannelsList(TermsHstSearchVO termsHstSearch) throws Exception {
		return termsDao.selectTermsChannelsList(termsHstSearch);
	}

	@Override
	public List<TermsHstVO> selectTermsHstListByTermsId(TermsHstSearchVO termsHstSearch) throws Exception {
		return termsDao.selectTermsHstListByTermsId(termsHstSearch);
	}
}
