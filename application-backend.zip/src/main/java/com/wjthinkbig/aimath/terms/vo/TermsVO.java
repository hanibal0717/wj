package com.wjthinkbig.aimath.terms.vo;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 24.
  * @프로그램 설명 : 이용약관 설정 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 24.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="이용약관 설정 정보")
public class TermsVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="이용약관ID")
	@FieldName("이용약관ID")
	private String termsId; 			/* 이용약관ID */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="약관명")
	@FieldName("약관명")
	private String termsNm; 			/* 약관명 */
	
	@Min(value = 1, groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="순서")
	@FieldName("순서")
	private int odr; 					/* 순서 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn;				/* 사용여부 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="필수여부")
	@FieldName("필수여부")
	private String esntlYn;				/* 필수여부 */
	
}
