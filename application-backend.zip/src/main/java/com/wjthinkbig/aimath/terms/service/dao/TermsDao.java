package com.wjthinkbig.aimath.terms.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.terms.vo.TermsHstSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsHstVO;
import com.wjthinkbig.aimath.terms.vo.TermsMetaVO;
import com.wjthinkbig.aimath.terms.vo.TermsSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsVO;

/**
  * @Date : 2020. 9. 24.
  * @프로그램 설명 : 이용약관 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 24.     19001861            최초작성
  * </pre>
  */
@Mapper("termsDao")
public interface TermsDao {
	
	/**
	  * @Method 설명 : 이용약관 설정 전체 리스트 조회
	  * @param termsSearch
	  * @return
	  */
	List<TermsVO> selectTermsList(TermsSearchVO termsSearch);
	
	/**
	  * @Method 설명 : 이용약관 설정 전체 리스트 수 조회 (검색 조건 적용)
	  * @param termsSearch
	  * @return
	  */
	int selectTermsListCnt(TermsSearchVO termsSearch);
	
	/**
	  * @Method 설명 : 이용약관 설정 단일 조회
	  * @param terms_id
	  * @return
	  */
	TermsVO selectTermsById(String terms_id);
	
	/**
	  * @Method 설명 : 신규등록시 사용할 이용약관ID 채번
	  * @return
	  */
	String selectNewTermsId();
	
	/**
	  * @Method 설명 : 이용약관 설정 신규 등록
	  * @param terms
	  */
	void insertTerms(TermsVO terms);
	
	/**
	  * @Method 설명 : 이용약관 설정 수정
	  * @param terms
	  */
	void updateTerms(TermsVO terms);
	
	/**
	  * @Method 설명 : 이용약관 설정 삭제
	  * @param terms_id
	  * @return
	  */
	int deleteTerms(String terms_id);
	
	
	/*******************************************
	 * 이용약관 이력
	 *******************************************/
	/**
	  * @Method 설명 : 이용약관 이력 전체 리스트 수 조회
	  * @param termsHstSearch
	  * @return
	  */
	int selectTermsHstCnt(TermsHstSearchVO termsHstSearch);
	
	/**
	  * @Method 설명 : 이용약관 이력 전체 리스트 조회
	  * @param termsHstSearch
	  * @return
	  */
	List<TermsHstVO> selectTermsHstList(TermsHstSearchVO termsHstSearch);
	
	/**
	  * @Method 설명 : 이용약관 이력 전체 리스트 수 조회 (검색 조건 적용)
	  * @param termsHstSearch
	  * @return
	  */
	int selectTermsHstListCnt(TermsHstSearchVO termsHstSearch);
	
	/**
	  * @Method 설명 : 이용약관 이력 단일 조회 (언어코드 필수)
	  * @param termsHstSearch
	  * @return
	  */
	TermsHstVO selectTermsHst(TermsHstSearchVO termsHstSearch);
	
	/**
	  * @Method 설명 : 이용약관 이력 단일 조회
	  * @param termsHstSearch
	  * @return
	  */
	TermsHstVO selectTermsHstById(TermsHstSearchVO termsHstSearch);
	
	/**
	  * @Method 설명 : 이용약관 메타 전체 리스트 조회
	  * @param termsHstSearch
	  * @return
	  */
	List<TermsMetaVO> selectTermsMetaList(TermsHstSearchVO termsHstSearch);
	
	/**
	  * @Method 설명 : 이용약관 이력 등록
	  * @param termsHst
	  */
	void insertTermsHst(TermsHstVO termsHst);
	
	/**
	  * @Method 설명 : 이용약관 메타 등록
	  * @param termsMeta
	  */
	void insertTermsMeta(TermsMetaVO termsMeta);
	
	/**
	  * @Method 설명 : 이용약관 이력 수정
	  * @param termsHst
	  */
	void updateTermsHst(TermsHstVO termsHst);
	
	/**
	  * @Method 설명 : 이용약관 이력 삭제
	  * @param termsHst
	  * @return
	  */
	int deleteTermsHst(TermsHstVO termsHst);
	
	/**
	  * @Method 설명 : 이용약관 메타 삭제
	  * @param termsMeta
	  * @return
	  */
	int deleteTermsMeta(TermsMetaVO termsMeta);
	
	/******************************************************************
	 * 사용자 
	 ******************************************************************/
	
	/**
	  * @Method 설명 : 사용자 회원 가입 시 이용약관 리스트
	  * @param termsHstSearch
	  * @return
	  */
	List<TermsHstVO> selectTermsChannelsList(TermsHstSearchVO termsHstSearch);
	
	/**
	  * @Method 설명 : 이용약관 이력 약관ID별 리스트 조회
	  * @param termsHstSearch
	  * @return
	  */
	List<TermsHstVO> selectTermsHstListByTermsId(TermsHstSearchVO termsHstSearch);
}
