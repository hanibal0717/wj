package com.wjthinkbig.aimath.lvl.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 8. 28.
  * @프로그램 설명 : 코스학습 레벨 하위 소주제 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 28.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="코스학습 레벨 하위 소주제 정보")
public class LvlStgVO extends BaseVO{
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="레벨코드")
	@FieldName("레벨코드")
	private String lvlCd;						/* 레벨코드 */
	
	@ApiModelProperty(value="변경할 레벨코드")
	@FieldName("변경할 레벨코드")
	private String chngeLvlCd;					/* 변경할 레벨코드 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd;						/* 소주제코드 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="사용여부")
	@FieldName("사용여부")
	private String useYn;						/* 사용여부 */
	
}
