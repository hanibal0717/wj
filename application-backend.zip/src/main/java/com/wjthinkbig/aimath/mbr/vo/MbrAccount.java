package com.wjthinkbig.aimath.mbr.vo;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

/**
  * @Date : 2020. 9. 4. 
  * @프로그램 설명 : 스프링시큐리티가 제공하는 User 객체에 대한 Custom User 객체
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 4.     Lee Seung Hyuk            최초작성
  * 2020. 9. 24     Kim Hee   Seok            수정
  * </pre>
 */
public class MbrAccount extends org.springframework.security.core.userdetails.User {
	
	private static final long serialVersionUID = -7495793419409636738L;
	
	// 실제 서비스용 MbrVO 객체
	private MbrVO mbr;

	public MbrAccount(MbrVO mbr) {	
		super(mbr.getMbrId(), mbr.getPw(), getAuthorities(mbr));		
		this.mbr = mbr;
	}
	
	// 실제 서비스용 UserVO 객체에 대한 Getter
	public MbrVO getMbrInfo() {		
		return this.mbr;		
	}
	
	// DB에 등록된 권한에 따라 인증객체의 권한을 설정
	private static Collection<SimpleGrantedAuthority> getAuthorities(MbrVO mbr){
		Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        for(String authority : mbr.getRoles()) {
        	authorities.add(new SimpleGrantedAuthority(authority));
        }
        return authorities;
    }
}