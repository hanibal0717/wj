package com.wjthinkbig.aimath.mbr.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 6 
  * @프로그램 설명 : MbrTermsVO.java 회원 약관 동의 여부 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 6          Kim Hee Seok       최초작성
  * </pre>
  */

@Getter
@Setter
@ApiModel(value = "서비스 회원", description = "회원 약관동의 여부 ")
@ToString(callSuper=true)
public class MbrTermsVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty("가입회원ID")
	@FieldName("가입회원ID")
	private String sbsceMbrId;  /* 가입회원ID */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty("약관ID")
	@FieldName("약관ID")
	private String termsId;      /* 약관ID */
	
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class})
	@ApiModelProperty("동의여부")
	@FieldName("동의여부")
	private String agrmtYn;      /* 동의여부 */
}
