package com.wjthinkbig.aimath.mbr.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrLoginVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 : AI연산 회원서비스 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * 2020. 9. 17.    Kim Hee Seok              수정작업 
  * </pre>
  */
@Slf4j
@Api(description = "서비스 회원정보")
@RestController
public class MbrController extends BaseController {
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 회원서비스
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService; 
	
	/**
	 * 단방향 암호화
	 */
	@Autowired
	@Qualifier("passwordEncoder")
	private PasswordEncoder passwordEncoder;
	
	
	
	/**
	  * @Method 설명 : selectMbrEmailAuth 이메일 인증 
	  * @작성일 : 2020. 10. 5
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param code
	  * @return
	  * @throws Exception
	*/
	@ApiOperation(value = "이메일 url 인증")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/members/email/verification/{code}")
	public CommonResult selectMbrEmailAuth(@ApiParam(value = "회원아이디 암호화 코드") @PathVariable(name="code",required=true) String code) throws Exception {
		int rows=mbrService.updateEmailCertYn(code);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.(인증실패)
		}
		return responseService.getResult(true); 
	}
	
	/**
	  * @Method 설명 : selectPwByEmail 	비밀번호 찾기 
	  * @작성일 : 2020. 9. 29
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param mbr
	  * @return
	  * @throws Exception
	*/
	@ApiOperation(value="회원 비밀번호 찾기")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language",value = "Accept-language 헤더", required = false, dataType = "String", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/members/password")
	public CommonResult selectPwByEmail(@RequestBody MbrVO mbr) throws Exception {
		mbrService.selectPwByEmail(mbr);
		return responseService.getResult(true,"S001023",mbr.getEmailAdrs());
	}
	
	/**
	  * @Method 설명 : 회원 로그인
	  * @param user 로그인정보를 담고 있는 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="회원 로그인")	
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@PostMapping("/api/members/signin")	
	public SingleResult<HashMap<String, String>> login(@ApiParam(value="로그인 VO") @Valid @RequestBody MbrLoginVO mbrLogin , HttpServletRequest request) throws Exception {
		log.debug("로그인 인증요청정보 : {}", mbrLogin);
		String token = mbrService.signin(mbrLogin);
		log.info("발급된 토큰 : {}", token);
		
		HashMap<String, String> data = new HashMap<>();
		data.put("accessToken", token);
						
		//최근 비밀번호 변경일로부터의 경과일수가 6개월(180일)을 초과시 변경대상자 표시
		/*String isNeedToChange = "N";
		long elapsedDays = mbrService.selectPassedDaysFromChangeDt(mbrLogin);
		log.info("비밀번호 최근 변경일로부터 {}일 경과", elapsedDays);
		if(elapsedDays > 180) {
			isNeedToChange = "Y";
		}
		data.put("isNeedToChange", isNeedToChange);*/
		
		// 회원 접속 로그를 쌓는다.
		mbrService.insertLog(token , request);

		return responseService.getSingleResult(data);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	  * @Method 설명 : 가입자 회원을 신규 등록(가입)한다.
	  * @param userVO 등록할 회원정보를 담은 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "가입자 회원 신규등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/members")
	public CommonResult insertMbr(@ApiParam(value = "가입자회원정보") @RequestBody MbrVO mbr, @ApiParam(value = "Http Session") HttpSession session) throws Exception {
		mbr.setSessionId(session.getId());
		mbrService.insertMbr(mbr);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 가입자회원 전체조회
	  * @param account
	  * @param userSearch 회원검색VO
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="가입자 회원 전체조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members")
	public SingleResult<HashMap<String,Object>> selectMbrsList(@ApiParam(value = "회원검색VO") @Valid @ModelAttribute MbrSearchVO mbrSearch) throws Exception {
		// 검색유형을 선택하지 않았을 경우 
		if(mbrSearch.getSrchTy() == null) {
			throw this.processException("S002002");
		}
		
		mbrSearch.setRowCnt((int)mbrSearch.getRowCnt());
		mbrSearch.setCurrentPage((int)mbrSearch.getCurrentPage());
		
		int cnt = mbrService.selectMbrsCnt(mbrSearch);		
		List<MbrVO> mbrs = mbrService.selectMbrs(mbrSearch);
		
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("mbrs", mbrs);
		data.put("totalCount", cnt);
		return responseService.getSingleResult(data);
	}
	
	/**
	  * @Method 설명 : 특정 가입자의 회원정보를 조회한다.
	  * @param mbrId 가입자회원ID
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/{member}")
	public SingleResult<MbrVO> selectMbrById(@ApiParam(value = "가입자회원ID") @PathVariable(name="member",required=true) String mbrId) throws Exception {
		MbrVO mbr = mbrService.selectMbrById(mbrId);
		if(mbr == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		return responseService.getSingleResult(mbr);
	}
	
	/**
	  * @Method 설명 : 특정 가입자의 회원정보를 변경한다. (비밀번호와 전화번호만 변경)
	  * @param mbrId 가입자회원ID
	  * @param mbr 변경할 가입자정보
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원정보 변경")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}")
	public CommonResult updateMbr(@ApiParam(value = "가입자회원ID") @PathVariable(name="member",required=true) String mbrId, @ApiParam(value="가입자정보 VO") @RequestBody MbrVO mbr) throws Exception {
		// 변경할 회원정보를 가져온다.
		MbrVO mbrSrc = mbrService.selectMbrById(mbrId);
		if(mbrSrc == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}	
		
		// 입력한 비밀번호가 있고 기존 비밀번호와 다른 경우 
		if(StringUtils.isNotBlank(mbr.getPw()) && !passwordEncoder.matches(mbr.getPw(), mbrSrc.getPw() == null ? "" : mbrSrc.getPw())) {
			mbrSrc.setPw(passwordEncoder.encode(mbr.getPw()));
			mbrSrc.setPwChngeDt(LocalDateTime.now());
		} else {
			mbrSrc.setPwChngeDt(null);
			mbrSrc.setPw(null);
		}
		
		BeanUtils.copyProperties(mbrSrc, mbr);
		
		if(!StringUtils.isNotBlank(mbr.getPhone())) {
			mbr.setPhone(mbr.getPhoneEn()); //전화번호 암호화
		}
		
		int rows = mbrService.updateMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 특정 가입자의 회원정보를 삭제한다.
	  * @param mbrId 가입자회원ID
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="특정 가입자 회원정보 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/members/{member}")	
	public CommonResult deleteMbr(@ApiParam(value = "가입자회원ID") @PathVariable(name="member",required=true) String mbrId) throws Exception {
		// 삭제할 회원정보를 가져온다.
		MbrVO mbr = mbrService.selectMbrById(mbrId);
		if(mbr == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		
		// 변경자 정보
		mbr.setModUser(LoginUtils.getUserId());
		mbr.setModDt(LocalDateTime.now());
		
		// 가입자 및 가입자의 학습자를 모두 삭제상태로 변경처리한다.
		int rows = mbrService.deleteMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);		
	}

	
	
	
	
	
	
	
	
	
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 학습자 회원을 신규 등록한다.
	  * @param member 가입자회원ID
	  * @param mbrLrn 등록할 학습자정보
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원의 학습자회원 신규등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/members/{member}/learners")	
	public CommonResult insertMbrLrn(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member, @ApiParam(value = "학습자회원ID") @RequestBody MbrLrnVO mbrLrn) throws Exception {	
		
		// 가입자가 삭제상태인지 확인한다. 
		
		// @RequestBody를 통해 전송된 데이터에 가입자ID가 있다면 경로변수의 가입자 ID와 일치해야 한다. 
		if(StringUtils.isNotBlank(mbrLrn.getSbsceMbrId()) && !member.equals(mbrLrn.getSbsceMbrId())) {
			throw this.processException("S002000"); // 학습자 정보가 일치하지 않습니다. 
		}
		
		mbrLrn.setSbsceMbrId(member);
		mbrService.insertMbrLrn(mbrLrn);
		return responseService.getResult(true);		
	}
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 특정 학습자 정보를 조회한다.
	  * @param mbrId 가입자회원ID
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원의 특정 학습자정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/{member}/learners/{learner}")
	public SingleResult<MbrLrnVO> selectLearnerOfMbr(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member, @ApiParam(value = "학습자회원ID") @PathVariable(name="learner",required=true) String learner) throws Exception {
		MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
		if(mbrLrn == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		} else {
			// 해당 학습자의 가입자회원ID가 경로변수와 일치해야 한다. 
			if(!member.equals(mbrLrn.getSbsceMbrId())) {
				throw this.processException("S002001"); // 해당 학습자 정보를 처리할 수 없습니다.
			}
		}
		
		return responseService.getSingleResult(mbrLrn);
	}
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 특정 학습자정보를 변경한다. (이름,성별만 변경)
	  * @param MbrLrnVO 변경할 학습자정보
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value = "특정 가입자 회원의 특정 학습자정보 변경")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}/learners/{learner}")
	public CommonResult updateLearnerOfMbr(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member, @ApiParam(value = "학습자회원ID") @PathVariable("learner") String learner, @ApiParam(value="학습회원 VO")  @RequestBody MbrLrnVO mbrLrn) throws Exception {
		
		// @RequestBody를 통해 전송된 데이터에 가입자ID가 있다면 경로변수의 가입자 ID와 일치해야 한다.
		if(!StringUtils.isNotBlank(mbrLrn.getSbsceMbrId()) && !member.equals(mbrLrn.getSbsceMbrId())) {
			throw this.processException("S002000"); // 학습자 정보가 일치하지 않습니다.
		} else {
			mbrLrn.setSbsceMbrId(member);
		}
		
		mbrLrn.setMbrId(learner);

		int rows = mbrService.updateMbrLrn(mbrLrn);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 학습자정보를 일괄 변경한다. 
	  * @param mbrLrnSaveVO 학습자 VO의 리스트 객체 
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원의 학습자회원정보 일괄변경", notes = "전송한 VO 리스트에 대해 일괄적으로 등록, 수정 또는 삭제 처리를 한다.")	
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}/learners")	
	public CommonResult learnersUpdate(@PathVariable("member") String member, @Valid @RequestBody @ApiParam(value = "일괄처리 MbrLrnVO 리스트") SaveVO<MbrLrnVO> mbrLrnSaveVO) throws Exception {
		int rows = mbrService.learnersUpdate(member, mbrLrnSaveVO);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 특정 학습자정보를 삭제한다. (상태변경)
	  * @param member 가입자ID
	  * @param mbrId 학습자ID
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="특정 가입자 회원의 특정 학습자정보 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/members/{member}/learners/{learner}")
	public CommonResult deleteLearnerOfMbr(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member, @ApiParam(value = "학습자회원ID") @PathVariable(name="learner",required=true) String learner) throws Exception {
		//가입회원의 학습회원 수를 가지고 온다.
		MbrVO mbrSrc = mbrService.selectMbrById(member);
		if(mbrSrc == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrLrnSrc == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		if(mbrSrc.getMbrLrnCnt() < 2) {
			throw this.processException("S002003");		// 더이상 학습회원을 삭제할 수 없습니다. 
		}
		MbrLrnVO mbrLrn = new MbrLrnVO();
		mbrLrn.setSbsceMbrId(member);
		mbrLrn.setMbrId(learner);
		mbrLrn.setModDt(LocalDateTime.now());
		mbrLrn.setModUser(LoginUtils.getUserId());
		
		int rows = mbrService.deleteMbrLrn(mbrLrn);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}	
}