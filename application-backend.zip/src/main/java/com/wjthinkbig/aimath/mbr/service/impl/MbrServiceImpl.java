/**
 * 
 */
package com.wjthinkbig.aimath.mbr.service.impl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.EmailUtils;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.SeedUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.utils.WebUtil;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.service.dao.MbrDao;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrLoginVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrTermsVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.security.JwtUtils;
import com.wjthinkbig.aimath.security.user.UserAuthenticationToken;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 :
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
@Service("mbrService")
public class MbrServiceImpl extends BaseServiceImpl implements MbrService {

	/**
	 * 채널구분코드
	 */
	@Value("${systemId}")
	String sysScnCd;
	
	/**
	 * 회원서비스 Dao
	 */
	@Resource(name = "mbrDao")
	private MbrDao mbrDao;

	/**
	 * 인증을 처리하는 Spring Security AuthenticationManager
	 */
	@Autowired
	private AuthenticationManager authenticationManager; 

	/**
	 * JWT Utility
	 */
	@Resource(name = "jwtUtils")
	private JwtUtils jwtUtils;	
		
	/**
	 * 단방향 암호화
	 */
	@Autowired
	@Qualifier("passwordEncoder")
	private PasswordEncoder passwordEncoder;
	
	/**
	 * 회원ID 신규생성 서비스
	 */
	@Resource(name = "mbrIdGenService")
	private EgovIdGnrService mbrIdGenService;
	
	/**
	 * 학습 회원ID 신규생성 서비스
	 */
	@Resource(name = "lrnIdGenService")
	private EgovIdGnrService lrnIdGenService;
	
	/**
	 * Email Utility
	 */
	@Resource(name = "emailUtils")
	private EmailUtils emailUtils;	
	
	/**
	 * url 암호화 Utility
	 */
	@Resource(name = "seedUtils")
	private SeedUtils seedUtils;	
		

	@Override
	public void insertMbr(MbrVO mbr) throws Exception {
		
		// 회원ID 채번
		String newMbrId = mbrIdGenService.getNextStringId();
		mbr.setMbrId(newMbrId);
		
		// 채널구분코드
		mbr.setChnCd(sysScnCd);
		
		//회원삭제여부
		mbr.setDelYn("N");
		
		// 이메일인증여부 (단독 서비스의 경우 반드시 필수이므로 초기 N, 연동서비스의 경우 자동로그인이므로 NULL)
		if(StringUtils.isNotBlank(mbr.getEmailAdrs())) {
			mbr.setEmailCertYn("N");
		}
		mbr.setPwChngeDt(LocalDateTime.now());
		mbr.setLoginUser(newMbrId);
		
		// 입력값 검증 (신규등록시)				
		this.validateOrElseThrow(mbr, Groups.Insert.class);
		
		// 비밀번호  암호화 (단독 서비스에서 비밀번호를 입력받은 경우에만 세팅, 스마트올과 같은 연동서비스의 경우 자동로그인하므로 NULL) 
		if(StringUtils.isNotBlank(mbr.getPw())) {
			mbr.setPw(passwordEncoder.encode(mbr.getPw()));
		}		
		
		// 가입할 이메일이 이미 등록되어 있는지 확인 (단독 서비스의 경우 반드시 필수, 연동서비스의 경우 자동로그인이므로 NULL)
		String rawEmail = mbr.getEmailAdrs();	// 암호화전 이메일
		String encEmail = mbr.getEmailAdrsEn();	// 이메일 암호화
		
		if(mbrDao.isExistsByEmail(encEmail)) {
			throw this.processException("S001015"); // 해당 이메일은 이미 등록되어 있습니다.
		}
		
		MbrLrnVO mbrLrn = mbr.getMbrLrnList().get(0);
		
		// 회원ID 채번
		String newMbrLrnId = lrnIdGenService.getNextStringId();
		mbrLrn.setMbrId(newMbrLrnId);
		
		mbrLrn.setSbsceMbrId(mbr.getMbrId());
		
		// 이모티콘 셋팅 
		mbrLrn.setEmotcSno(1);

		// 학습 회원삭제여부
		mbrLrn.setDelYn("N");		
		
		mbrLrn.setLoginUser(newMbrId);
		
		// 학습회원 입력값 검증 (신규등록시)				
		this.validateOrElseThrow(mbrLrn, Groups.Insert.class);
		
		mbrDao.insertMbr(mbr);
		mbrDao.insertMbrLrn(mbrLrn);
		
		//회원 약관 여부 등록  
		List<MbrTermsVO> mbrTermsList=mbr.getMbrTermsList();
		for(MbrTermsVO vo : mbrTermsList) {
			//회원 약관VO에 아이디를 셋팅한다.
			vo.setLoginUser(newMbrId);
			vo.setSbsceMbrId(newMbrId);
			this.validateOrElseThrow(vo, Groups.Insert.class);
			mbrDao.insertMbrTerms(vo);
			
		}
		// 인증메일을 보낸다
		emailUtils.mailAuth(seedUtils.getEnCrypt(newMbrId), rawEmail);
	}
	
	@Override
	public int updateEmailCertYn(String code) throws Exception {
		String mbrId=seedUtils.getDeCrypt(code);
		int rows=mbrDao.updateEmailCertYn(mbrId);
		return rows;
	}
	
	@Override
	public void selectPwByEmail(MbrVO mbr) throws Exception {
		MbrVO mbrVO =mbrDao.selectMbrByEmail(mbr.getEmailAdrsEn());
		if(mbrVO == null) {
			throw this.processException("S001005");
		}
		//임시번호 발급 
		String tmpPw = emailUtils.getTempPw(8);
		//암호화 및 업데이트 셋팅
		mbr.setPw(passwordEncoder.encode(tmpPw));
		mbr.setPwChngeDt(LocalDateTime.now());
		mbr.setMbrId(mbrVO.getMbrId());
		mbr.setModDt(LocalDateTime.now());
		mbr.setModUser(mbrVO.getMbrId());
		
		//비밀번호 변경 
		int rows = mbrDao.updateMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		//이메일 발송 
		mbr.setEmailAdrsDe(mbr.getEmailAdrsEn());
		emailUtils.findPw(tmpPw,mbr.getEmailAdrs());
	}

	@Override
	public void insertMbrLrn(MbrLrnVO mbrLrn) throws Exception{
		// 등록하려는 학습자 정보가 이미 가입자의 학습자 중에 존재하는지 확인 (이름/성별/생년월)
		List<MbrLrnVO> learners = mbrDao.selectMbrLrnListById(mbrLrn.getSbsceMbrId());
		long learnerCnt = learners.stream().filter(x -> {
			return x.getBrthmt().equals(mbrLrn.getBrthmt()) &&
					x.getMbrNm().equals(mbrLrn.getMbrNm()) &&
					x.getSxdnCd().equals(mbrLrn.getSxdnCd());
		}).count();
		
		if(learnerCnt > 0) {
			throw this.processException("S001004"); // 이미 사용자가 등록되어 있습니다.
		}
		
		String newMbrLrnId = lrnIdGenService.getNextStringId();
		mbrLrn.setMbrId(newMbrLrnId);
				
		//이모티콘 셋팅 
		mbrLrn.setEmotcSno(1);

		//학습 회원삭제여부
		mbrLrn.setDelYn("N");
		
		mbrLrn.setLoginUser(mbrLrn.getSbsceMbrId());

		// 입력값 검증 (신규등록시)				
		this.validateOrElseThrow(mbrLrn, Groups.Insert.class);
		mbrDao.insertMbrLrn(mbrLrn);
	}

	@Override
	public MbrVO selectMbrById(String mbrId) throws Exception {
		MbrVO mbr = mbrDao.selectMbrById(mbrId);
		if(mbr != null) {
			mbr.setEmailAdrsDe(mbr.getEmailAdrs()); //이메일 복호화
			mbr.setPhoneDe(mbr.getPhone());//전화번호 복호화
			
			mbr.setMbrLrnList(mbrDao.selectMbrLrnListById(mbrId));
		}
		return mbr;
	}
	
	@Override
	public MbrLrnVO selectMbrLrnById(String mbrLrnId) throws Exception {
		MbrLrnVO mbrLrn = mbrDao.selectMbrLrnById(mbrLrnId);
		return mbrLrn;
	}
	
	@Override
	public int deleteMbrLrn(MbrLrnVO mbrLrn) throws Exception {
		mbrLrn.setModUser(LoginUtils.getUserId());
		mbrLrn.setModDt(LocalDateTime.now());
		return mbrDao.deleteMbrLrn(mbrLrn);
	}

	@Override
	public int deleteMbr(MbrVO mbr) throws Exception {
		mbr.setModUser(LoginUtils.getUserId());
		mbr.setModDt(LocalDateTime.now());
		mbrDao.deleteMbrLrnBySbsceId(mbr);
		return mbrDao.deleteMbr(mbr);
	}
	
	@Override
	public int updateMbrLrn(MbrLrnVO mbrLrn) throws Exception {
		mbrLrn.setModUser(LoginUtils.getUserId());
		mbrLrn.setModDt(LocalDateTime.now());
		return mbrDao.updateMbrLrn(mbrLrn);
	}
	
	
	@Override
	public int learnersUpdate(String sbsceMbrId, @Valid SaveVO<MbrLrnVO> mbrLrnSaveVO) {
		
		// 처리대상 가입자의 학습자 정보가 일치하는지 검증
		long notMatchedCnt = 0;
		
		List<MbrLrnVO> updateList = mbrLrnSaveVO.getUpdateList();		
		if(updateList != null) {
			// 실제 가입자와 입력값에 기술된 가입자가 일치하는지 검증
			notMatchedCnt = updateList.stream().filter(x -> {
				return !sbsceMbrId.equals(x.getSbsceMbrId());
			}).count();
		}
		
		if(notMatchedCnt > 0) {
			throw this.processException("S002004"); // 학습자의 가입자 정보가 실제 가입자 정보와 일치하지 않습니다.
		}
		
		// 일괄 처리된 건 수
		int updateCnt = 0;
		
		for(MbrLrnVO vo : updateList) {
			int rowsAffected = 0;
			
			rowsAffected = mbrDao.updateMbrLrn(vo);
			updateCnt += rowsAffected; 			

		}
		
		return updateCnt;
	}

	@Override
	public int updateMbr(MbrVO mbr) throws Exception {
		if(!StringUtils.isNotBlank(mbr.getPw())) {
			mbr.setModUser(LoginUtils.getUserId());
			mbr.setModDt(LocalDateTime.now());
			mbr.setPw(passwordEncoder.encode(mbr.getPw()));
		}
		mbr.setPhone(mbr.getPhoneEn()); //전화번호 암호화
		return mbrDao.updateMbr(mbr);
	}
	
	
	@Override
	public List<MbrVO> selectMbrs(MbrSearchVO mbrSearch) throws Exception {
		if(mbrSearch != null) {
			if(mbrSearch.getSrchTy().equals("EMAIL") || mbrSearch.getSrchTy().equals("ALL")) {
				mbrSearch.setSrchTxt(mbrSearch.getSrchTxtEnE());
			}
		}
		
		List<MbrVO> mbrs = mbrDao.selectMbrs(mbrSearch);
		
		for(int i = 0; i < mbrs.size(); i++) {
			mbrs.get(i).setEmailAdrsDe(mbrs.get(i).getEmailAdrs());
		}
		return mbrs;
	}

	@Override
	public int selectMbrsCnt(MbrSearchVO mbrSearch) throws Exception {
		if(mbrSearch.getSrchTy().equals("EMAIL")) {
			mbrSearch.setSrchTxt(mbrSearch.getSrchTxtEnE());
		}
		return mbrDao.selectMbrsCnt(mbrSearch);
	}
	
	@Override
	public String signin(@Valid MbrLoginVO mbr) throws Exception {
		try {
			// 전송된 이메일 암호화 후 인증처리		
			mbr.getEmailAdrsEn();
			
			// 정상적으로 인증처리가 되면 
			UserAuthenticationToken authenticationToken = new UserAuthenticationToken(mbr.getEmailAdrs(), mbr.getPw());
			Authentication authentication = authenticationManager.authenticate(authenticationToken);
			log.debug("정상인증된 객체 (a fully populated Authentication object (including granted authorities) : " + authentication.toString());
			
			// 토큰을 발급한다.			
			MbrAccount mbrAccount = (MbrAccount) authentication.getPrincipal();
			HashMap<String, String> tokenClaims = new HashMap<String, String>();
			tokenClaims.put("mbr",mbrAccount.getMbrInfo().getMbrId());//일반회원 회원 아이디를 토큰에 추가한다.
			String token = jwtUtils.createToken(mbr.getEmailAdrs(), mbrAccount.getMbrInfo().getRoles(), tokenClaims);
			return token;
		} catch (BadCredentialsException e) {
			log.debug("로그인 인증실패({}) : {}", ClassUtils.getShortName(e.getClass()), e.getMessage());
			
			// 인증처리 실패시 BadCredentialsException 반환
			throw this.processException("S001006"); // 계정이 존재하지 않거나 계정정보가 올바르지 않습니다.
		} catch (AuthenticationException e) {
			log.debug("로그인 인증실패({}) : {}", ClassUtils.getShortName(e.getClass()), e.getMessage());
			
			// 인증처리 실패시 AuthenticationException 반환
			throw this.processException("E000015"); // 해당 리소스에 접근하기 위한 권한이 없습니다.
		}
	}

	@Override
	public void insertLog(String token, HttpServletRequest request) throws Exception {
		HashMap<String, Object> logData = new HashMap<String, Object>();
		String device = WebUtil.getDeviceKind(request);
		logData.put("device_scn_cd",device);
		logData.put("mbrId",jwtUtils.getClaims(token).get("mbr").toString());
		logData.put("loginDt", LocalDateTime.now());
		mbrDao.insertMbrLog(logData);
		
	}
	
	@Override
	public List<MbrLrnVO> selectLearnersBySbsceMbrId(String mbrId) throws Exception {
		return mbrDao.selectMbrLrnListById(mbrId);
	}
	
	
}
