package com.wjthinkbig.aimath.mbr.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 23 
  * @프로그램 설명 : MbrLrnVO.java
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 17          Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ApiModel(value = "서비스 회원", description = "AI연산 서비스 회원")
@ToString(callSuper=true)
public class MbrLrnVO extends BaseVO {
	/**
	 * 학습 회원 ID
	 */
	@NotBlank(groups = {Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value = "학습회원 ID")
	@FieldName("학습회원 ID")
	private String mbrId;
	
	/**
	 * 가입회원 ID
	 */
	@NotBlank(groups = {Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value = "가입회원 ID")
	@FieldName("가입회원 ID")
	private String sbsceMbrId;
	
	/**
	 * 회원명 #이전
	 */
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})		
	@ApiModelProperty(value = "회원명")
	@FieldName("회원명")
	private String mbrNm;
	
	/**
	 * 생년월일 (YYYYMMDD) #이전
	 */
	@Pattern(regexp = "(19|20)\\d{2}(0[1-9]|1[012])")
	@NotBlank(groups = {Groups.Insert.class})		
	@ApiModelProperty(value = "생년월일")
	@FieldName("생년월일")
	private String brthmt;
	
	/**
	 * 성별코드 (남:M, 여:F)
	 */
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "M|F")
	@ApiModelProperty(value = "성별코드")
	@FieldName("성별코드")
	private String sxdnCd;
	
	/**
	 * 이모티콘일련번호
	 */
	@ApiModelProperty(value = "이모티콘일련번호")
	@FieldName("이모티콘일련번호")
	private int emotcSno;
	
	/**
	 * 회원 삭제여부
	 */
	@Pattern(regexp = "Y|N")
	@ApiModelProperty(value = "삭제여부")
	@FieldName("삭제여부")
	private String delYn;
	
	/**
	 * 학습회원여부 
	 */
	@Pattern(regexp = "Y|N")
	@ApiModelProperty(value = "학습회원여부")
	@FieldName("학습회원여부")
	private String MbrLrnYn;
	
	
}
