package com.wjthinkbig.aimath.stg.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 4.
  * @프로그램 설명 : 커리큘럼 소주제 연령 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 4.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 소주제 연령 검색 정보")
public class StgAgeInfoSearchVO {
	
	@ApiModelProperty(value="스테이지코드")
	@FieldName("스테이지코드")
	private String stgCd; 					/* 스테이지코드 */
	
}
