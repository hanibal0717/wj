package com.wjthinkbig.aimath.stg.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.common.vo.FileVO;
import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.FileUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.qst.service.dao.QstDao;
import com.wjthinkbig.aimath.qst.vo.QstSearchVO;
import com.wjthinkbig.aimath.stg.service.StgService;
import com.wjthinkbig.aimath.stg.service.dao.StgDao;
import com.wjthinkbig.aimath.stg.vo.StgAgeInfoSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgAgeInfoVO;
import com.wjthinkbig.aimath.stg.vo.StgMetaSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgMetaVO;
import com.wjthinkbig.aimath.stg.vo.StgSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 소주제(스테이지) 관리서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Slf4j
@Service("stgService")
public class StgServiceImpl extends BaseServiceImpl implements StgService {

	/**
	 * 소주제관리 Dao
	 */
	@Resource(name = "stgDao")
	private StgDao stgDao;
	
	/**
	 * 문항관리 Dao
	 */
	@Resource(name = "qstDao")
	private QstDao qstDao;
	
	/**
	 * AWS S3 도메인
	 */
	private static String domain;
	@Value("${aws.domain}")
	public void setDomain(String url) {
		domain = url;
	}
	
	/**
	 * AWS S3 bucketName 키값
	 */
	private static String bucketName;
	@Value("${aws.bucket.name}")
	public void setBucketName(String name) {
		bucketName = name;
	}
	
	@Override
	public List<StgVO> selectStgList(StgSearchVO stgSearch) throws Exception {
		List<StgVO> stgList = stgDao.selectStgList(stgSearch);
		List<StgVO> resultList = new ArrayList<StgVO>();
		
		if( stgList != null && stgList.size() > 0 ) {
			//파일 경로에 S3 도메인을 넣어준다
			for( StgVO stg : stgList ) {
				if( StringUtils.isNotEmpty(stg.getStgImgFilePath()) ) {
					stg.setStgImgFilePath(domain + "/" + bucketName + stg.getStgImgFilePath());
				}
				
				resultList.add(stg);
			}
		}
		
		return resultList;
	}
	
	@Override
	public int selectStgListCnt(StgSearchVO stgSearch) throws Exception {
		return stgDao.selectStgListCnt(stgSearch);
	}
	
	@Override
	public StgVO selectStgById(StgSearchVO stgSearch) throws Exception {
		StgVO stg = null;
		
		if( StringUtils.isNotEmpty(stgSearch.getLangCd()) ) {
			//언어 코드가 존재할 경우
			stg = stgDao.selectStg(stgSearch);
			
			if( stg != null ) {
				
			}
		} else {
			//언어 코드가 존재하지 않을 경우
			stg = stgDao.selectStgById(stgSearch.getStgCd());
			
			if( stg != null ) {
				//메타 정보 리스트 조회
				StgMetaSearchVO stgMetaSearch = new StgMetaSearchVO();
				stgMetaSearch.setStgCd(stgSearch.getStgCd());
				
				stg.setStgMetaList(stgDao.selectStgMetaList(stgMetaSearch));
			}
		}
		
		if( stg != null ) {
			//파일 경로에 S3 도메인을 넣어준다
			if( StringUtils.isNotEmpty(stg.getStgImgFilePath()) ) {
				stg.setStgImgFilePath(domain + "/" + bucketName + stg.getStgImgFilePath());
			}
			
			//연령정보 조회
			StgAgeInfoSearchVO stgAgeInfoSearch = new StgAgeInfoSearchVO();
			stgAgeInfoSearch.setStgCd(stg.getStgCd());
			
			stg.setStgAgeInfoList(stgDao.selectStgAgeInfoList(stgAgeInfoSearch));
		}
		
		return stg;
	}

	@Override
	public int selectStgCdDplctCeck(String stg_cd) throws Exception {
		return stgDao.selectStgCdDplctCeck(stg_cd);
	}

	@Override
	public void insertStg(StgVO stg) throws Exception {
		MultipartFile mFile = stg.getMFile();

		//첨부파일 확인 후 등록
		if( mFile != null && !mFile.isEmpty() ) {
			FileVO file = FileUtils.sendAWSS3(mFile, "stage");
			
			if( file != null ) {
				//객체 저장
				stg.setStgImgFilePath(file.getFilePath());
				stg.setStgImgFileNm(file.getFileNm());
			}
		}
		
		// Insert Group에 대한 빈 검증 (신규등록 시의 검증, 파일업로드 이후 파일첨부 필수여부 확인) 
		this.validateOrElseThrow(stg, Groups.Insert.class);
		
		stgDao.insertStg(stg);
		
		//메타정보 등록
		List<StgMetaVO> stgMetaList = stg.getStgMetaList();
		if( stgMetaList != null && stgMetaList.size() > 0 ) {
			for( StgMetaVO stgMeta : stgMetaList ) {
				if( stgMeta != null ) {
					stgMeta.setStgCd(stg.getStgCd());
					stgMeta.setRgtnUser(stg.getRgtnUser());
					
					this.validateOrElseThrow(stgMeta, Groups.Insert.class);
					
					stgDao.insertStgMeta(stgMeta);
				}
			}
		}
		
		//연령 등록
		List<StgAgeInfoVO> stgAgeInfoList = stg.getStgAgeInfoList();
		if( stgAgeInfoList != null && stgAgeInfoList.size() > 0 ) {
			for( StgAgeInfoVO stgAgeInfo : stgAgeInfoList ) {
				if( stgAgeInfo != null ) {
					stgAgeInfo.setStgCd(stg.getStgCd());
					stgAgeInfo.setRgtnUser(stg.getRgtnUser());
					
					this.validateOrElseThrow(stgAgeInfo, Groups.Insert.class);
					
					stgDao.insertStgAgeInfo(stgAgeInfo);
				}
			}
		}
	}

	@Override
	public void updateStg(StgVO stg) throws Exception {
		MultipartFile mFile = stg.getMFile();
		
		//첨부파일 확인 후 등록
		if( mFile != null ) {
			//기존 파일 경로를 가져와 파일 삭제 후 재 업로드 한다.
			StgVO tmp = stgDao.selectStgById(stg.getStgCd());
			
			if( FileUtils.deleteAWSS3(tmp.getStgImgFilePath(), tmp.getStgImgFileNm()) ) {
				//파일 업로드
				FileVO file = FileUtils.sendAWSS3(mFile, "stage");
				
				if( file != null ) {
					//객체 저장
					stg.setStgImgFilePath(file.getFilePath());
					stg.setStgImgFileNm(file.getFileNm());
				}
			}
		}
		
		// Update Group에 대한 빈 검증
		this.validateOrElseThrow(stg, Groups.Update.class);
		
		stgDao.updateStg(stg);
		
		//메타 정보 삭제 후 등록
		stgDao.deleteStgMeta(stg.getStgCd());
		
		//메타정보 등록
		List<StgMetaVO> stgMetaList = stg.getStgMetaList();
		if( stgMetaList != null && stgMetaList.size() > 0 ) {
			for( StgMetaVO stgMeta : stgMetaList ) {
				if( stgMeta != null ) {
					stgMeta.setStgCd(stg.getStgCd());
					stgMeta.setRgtnUser(stg.getRgtnUser());
					
					this.validateOrElseThrow(stgMeta, Groups.Insert.class);
					
					stgDao.insertStgMeta(stgMeta);
				}
			}
		}
		
		//연령 삭제 후 등록
		stgDao.deleteStgAgeInfo(stg.getStgCd());
		
		List<StgAgeInfoVO> stgAgeInfoList = stg.getStgAgeInfoList();
		if( stgAgeInfoList != null && stgAgeInfoList.size() > 0 ) {
			for( StgAgeInfoVO stgAgeInfo : stgAgeInfoList ) {
				if( stgAgeInfo != null ) {
					stgAgeInfo.setStgCd(stg.getStgCd());
					stgAgeInfo.setRgtnUser(stg.getModUser());
					
					this.validateOrElseThrow(stgAgeInfo, Groups.Insert.class);
					
					stgDao.insertStgAgeInfo(stgAgeInfo);
				}
			}
		}
	}

	@Override
	public int deleteStg(String stg_cd) throws Exception {
		int rows = 0;
		QstSearchVO qstSearch = new QstSearchVO();
		qstSearch.setStgCd(stg_cd);
		
		if( qstDao.selectQstCount(qstSearch) == 0 ) {
			//기존 파일 경로를 가져와 파일 삭제
			StgVO tmp = stgDao.selectStgById(stg_cd);
			
			if( tmp != null ) {
				if( StringUtils.isNotEmpty(tmp.getStgImgFilePath()) && StringUtils.isNotEmpty(tmp.getStgImgFileNm()) ) {
					FileUtils.deleteAWSS3(tmp.getStgImgFilePath(), tmp.getStgImgFileNm());
				}
				
				rows = stgDao.deleteStg(stg_cd);
				
				if( rows > 0 ) {
					//메타 정보 삭제
					stgDao.deleteStgMeta(stg_cd);
					
					//연령 삭제
					stgDao.deleteStgAgeInfo(stg_cd);
				}
			}
		} else {
			throw this.processException("S001012");		//하위 문항이 존재할 경우 삭제가 불가능합니다.
		}
		
		return rows;
	}

	@Override
	public int deleteStgList(SaveVO<StgVO> saveStg) throws Exception {
		int cnt = 0;
		List<StgVO> stgList = saveStg.getDeleteList();
		
		if( stgList != null && stgList.size() > 0 ) {
			for( StgVO stg : stgList ) {
				//필수값 확인
				this.validateOrElseThrow(stg, Groups.Delete.class);
				
				String stgCd = stg.getStgCd();
				
				QstSearchVO qstSearch = new QstSearchVO();
				qstSearch.setStgCd(stgCd);
				
				if( qstDao.selectQstCount(qstSearch) == 0 ) {
					//기존 파일 경로를 가져와 파일 삭제
					StgVO tmp = stgDao.selectStgById(stg.getStgCd());
					
					if( StringUtils.isNotEmpty(tmp.getStgImgFilePath()) && StringUtils.isNotEmpty(tmp.getStgImgFileNm()) ) {
						FileUtils.deleteAWSS3(tmp.getStgImgFilePath(), tmp.getStgImgFileNm());
					}
					
					if( stgDao.deleteStg(stgCd) > 0 ){
						//언어 개념메타 삭제
						stgDao.deleteStgMeta(stgCd);
						
						//연령 삭제
						stgDao.deleteStgAgeInfo(stgCd);
						
						cnt++;
					} else {
						throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
					}
				} else {
					throw this.processException("S001012");		//하위 문항이 존재할 경우 삭제가 불가능합니다.
				}
			}
		}
		
		return cnt;
	}
}