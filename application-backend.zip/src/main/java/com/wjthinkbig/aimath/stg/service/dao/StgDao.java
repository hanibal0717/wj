package com.wjthinkbig.aimath.stg.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.stg.vo.StgAgeInfoSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgAgeInfoVO;
import com.wjthinkbig.aimath.stg.vo.StgMetaSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgMetaVO;
import com.wjthinkbig.aimath.stg.vo.StgSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : 소주제 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     10013871            최초작성
  * </pre>
 */
@Mapper("stgDao")
public interface StgDao {
	
	/**
	  * @Method 설명 : 검색조건에 맞는 커리큘럼 스테이지 전체 리스트를 가져온다.
	  * @param stgSearch 검색할 정보를 담은 소주제 VO
	  * @return
	  */
	List<StgVO> selectStgList(StgSearchVO stgSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 특정 소주제정보를 가져온다.(언어코드 필수)
	  * @param stgSearch 검색할 정보를 담은 소주제 VO
	  * @return
	  */
	StgVO selectStg(StgSearchVO stgSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 특정 소주제정보를 가져온다.
	  * @param stg_cd 가져올 소주제 식별코드
	  * @return 소주제 VO
	  * @throws Exception
	 */
	StgVO selectStgById(String stg_cd);
	
	/**
	  * @Method 설명 : 커리큘럼 소주제 리스트 수를 가져온다.
	  * @param stgSearch
	  * @return
	  * @throws Exception
	  */
	int selectStgCnt(StgSearchVO stgSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 소주제 리스트 수를 가져온다.(검색조건 적용)
	  * @param stgSearch
	  * @return
	  */
	int selectStgListCnt(StgSearchVO stgSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 소주제 코드 중복 여부 체크
	  * @param stg_cd
	  * @return
	  * @throws Exception
	  */
	int selectStgCdDplctCeck(String stg_cd);
	
	/**
	  * @Method 설명 : 커리큘럼 소주제 메타 정보 리스트 조회
	  * @param stgMetaSearch
	  * @return
	  * @throws Exception
	  */
	List<StgMetaVO> selectStgMetaList(StgMetaSearchVO stgMetaSearch);
	
	/**
	  * @Method 설명 : 커리큘럼 소주제 연령정보 리스트 조회
	  * @param stgAgeInfoSearch
	  * @return
	  * @throws Exception
	  */
	List<StgAgeInfoVO> selectStgAgeInfoList(StgAgeInfoSearchVO stgAgeInfoSearch);
	
	/**
	  * @Method 설명 : 신규 소주제정보를 등록한다.
	  * @param stg 등록할 소주제정보 VO
	  * @throws Exception
	 */
	void insertStg(StgVO stg);
	
	/**
	  * @Method 설명 : 신규 소주제 메타정보를 등록한다.
	  * @param stgLangMeta
	  * @throws Exception
	  */
	void insertStgMeta(StgMetaVO stgMeta);
	
	/**
	  * @Method 설명 : 신규 소주제 연령을 등록한다.
	  * @param stgAgeInfo
	  * @throws Exception
	  */
	void insertStgAgeInfo(StgAgeInfoVO stgAgeInfo);
	
	/** 
	  * @Method 설명 : 등록된 특정 커리큘럼 소주제정보를 변경한다.  
	  * @param stg 변경할 소주제정보를 담은 VO
	  * @throws Exception
	 */
	void updateStg(StgVO stg);
	
	/**
	  * @Method 설명 : 특정 키를 갖는 소주제 정보를 삭제한다.
	  * @param stg_cd 삭제할 소주제 식별코드
	  * @return 삭제된 데이터 건수 
	  * @throws Exception
	 */
	int deleteStg(String stg_cd);
	
	/**
	  * @Method 설명 : 특정 키를 갖는 소주제 메타 정보를 삭제한다.
	  * @param stg_cd
	  * @return
	  * @throws Exception
	  */
	int deleteStgMeta(String stg_cd);
	
	/**
	  * @Method 설명 : 특정 키를 갖는 소주제 연령 정보를 삭제한다.
	  * @param stg_cd
	  * @return
	  * @throws Exception
	  */
	int deleteStgAgeInfo(String stg_cd);
}