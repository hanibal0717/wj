echo "  > Code Deploy Download Bundle Finished "
/server/was/launcher/job_aimath.sh stop
/bin/mv -f /server/deploy/aimath-api-0.0.1-SNAPSHOT.jar /server/was/instances/aimath/
ls -al /server/was/instances/aimath/
/server/was/launcher/job_aimath.sh start