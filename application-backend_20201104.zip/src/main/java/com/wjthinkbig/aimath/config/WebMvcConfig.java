package com.wjthinkbig.aimath.config;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.mobile.device.DeviceHandlerMethodArgumentResolver;
import org.springframework.mobile.device.DeviceResolverHandlerInterceptor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.filter.CommonsRequestLoggingFilter;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.wjthinkbig.aimath.core.interceptor.LoggerInterceptor;

@Configuration
@EnableWebMvc
public class WebMvcConfig implements WebMvcConfigurer {
	
	// 업로드된 메타 파일의 물리적 경로
	@Value("${spring.servlet.multipart.location}")
	private String uploadImagesPath;	

	// 업로드된 메타 파일의 URL 기준경로
	@Value("${directory.meta.images}")
	private String uploadImagesUrlBasePath;
	
	// Front Domain
	@Value("${server.front.url}") 
	private String[] frontUrl;
	
	// 정적 리소스 리스트
	private static final String[] CLASSPATH_RESOURCE_LOCATIONS = { 
			"classpath:/static/", 
            "classpath:/resources/", 
            "classpath:/META-INF/resources/", 
            "classpath:/META-INF/resources/webjars/"
	};
	
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(new LoggerInterceptor());
		registry.addInterceptor(new DeviceResolverHandlerInterceptor()).addPathPatterns("/**");
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/**").addResourceLocations(CLASSPATH_RESOURCE_LOCATIONS);
		
		// 업로드된 메타 이미지 URL 기준경로	    
		registry.addResourceHandler(uploadImagesUrlBasePath + "**").addResourceLocations("file:///" + uploadImagesPath + "/");
	}	

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addRedirectViewController("/**/configuration/ui", "/swagger-resources/configuration/ui");
	}

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/api/**").allowedMethods("GET", "HEAD", "POST", "PUT", "DELETE", "OPTIONS").allowedOrigins(frontUrl); 
	}
	
	@Override
	public void extendMessageConverters(List<HttpMessageConverter<?>> converters) {
		DateTimeFormatter deserializer_formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

		// SpringBoot 2.x는 Java 8 date/time 에 대해 자동으로 ISO 포맷을 사용
		ObjectMapper objectMapper = Jackson2ObjectMapperBuilder 
				.json() 
				.timeZone(TimeZone.getDefault())
				.simpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX") // 일관성 있는 포맷을 위한 설정 (java.util.Date)
				.deserializerByType(LocalDateTime.class, new LocalDateTimeDeserializer(deserializer_formatter))				
				.build(); 
		
		converters.add(0, new MappingJackson2HttpMessageConverter(objectMapper));
	}
	
	@Bean
    public ViewResolver getViewResolver() {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();
        resolver.setPrefix("/WEB-INF/views/");
        resolver.setSuffix(".jsp");
        return resolver;
    }	
	
	@Bean(name = "errorAttributes")
	public ErrorAttributes errorAttributes() {
		// Hide exception field in the return object
		return new DefaultErrorAttributes() {
			@Override
			public Map<String, Object> getErrorAttributes(WebRequest webRequest, boolean includeStackTrace) {
				Map<String, Object> errorAttributes = super.getErrorAttributes(webRequest, includeStackTrace);
				return errorAttributes;
			}
		};
	}
	
//	@Bean
	public CommonsRequestLoggingFilter commonsRequestLoggingFilter() {
	    CommonsRequestLoggingFilter filter = new CommonsRequestLoggingFilter();
	    filter.setIncludeClientInfo(true);
	    filter.setIncludeHeaders(true);
	    filter.setIncludePayload(true);
	    filter.setIncludeQueryString(true);
	    filter.setMaxPayloadLength(1000);
	    return filter;
	}	

	@Bean
	public MessageSource messageSource() {
		ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource(); 
		messageSource.setBasenames("classpath:/i18n/messages", "classpath:/i18n/exception", "classpath:/i18n/idgnr"); 
		messageSource.setDefaultEncoding("UTF-8");					
		messageSource.setAlwaysUseMessageFormat(false);		// MessageFormat 룰 적용하지 않음, 기본값 false
		messageSource.setUseCodeAsDefaultMessage(false);	// 메시지를 찾지 못했을 때 예외 발생시킴, 기본값 false
		messageSource.setFallbackToSystemLocale(true);		// 감지된 locale에 대한 파일이 없으면 system locale 사용(true), messages.properties 파일을 사용(false)
		return messageSource;
	}
	
	@Bean(name = "validator")
	@Override
	public LocalValidatorFactoryBean getValidator() {
	    LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
	    bean.setValidationMessageSource(messageSource());
	    return bean;
	}
	
	/**
	  * 비밀번호 암호화 처리기
	 */
	@Bean(name = "passwordEncoder")
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder(12);
	}

	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
		resolvers.add(new DeviceHandlerMethodArgumentResolver());
	}
}