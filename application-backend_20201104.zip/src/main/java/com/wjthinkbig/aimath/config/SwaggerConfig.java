package com.wjthinkbig.aimath.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
	
	@Bean
    public Docket api() {
		List<Parameter> operationParameters = new ArrayList<Parameter>();
/*		
		springfox.documentation.service.Parameter authParam = new ParameterBuilder()
			.name("Authorization")
			.description("Authorization Header")
			.defaultValue("Bearer ")
			.parameterType("header")
			.required(false)
			.parameterType("string")			
			.build();
			
		springfox.documentation.service.Parameter acceptParam = new ParameterBuilder()
				.name("Accept-Language")
				.description("Accept-Language Header")
				.defaultValue("ko-KR")
				.parameterType("header")
				.required(false)
				.parameterType("string")				
				.build();
		
		operationParameters.add(authParam);
		operationParameters.add(acceptParam);
*/		
        return new Docket(DocumentationType.SWAGGER_2)
        		.globalOperationParameters(operationParameters)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.wjthinkbig.aimath"))
                .paths(PathSelectors.ant("/api/**"))
                .build()
                .apiInfo(apiInfo());
    }
	
	private ApiInfo apiInfo() { 
		return new ApiInfoBuilder()
				.title("AI 연산서비스 API")
				.description("AI 연산 서비스를 위한 API입니다.")
				.version("1.0")
				.build(); 
		}
}