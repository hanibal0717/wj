package com.wjthinkbig.aimath.config;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wjthinkbig.aimath.security.JwtAuthenticationFilter;
import com.wjthinkbig.aimath.security.auth.ajax.admin.AjaxAdminAuthenticationProvider;
import com.wjthinkbig.aimath.security.auth.ajax.admin.AjaxAdminLoginProcessingFilter;
import com.wjthinkbig.aimath.security.auth.ajax.user.AjaxUserAuthenticationProvider;
import com.wjthinkbig.aimath.security.auth.ajax.user.AjaxUserLoginProcessingFilter;
import com.wjthinkbig.aimath.security.auth.jwt.JwtAuthenticationProvider;
import com.wjthinkbig.aimath.security.auth.jwt.extractor.TokenExtractor;
import com.wjthinkbig.aimath.security.config.JwtSettings;

import lombok.extern.slf4j.Slf4j;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true,prePostEnabled = true)
@Slf4j
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
	public static final String AUTHENTICATION_HEADER_NAME = "Authorization";	
	public static final String AUTHENTICATION_USER_URL = "/api/members/signin";
	public static final String AUTHENTICATION_ADMIN_URL = "/api/account/signin"; 
    public static final String REFRESH_TOKEN_URL = "/api/auth/token";
    public static final String API_ROOT_URL = "/api/**";
    
	/**
	 * 인증처리 핸들러
	 */
	@Resource(name = "authenticationEntryPoint")
	private AuthenticationEntryPoint authenticationEntryPoint;
	
	/**
	 * 권한처리 핸들러
	 */
	@Resource(name = "accessDeniedHandler")
	private AccessDeniedHandler accessDeniedHandler;
	
	/**
	 * 인증 매니저
	 */
	@Bean
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}	
	
	/**
	 * (로그인) 인증성공시 핸들러 - AjaxUserLoginProcessingFilter, AjaxAdminLoginProcessingFilter 호출 
	 */
	@Autowired 
	private AuthenticationSuccessHandler successHandler;
	
	/**
	 * (로그인) 인증실패시 핸들러 - AjaxUserLoginProcessingFilter, AjaxAdminLoginProcessingFilter 호출 
	 */
	@Autowired
	private AuthenticationFailureHandler failureHandler;

	/**
	 * 로그인 인증 프로바이더 (사용자)
	 */
	@Resource(name = "ajaxUserAuthenticationProvider")
	private AjaxUserAuthenticationProvider ajaxUserAuthenticationProvider;

	/**
	 * 로그인 인증 프로바이더 (관리자)
	 */
	@Resource(name = "ajaxAdminAuthenticationProvider")
	private AjaxAdminAuthenticationProvider ajaxAdminAuthenticationProvider;

	/**
	 * JWT 토큰인증 프로바이더
	 */
	@Autowired 
	private JwtAuthenticationProvider jwtAuthenticationProvider; 
		
	/**
	 * JWT 토큰을 가져오는 Extractor 
	 */
	@Autowired
	private TokenExtractor tokenExtractor;

	/**
	 * JWT Settings
	 */
	@Autowired
	private JwtSettings JwtSettings;
	
	/**
	 * JSON ObjectMapper
	 */
	@Autowired 
	private ObjectMapper objectMapper;
	
	/**
	 * 회원인증용 프로바이더
	 *//*
	@Resource(name = "userCustomAuthenticationProvider")
	private UserCustomAuthenticationProvider userCustomAuthenticationProvider;
	
	*//**
	 * 관리자인증용 프로바이더
	 *//*
	@Resource(name = "adminCustomAuthenticationProvider")
	private AdminCustomAuthenticationProvider adminCustomAuthenticationProvider;*/
	

	
	
	/**
	  * @Method 설명 : 해당 로그인 페이지에 대한 로그인처리 필터 (사용자)
	  * @param loginEntryPoint 로그인 페이지 
	  * @return 로그인처리 필터
	  */
	private AjaxUserLoginProcessingFilter buildUserAjaxLoginProcessingFilter(String loginEntryPoint) throws Exception {
		AjaxUserLoginProcessingFilter filter = new AjaxUserLoginProcessingFilter(loginEntryPoint, successHandler, failureHandler, objectMapper);
		filter.setAuthenticationManager(this.authenticationManagerBean());
		return filter;
	}
	
	/**
	  * @Method 설명 : 해당 로그인 페이지에 대한 로그인처리 필터 (관리자)
	  * @param loginEntryPoint 로그인 페이지 
	  * @return 로그인처리 필터
	  */
	private AjaxAdminLoginProcessingFilter buildAdminAjaxLoginProcessingFilter(String loginEntryPoint) throws Exception {
		AjaxAdminLoginProcessingFilter filter = new AjaxAdminLoginProcessingFilter(loginEntryPoint, successHandler, failureHandler, objectMapper);
		filter.setAuthenticationManager(this.authenticationManagerBean());
		return filter;
	}

	/**
	  * @Method 설명 : JWT 토큰인증처리 필터
	  * @param pathsToSkip 인증하지 않아도 되는 경로의 목록
	  * @param pattern 인증대상 경로
	  * @return 처리필터
	  * @throws Exception
	 *//*
	protected JwtTokenAuthenticationProcessingFilter buildJwtTokenAuthenticationProcessingFilter(List<String> pathsToSkip, String pattern) throws Exception {
        SkipPathRequestMatcher matcher = new SkipPathRequestMatcher(pathsToSkip, pattern);
        JwtTokenAuthenticationProcessingFilter filter = new JwtTokenAuthenticationProcessingFilter(failureHandler, tokenExtractor, matcher);
        filter.setAuthenticationManager(this.authenticationManagerBean());
        return filter;
    }*/
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
/*		auth.authenticationProvider(userCustomAuthenticationProvider);
		auth.authenticationProvider(adminCustomAuthenticationProvider);*/	
		auth.authenticationProvider(ajaxAdminAuthenticationProvider);
		auth.authenticationProvider(ajaxUserAuthenticationProvider);
		auth.authenticationProvider(jwtAuthenticationProvider);
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
/*		List<String> permitAllEndpointList = new ArrayList<String>();		
		permitAllEndpointList.add(AUTHENTICATION_USER_URL);		
		permitAllEndpointList.add(AUTHENTICATION_ADMIN_URL);
		permitAllEndpointList.add(REFRESH_TOKEN_URL);		
				
		log.debug("excludeSessionUri : {}", permitAllEndpointList);*/
		
		// API 기본설정 및 오류 처리
	    http
	    	.httpBasic().disable()
	    	.csrf().disable()
	    	.formLogin().disable()
	    	.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)	
	    	.and()
				.exceptionHandling().authenticationEntryPoint(authenticationEntryPoint) // 인증에 실패한 경우
				.accessDeniedHandler(accessDeniedHandler); // 권한이 없는 경우
	    
	    // 요청 경로별 처리
	    http
    		.authorizeRequests()
	    		.antMatchers(HttpMethod.POST, "/api/members").permitAll()				// 회원가입
	    		.antMatchers(HttpMethod.POST, AUTHENTICATION_USER_URL).permitAll() 		// 사용자 로그인
	    		.antMatchers(HttpMethod.POST, AUTHENTICATION_ADMIN_URL).permitAll() 	// 관리자 로그인
	    		.antMatchers(REFRESH_TOKEN_URL).permitAll() 							// 액세스 토큰 재발급
	    		.antMatchers(HttpMethod.GET, "/api/diagnosis/guestid").permitAll()  	// 비회원 세션아이디 발급
	    		.antMatchers(HttpMethod.POST, "/api/members/password").permitAll() 		// 비밀번호 찾기
	    		.antMatchers(HttpMethod.GET, "/api/members/email/verification/**").permitAll()			// 이메일 인증시 경로 
	    		.antMatchers(HttpMethod.GET, "/api/integration/smartall/contracts/**").permitAll()  //스마트올 연동 
	    		.antMatchers("/api/members/**").hasAnyRole("USER","ADMIN")
	    		.antMatchers("/api/account/**").hasAnyRole("ADMIN")
	    		.antMatchers("/api/members/email/verification/**").permitAll()			// 이메일 인증시 경로 
				.antMatchers("/api/diagnosis/**").permitAll() 							// 비회원, 회원 진단학습 모두 허용
	    		;
		    
	    // Custom Filter 처리
	    http 
	    	.addFilterBefore(new JwtAuthenticationFilter(tokenExtractor, JwtSettings), UsernamePasswordAuthenticationFilter.class)
	    	.addFilterBefore(buildUserAjaxLoginProcessingFilter(AUTHENTICATION_USER_URL), UsernamePasswordAuthenticationFilter.class)
	    	.addFilterBefore(buildAdminAjaxLoginProcessingFilter(AUTHENTICATION_ADMIN_URL), UsernamePasswordAuthenticationFilter.class)
	    	/*.addFilterBefore(buildJwtTokenAuthenticationProcessingFilter(permitAllEndpointList, API_ROOT_URL), UsernamePasswordAuthenticationFilter.class)*/
	    	;
	}
	
	@Override
	public void configure(WebSecurity web) throws Exception {
		// SpringSecurity에서는 Security FilterChain을 적용하고 싶지 않은 리소스에 대해 설정을 할수있도록 ignoring() 메소드를 제공
		web.ignoring()
			.antMatchers("/v2/api-docs")
			.antMatchers("/swagger-resources/**")
			.antMatchers("/swagger-ui.html")
			.antMatchers("/configuration/**")
			.antMatchers("/webjars/**")
			.antMatchers("/exception/**")	// ExceptionController(인증이나 권한실패 시 리다이렉트할 컨트롤러) 참조경로
			.antMatchers("/error/**")		// CustomErrorController 참조경로
			;
		
		// 정적자원에 대해 스프링 시큐리티 필터를 타지 않도록 설정
		web.ignoring().requestMatchers(PathRequest.toStaticResources().atCommonLocations());
	}
}