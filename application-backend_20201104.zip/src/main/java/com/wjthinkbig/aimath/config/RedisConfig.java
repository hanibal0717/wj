package com.wjthinkbig.aimath.config;

import java.time.Duration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisClusterConfiguration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.session.data.redis.config.ConfigureRedisAction;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 10. 
  * @프로그램 설명 : Redis 설정
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 10.     Lee Seung Hyuk              최초작성
  * </pre>
 */
@Slf4j
@Configuration
public class RedisConfig {
	
	@Autowired
	RedisProperties properties; 
	
	@Bean
    public RedisConnectionFactory redisConnectionFactory() {
        
        if(!"localhost".equals(properties.getHost()) && properties.isSsl()) {
        	/* * 
        	 * Redis client configuration for lettuce. This configuration provides optional configuration elements such as ClientResources and * ClientOptions specific to Lettuce client features. 
        	 * Providing optional elements allows a more specific configuration of the client: 
        	 * 
        	 * Whether to use SSL 
        	 * Whether to verify peers using SSL 
        	 * Whether to use StartTLS 
        	 * Optional ClientResources 
        	 * Optional ClientOptions, defaults to ClientOptions with enabled TimeoutOptions. 
        	 * Optional client name 
        	 * Optional ReadFrom. Enables Master/Replica operations if configured. 
        	 * Client timeout 
        	 * Shutdown timeout 
        	 * Shutdown quiet period  
        	*/
        	LettuceClientConfiguration clientConfig = null;
        	clientConfig = LettuceClientConfiguration.builder()
        		.useSsl()
        		.and()
        		.commandTimeout(Duration.ofSeconds(2))
        		.shutdownTimeout(Duration.ZERO)
        		.build();
        	
        	RedisClusterConfiguration config = new RedisClusterConfiguration();
        	config.clusterNode(properties.getHost(), properties.getPort());
        	config.setPassword(properties.getPassword());
        	
        	return new LettuceConnectionFactory(config, clientConfig);        		
        } else {
        	LettuceClientConfiguration clientConfig = null;
        	clientConfig = LettuceClientConfiguration.builder()
        			.commandTimeout(Duration.ofSeconds(2))
        			.shutdownTimeout(Duration.ZERO)
        			.build();
        	
        	RedisStandaloneConfiguration config = new RedisStandaloneConfiguration(properties.getHost(), properties.getPort());
        	config.setPassword(properties.getPassword());
        	return new LettuceConnectionFactory(config, clientConfig);
        }
    }

	@Bean(name="redisTemplate")
    public RedisTemplate<String, Object> redisTemplate() {		
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
        
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        /*redisTemplate.setValueSerializer(new GenericToStringSerializer<Object>(Object.class));*/
        redisTemplate.setValueSerializer(new Jackson2JsonRedisSerializer<>(Object.class));        
        redisTemplate.setConnectionFactory(redisConnectionFactory());        
        
        return redisTemplate;
    }	
	
	@Bean
	public static ConfigureRedisAction configureRedisAction() {
        return ConfigureRedisAction.NO_OP;
    }
}