package com.wjthinkbig.aimath.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.boot.autoconfigure.SpringBootVFS;
import org.springframework.aop.Advisor;
import org.springframework.aop.aspectj.AspectJExpressionPointcut;
import org.springframework.aop.support.DefaultPointcutAdvisor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.interceptor.DefaultTransactionAttribute;
import org.springframework.transaction.interceptor.RollbackRuleAttribute;
import org.springframework.transaction.interceptor.RuleBasedTransactionAttribute;
import org.springframework.transaction.interceptor.TransactionInterceptor;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.core.support.mybatis.annotation.MapperBeanNameGenerator;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
@MapperScan(
		basePackages = "com.wjthinkbig.aimath.**.dao",
		sqlSessionFactoryRef = "defaultSqlSessionFactory",
		annotationClass = Mapper.class,
		nameGenerator = MapperBeanNameGenerator.class
)
public class DefaultSqlSessionConfig {

	@Autowired
	private ApplicationContext applicationContext;
	
	@Primary
	@Bean(name = "defaultHikariConfig")
	@ConfigurationProperties(prefix="spring.datasource.hikari")
	public HikariConfig hikariConfig() {
		return new HikariConfig();
	}

	@Primary
	@Bean(name = "defaultDataSource", destroyMethod = "close")	
	public DataSource dataSource(@Qualifier("defaultHikariConfig") HikariConfig config) throws Exception {
		DataSource dataSource = new HikariDataSource(config);
		log.info("Default DataSource : {}", dataSource.toString());	
		log.info("Default JdbcUrl : {}", config.getJdbcUrl());
		return dataSource;
	}

	@Primary
	@Bean(name = "defaultSqlSessionFactory")
	public SqlSessionFactory sqlSessionFactory(@Qualifier("defaultDataSource") DataSource dataSource) throws Exception {
		SqlSessionFactoryBean sqlSessionFactoryBean = new SqlSessionFactoryBean();
		sqlSessionFactoryBean.setDataSource(dataSource);
		sqlSessionFactoryBean.setVfs(SpringBootVFS.class);
		sqlSessionFactoryBean.setConfigLocation(applicationContext.getResource("classpath:/mybatis-config.xml"));
		sqlSessionFactoryBean.setMapperLocations(applicationContext.getResources("classpath*:/sqlmap/**/*_BRS_Mapper.xml"));		
		return sqlSessionFactoryBean.getObject();
	}
	
	@Primary
	@Bean(name = "defaultSqlSessionTemplate")
	public SqlSessionTemplate sqlSessionTemplate(@Qualifier("defaultSqlSessionFactory") SqlSessionFactory sqlSessionFactory) {
		return new SqlSessionTemplate(sqlSessionFactory);
	}
	
	@Primary
	@Bean(name = "defaultTransactionManager")
	public PlatformTransactionManager transactionManager(@Qualifier("defaultDataSource") DataSource dataSource) throws Exception {
		return new DataSourceTransactionManager(dataSource);
	}
	
	@Primary
	@Bean(name = "defaultTransactionAdvice")
	public TransactionInterceptor transactionAdvice(@Qualifier("defaultTransactionManager") PlatformTransactionManager transactionManager) {
		
		TransactionInterceptor transactionInterceptor = new TransactionInterceptor();
		
		Properties transactionAttributes = new Properties();
		
		// 트랜잭션 롤백 룰 설정
		List<RollbackRuleAttribute> rollbackRules = new ArrayList<RollbackRuleAttribute>();
		rollbackRules.add(new RollbackRuleAttribute(Exception.class));
				
		// 읽기전용 트랜잭션 속성 설정
		DefaultTransactionAttribute readOnlyAttribute = new DefaultTransactionAttribute();
		readOnlyAttribute.setReadOnly(true);
		
		String readOnlyAttributesDefinition = readOnlyAttribute.toString();
		log.info("읽기전용 트랜잭션 속성 : {}", readOnlyAttributesDefinition);
				
		// 기본 트랜잭션 속성 설정
		RuleBasedTransactionAttribute writeAttribute = new RuleBasedTransactionAttribute(
				TransactionDefinition.PROPAGATION_REQUIRED, rollbackRules);
				
		String writeAttributesDefinition = writeAttribute.toString();
		log.info("기본 트랜잭션 속성 : {}", writeAttributesDefinition);
		
		transactionAttributes.setProperty("insert*", writeAttributesDefinition);
		transactionAttributes.setProperty("update*", writeAttributesDefinition);
		transactionAttributes.setProperty("delete*", writeAttributesDefinition);
		transactionAttributes.setProperty("merge*", writeAttributesDefinition);
		transactionAttributes.setProperty("save*", writeAttributesDefinition);
		transactionAttributes.setProperty("create*", writeAttributesDefinition);
		transactionAttributes.setProperty("drop*", writeAttributesDefinition);
		transactionAttributes.setProperty("cancel*", writeAttributesDefinition);
		transactionAttributes.setProperty("proc*", writeAttributesDefinition);
		transactionAttributes.setProperty("apply*", writeAttributesDefinition);
		
		transactionInterceptor.setTransactionManager(transactionManager);		
		transactionInterceptor.setTransactionAttributes(transactionAttributes);
		
		return transactionInterceptor;
	}
	
	@Primary
	@Bean(name = "defaultAdvisor")
	public Advisor txAdviceAdvisor(@Qualifier("defaultTransactionAdvice") TransactionInterceptor transactionInterceptor) {
		AspectJExpressionPointcut pointcut = new AspectJExpressionPointcut();
		pointcut.setExpression("execution(* com.wjthinkbig.aimath..impl.*Impl.*(..))");				
		return new DefaultPointcutAdvisor(pointcut, transactionInterceptor);
	}
}