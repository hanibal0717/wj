package com.wjthinkbig.aimath.mbr.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.mbr.vo.SmartAllMbrVO;
import com.wjthinkbig.aimath.security.model.token.JwtToken;
import com.wjthinkbig.aimath.security.model.token.JwtTokenFactory;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 : AI연산 회원서비스 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * 2020. 9. 17.    Kim Hee Seok              수정작업 
  * </pre>
  */
@Slf4j
@Api(description = "서비스 회원정보")
@RestController
public class MbrController extends BaseController {
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 회원서비스
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService; 
	
	@Resource(name = "userDetailsService")
	protected UserDetailsService userDetailsService;
	/**
	 * 단방향 암호화
	 */
	@Autowired
	@Qualifier("passwordEncoder")
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private JwtTokenFactory tokenFactory;
	
	/**
	  * @Method 설명 : selectMbrEmailAuth 이메일 인증 
	  * @작성일 : 2020. 10. 5
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param code
	  * @return
	  * @throws Exception
	*/
	@ApiOperation(value = "이메일 url 인증")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/email/verification/{code}")
	public CommonResult selectMbrEmailAuth(@ApiParam(value = "회원아이디 암호화 코드") @PathVariable(name="code",required=true) String code) throws Exception {
		int rows=mbrService.updateEmailCertYn(code);
		if(rows == 0) {
			throw this.processException("S002009"); // 이메일 인증이 실패하였습니다. 
		}
		return responseService.getResult(true); 
	}
	
	/**
	  * @Method 설명 : selectPwByEmail 	비밀번호 찾기 
	  * @작성일 : 2020. 9. 29
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param mbr
	  * @return
	  * @throws Exception
	*/
	@ApiOperation(value="회원 비밀번호 찾기")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/members/password")
	public CommonResult selectPwByEmail(@ApiParam(value = "회원 객체") @RequestBody MbrVO mbr) throws Exception {
		mbrService.selectPwByEmail(mbr);
		return responseService.getResult(true,"S001023",mbr.getEmailAdrs());
	}
	
	/**
	  * @Method 설명 : 회원
	  * @param userContext MbrAccount
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="회원 로그아웃", tags = "인증")	
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/members/signout")	
	public CommonResult logout(@ApiParam(value="로그인 회원 객체") @AuthenticationPrincipal User userContext) throws Exception {
		if(userContext instanceof MbrAccount) {
			log.info("사용자 로그아웃 : ({}) {}", userContext.getClass().getSimpleName(), ((MbrAccount)userContext).getUserId());
			
			// Redis에서 이 회원의 리프레시 토큰을 제거한다.
			mbrService.signout(userContext);
			
			return responseService.getResult(true);
		} else {
			// 사용자 로그인을 통해 발급된 토큰이 아닌 경우
			return responseService.getResult(false);
		}
	}
	
	/**
	  * @Method 설명 : 가입자 회원을 신규 등록(가입)한다.
	  * @param userVO 등록할 회원정보를 담은 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "가입자 회원 신규등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/members")
	public CommonResult insertMbr(@ApiParam(value = "가입자회원정보") @Validated(value = Groups.Insert.class) @RequestBody MbrVO mbr) throws Exception {
		mbrService.insertMbr(mbr);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 가입자회원 전체조회
	  * @param account
	  * @param userSearch 회원검색VO
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="가입자 회원 전체조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members")
	public SingleResult<HashMap<String,Object>> selectMbrsList(@ApiParam(value = "회원검색VO") @Valid @ModelAttribute MbrSearchVO mbrSearch) throws Exception {
		// 검색유형을 선택하지 않았을 경우 
		if(mbrSearch.getSrchTy() == null) {
			throw this.processException("S002002");
		}
		
		mbrSearch.setRowCnt((int)mbrSearch.getRowCnt());
		mbrSearch.setCurrentPage((int)mbrSearch.getCurrentPage());
		
		int cnt = mbrService.selectMbrsCnt(mbrSearch);		
		List<MbrVO> mbrs = mbrService.selectMbrs(mbrSearch);
		
		HashMap<String, Object> data = new HashMap<String, Object>();
		data.put("mbrs", mbrs);
		data.put("totalCount", cnt);
		return responseService.getSingleResult(data);
	}
	
	/**
	  * @Method 설명 : 특정 가입자의 회원정보를 조회한다.
	  * @param mbrId 가입자회원ID
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/{member}")
	public SingleResult<MbrVO> selectMbrById(@ApiParam(value = "가입자회원ID") @PathVariable(name="member",required=true) String mbrId) throws Exception {
		MbrVO mbr = mbrService.selectMbrById(mbrId);
		if(mbr == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		return responseService.getSingleResult(mbr);
	}
	
	/**
	  * @Method 설명 : 특정 가입자의 회원정보를 변경한다. (비밀번호와 전화번호만 변경)
	  * @param mbrId 가입자회원ID
	  * @param mbr 변경할 가입자정보
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원정보 변경")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}")
	public CommonResult updateMbr(@ApiParam(value = "가입자회원ID") @PathVariable(name="member",required=true) String mbrId
			, @ApiParam(value="가입자정보 VO") @Validated(value = Groups.Update.class) @RequestBody MbrVO mbr) throws Exception {
		// 변경할 회원정보를 가져온다.
		MbrVO mbrSrc = mbrService.selectMbrById(mbrId);
		if(mbrSrc == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}	
		
		// 입력한 비밀번호가 있고 기존 비밀번호와 다른 경우 
		if(StringUtils.isNotBlank(mbr.getPw()) && !passwordEncoder.matches(mbr.getPw(), mbrSrc.getPw() == null ? "" : mbrSrc.getPw())) {
			mbrSrc.setPw(passwordEncoder.encode(mbr.getPw()));
			mbrSrc.setPwChngeDt(LocalDateTime.now());
		} else {
			mbrSrc.setPwChngeDt(null);
			mbrSrc.setPw(null);
		}
		
		BeanUtils.copyProperties(mbrSrc, mbr);
		
		if(!StringUtils.isNotBlank(mbr.getPhone())) {
			mbr.setPhone(mbr.getPhoneEn()); //전화번호 암호화
		}
		
		int rows = mbrService.updateMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 특정 가입자의 회원정보를 삭제한다.
	  * @param mbrId 가입자회원ID
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="특정 가입자 회원정보 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/members/{member}")	
	public CommonResult deleteMbr(@ApiParam(value = "가입자회원ID") @PathVariable(name="member",required=true) String member) throws Exception {
		// 삭제할 회원정보를 가져온다.
		MbrVO mbr = mbrService.selectMbrById(member);
		if(mbr == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		// 변경자 정보
		mbr.setModUser(LoginUtils.getUserId());
		mbr.setModDt(LocalDateTime.now());
		
		// 가입자 및 가입자의 학습자를 모두 삭제상태로 변경처리한다.
		int rows = mbrService.deleteMbr(mbr);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);		
	}

	
	
	
	
	
	
	
	
	
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 학습자 회원을 신규 등록한다.
	  * @param member 가입자회원ID
	  * @param mbrLrn 등록할 학습자정보
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원의 학습자회원 신규등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/members/{member}/learners")	
	public CommonResult insertMbrLrn(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member
			, @ApiParam(value = "학습자회원ID") @Validated(value = Groups.Insert.class) @RequestBody MbrLrnVO mbrLrn) throws Exception {	
		MbrVO mbr = mbrService.selectMbrById(member);
		if(mbr == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		// @RequestBody를 통해 전송된 데이터에 가입자ID가 있다면 경로변수의 가입자 ID와 일치해야 한다. 
		if(StringUtils.isBlank(mbrLrn.getSbsceMbrId()) || !member.equals(mbrLrn.getSbsceMbrId())) {
			throw this.processException("S002008"); // 데이터가 일치하지 않습니다. 
		}
		mbrService.insertMbrLrn(mbrLrn);
		return responseService.getResult(true);		
	}
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 특정 학습자 정보를 조회한다.
	  * @param mbrId 가입자회원ID
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원의 특정 학습자정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/members/{member}/learners/{learner}")
	public SingleResult<MbrLrnVO> selectLearnerOfMbr(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member
			, @ApiParam(value = "학습자회원ID") @PathVariable(name="learner",required=true) String learner) throws Exception {
		MbrVO mbr = mbrService.selectMbrById(member);
		MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
		if(mbrLrn == null || mbr == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		// 해당 학습자의 가입자회원ID가 경로변수와 일치해야 한다. 
		if(!member.equals(mbrLrn.getSbsceMbrId())) {
			throw this.processException("S002001"); // 해당 학습자 정보를 처리할 수 없습니다.
		}
		return responseService.getSingleResult(mbrLrn);
	}
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 특정 학습자정보를 변경한다. (이름,성별만 변경)
	  * @param MbrLrnVO 변경할 학습자정보
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value = "특정 가입자 회원의 특정 학습자정보 변경")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}/learners/{learner}")
	public CommonResult updateLearnerOfMbr(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member
			, @ApiParam(value = "학습자회원ID") @PathVariable("learner") String learner
			, @ApiParam(value="학습회원 VO") @Validated(value = Groups.Update.class)  @RequestBody MbrLrnVO mbrLrn) throws Exception {
		// @RequestBody를 통해 전송된 데이터에 가입자ID가 있다면 경로변수의 가입자 ID와 일치해야 한다.
		if(StringUtils.isBlank(mbrLrn.getSbsceMbrId()) || !member.equals(mbrLrn.getSbsceMbrId())
				 || StringUtils.isBlank(mbrLrn.getMbrId()) || !learner.equals(mbrLrn.getMbrId())) {
			throw this.processException("S002000"); // 학습자 정보가 일치하지 않습니다.
		}
		int rows = mbrService.updateMbrLrn(mbrLrn);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 학습자정보를 일괄 변경한다. 
	  * @param mbrLrnSaveVO 학습자 VO의 리스트 객체 
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value = "특정 가입자 회원의 학습자회원정보 일괄변경", notes = "전송한 VO 리스트에 대해 일괄적으로 등록, 수정 또는 삭제 처리를 한다.")	
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/members/{member}/learners")	
	public CommonResult learnersUpdate(@PathVariable("member") String member
			, @Validated(value = Groups.Update.class) @RequestBody @ApiParam(value = "일괄처리 MbrLrnVO 리스트") SaveVO<MbrLrnVO> mbrLrnSaveVO) throws Exception {
		int rows = mbrService.learnersUpdate(member, mbrLrnSaveVO);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 특정 가입자 회원의 특정 학습자정보를 삭제한다. (상태변경)
	  * @param member 가입자ID
	  * @param mbrId 학습자ID
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="특정 가입자 회원의 특정 학습자정보 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/members/{member}/learners/{learner}")
	public CommonResult deleteLearnerOfMbr(@ApiParam(value = "가입자회원ID") @PathVariable("member") String member
			, @ApiParam(value = "학습자회원ID") @PathVariable(name="learner", required=true) String learner) throws Exception {
		// 가입회원의 학습회원 가지고 온다.
		MbrVO mbrSrc = mbrService.selectMbrById(member);
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrSrc == null || mbrLrnSrc == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		if(mbrSrc.getMbrLrnCnt() < 2) {
			throw this.processException("S002003");		// 더이상 학습회원을 삭제할 수 없습니다. 
		}
		MbrLrnVO mbrLrn = new MbrLrnVO();
		mbrLrn.setSbsceMbrId(member);
		mbrLrn.setMbrId(learner);
		mbrLrn.setModDt(LocalDateTime.now());
		mbrLrn.setModUser(LoginUtils.getUserId());
		
		int rows = mbrService.deleteMbrLrn(mbrLrn);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		return responseService.getResult(true);
	}	
	
	/**
	 * @Method 설명 : 특정 학습자의 진입 로그를 쌓고 같은 학습회원 진입을 막는다.
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @param member
	 * @param learner
	 * @return responseService.getResult(true)
	 * @throws Exception
	 */
	@ApiOperation(value="특정 학습자의 진입 로그를 쌓고 같은 학습회원 진입을 막는다.")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/log/members/{member}/learners/{learner}")
	public CommonResult insertLearnerOfMbrLog(HttpServletRequest request, HttpServletResponse response
			, @ApiParam(value = "가입자회원ID") @PathVariable("member") String member
			, @ApiParam(value = "학습자회원ID") @PathVariable(name="learner", required=true) String learner) throws Exception{
		// 가입회원의 학습회원 수를 가지고 온다.
		MbrVO mbrSrc = mbrService.selectMbrById(member);
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrSrc == null || mbrLrnSrc == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		mbrService.insertMbrLrnLog(learner,request,response);
		return responseService.getResult(true);
	}
	
	/**
	 * @Method 설명 : selectSmartAllIntegration 스마트 올 연동 (스마트 올 패드에서 호출 )
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @return
	 * @throws Exception 
	 */
	@ApiOperation(value="스마트올 패드에 호출 ")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/integration/smartall/contracts/{contract}/languages/{language}")
	public SingleResult<HashMap<String, Object>> selectSmartAllIntegration(@ApiParam(value = "계약번호") @PathVariable(name="contract", required=true) String contract
			, @ApiParam(value = "언어코드") @PathVariable(name="language", required=true) String language
			, HttpServletRequest request) throws Exception {
		MbrVO smMbr = mbrService.selectMbrByCtrCode(contract);
		MbrVO mbr = new MbrVO();
		if(smMbr == null) {
			// **자동회원 가입부터 자동 로그인 까지** 
			// 1.스마트 올 api를 호출 하여 학습자 정보를 가져온다 
			SmartAllMbrVO smInfo = new SmartAllMbrVO();
			smInfo.setCtrCode(contract);
			smInfo.setMbrNm("스타트올1");
			smInfo.setBrthmt("201012");
			smInfo.setSxdnCd("F");
			smInfo.setLangCd(language);
			this.validateOrElseThrow(smInfo);
			// 2.회원 가입을 한다 (insert)
			mbr = mbrService.insertSmartAllMbr(smInfo);
		} else {
			mbr = smMbr;
		}
		
		// 로그인 한다 
		UserDetails user = userDetailsService.loadUserByUsername(mbr.getEmailAdrs());
		Authentication authentication = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
		SecurityContext securityContext = SecurityContextHolder.getContext();
	    securityContext.setAuthentication(authentication);
	    HashMap<String, String> additionalClaims = new HashMap<String, String>();
	    User usr = (MbrAccount) authentication.getPrincipal();	
	    additionalClaims.put("mbr", ((MbrAccount) usr).getUserId());
	    JwtToken accessToken = tokenFactory.createAccessJwtToken(usr, additionalClaims);
	    JwtToken refreshToken = tokenFactory.createRefreshToken(usr, additionalClaims);
	    // 로그인 됐으면 로그를 쌓는다.
	    if(LoginUtils.isLogin()) {
	    	try {
	    		mbrService.insertLog(accessToken.getToken(), request);
	    	} catch (Exception e) {    			
	    		e.printStackTrace();
	    	}
		}
	    HashMap<String, Object> rst = new HashMap<String, Object>();
	    rst.put("accessToken", accessToken.getToken());
	    rst.put("refreshToken", refreshToken.getToken());
	    rst.put("mbr", mbr);
		return responseService.getSingleResult(rst);
	}
}