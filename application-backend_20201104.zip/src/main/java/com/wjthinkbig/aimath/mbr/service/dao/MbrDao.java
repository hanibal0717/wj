/**
 * 
 */
package com.wjthinkbig.aimath.mbr.service.dao;

import java.util.HashMap;
import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrTermsVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
/**
  * @Date : 2020. 9. 25 
  * @프로그램 설명 : MbrDao.java
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 25          Kim Hee Seok       최초작성
  * </pre>
  */
@Mapper("mbrDao")
public interface MbrDao {

	/**
	  * @Method 설명 : 신규 회원을 등록(가입)한다.
	  * @param user 등록할 회원정보를 담고 있는 VO 객체
	  */
	void insertMbr(MbrVO mbr);
	
	/**
	  * @Method 설명 : 신규 회원을 등록(가입)한다.
	  * @param user 등록할 회원정보를 담고 있는 VO 객체
	  */
	void insertMbrLrn(MbrLrnVO mbrLrn);
	
	/**
	  * @Method 설명 : 약관동의 여부 리스트를 등록한다.
	  * @작성일 : 2020. 10. 6
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param vo
	*/
	void insertMbrTerms(MbrTermsVO vo);
	
	/**
	  * @Method 설명 : 특정 가입 회원정보를 조회한다.
	  * @param mbrId 회원식별코드
	  * @return
	  */
	MbrVO selectMbrById(String mbrId);
	
	/**
	  * @Method 설명 : 특정 회원의 학습자 리스트 조회
	  * @param mbr_id
	  * @return
	  */
	List<MbrLrnVO> selectMbrLrnListById(String sbsceMbrId);
	
	/**
	  * @Method 설명 : 특정 학습 회원조회
	  * @param mbr_id
	  * @return
	  */
	MbrLrnVO selectMbrLrnById(String sbsceMbrId);
	
	/**
	  * @Method 설명 : 해당 이메일 주소를 가지고 있는 회원의 존재여부를 반환한다.
	  * @param email 이메일 주소
	  * @return 회원이 이미 있으면 true, 없으면 false  
	 */
	boolean isExistsByEmail(String email);

	/**
	  * @Method 설명 :
	  * @param username
	  * @return
	  */
	MbrVO selectMbrByEmail(String email);

	/**
	  * @Method 설명 : 학습자 삭제
	  * @param user
	  * @return
	  */
	int deleteMbrLrn(MbrLrnVO mbrLrn);
	
	/**
	  * @Method 설명 : 회원정보 삭제
	  * @param user
	  * @return
	  */
	int deleteMbr(MbrVO mbr);
	
	/**
	  * @Method 설명 : 가입회원 아이디를 가진 학습회원 일괄삭제
	  * @param sbsceMbrId
	  * @return
	  */
	void deleteMbrLrnBySbsceId(MbrVO mbr);
	/**
	  * @Method 설명 : 회원정보 변경
	  * @param user
	  */
	int updateMbr(MbrVO mbr);
	
	/**
	  * @Method 설명 : 학습자 정보 변경
	  * @param user
	 * @return 
	  */
	int updateMbrLrn(MbrLrnVO mbrLrn);
	
	/**
	  * @Method 설명 : 전체 회원정보를 가져온다.
	  * @return 전체 회원리스트
	 */
	List<MbrVO> selectMbrs(MbrSearchVO mbrSearch);
	
	/**
	  * @Method 설명 : 전체 회원 수를 가져온다.
	  * @param userSearch
	  * @return
	  */
	int selectMbrsCnt(MbrSearchVO mbrSearch);
	
	/**
	  * @Method 설명 : 이메일 인증업데이트 한다
	  * @param userSearch
	  * @return
	  */
	int updateEmailCertYn(String mbrId);
	
	/**
	  * @Method 설명 : insertMbrLog 로그인 정보 로그를 쌓는다 
	  * @작성일 : 2020. 9. 28
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param string
	*/
	void insertMbrLog(HashMap<String, Object> logData);

	/**
	 * @Method 설명 : insertMbrLrnLog 학습회원 로그인 정보를 입력한다 
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @param logData
	 */
	void insertMbrLrnLog(HashMap<String, Object> logData);

	/**
	 * @Method 설명 : selectMbrByCtrCode   스마트 올 연동 (스마트 올 패드에서 호출 )
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @param contract 
	 * @return MbrVO
	 */
	MbrVO selectMbrByCtrCode(String contract);

	
	
}
