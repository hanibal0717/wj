package com.wjthinkbig.aimath.mbr.service.impl;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.DateUtils;
import com.wjthinkbig.aimath.core.utils.EmailUtils;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.SeedUtils;
import com.wjthinkbig.aimath.core.utils.SessionUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.utils.WebUtil;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.service.dao.MbrDao;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrTermsVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.mbr.vo.SmartAllMbrVO;
import com.wjthinkbig.aimath.security.JwtUtils;
import com.wjthinkbig.aimath.terms.service.dao.TermsDao;
import com.wjthinkbig.aimath.terms.vo.TermsHstSearchVO;
import com.wjthinkbig.aimath.terms.vo.TermsHstVO;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 : 회원관리 서비스 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
@Service("mbrService")
public class MbrServiceImpl extends BaseServiceImpl implements MbrService {

	/**
	 * 채널구분코드
	 */
	@Value("${systemId}")
	String sysScnCd;
	
	/**
	 * 회원서비스 Dao
	 */
	@Resource(name = "mbrDao")
	private MbrDao mbrDao;
	
	/**
	 * 이용약관 Dao
	 */
	@Resource(name = "termsDao")
	private TermsDao termsDao;
	
	/**
	 * 인증을 처리하는 Spring Security AuthenticationManager
	 */
	/*@Autowired
	private AuthenticationManager authenticationManager;*/ 

	/**
	 * JWT Utility
	 */
	@Resource(name = "jwtUtils")
	private JwtUtils jwtUtils;	
		
	/**
	 * 단방향 암호화
	 */
	@Autowired
	@Qualifier("passwordEncoder")
	private PasswordEncoder passwordEncoder;
	
	/**
	 * 회원ID 신규생성 서비스
	 */
	@Resource(name = "mbrIdGenService")
	private EgovIdGnrService mbrIdGenService;
	
	/**
	 * 학습 회원ID 신규생성 서비스
	 */
	@Resource(name = "lrnIdGenService")
	private EgovIdGnrService lrnIdGenService;
	
	/**
	 * 비회원 (guest) 아이디 신규생성 서비스
	 */
	@Resource(name = "gstIdGenService")
	private EgovIdGnrService gstIdGenService;
	
	/**
	 * Email Utility
	 */
	@Resource(name = "emailUtils")
	private EmailUtils emailUtils;	
	
	/**
	 * url 암호화 Utility
	 */
	@Resource(name = "seedUtils")
	private SeedUtils seedUtils;	
		
	/**
	 * Redis Template
	 */
	@Resource(name = "redisTemplate")
	private RedisTemplate<String, Object> redisTemplate;
	
	/**
	 * Session Utility
	 */
	@Resource(name = "sessionUtils")
	private SessionUtils sessionUtils;	

	
	@Override
	public void insertMbr(MbrVO mbr) throws Exception {
		
		// 회원ID 채번
		String newMbrId = mbrIdGenService.getNextStringId();
		mbr.setMbrId(newMbrId);
		
		// 채널구분코드
		if(StringUtils.isBlank(mbr.getChnCd())) {
			mbr.setChnCd(sysScnCd);
		}
		
		//회원삭제여부
		mbr.setDelYn("N");
		
		// 이메일인증여부 (단독 서비스의 경우 반드시 필수이므로 초기 N, 연동서비스의 경우 자동로그인이므로 NULL)
		if(StringUtils.isNotBlank(mbr.getEmailAdrs())) {
			mbr.setEmailCertYn("N");
		}
		mbr.setPwChngeDt(LocalDateTime.now());
		mbr.setLoginUser(newMbrId);
		
		if(StringUtils.isBlank(mbr.getSessionId())) {
			mbr.setSessionId(gstIdGenService.getNextStringId());
		}
		
		// 입력값 검증 (신규등록시)				
		this.validateOrElseThrow(mbr, Groups.Insert.class);
		
		// 비밀번호  암호화 (단독 서비스에서 비밀번호를 입력받은 경우에만 세팅, 스마트올과 같은 연동서비스의 경우 자동로그인하므로 NULL) 
		if(StringUtils.isNotBlank(mbr.getPw())) {
			mbr.setPw(passwordEncoder.encode(mbr.getPw()));
		}		
		
		// 가입할 이메일이 이미 등록되어 있는지 확인 (단독 서비스의 경우 반드시 필수, 연동서비스의 경우 자동로그인이므로 NULL)

		String rawEmail = mbr.getEmailAdrs();	// 암호화전 이메일
		String encEmail = mbr.getEmailAdrsEn();	// 이메일 암호화
		
		if(mbrDao.isExistsByEmail(encEmail)) {
			throw this.processException("S001015"); // 해당 이메일은 이미 등록되어 있습니다.
		}
		
		MbrLrnVO mbrLrn = mbr.getMbrLrnList().get(0);
		
		// 회원ID 채번
		String newMbrLrnId = lrnIdGenService.getNextStringId();
		mbrLrn.setMbrId(newMbrLrnId);
		
		mbrLrn.setSbsceMbrId(mbr.getMbrId());
		
		// 이모티콘 셋팅 
		mbrLrn.setEmotcSno(1);

		// 학습 회원삭제여부
		mbrLrn.setDelYn("N");		
		
		mbrLrn.setLoginUser(newMbrId);
		// 학습회원 입력값 검증 (신규등록시)				
		this.validateOrElseThrow(mbrLrn, Groups.Insert.class);
		
		mbrDao.insertMbr(mbr);
		mbrDao.insertMbrLrn(mbrLrn);
		
		//회원 약관 여부 등록  
		List<MbrTermsVO> mbrTermsList=mbr.getMbrTermsList();
		for(MbrTermsVO vo : mbrTermsList) {
			//회원 약관VO에 아이디를 셋팅한다.
			vo.setLoginUser(newMbrId);
			vo.setSbsceMbrId(newMbrId);
			this.validateOrElseThrow(vo, Groups.Insert.class);
			mbrDao.insertMbrTerms(vo);
			
		}
		// 인증메일을 보낸다
		emailUtils.mailAuth(seedUtils.getEnCrypt(newMbrId), rawEmail);
	}
	
	@Override
	public MbrVO insertSmartAllMbr(SmartAllMbrVO smInfo) throws Exception {
		MbrVO mbr = new MbrVO();
		MbrLrnVO mbrLrn = new MbrLrnVO();
		
		// 회원ID 채번
		String newMbrId = mbrIdGenService.getNextStringId();
		mbr.setMbrId(newMbrId);
		mbr.setPw(passwordEncoder.encode("SMARTALL"));
		mbr.setChnCd("SMARTALL");
		//회원삭제여부
		mbr.setDelYn("N");
		mbr.setPwChngeDt(LocalDateTime.now());
		mbr.setLoginUser(newMbrId);
		mbr.setSessionId(gstIdGenService.getNextStringId());
		mbr.setEmailCertYn("Y");
		mbr.setEmailAdrs(smInfo.getCtrCode());
		
		// 회원ID 채번
		String newMbrLrnId = lrnIdGenService.getNextStringId();
		mbrLrn.setMbrId(newMbrLrnId);
		mbrLrn.setSbsceMbrId(mbr.getMbrId());
		
		mbrLrn.setMbrNm(smInfo.getMbrNm());
		mbrLrn.setBrthmt(smInfo.getBrthmt());
		mbrLrn.setSxdnCd(smInfo.getSxdnCd());
		// 이모티콘 셋팅 
		mbrLrn.setEmotcSno(1);
		// 학습 회원삭제여부
		mbrLrn.setDelYn("N");		
		mbrLrn.setLoginUser(newMbrId);
		// 학습회원 입력값 검증 (신규등록시)				
		this.validateOrElseThrow(mbrLrn, Groups.Insert.class);
		mbrDao.insertMbr(mbr);
		mbrDao.insertMbrLrn(mbrLrn);
		TermsHstSearchVO termsHstSearch = new TermsHstSearchVO();
		termsHstSearch.setChnCd(mbr.getChnCd());
		termsHstSearch.setLangCd(smInfo.getLangCd());
		List<TermsHstVO> termsHstList=termsDao.selectTermsChannelsList(termsHstSearch);
		//회원 약관 여부 등록
		if(termsHstList != null) {
			for(TermsHstVO vo : termsHstList) {
				//회원 약관VO에 아이디를 셋팅한다.
				MbrTermsVO termsVO = new MbrTermsVO();
				termsVO.setAgrmtYn("Y");
				termsVO.setSbsceMbrId(newMbrId);
				termsVO.setLoginUser(newMbrId);
				termsVO.setTermsId(vo.getTermsId());
				this.validateOrElseThrow(termsVO, Groups.Insert.class);
				mbrDao.insertMbrTerms(termsVO);
				
			}
		}
		return mbr;
	}

	@Override
	public int updateEmailCertYn(String code) throws Exception {
		String mbrId=seedUtils.getDeCrypt(code);
		MbrVO mbr = mbrDao.selectMbrById(mbrId);
		if(mbr == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다
		}
		if(mbr.getEmailCertYn().equals("Y")) {
			throw this.processException("S002010");		// 이미 이메일 인증한 회원입니다. 
		}
		int rows=mbrDao.updateEmailCertYn(mbrId);
		return rows;
	}
	
	@Override
	public void selectPwByEmail(MbrVO mbr) throws Exception {
		MbrVO mbrVO =mbrDao.selectMbrByEmail(mbr.getEmailAdrsEn());
		if(mbrVO == null) {
			throw this.processException("S002011"); //해당 이메일이 존재하지 않습니다. 
		}
		//임시번호 발급 
		String tmpPw = emailUtils.getTempPw(8);
		//암호화 및 업데이트 셋팅
		mbr.setPw(passwordEncoder.encode(tmpPw));
		mbr.setPwChngeDt(LocalDateTime.now());
		mbr.setMbrId(mbrVO.getMbrId());
		mbr.setModDt(LocalDateTime.now());
		mbr.setModUser(mbrVO.getMbrId());
		
		//비밀번호 변경 
		int rows = mbrDao.updateMbr(mbr);
		if(rows == 0) {
			throw this.processException("S002013"); // 임시 비밀번호로 변경 되지 않았습니다. 
		}
		//이메일 발송 
		mbr.setEmailAdrsDe(mbr.getEmailAdrsEn());
		emailUtils.findPw(tmpPw,mbr.getEmailAdrs());
	}
	
	@Override
	public long selectPassedDaysFromChangeDt(String mbrId) throws Exception {
		MbrVO mbrVO = new MbrVO();		
		mbrVO = mbrDao.selectMbrById(mbrId);
		if(mbrVO == null) {
			throw this.processException("S002012");		// 해당 가입자가 존재하지 않습니다
		}
		long elapsedDays = DateUtils.betweenDays(mbrVO.getPwChngeDt(), LocalDateTime.now());		
		return elapsedDays;
	}

	@Override
	public void insertMbrLrn(MbrLrnVO mbrLrn) throws Exception{
		// 등록하려는 학습자 정보가 이미 가입자의 학습자 중에 존재하는지 확인 (이름/성별/생년월)
		List<MbrLrnVO> learners = mbrDao.selectMbrLrnListById(mbrLrn.getSbsceMbrId());
		long learnerCnt = learners.stream().filter(x -> {
			return x.getBrthmt().equals(mbrLrn.getBrthmt()) &&
					x.getMbrNm().equals(mbrLrn.getMbrNm()) &&
					x.getSxdnCd().equals(mbrLrn.getSxdnCd());
		}).count();
		
		if(learnerCnt > 0) {
			throw this.processException("S001004"); // 이미 사용자가 등록되어 있습니다.
		}
		
		String newMbrLrnId = lrnIdGenService.getNextStringId();
		mbrLrn.setMbrId(newMbrLrnId);
				
		//이모티콘 셋팅 
		mbrLrn.setEmotcSno(1);

		//학습 회원삭제여부
		mbrLrn.setDelYn("N");
		
		mbrLrn.setLoginUser(mbrLrn.getSbsceMbrId());

		// 입력값 검증 (신규등록시)				
		this.validateOrElseThrow(mbrLrn);
		mbrDao.insertMbrLrn(mbrLrn);
	}

	@Override
	public MbrVO selectMbrById(String mbrId) throws Exception {
		MbrVO mbr = mbrDao.selectMbrById(mbrId);
		if(mbr != null) {
			mbr.setEmailAdrsDe(mbr.getEmailAdrs()); //이메일 복호화
			mbr.setPhoneDe(mbr.getPhone());//전화번호 복호화
			
			mbr.setMbrLrnList(mbrDao.selectMbrLrnListById(mbrId));
		}
		return mbr;
	}
	
	@Override
	public MbrLrnVO selectMbrLrnById(String mbrLrnId) throws Exception {
		MbrLrnVO mbrLrn = mbrDao.selectMbrLrnById(mbrLrnId);
		return mbrLrn;
	}
	
	@Override
	public int deleteMbrLrn(MbrLrnVO mbrLrn) throws Exception {
		mbrLrn.setModUser(LoginUtils.getUserId());
		mbrLrn.setModDt(LocalDateTime.now());
		return mbrDao.deleteMbrLrn(mbrLrn);
	}

	@Override
	public int deleteMbr(MbrVO mbr) throws Exception {
		mbr.setModUser(LoginUtils.getUserId());
		mbr.setModDt(LocalDateTime.now());
		mbrDao.deleteMbrLrnBySbsceId(mbr);
		return mbrDao.deleteMbr(mbr);
	}
	
	@Override
	public int updateMbrLrn(MbrLrnVO mbrLrn) throws Exception {
		mbrLrn.setModUser(LoginUtils.getUserId());
		mbrLrn.setModDt(LocalDateTime.now());
		return mbrDao.updateMbrLrn(mbrLrn);
	}
	
	
	@Override
	public int learnersUpdate(String sbsceMbrId, @Valid SaveVO<MbrLrnVO> mbrLrnSaveVO) {
		
		// 처리대상 가입자의 학습자 정보가 일치하는지 검증
		long notMatchedCnt = 0;
		
		List<MbrLrnVO> updateList = mbrLrnSaveVO.getUpdateList();		
		if(updateList != null) {
			// 실제 가입자와 입력값에 기술된 가입자가 일치하는지 검증
			notMatchedCnt = updateList.stream().filter(x -> {
				return !sbsceMbrId.equals(x.getSbsceMbrId());
			}).count();
		}
		
		if(notMatchedCnt > 0) {
			throw this.processException("S002004"); // 학습자의 가입자 정보가 실제 가입자 정보와 일치하지 않습니다.
		}
		
		// 일괄 처리된 건 수
		int updateCnt = 0;
		
		for(MbrLrnVO vo : updateList) {
			int rowsAffected = 0;
			
			rowsAffected = mbrDao.updateMbrLrn(vo);
			updateCnt += rowsAffected; 			

		}
		
		return updateCnt;
	}

	@Override
	public int updateMbr(MbrVO mbr) throws Exception {
		if(!StringUtils.isNotBlank(mbr.getPw())) {
			mbr.setModUser(LoginUtils.getUserId());
			mbr.setModDt(LocalDateTime.now());
			mbr.setPw(passwordEncoder.encode(mbr.getPw()));
		}
		mbr.setPhone(mbr.getPhoneEn()); //전화번호 암호화
		return mbrDao.updateMbr(mbr);
	}
	
	
	@Override
	public List<MbrVO> selectMbrs(MbrSearchVO mbrSearch) throws Exception {
		if(mbrSearch != null) {
			if(mbrSearch.getSrchTy().equals("EMAIL") || mbrSearch.getSrchTy().equals("ALL")) {
				mbrSearch.setSrchTxt(mbrSearch.getSrchTxtEnE());
			}
		}
		
		List<MbrVO> mbrs = mbrDao.selectMbrs(mbrSearch);
		
		for(int i = 0; i < mbrs.size(); i++) {
			mbrs.get(i).setEmailAdrsDe(mbrs.get(i).getEmailAdrs());
		}
		return mbrs;
	}

	@Override
	public int selectMbrsCnt(MbrSearchVO mbrSearch) throws Exception {
		if(mbrSearch.getSrchTy().equals("EMAIL")) {
			mbrSearch.setSrchTxt(mbrSearch.getSrchTxtEnE());
		}
		return mbrDao.selectMbrsCnt(mbrSearch);
	}	

	@Override
	public void insertLog(String token, HttpServletRequest request) throws Exception {
		HashMap<String, Object> logData = new HashMap<String, Object>();
		String device = WebUtil.getDeviceKind(request);
		logData.put("deviceScnCd", device);
		logData.put("mbrId", jwtUtils.getClaims(token).get("mbr").toString());
		logData.put("loginDt", LocalDateTime.now());
		mbrDao.insertMbrLog(logData);
		
	}
	
	@Override
	public List<MbrLrnVO> selectLearnersBySbsceMbrId(String mbrId) throws Exception {
		return mbrDao.selectMbrLrnListById(mbrId);
	}
	
	@Override
	public void signout(User userContext) throws Exception {		
		// 회원의 서비스 ID
		String userId = ((MbrAccount)userContext).getUserId();
		String redisKey = "token:refresh:" + userId;
		
		if(StringUtils.isNotBlank((String)redisTemplate.opsForValue().get(redisKey))) {
			redisTemplate.delete(redisKey);
			log.info("사용자({}) 리프레시 토큰 파기", redisKey);
		}
	}

	@Override
	public void insertMbrLrnLog(String learner,HttpServletRequest request, HttpServletResponse response) throws Exception {
		log.info("사용여부 : {}",sessionUtils.isUsing(learner));
		sessionUtils.printMbrLrn();
		if(sessionUtils.isUsing(learner)) {
			throw this.processException("S002362"); // 같은 학습아이디가 학습중입니다. 
		}
		//같은 학습회원 집입 여부에 따라 예외처리한다 
		HttpSession session = request.getSession(true);
		session.setMaxInactiveInterval(60*10);
		session.setAttribute("mbrLrnId", learner);
		sessionUtils.setSession(session, learner);
		
		//로그정보를 입력한다.
		HashMap<String, Object> logData = new HashMap<String, Object>();
		logData.put("lrnMbrId", learner);
		logData.put("entyBgnDt", LocalDateTime.now());
		mbrDao.insertMbrLrnLog(logData);
	}

	@Override
	public MbrVO selectMbrByCtrCode(String contract) throws Exception {
		return mbrDao.selectMbrByCtrCode(contract);
	}
	
	
}
