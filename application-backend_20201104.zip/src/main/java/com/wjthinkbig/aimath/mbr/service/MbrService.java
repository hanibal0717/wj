package com.wjthinkbig.aimath.mbr.service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.security.core.userdetails.User;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.mbr.vo.MbrSearchVO;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.mbr.vo.SmartAllMbrVO;

/**
  * @Date : 2020. 9. 2. 
  * @프로그램 설명 : 회원서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 2.     Lee Seung Hyuk            최초작성
  * 2020. 9. 17.    Kim Hee Seok              수정작업 
  * </pre>
  */
public interface MbrService {

	/**
	  * @Method 설명 : 신규 회원을 등록(가입)한다.
	  * @param mbrVO 등록할 회원 정보를 담은 VO 객체
	  * @throws Exception
	 */
	public void insertMbr(MbrVO mbr) throws Exception;
	
	/**
	  * @Method 설명 : 신규 학습 회원을 등록한다.
	  * @param mbrLrn
	  * @throws Exception
	 */
	public void insertMbrLrn(MbrLrnVO mbrLrn) throws Exception;
	/**
	  * @Method 설명 : 특정 가입 회원정보를 가져온다.
	  * @param mbrId 회원식별코드
	  * @return
	  */
	
	/**
	  * @Method 설명 : updateEmailCertYn 이메일 인증
	  * @작성일 : 2020. 9. 25
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param code
	  * @return
	  * @throws Exception
	*/
	public int updateEmailCertYn(String code) throws Exception;

	/**
	  * @Method 설명 : selectMbrByEmail 이메일로 회원 정보 검색
	  * @작성일 : 2020. 9. 25
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param email
	  * @return
	*/
	public void selectPwByEmail(MbrVO mbr) throws Exception;
	
	/**
	  * @Method 설명 : insertLog 토큰을 파싱해 로그인 로그 를 쌓는다 .
	  * @작성일 : 2020. 9. 28
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param token
	*/
	public void insertLog(String token, HttpServletRequest request) throws Exception;
	
	/**
	  * @Method 설명 : selectMbrById 아이디로 회원정보 검색
	  * @작성일 : 2020. 9. 25
	  * @작성자 : 19001877 - Kim Hee Seok
	  * @변경이력 : 
	  * @param mbrLrnId
	  * @return
	  * @throws Exception
	*/
	public MbrVO selectMbrById(String mbrLrnId) throws Exception;
	
	/**
	  * @Method 설명 : 특정 학습 회원정보를 가져온다.
	  * @param mbrId 회원식별코드
	  * @return
	  */
	public MbrLrnVO selectMbrLrnById(String mbrId) throws Exception;

	
		
	/**
	  * @Method 설명 : 학습자 삭제
	  * @param user
	  * @return
	  */
	public int deleteMbrLrn(MbrLrnVO mbrLrn) throws Exception;
	
	/**
	  * @Method 설명 : 회원정보 삭제
	  * @param user
	  * @return
	  */
	public int deleteMbr(MbrVO mbr) throws Exception;
		
	/**
	  * @Method 설명 : 학습 회원정보 변경 (이름, 성별 수정)
	  * @param mbrLrn 학습자 VO
	  * @return
	  * @throws Exception
	 */
	public int updateMbrLrn(MbrLrnVO mbrLrn) throws Exception;	
	
	/**
	  * @Method 설명 : 특정 가입자의 학습자를 일괄 처리한다.
	  * @param sbsceMbrId 가입자회원ID
	  * @param mbrLrnSaveVO 특정 가입자의 학습자회원 리스트
	  * @return
	  * @throws Exception
	 */
	public int learnersUpdate(String sbsceMbrId, @Valid SaveVO<MbrLrnVO> mbrLrnSaveVO) throws Exception;
		
	/**
	  * @Method 설명 : 가입 회원정보 변경 (비밀번호 만 수정)
	  * @param user
	  * @throws Exception
	  */
	public int updateMbr(MbrVO mbr) throws Exception;
	
	/**
	  * @Method 설명 : 전체 회원정보를 가져온다.
	  * @return 전체 회원리스트
	  * @throws Exception
	 */
	public List<MbrVO> selectMbrs(MbrSearchVO mbrSearch) throws Exception;
	
	/**
	  * @Method 설명 : 전체 회원 수를 가져온다.
	  * @param mbrSearch
	  * @return
	  */
	public int selectMbrsCnt(MbrSearchVO mbrSearch) throws Exception;
	
	/**
	  * @Method 설명 : 회원 로그아웃
	  * @param userContext MbrAccount
	  * @return
	  * @throws Exception
	 */
	public void signout(User userContext) throws Exception;
	
	/**
	  * @Method 설명 : 특정 가입자ID의 모든 학습자 정보를 가져오기
	  * @param mbrId 가입자ID
	  * @return 
	  * @throws Exception
	 */
	public List<MbrLrnVO> selectLearnersBySbsceMbrId(String mbrId) throws Exception;

	/**
	 * @Method 설명 : 특정 학습자의 진입 로그를 쌓고 같은 학습회원 진입을 막는다.
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @param learner
	 * @param response 
	 * @param request 
	 */
	public void insertMbrLrnLog(String learner, HttpServletRequest request, HttpServletResponse response) throws Exception;

	/**
	 * @Method 설명 : selectPassedDaysFromChangeDt 비밀번호 변경일 체크
	 * @author Kim Hee Seok [2020. 10. 27]
	 * @param mbrId 회원식별ID
	 * @return 비밀번호 변경일로부터의 경과 일수
	 * @throws Exception 
	 */
	public long selectPassedDaysFromChangeDt(String mbrId) throws Exception;

	/**
	 * @Method 설명 : selectMbrByCtrCode 스마트 올 연동 (스마트 올 패드에서 호출 )
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @param contract
	 * @return
	 * @throws Exception
	 */
	public MbrVO selectMbrByCtrCode(String contract) throws Exception;

	/**
	 * @Method 설명 : insertSmartAllMbr 스마트 올 회원의 회원 가입 
	 * @author Kim Hee Seok [2020. 11. 3]
	 * @param smInfo
	 * @return
	 * @throws Exception
	 */
	public MbrVO insertSmartAllMbr(SmartAllMbrVO smInfo) throws Exception;	
}