package com.wjthinkbig.aimath.mbr.vo;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.security.core.authority.SimpleGrantedAuthority;

import com.wjthinkbig.aimath.security.UserContext;

/**
  * @Date : 2020. 9. 4.
  * @프로그램 설명 : 스프링시큐리티가 제공하는 User 객체에 대한 사용자 UserContext 객체
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 4.     Lee Seung Hyuk            최초작성
  * 2020. 9. 24     Kim Hee   Seok            수정
  * </pre>
 */
public class MbrAccount extends org.springframework.security.core.userdetails.User implements UserContext {
	
	private static final long serialVersionUID = -7495793419409636738L;
	
	// 실제 서비스용 MbrVO 객체
	private MbrVO mbr;

	/**
	 * @param mbr 인증받은 회원의 MbrVO 객체
	 */
	public MbrAccount(MbrVO mbr) {	
		super(mbr.getEmailAdrs(), mbr.getPw(), getAuthorities(mbr));		
		this.mbr = mbr;
	}
	
	/**
	  * @Method 설명 : 인증받은 회원의 MbrVO 객체를 가져온다.
	  * @return MbrVO
	 */
	public MbrVO getMbrInfo() {		
		return this.mbr;		
	}
	
	/**
	 * 인증된 객체의 식별아이디 (회원ID)
	 */
	@Override
	public String getUserId() {
		return this.mbr.getMbrId();
	}

	/**
	  * @Method 설명 : MbrVO 객체의 Role 정보로부터 인증된 사용자의 권한을 세팅
	  * @param mbr MbrVO 객체
	  * @return
	 */
	private static Collection<SimpleGrantedAuthority> getAuthorities(MbrVO mbr){
		Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        for(String authority : mbr.getRoles()) {
        	authorities.add(new SimpleGrantedAuthority(authority));
        }
        return authorities;
    }
}