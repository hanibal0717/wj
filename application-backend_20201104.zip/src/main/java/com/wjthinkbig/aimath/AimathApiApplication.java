package com.wjthinkbig.aimath;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;
@EnableAsync
@EnableRedisHttpSession(redisNamespace = "spring:session:${systemId}", maxInactiveIntervalInSeconds = 600)
@SpringBootApplication
public class AimathApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AimathApiApplication.class, args);
	}

}
