package com.wjthinkbig.aimath.dgns.controller;

import java.time.LocalDateTime;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.ApiUtil;
import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.utils.WebUtil;
import com.wjthinkbig.aimath.dgns.service.DgnsService;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstReqVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsHstVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPrgsResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPrgsReqVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPropsReqAIVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPropsResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPropsReqVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsStgDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsTrnsMbrVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 13 
  * @프로그램 설명 : DgnsController.java : AI연산 진단테스트  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13          Kim Hee Seok       최초작성
  * </pre>
  */
@Slf4j
@Api(description = "진단테스트")
@RestController
public class DgnsController extends BaseController {
	/**
	 * 채널구분코드
	 */
	@Value("${systemId}")
	String sysScnCd;
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 진단 테스트 서비스 
	 */
	@Resource(name = "dgnsService")
	private DgnsService dgnsService;
	
	/**
	 * 회원 서비스 
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService;
	
	/**
	 * 비회원 (guest) 아이디 신규생성 서비스
	 */
	@Resource(name = "gstIdGenService")
	private EgovIdGnrService gstIdGenService;
	
	/**
	 * 외부 API 사용 유틸
	 */
	@Resource(name = "apiUtil")
	private ApiUtil apiUtil;
	
	
	
	/**
	 * @Method 설명 : getSessionId 비회원 세션 아이디 얻기
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @param data
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "비회원 세션 아이디 얻기")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/diagnosis/guestid")
	public SingleResult<HashMap<String, String>> getSessionId(HashMap<String, String> data) throws Exception {
		// 비회원ID (guest) 채번
		data.put("guestId", gstIdGenService.getNextStringId());
		return responseService.getSingleResult(data);
	}
	
	
	/**
	 * @Method 설명 : insertDgnsProposal 학습회원(비회원 포함)의 진단 신청 정보를  AI 모델서버에 요청하여 응답을 받는다 
	 * @author Kim Hee Seok [2020. 10. 15]
	 * @param learner
	 * @param channel
	 * @param propsVO
	 * @return DgnsPropsResVO
	 * @throws Exception
	 */
	@ApiOperation(value = "진단을 위한 신청 데이터 교환")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/diagnosis/proposal/channels/{channel}/learners/{learner}")
	public SingleResult<DgnsPropsResVO> insertDgnsProposal(@ApiParam(value = "학습자 아이디") @PathVariable(name = "learner", required = true) String learner
			, @ApiParam(value = "언어 코드") @PathVariable(name = "channel", required = true) String channel
			, @ApiParam(value = "진단 회원 객체") @Valid @RequestBody DgnsPropsReqVO propsReqVO
			, HttpServletRequest request) throws Exception {
		if(propsReqVO.getChnCd() == null) {
			propsReqVO.setChnCd(sysScnCd);
		}
		
		// @RequestBody를 통해 전송된 데이터에 학습자 ID가 경로변수의 가입자 ID와 일치해야 한다.
		if((StringUtils.isNotBlank(propsReqVO.getLrnMbrId()) && !learner.equals(propsReqVO.getLrnMbrId()))
				|| (StringUtils.isNotBlank(propsReqVO.getChnCd()) && !channel.equals(propsReqVO.getChnCd()))) {
			throw this.processException("S002000"); // 학습자 정보가 일치하지 않습니다. 
		}
		// 로그인한 사용자의 학습회원 존재 여부 판단 
		if(LoginUtils.isLogin()) {
			MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
			if(mbrLrn == null) {
				throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
			}
		}
		DgnsPropsReqAIVO dpsVO = new DgnsPropsReqAIVO();
		dpsVO.setLrnMbrId(propsReqVO.getLrnMbrId());
		dpsVO.setDeviceScnCd(WebUtil.getDeviceKind(request));
		dpsVO.setOsScnCd(WebUtil.getOsKind(request));
		this.validateOrElseThrow(propsReqVO);
		
		/*
		 ### AI 모델 서버에 진단 신청 객체를 보내고 결과 값을 받는다.###
		 (결과 맵에 body를 응답객체에 케스팅해서  담는다 )
		
		HashMap<String,Object> resResult = apiUtil.externalApi("[AI 서버 URL]", propsVO, HttpMethod.GET); 
		DgnsPropsResVO dprVO = (DgnsPropsResVO) resResult.get("body");
		
		*/

		/*======================= 응답테스트 용 응답 ==================================*/
		DgnsPropsResVO propsResVO = new DgnsPropsResVO();
		propsResVO.setMbrLrnId(dpsVO.getLrnMbrId());
		propsResVO.setEstQstNo(20);
		propsResVO.setEstDiagDur(600000); //10분
		propsResVO.setQstCd("B02010006");
		
		/* ============================================================================*/
		/*
		 * 진단 시작 데이터를 입력한다.
		 * */
		
		// 시작 스테이지와 시작 레벨을 구한다
		DgnsHstVO hstVO = new DgnsHstVO();
		hstVO = dgnsService.selectLvlStgByQst(propsResVO);
		log.info("시작 레벨과 스테이지는 ? {}",hstVO.getBgnLvlCd()+"|"+hstVO.getBgnStgCd());
		
		hstVO.setLrnMbrId(propsReqVO.getLrnMbrId()); 
		hstVO.setChnCd(sysScnCd);
		hstVO.setDgnsBgnDt(LocalDateTime.now());          
		hstVO.setDgnsTargtBrthmt(propsReqVO.getBrthmt());    
		hstVO.setDgnsTargtSxdnCd(propsReqVO.getSxdnCd());    
		hstVO.setDgnsTargtGradeCd(propsReqVO.getGrade()); 
       	hstVO.setDgnsRsltCnfmYn("N");  
		hstVO.setLoginUser(propsReqVO.getLrnMbrId());
		this.validateOrElseThrow(hstVO);
		DgnsHstVO isVO = dgnsService.selectHstById(propsReqVO.getLrnMbrId());
		if(isVO != null) {
			if(isVO.getDgnsEndDt() == null&&isVO.getCompStgCd() == null) {
				// 삭제 
				int rows = dgnsService.deleteDgnsById(propsReqVO.getLrnMbrId());
				if(rows == 0) {
					throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
				}
			}else {
				throw this.processException("S002007"); // 이미진단 이력이 존재합니다.
			}
			
		}
		dgnsService.insertDgnsHst(hstVO);
		
		return responseService.getSingleResult(propsResVO);
	}
	
	/**
	 * @Method 설명 : selectQstById 문항 정보 불러오기 
	 * @author Kim Hee Seok [2020. 10. 15]
	 * @param question
	 * @param language
	 * @param dqdlVO
	 * @return dqdlVO
	 * @throws Exception
	 */
	@ApiOperation(value = "단순 문항 정보")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/diagnosis/questions/{question}/languages/{language}")
	public SingleResult<DgnsQstDtlVO> selectQstById(@ApiParam(value = "문항코드") @PathVariable(name = "question", required = true) String question
			, @ApiParam(value = "언어 코드") @PathVariable(name = "language", required = true) String language
			, @ApiParam(value = "문항 객체") DgnsQstDtlVO qstDtlVO) throws Exception {
		qstDtlVO.setQstCd(question);
		qstDtlVO.setLangCd(language);
		qstDtlVO = dgnsService.selectQstById(qstDtlVO);
		if(qstDtlVO == null) {
			throw this.processException("S002005"); //해당 문항이 존제하지 않습니다. 
		}
		return responseService.getSingleResult(qstDtlVO);
	}
	
	
	// 요청 : (사용자 입력한 정답) 반복 API/응답 dgnsPrsCd 이 E 일때 까지 반복 호출 
	/**
	 * @Method 설명 : 진단 테스트 진행중일때 요청/응답 메소드 
	 * @author Kim Hee Seok [2020. 10. 15]
	 * @param question
	 * @param learner
	 * @param language
	 * @param PrgsVO
	 * @return DgnsPrgsResVO
	 * @throws Exception 
	 */
	@ApiOperation(value = "진단 진행을 위한 테이터 교환")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/diagnosis/progress/questions/{question}/learners/{learner}/languages/{language}")
	public SingleResult<DgnsPrgsResVO> insertDgnsPrgrs(@ApiParam(value = "문항코드") @PathVariable(name = "question", required = true) String question
			, @ApiParam(value = "회원 코드") @PathVariable(name = "learner", required = true) String learner
			, @ApiParam(value = "언어 코드") @PathVariable(name = "language", required = true) String language
			, @ApiParam(value = "진단문항 진행객체") @RequestBody DgnsPrgsReqVO prgsReqVO) throws Exception{ 
		// @RequestBody를 통해 전송된 데이터에 학습자 ID가 경로변수의 가입자 ID와 일치해야 한다.
		if((StringUtils.isNotBlank(prgsReqVO.getLrnMbrId()) && !learner.equals(prgsReqVO.getLrnMbrId()))
				&& (StringUtils.isNotBlank(prgsReqVO.getQstCd()) && !question.equals(prgsReqVO.getQstCd()))) {
			throw this.processException("S002014");		// 경로변수 값이 일치하지 않습니다. 
		}
		// 로그인한 사용자의 학습회원 존재 여부 판단 
		if(LoginUtils.isLogin()) {
			MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
			if(mbrLrn == null) {
				throw this.processException("S001005"); // 해당 사용자가 존재하지 않습니다.
			}
		}
		// 문항 존재 여부 판단 
		int count = dgnsService.getQstCntById(question);
		if(count == 0) {
			throw this.processException("S002005"); // 해당 문항이 존제하지 않습니다. 
		}
		
		// 1. 정답을 정답을 체크(apiUtil.jugeAnswer(). 사용)하여 ansrCw 에 Y|N 값으로 변경하여 넣는다  
		DgnsQstResVO  qstResVO = dgnsService.selectQstAns(question); 
		String ansrCwYn = apiUtil.jugeAnswer(prgsReqVO.getAnsrCw(),qstResVO.getQstCransr(),qstResVO.getCransrTyScnCd());
		prgsReqVO.setBlkYn("N");
		prgsReqVO.setAnsrCwYn(ansrCwYn);
		if(StringUtils.isBlank(prgsReqVO.getAnsrCw())||ansrCwYn.equals("B")||ansrCwYn.equals("E")) {
			prgsReqVO.setBlkYn("Y");
			prgsReqVO.setAnsrCwYn("N");
		}
		this.validateOrElseThrow(prgsReqVO);
		
		/*2. ### AI 모델 서버에 진단 신청 객체를 보내고 결과 값을 받는다.###
		 (결과 맵에 body를 응답객체에 케스팅해서  담는다 ) 
		HashMap<String,Object> resResult = apiUtil.externalApi("[AI 서버 URL]", prgsVO, HttpMethod.GET); 
		DgnsPrgsVOResVO dprVO = (DgnsPrgsVOResVO) resResult.get("body");*/
		
		// 테스트 용 랜덤 setDgnsPrsCd("E")
		String setDgnsPrsCd = apiUtil.randomDgnsPrsCd();
		log.info("###랜덤하게 뽑은 코드 {}",setDgnsPrsCd);
		/*======================= 응답테스트 용 응답 ==================================*/
		DgnsPrgsResVO prgsResVO = new DgnsPrgsResVO();			// 버전 
		prgsResVO.setMbrLrnId(prgsReqVO.getLrnMbrId());				// 학습자 아이디
		prgsResVO.setDgnsPrsCd(setDgnsPrsCd);	// 진행코드
		prgsResVO.setAccuracy("30%");  			// 정확도
		prgsResVO.setCnAnsCnt(2);  			// 모름횟수 
		prgsResVO.setQstCd(prgsReqVO.getQstCd());	// 다음문제 
		prgsResVO.setAnsrCwYn(prgsReqVO.getAnsrCwYn());			// 이전문제 정답여부
		/*===============================dgnsPrsCd 가 E로 오면 응답받는다===============================================*/
		if(setDgnsPrsCd.equals("E")) {
			prgsResVO.setDgnsBgnDt(LocalDateTime.now());		// 진단 시작일시 
			prgsResVO.setDgnsEndDt(LocalDateTime.now());		// 잔단 종료 일시 
			prgsResVO.setEstLastStgCd("B02_0_1");		// 충분히 학습된 것으로 예측되는 스테이지 코드 
			DgnsStgDtlVO lastStgNm = dgnsService.selectStgNm("B02_0_1", language);
			prgsResVO.setEstLastStgNm(lastStgNm.getStgNm());// 충분히 학습된 것으로 예측되는 스테이지 명 
			prgsResVO.setEstPreLvlCd("LV001");			// 적정 시작 지점의 레벨코드 
			prgsResVO.setEstPreStgCd("B02_0_1");		// 적정 시작 지정의 스테이지 코드 
			DgnsStgDtlVO preStgNm = dgnsService.selectStgNm("B02_0_1", language);
			prgsResVO.setEstPreStgNm(preStgNm.getStgNm());// 적정 시작 지정의 스테이지 명 
			prgsResVO.setEstPreStgDtl(preStgNm.getStgDtl());
			prgsResVO.setLrnMbrNm("GUEST");
			//회원명
			if(LoginUtils.isLogin()) {
				MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(prgsReqVO.getLrnMbrId());
				prgsResVO.setLrnMbrNm(mbrLrn.getMbrNm());
			}
			
			/*모든 응답을 받으면 tb_lnr_dgns_hst 이력을 쌓는다.*/
			DgnsHstVO hstVO = new DgnsHstVO();
			hstVO.setLrnMbrId(prgsResVO.getMbrLrnId());          
			hstVO.setDgnsBgnDt(prgsResVO.getDgnsBgnDt());          
			hstVO.setDgnsEndDt(prgsResVO.getDgnsEndDt());          
			hstVO.setBgnLvlCd(prgsResVO.getEstPreLvlCd());
			hstVO.setBgnStgCd(prgsResVO.getEstPreStgCd());
			hstVO.setCompStgCd(prgsResVO.getEstPreStgCd());
			hstVO.setDgnsRsltCnfmYn("N");  
			hstVO.setLoginUser(prgsResVO.getMbrLrnId());
			hstVO.setModUser(prgsResVO.getMbrLrnId());
			hstVO.setModDt(LocalDateTime.now());
			int rows = dgnsService.updateDgnsHst(hstVO);
			if(rows == 0) {
				throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
			}
		}
		/* ============================================================================*/
		return responseService.getSingleResult(prgsResVO);
	}
	
	
	/**
	 * @Method 설명 : 문항의 정답확인 
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @param question
	 * @param ansVo
	 * @return 
	 * @throws Exception
	 */
	@ApiOperation(value = "정답 확인")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/diagnosis/questions/{question}")
	public SingleResult<HashMap<String, String>> selectAnswrYn(@ApiParam(value = "문항코드") @PathVariable(name = "question", required = true) String question
			,@ApiParam(value = "정답판단 객체") @Valid @RequestBody  DgnsQstReqVO qstReqVO) throws Exception {
		
		DgnsQstResVO qstResVO = dgnsService.selectQstAns(question);
		if(qstReqVO == null || !question.equals(qstReqVO.getQstCd())) {
			throw this.processException("S002014"); // 경로변수 값이 일치하지 않습니다.
		}
		// 문항 존재 여부 판단 
		int count = dgnsService.getQstCntById(question);
		if(count == 0) {
			throw this.processException("S002005"); // 해당 문항이 존제하지 않습니다. 
		}
		
		String ansrCwYn = apiUtil.jugeAnswer(qstReqVO.getUserAnsr(), qstResVO.getQstCransr(), qstResVO.getCransrTyScnCd());
		HashMap<String, String> data = new HashMap<String, String>();
		data.put("ansrCwYn", ansrCwYn);
		return responseService.getSingleResult(data);
	}
	
	/**
	 * @Method 설명 :  진단결과 확인 업데이트
	 * @author Kim Hee Seok [2020. 10. 28]
	 * @param guest
	 * @param learner
	 * @param trnsMbrVO
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "진단결과 확인 업데이트")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/diagnosis/confirm/guests/{guest}/learners/{learner}")
	public SingleResult<DgnsHstVO> updateRsltCnfm(@ApiParam(value = "게스트 아이디") @PathVariable(name = "guest", required = true) String guest
			, @ApiParam(value = "로그인 아이디") @PathVariable(name = "learner") String learner
			, @Valid @RequestBody @ApiParam(value = "회원전환객체 ") DgnsTrnsMbrVO trnsMbrVO) throws Exception {
		if(StringUtils.isBlank(learner) 
				|| !learner.equals(trnsMbrVO.getMbrLrnId())
				|| StringUtils.isBlank(guest)
				|| !guest.equals(trnsMbrVO.getGuestId())) {
			throw this.processException("S002014"); // 경로변수 값이 일치하지 않습니다.
		}
		// 학습자 존재 여부 
		MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
		if(mbrLrn == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		// 학습자 진단이력 존제 여부 
		DgnsHstVO lrnHstVO = dgnsService.selectHstById(learner);
		if(lrnHstVO != null) {
			throw this.processException("S002007"); // 진단이력이 이미 존재합니다.
		}
		// 진단 이력 데이터  확인 
		DgnsHstVO gsthstVO = dgnsService.selectHstById(guest);
		if(gsthstVO == null) {
			throw this.processException("S001029"); // 진단이력이 존재하지 않습니다. 
		}
		trnsMbrVO.setModUser(learner);
		trnsMbrVO.setModDt(LocalDateTime.now());
		int rows = dgnsService.updateRsltCnfm(trnsMbrVO);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		DgnsHstVO rstHstVO = dgnsService.selectHstById(learner);
		return responseService.getSingleResult(rstHstVO);
	}
}























