package com.wjthinkbig.aimath.dgns.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 19 
  * @프로그램 설명 : 정답여부를 알기위한 응답  VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 19     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "정답여부를 알기위한 응답  VO")
public class DgnsQstResVO {
	/*
	 * 정답 
	 */
	@NotBlank
	@ApiModelProperty(value="정답")
	@FieldName("정답")
	private String qstCransr;
	
	/*
	 * 정답유형 
	 */
	@NotBlank
	@ApiModelProperty(value="정답유형")
	@FieldName("정답유형")
	private String cransrTyScnCd;
}
