package com.wjthinkbig.aimath.dgns.vo;

import java.time.LocalDateTime;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 28 
  * @프로그램 설명 :  진단 테스트 진행 응답 VO 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 28     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "진단 테스트 진행 응답 VO")
public class DgnsPrgsResVO {
	/**
	 * 	학습 회원 ID  또는 비회원 ID
	 */
	@NotBlank
	@ApiModelProperty(value="학습 회원아이디")
	@FieldName("학습 회원아이디")
	private String mbrLrnId;
	
	/**
	 * 진행코드(S 시작, W 진행, E 종료 등) -> 여기선 W
	 */
	@NotBlank
	@ApiModelProperty(value="진행코드")
	@FieldName("진행코드")
	private String dgnsPrsCd;
	
	/**
	 * 정확도 수준 (%)
	 */
	@NotBlank
	@ApiModelProperty(value="정확도")
	@FieldName("정확도")
	private String accuracy;
	
	/**
	 * 모름횟수
	 */
	@NotNull
	@ApiModelProperty(value="모름횟수")
	@FieldName("모름횟수")
	private int cnAnsCnt;
	
	/**
	 * 다음 문제의 문항코드
	 */
	@NotBlank
	@ApiModelProperty(value="다음문항코드")
	@FieldName("다음문항코드")
	private String qstCd;
	
	/**
	 * 이전 문제 정답여부 
	 */
	@NotBlank
	@ApiModelProperty(value=" 이전 문제 정답여부")
	@FieldName(" 이전 문제 정답여부")
	private String ansrCwYn;
	
	/*********진단 종료시 **** 응답받는 값**********/
		
	/**
	 * 진단 시작 일시
	 */
	@ApiModelProperty(value="진단시작일시")
	@FieldName("진단시작일시")
	private LocalDateTime dgnsBgnDt;
	
	/**
	 * 진단 종료 일시
	 */
	@ApiModelProperty(value=" 진단종료일시")
	@FieldName("진단종료일시")
	private LocalDateTime dgnsEndDt;
	
	/**
	 * 충분히 학습된 것으로 예측되는 스테이지 코드
	 */
	@ApiModelProperty(value="학습완료스테이지")
	@FieldName("학습완료스테이지")
	private String estLastStgCd;
	
	/*
	 * 충분히 학습된 것으로 예측되는 스테이지 명
	 */
	@ApiModelProperty(value="충분한 스테이지명")
	@FieldName("충분한 스테이지명")
	private String estLastStgNm;
	
	/**
	 * 적정 시작 지점의 레벨 코드
	 */
	@ApiModelProperty(value="적정레벨코드")
	@FieldName("적정레벨코드")
	private String estPreLvlCd;
	
	/**
	 * 적정 시작 지점의 스테이지 코드
	 */
	@ApiModelProperty(value="적정스테이지코드")
	@FieldName("적정스테이지코드")
	private String estPreStgCd;
	
	/*
	 * 적정 시작 지정의 스테이지 명 
	 */
	@ApiModelProperty(value="충분한 스테이지명")
	@FieldName("충분한 스테이지명")
	private String estPreStgNm;
	
	/*
	 * 적정 시작 지정의 스테이지 상세내용  
	 */
	@ApiModelProperty(value="스테이지 상세내용")
	@FieldName("스테이지 상세내용")
	private String estPreStgDtl;
	
	/**
	 * 학습자 명 (비회원 GUEST 회원일경우 회원이름)
	 */
	@ApiModelProperty(value="학습자 명")
	@FieldName("학습자 명")
	private String lrnMbrNm;
}
