package com.wjthinkbig.aimath.dgns.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 28 
  * @프로그램 설명 : 스테이지명 과 스테이지 상세 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 28          Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "스테이지명 과 스테이지 상세 VO")
public class DgnsStgDtlVO {

	/**
	 * 스테이지 명 
	 */
	@ApiModelProperty(value="스테이지 명 ")
	@FieldName("스테이지 명 ")
	private String stgNm;
	
	/**
	 * 스테이지 상세
	 */
	@ApiModelProperty(value="스테이지 상세")
	@FieldName("스테이지 상세")
	private String stgDtl;
}
