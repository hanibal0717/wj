package com.wjthinkbig.aimath.dgns.vo;

import java.time.LocalDateTime;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 19 
  * @프로그램 설명 :  진단 이력 VO 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 19     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "진단 이력 VO ")
public class DgnsHstVO extends BaseVO {
	/*
	 * 학습회원id 
	 * */
	@NotBlank
	@ApiModelProperty(value="학습회원id")
	@FieldName("학습회원id")
	private String lrnMbrId; 
	
	/*
	 * 채녈코드 
	 * */
	@NotBlank
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd; 
	
	/*
	 * 진단시작일시 
	 * */
	@ApiModelProperty(value="진단시작일시")
	@FieldName("진단시작일시")
	private LocalDateTime dgnsBgnDt;
	
	 /*
	  * 진단종료일시 
	  * */
	@ApiModelProperty(value="진단종료일시 ")
	@FieldName("진단종료일시")
	private LocalDateTime dgnsEndDt;  
	
	 /*
	  * 진단대상생년월 
	  * */
	@NotBlank
	@ApiModelProperty(value="진단대상생년월")
	@FieldName("진단대상생년월")
	private String dgnsTargtBrthmt;
	
	/*
	 * 진단대상성별코드 
	 * */
	@NotBlank
	@ApiModelProperty(value="진단대상성별코드")
	@FieldName("진단대상성별코드")
	private String dgnsTargtSxdnCd;  
	
	/*
	 * 진단대상학년코드 
	 * */
	@NotBlank
	@ApiModelProperty(value="진단대상학년코드")
	@FieldName("진단대상학년코드")
	private String dgnsTargtGradeCd;       
	
	/**
	 *  시작 레벨코드 
	 */
	@NotBlank
	@ApiModelProperty(value="시작 레벨코드 ")
	@FieldName("시작 레벨코드 ")
	private String bgnLvlCd;
	 /*
	  * 시작스테이지코드 
	  * */
	@NotBlank
	@ApiModelProperty(value="시작스테이지코드")
	@FieldName("시작스테이지코드")
	private String bgnStgCd;
	
	 /*
	  * 완료스테이지코드 
	  * */
	@ApiModelProperty(value="완료스테이지코드")
	@FieldName("완료스테이지코드")
	private String compStgCd;
	
 	/*
 	 * 진단결과확인여부 
 	 * */
	@NotBlank
	@ApiModelProperty(value="진단결과확인여부")
	@FieldName("진단결과확인여부")
	private String dgnsRsltCnfmYn;                    
}
