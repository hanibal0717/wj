package com.wjthinkbig.aimath.dgns.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 28 
  * @프로그램 설명 : 진단 테스트 진행 요청 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 28     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "진단 테스트 진행 요청 VO")
public class DgnsPrgsReqVO {
	
	/**
	 * 학습회원 아이디  
	 */
	@NotBlank
	@ApiModelProperty(value="학습회원 아이디")
	@FieldName("학습회원")
	private String lrnMbrId;
	
	/**
	 * 진단진행 코드   진행 코드( W 진행)
	 */
	@NotBlank
	@Pattern(regexp = "W|U")
	@ApiModelProperty(value="진단진행 코드")
	@FieldName("진단진행 코드")
	private String dgnsPrsCd;
	
	/**
	 * 문항코드
	 */
	@NotBlank
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;
	
	/**
	 * 사용자가 입력한 답
	 */
	@NotBlank
	@ApiModelProperty(value="사용자답")
	@FieldName("사용자답")
	private String ansrCw;
	
	
	/**
	 * 입력 방식
	 */
	@NotBlank
	@ApiModelProperty(value="입력 방식")
	@FieldName("입력 방식")
	private String inputTy;
	
	
	
	/**
	 * 정오답여부 
	 */
	@NotBlank
	@ApiModelProperty(value="정오답여부")
	@FieldName("정오답여부")
	private String ansrCwYn;
	
	/**
	 * 모름여부
	 */
	@NotBlank
	@ApiModelProperty(value="모름여부")
	@FieldName("모름여부")
	private String cnAnsrYn;
	
	/**
	 * 빈칸여부
	 */
	@NotBlank
	@Pattern(regexp = "Y|N")
	@ApiModelProperty(value="빈칸여부")
	@FieldName("빈칸여부")
	private String blkYn;
	
	/**
	 * 누적 학습시간(ms)
	 */
	@NotNull
	@ApiModelProperty(value="누적학습시간")
	@FieldName("누적학습시간")
	private int accmTime;
	
	/**
	 * 문제 풀이 시간 (ms)
	 */
	@NotNull
	@ApiModelProperty(value = "문제풀이시간")
	@FieldName("문제풀이시간")
	private long slvTime;
	
	/**
	 * 입력에 소요된 시간(ms)
	 */
	@NotNull
	@ApiModelProperty(value = "입력소요시간")
	@FieldName("입력소요시간")
	private long inptTime;
}
