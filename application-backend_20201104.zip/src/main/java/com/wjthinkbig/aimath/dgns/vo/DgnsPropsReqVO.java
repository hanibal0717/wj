package com.wjthinkbig.aimath.dgns.vo;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


/**
  * @Date : 2020. 10. 14 
  * @프로그램 설명 :  진단테스트  신청 요청 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "진단테스트  신청 요청 VO")
public class DgnsPropsReqVO {
	
	/**
	 * 학습회원 아이디  
	 */
	@NotBlank
	@ApiModelProperty(value="학습회원 아이디")
	@FieldName("학습회원")
	private String lrnMbrId;
	
	/**
	 * 채녈코드  
	 */
	@NotBlank
	@ApiModelProperty(value="채녈코드")
	@FieldName("채녈코드")
	private String chnCd;
	
	/**
	 * 생년월 
	 */
	@NotBlank
	@Pattern(regexp = "(19|20)\\d{2}(0[1-9]|1[012])")
	@ApiModelProperty(value="생년월")
	@FieldName("생년월")
	private String brthmt;
	
	/**
	 * 학년
	 */
	@NotBlank
	@ApiModelProperty(value="학년")
	@FieldName("학년")
	private String grade;
	
	/**
	 * 성별 (남:M, 여:F)
	 */
	@NotBlank
	@Pattern(regexp = "M|F")
	@ApiModelProperty(value="성별")
	@FieldName("성별")
	private String sxdnCd;
	
	
	
	
	
	
}
