package com.wjthinkbig.aimath.dgns.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 19 
  * @프로그램 설명 : 문항 상세 정보 VO 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 19     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "문항 상세 정보 VO")
public class DgnsQstDtlVO {
	/*
	 * 언어코드 
	 */
	@ApiModelProperty(value = "언어코드")
	@FieldName("언어코드")
	private String langCd;
	
	/* 
	 * 문항코드 
	*/
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;
	
	/* 
	 * 스테이지코드 
	 */
	@ApiModelProperty(value="스테이지코드")
	@FieldName("스테이지코드")
	private String stgCd;
	

	/* 
	 * 폰트크기 
	 */
	@ApiModelProperty(value="폰트크기")
	@FieldName("폰트크기")
	private String fontSize;
	
	/* 
	 * 키보드 유형 
	 */
	@ApiModelProperty(value="키보드 유형")
	@FieldName("키보드 유형")
	private String kypdTyCd;
	
	/**
	 * 문항내용
	 */
	@ApiModelProperty(value="문항내용")
	@FieldName("문항내용")
	private String qstCn;
	
	/**
	 * 지문내용 
	 */
	@ApiModelProperty(value="지문내용")
	@FieldName("지문내용")
	private String textCn;
	
	/**
	 * 보기내용 
	 */
	@ApiModelProperty(value="보기내용")
	@FieldName("보기내용")
	private String exmpCn;
}
