package com.wjthinkbig.aimath.dgns.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 28 
  * @프로그램 설명 :  임시아이디 와 가입아이디 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 28     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "임시아이디 와 가입아이디 VO")
public class DgnsTrnsMbrVO extends BaseVO {
	
	/*
	 * 임시 아이디  
	 */
	@NotBlank
	@ApiModelProperty(value="임시 아이디 ")
	@FieldName("임시 아이디 ")
	private String guestId;
	/*
	 * 가입아이디  
	 */
	@NotBlank
	@ApiModelProperty(value="가입아이디")
	@FieldName("가입아이디")
	private String mbrLrnId;
	
}
