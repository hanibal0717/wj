package com.wjthinkbig.aimath.dgns.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 22 
  * @프로그램 설명 :  진단 테스트 AI모델 요청 VO 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 22     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "진단 테스트 AI모델 요청 VO")
public class DgnsPropsReqAIVO {
	
	/**
	 * 학습회원 아이디  
	 */
	@NotBlank
	@ApiModelProperty(value="학습회원 아이디")
	@FieldName("학습회원")
	private String lrnMbrId;
	
	/**
	 * 디바이스 종류  
	 */
	@NotBlank
	@ApiModelProperty(value="디바이스 종류")
	@FieldName("디바이스 종류")
	private String deviceScnCd;
	
	/**
	 * OS 종류
	 */
	@NotBlank
	@ApiModelProperty(value="OS 종류")
	@FieldName("OS 종류")
	private String osScnCd;
}
