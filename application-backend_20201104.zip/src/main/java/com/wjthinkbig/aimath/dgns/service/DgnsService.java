package com.wjthinkbig.aimath.dgns.service;

import com.wjthinkbig.aimath.dgns.vo.DgnsHstVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPropsResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsStgDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsTrnsMbrVO;

/**
  * @Date : 2020. 10. 13 
  * @프로그램 설명 : DgnsService.java 진단테스트 서비스 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13          Kim Hee Seok       최초작성
  * </pre>
  */
public interface DgnsService {

	/**
	 * @Method 설명 : selectQstById 문항 코드로 문항 객체를 불러온다 
	 * @author Kim Hee Seok [2020. 10. 15]
	 * @param dqdlVO
	 * @return DgnsQstDtlVO
	 * @throws Exception
	 */
	public DgnsQstDtlVO selectQstById(DgnsQstDtlVO qstDtlVO) throws Exception;

	/**
	 * @Method 설명 : getQstCountById 문항 코드로 문항 존재여부를 판단힌다 .
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param question
	 * @return int
	 * @throws Exception
	 */
	public int getQstCntById(String question) throws Exception;

	/**
	 * @Method 설명 : selectQstAns 문항코드로 정답과 정답 유형을 불러온다 
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param question
	 * @return DgnsQstAnsVO
	 * @throws Exception
	 */
	public DgnsQstResVO selectQstAns(String question) throws Exception;

	
	/**
	 * @Method 설명 : insertDgnsHst 진단이력을 입력한다
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param hstVO
	 * @throws Exception
	 */
	public void insertDgnsHst(DgnsHstVO hstVO) throws Exception;

	/**
	 * @Method 설명 : selectHstById 임시아이디 존재 여부
	 * @author Kim Hee Seok [2020. 10. 19]
	 * @param guest
	 * @return DgnsHstVO
	 * @throws Exception
	 */
	public DgnsHstVO selectHstById(String guest) throws Exception;

	/**
	 * @Method 설명 : updateRsltCnfm 진단 이력을 확인여부와 임시아이디를 학습회원 아이디로 전환한다.
	 * @author Kim Hee Seok [2020. 10. 19]
	 * @param trnsMbrVO
	 * @returnint
	 * @throws Exception
	 */
	public int updateRsltCnfm(DgnsTrnsMbrVO trnsMbrVO) throws Exception;

	/**
	 * @Method 설명 : selectLvlStg 진단 시작 지점의 문제로 레벨과 스테이지를 구한다.
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param propsResVO
	 * @return
	 * @throws Exception
	 */
	public DgnsHstVO selectLvlStgByQst(DgnsPropsResVO propsResVO) throws Exception;

	/**
	 * @Method 설명 : deleteDgnsById 해당 회원의 진단 이력을 지운다. 
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param mbrLrnId
	 * @return int
	 */
	public int deleteDgnsById(String mbrLrnId) throws Exception;

	/**
	 * @Method 설명 : updateDgnsHst 해당 진단 종료시  이력을 업데이트 한다 
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param hstVO
	 * @return int
	 * @throws Exception
	 */
	public int updateDgnsHst(DgnsHstVO hstVO) throws Exception;

	/**
	 * @Method 설명 : selectStgNm 스테이지 코드로 스테이지 명을 가져온다 
	 * @author Kim Hee Seok [2020. 10. 27]
	 * @param language 
	 * @param stgCd
	 * @return
	 * @throws Exception
	 */
	public DgnsStgDtlVO selectStgNm(String stgCd, String language) throws Exception;

}
