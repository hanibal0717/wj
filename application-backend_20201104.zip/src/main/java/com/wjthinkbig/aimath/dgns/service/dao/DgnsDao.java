package com.wjthinkbig.aimath.dgns.service.dao;
import java.util.HashMap;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.dgns.vo.DgnsHstVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsPropsResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstResVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsQstDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsStgDtlVO;
import com.wjthinkbig.aimath.dgns.vo.DgnsTrnsMbrVO;

/**
  * @Date : 2020. 10. 13 
  * @프로그램 설명 : DgnsDao.java 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13          Kim Hee Seok       최초작성
  * </pre>
  */
@Mapper("dgnsDao")
public interface DgnsDao {

	/**
	 * @Method 설명 : selectQstById 아이디로 문항 정보를 가져온다.
	 * @author Kim Hee Seok [2020. 10. 15]
	 * @param qstCd
	 * @return DgnsQstDtlVO
	 */
	DgnsQstDtlVO selectQstById(DgnsQstDtlVO qstDtlVO);

	/**
	 * @Method 설명 : getQstCntById 아이디로 문항 존제 여부를 가져온다
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param question
	 * @return int 
	 */
	int getQstCntById(String qstCd);

	/**
	 * @Method 설명 : selectQstAns 문
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param question
	 * @return
	 */
	DgnsQstResVO selectQstAns(String qstCd);

	/**
	 * @Method 설명 : insertDgnsHst 진단 이력을 넣는다.
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param hstVO
	 * @return 
	 * @return
	 */
	 void insertDgnsHst(DgnsHstVO hstVO);

	/**
	 * @Method 설명 : selectHstById 진단이력 존재여부
	 * @author Kim Hee Seok [2020. 10. 19]
	 * @param guest
	 * @return
	 */
	DgnsHstVO selectHstById(String guest);

	/**
	 * @Method 설명 : updateRsltCnfm  진단 이력을 확인여부와 임시아이디를 학습회원 아이디로 전환
	 * @author Kim Hee Seok [2020. 10. 19]
	 * @param trnsMbrVO
	 * @return
	 */
	int updateRsltCnfm(DgnsTrnsMbrVO trnsMbrVO);

	/**
	 * @Method 설명 : selectLvlStgByQst
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param propsResVO
	 * @return
	 */
	DgnsHstVO selectLvlStgByQst(DgnsPropsResVO propsResVO);

	/**
	 * @Method 설명 : deleteDgnsById 해당 회원의 진단 이력을 지운다. 
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param mbrLrnId
	 * @return
	 */
	int deleteDgnsById(String mbrLrnId);

	/**
	 * @Method 설명 : updateDgnsHst  해당 진단 종료시  이력을 업데이트 한다 
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param hstVO
	 * @return
	 */
	int updateDgnsHst(DgnsHstVO hstVO);

	/**
	 * @Method 설명 : selectStgNm 스테이지 코드로 스테이지 명을 가져온다 
	 * @author Kim Hee Seok [2020. 10. 27]
	 * @param paramMap
	 * @return DgnsStgNmDtlVO
	 */
	DgnsStgDtlVO selectStgNm(HashMap<String, String> paramMap);

}
