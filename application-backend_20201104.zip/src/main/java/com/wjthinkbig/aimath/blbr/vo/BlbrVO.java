package com.wjthinkbig.aimath.blbr.vo;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 23.
  * @프로그램 설명 : 게시판 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 23.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="게시판 정보")
public class BlbrVO extends BaseVO {
	
	@Min(value = 1, groups = {Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="게시물일련번호")
	@FieldName("게시물일련번호")
	private int bltnSeq;					/* 게시물일련번호 */
	
	@Min(value = 1, groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="게시판일련번호")
	@FieldName("게시판일련번호")
	private int blbrSno;					/* 게시판일련번호 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="게시물제목")
	@FieldName("게시물제목")
	private String bltnTitle;				/* 게시물제목 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="게시물내용")
	@FieldName("게시물내용")
	private String bltnCn;					/* 게시판내용 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="노출채널구분코드")
	@FieldName("노출채널구분코드")
	private String dspChnScnCd;				/* 노출채널구분코드 */
	
	@ApiModelProperty(value="노출채널구분코드")
	@FieldName("노출채널구분코드명")
	private String dspChnScnNm;				/* 노출채널구분코드명 */
	
	@ApiModelProperty(value="게시물구분코드")
	@FieldName("게시물구분코드")
	private String bltnScnCd;				/* 게시물구분코드 */
	
	@ApiModelProperty(value="게시물구분코드명")
	@FieldName("게시물구분코드명")
	private String bltnScnNm;				/* 게시물구분코드명 */
	
	@ApiModelProperty(value="조회수")
	@FieldName("조회수")
	private int chkCt;						/* 조회수 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@Pattern(regexp = "(Y|N)", groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="게시물공개여부")
	@FieldName("게시물공개여부")
	private String bltnOpenYn;				/* 게시물공개여부 */
	
	@Pattern(regexp = "(Y|N)")
	@ApiModelProperty(value="질문등록여부")
	@FieldName("질문등록여부")
	private String inqRgtnYn;				/* 질문등록여부 */
}
