package com.wjthinkbig.aimath.blbr.vo;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 23.
  * @프로그램 설명 : 게시판 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 23.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="게시판 검색 정보")
public class BlbrSearchVO {
	
	@ApiModelProperty(value="검색타입")
	@FieldName("검색타입")
	private String srchTy;						/* 검색타입 */
	
	@ApiModelProperty(value="검색어")
	@FieldName("검색어")
	private String srchTxt;						/* 검색어 */
	
	@ApiModelProperty(value="현재 페이지")
	@FieldName("현재 페이지")
	private int currentPage;					/* 현재 페이지 */
	
	@ApiModelProperty(value="페이지에 노출될 리스트 수")
	@FieldName("페이지에 노출될 리스트 수")
	private int rowCnt;							/* 페이지에 노출될 리스트 수 */
	
	@Min(1)
	@ApiModelProperty(value="게시판일련번호")
	@FieldName("게시판일련번호")
	private int blbrSno;						/* 게시판일련번호 */
	
	@ApiModelProperty(value="게시물일련번호")
	@FieldName("게시물일련번호")
	private int bltnSeq;						/* 게시물일련번호 */
	
	@ApiModelProperty(value="노출채널구분코드")
	@FieldName("노출채널구분코드")
	private String dspChnScnCd;					/* 노출채널구분코드 */
	
	@ApiModelProperty(value="게시물공개여부")
	@FieldName("게시물공개여부")
	private String bltnOpenYn;					/* 게시물공개여부 */
	
	@ApiModelProperty(value="질문등록여부")
	@FieldName("질문등록여부")
	private String inqRgtnYn;					/* 질문등록여부 */
	
}
