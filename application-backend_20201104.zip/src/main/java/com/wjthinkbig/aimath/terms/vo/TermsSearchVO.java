package com.wjthinkbig.aimath.terms.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="이용약관 검색 정보")
public class TermsSearchVO {
	@ApiModelProperty(value="페이징 처리 여부")
	
	@FieldName("페이징 처리 여부")
	private String pagingYn;				/* 페이징 처리 여부 */
	
	@ApiModelProperty(value="현재 페이지")
	@FieldName("현재 페이지")
	private int currentPage;				/* 현재 페이지 */
	
	@ApiModelProperty(value="페이지에 노출될 리스트 수")
	@FieldName("페이지에 노출될 리스트 수")
	private int rowCnt;						/* 페이지에 노출될 리스트 수 */
}
