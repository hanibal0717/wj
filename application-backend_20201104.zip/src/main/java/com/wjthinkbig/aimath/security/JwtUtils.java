/**
 * 
 */
package com.wjthinkbig.aimath.security;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;

import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.security.config.JwtSettings;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 11. 
  * @프로그램 설명 : JWT 토큰 Utility
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
@Component(value = "jwtUtils")
public class JwtUtils {

	private final JwtSettings settings;
	
	@Autowired
	public JwtUtils(JwtSettings settings) {
		this.settings = settings;
	}
	
	// 이 빈의 의존성 주입이 이루어진 후 초기화를 수행하는 메소드
	@PostConstruct
	protected void init() {
		// 서명키를 Base64로 인코딩		
		settings.setTokenSigningKey(Base64.getEncoder().encodeToString(settings.getTokenSigningKey().getBytes())); 
	}
	
	/**
	  * @Method 설명 : 지정한 권한을 갖는 Access 토큰을 생성한다.  
	  * @param username 사용자(JWT 토큰의 sub 항목값) 
	  * @param roles 권한
	  * @param tokenClaims 토큰에 추가할 Claim 정보
	  * @return JWT Access 토큰 
	 */
	public String createAccessToken(User userContext, HashMap<String, String> tokenClaims) {

		if(StringUtils.isBlank(userContext.getUsername())) {
			throw new IllegalArgumentException();
		}
		
		Claims claims = Jwts.claims().setSubject(userContext.getUsername());
		
		// "ath" 항목에 인증된 사용자의 권한을 넣는다.
		claims.put("ath", userContext.getAuthorities().stream().map(s -> s.toString()).collect(Collectors.toList()));
		
		if(tokenClaims != null) {
			Set<Map.Entry<String,String>> entries = tokenClaims.entrySet();
			for (Map.Entry<String, String> entry : entries) {
				claims.put(entry.getKey(), entry.getValue());
	        }
		}
		
		LocalDateTime currentTime = LocalDateTime.now();
		
		String token = Jwts.builder()
				.setClaims(claims)				// JWT Body
		        .setIssuer(settings.getTokenIssuer())				// 토큰 발급자
		        .setIssuedAt(Date.from(currentTime.atZone(ZoneId.systemDefault()).toInstant()))	// 발급시간
		        .setExpiration(Date.from(currentTime.plusMinutes(settings.getAccessTokenExpirationTime()).atZone(ZoneId.systemDefault()).toInstant())) // 만료시간
		        .signWith(SignatureAlgorithm.HS512, settings.getTokenSigningKey())
		        .compact();
		
		if(log.isDebugEnabled()) {
			log.debug("==========================================================");
	        log.debug("tokenExpirationTime : {} min", settings.getAccessTokenExpirationTime());
	        log.debug("expiration : {}", Date.from(currentTime.plusMinutes(settings.getAccessTokenExpirationTime()).atZone(ZoneId.systemDefault()).toInstant()));
	        log.debug("token : {}", token);
	        log.debug("authorities : {}", userContext.getAuthorities());
	        log.debug("==========================================================");
		}
       
		return token;
	}
	
	/**
	  * @Method 설명 : Refresh 토큰을 생성한다.  
	  * @param username 사용자(JWT 토큰의 sub 항목값)
	  * @param roles 권한
	  * @param tokenClaims 토큰에 추가할 Claim 정보
	  * @return JWT Refresh 토큰
	 */
	public String createRefreshToken(User userContext, HashMap<String, String> tokenClaims) {
		
		if(StringUtils.isBlank(userContext.getUsername())) {
			throw new IllegalArgumentException();
		}
		
		Claims claims = Jwts.claims().setSubject(userContext.getUsername());
		
		// "ath" 항목에 인증된 사용자의 권한을 넣는다.
		claims.put("ath", userContext.getAuthorities().stream().map(s -> s.toString()).collect(Collectors.toList()));
		
		if(tokenClaims != null) {
			Set<Map.Entry<String,String>> entries = tokenClaims.entrySet();
			for (Map.Entry<String, String> entry : entries) {
				claims.put(entry.getKey(), entry.getValue());
	        }
		}
		
		LocalDateTime currentTime = LocalDateTime.now();
		
		String token = Jwts.builder()
				.setClaims(claims)				// JWT Body
				.setId(UUID.randomUUID().toString())
		        .setIssuer(settings.getTokenIssuer())				// 토큰 발급자
		        .setIssuedAt(Date.from(currentTime.atZone(ZoneId.systemDefault()).toInstant()))	// 발급시간
		        .setExpiration(Date.from(currentTime.plusMinutes(settings.getRefreshTokenExpirationTime()).atZone(ZoneId.systemDefault()).toInstant())) // 만료시간
		        .signWith(SignatureAlgorithm.HS512, settings.getTokenSigningKey())
		        .compact();
		
		if(log.isDebugEnabled()) {
			log.debug("==========================================================");
	        log.debug("tokenExpirationTime : {} min", settings.getAccessTokenExpirationTime());
	        log.debug("expiration : {}", Date.from(currentTime.plusMinutes(settings.getRefreshTokenExpirationTime()).atZone(ZoneId.systemDefault()).toInstant()));
	        log.debug("refreshToken token : {}", token);
	        log.debug("authorities : {}", userContext.getAuthorities());
	        log.debug("==========================================================");
		}
      
		return token;
	}

	/**
	  * @Method 설명 : 요청헤더(Authorization)에서 JWT 토큰을 가져온다. 없으면 NULL 
	  * @param req HttpServletRequest
	  * @return JWT 토큰 또는 NULL
	 */
	public String resolveToken(HttpServletRequest req) {
		String bearerToken = req.getHeader("Authorization");
		if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7);
		}
		return null;
	}
	
	/**
	  * @Method 설명 : JWT 토큰의 유효성을 검증한다. 
	  * @param token JWT 토큰키
	  * @return 문제(위변조, 만료 등)가 있으면 Exception을 던지고 정상토큰이면 true
	 */
	public boolean validateToken(String token) {
		try {
			Jws<Claims> claims = Jwts.parser()
					.setSigningKey(settings.getTokenSigningKey())
					.parseClaimsJws(token);
			
			ArrayList<String> auth = (ArrayList<String>) claims.getBody().get("ath");	// 토큰에서 권한정보 추출		
			Date expiratioDate = getExpirationDate(token);								// 토큰만료시간 추출
			boolean isExpired = isTokenExpired(token);									// 토큰만료여부
			
			// 정상토큰의 만료정보 출력
			log.debug("1) validateToken) 권한 : {}, 만료시간 : {}, 만료여부 : {}", 
					auth,
					new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(expiratioDate), 
					isExpired);
			
			return true;
		} catch (ExpiredJwtException e) { 
			// 유효 기간이 지난 JWT를 수신한 경우
			log.warn("1) validateToken 실패({}) : {}", e.getClass().getSimpleName(), e.getMessage());
			throw e; // return false;			
		} catch (UnsupportedJwtException e) { 
			// 수신한 JWT의 형식이 애플리케이션에서 원하는 형식과 맞지 않는 경우. 예를 들어, 암호화된 JWT를 사용하는 어플리케이션에 암호화되지 않은 JWT가 전달되는 경우에 이 예외가 발생합니다.
			log.warn("1) validateToken 실패({}) : {}", e.getClass().getSimpleName(), e.getMessage());
			throw e; // return false;
		} catch (MalformedJwtException e) { 
			// 구조적인 문제가 있는 JWT인 경우
			log.warn("1) validateToken 실패({}) : {}", e.getClass().getSimpleName(), e.getMessage());
			throw e; // return false;
		} catch (SignatureException e) { 
			// 시그너처 연산이 실패하였거나, JWT의 시그너처 검증이 실패한 경우 : JWT signature does not match locally computed signature. JWT validity cannot be asserted and should not be trusted.
			log.warn("1) validateToken 실패({}) : {}", e.getClass().getSimpleName(), e.getMessage());
			throw e; // return false;
		} catch (IllegalArgumentException e) {
			// a method has been passed an illegal or inappropriate argument
			log.warn("1) validateToken 실패({}) : {}", e.getClass().getSimpleName(), e.getMessage());
			throw e; // return false;
		}
	}
	
	/**
	  * @Method 설명 : 토큰에서 특정 클레임의 정보만 가져오기
	  * @param token
	  * @param claimsResolver
	  * @return
	 */
	public <T> T getClaim(String token, Function<Claims, T> claimsResolver) {
		final Claims claims = getClaims(token);
		return claimsResolver.apply(claims);
	}
	
	/**
	  * @Method 설명 : 토큰으로부터 JWT Body(Payload)를 가져온다. 
	  * @param token JWT 토큰
	  * @return JWT body, either a String or a Claims instance
	 */
	public Claims getClaims(String token) {
		return Jwts
				.parser()
				.setSigningKey(settings.getTokenSigningKey())
				.parseClaimsJws(token)
				.getBody();
	}
	
	/**
	  * @Method 설명 : 토큰에서 사용자정보(JWT sub 항목값)를 가져온다.
	  * @param token JWT 토큰
	  * @return JWT sub 항목값 또는 NULL
	 */
	public String getUsername(String token) {		
		return getClaim(token, Claims::getSubject);
	}	
	
	/**
	  * @Method 설명 : 토큰에서 만료날짜 정보를 가져온다.
	  * @param token JWT 토큰
	  * @return 만료일자 및 시간
	 */
	public Date getExpirationDate(String token) {
		return getClaim(token, Claims::getExpiration);
	}
	
	/**
	  * @Method 설명 : 토큰에서 JTI 항목값을 가져온다.
	  * @param token JWT 토큰
	  * @return
	 */
	public String getJti(String token) {
		return getClaim(token, Claims::getId);
   }
	
	/**
	  * @Method 설명 : 토큰의 만료여부를 판별한다.
	  * @param token JWT 토큰
	  * @return 만료되면 true, 유효한 토큰이면 false
	 */
	private Boolean isTokenExpired(String token) {
		final Date expiration = getExpirationDate(token);
		return expiration.before(new Date());
	}	
}