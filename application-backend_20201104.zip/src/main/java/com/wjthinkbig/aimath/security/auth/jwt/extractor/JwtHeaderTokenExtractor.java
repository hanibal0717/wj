/**
 * 
 */
package com.wjthinkbig.aimath.security.auth.jwt.extractor;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;

import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.security.exception.NoTokenHeaderException;

/**
  * @Date : 2020. 10. 14. 
  * @프로그램 설명 : HTTP 헤더로부터 JWT Bearer 토큰을 가져오는 Extractor 구현체
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Component("jwtHeaderTokenExtractor")
public class JwtHeaderTokenExtractor implements TokenExtractor {
	public static String HEADER_PREFIX = "Bearer ";
	
	@Autowired
	private MessageSource messageSource;
	
	@Override
	public String extract(String headerPayload) {
		if (StringUtils.isNotBlank(headerPayload) && headerPayload.startsWith(HEADER_PREFIX)) {
			// 헤더에서 JWT 토큰값만 추출한다.
			return headerPayload.substring(HEADER_PREFIX.length(), headerPayload.length());
		} else {
			String msgKey = "S003001"; // 헤더 정보가 존재하지 않거나 올바르지 않습니다.
			throw new NoTokenHeaderException(messageSource.getMessage(msgKey,  null, Locale.getDefault()));
        }		
	}
}