/**
 * 
 */
package com.wjthinkbig.aimath.security.auth.jwt;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;

import com.wjthinkbig.aimath.acnt.vo.AcntVO;
import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.security.auth.JwtAuthenticationToken;
import com.wjthinkbig.aimath.security.config.JwtSettings;
import com.wjthinkbig.aimath.security.model.token.RawAccessJwtToken;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 10. 
  * @프로그램 설명 : JWT 토큰인증 프로바이더
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 10.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Component("jwtAuthenticationProvider")
@Slf4j
public class JwtAuthenticationProvider implements AuthenticationProvider {	
	private final JwtSettings jwtSettings;
	
	@Autowired
	public JwtAuthenticationProvider(JwtSettings jwtSettings) {	
		this.jwtSettings = jwtSettings;
	}

	/**
	 * 회원용 인증토큰(JwtAuthenticationToken) 토큰을 받아 인증을 처리
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		// 전달받은 인증토큰을 가져와 파싱하여 유효성을 체크
		RawAccessJwtToken rawAccessJwtToken = (RawAccessJwtToken)(authentication.getCredentials());
		
		/**
		 * BadCredentialsException : JWT 토큰의 유효성에 문제가 있는 모든 경우
		 * JwtExpiredTokenException : 토큰이 만료된 경우
		 */
		Jws<Claims> jwsClaims = rawAccessJwtToken.parseClaim(jwtSettings.getTokenSigningKey());
		String subject = jwsClaims.getBody().getSubject(); // 회원용 토큰의 sub는 이메일주소		
		List<String> scopes = jwsClaims.getBody().get("ath", List.class);
		List<SimpleGrantedAuthority> authorities = scopes.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
		
		boolean isUser = scopes.contains("ROLE_USER");
		boolean isAdmin = scopes.contains("ROLE_ADMIN");
		
		log.info("전송된 토큰 구분 : 사용자({}), 관리자({})", isUser, isAdmin);
		
		User user = null;
		
		if(isUser) {			
			MbrVO mbrVO = new MbrVO();
			mbrVO.setMbrId(jwsClaims.getBody().get("mbr").toString());
			mbrVO.setPw("");
			mbrVO.setEmailAdrs(subject);
			mbrVO.setRoles(scopes);
			
			user = new MbrAccount(mbrVO);
		} else if(isAdmin) {
			AcntVO acntVO = new AcntVO();
			acntVO.setMngtUserId(jwsClaims.getBody().getSubject());
			acntVO.setPw("");
			acntVO.setRoles(scopes);

			user = new AdminAccount(acntVO);
		}
		
		log.info("인증된 어댑터 객체 : {}", user);
		
		// 인증된 객체를 반환 
		return new JwtAuthenticationToken(user, authorities);
	}

	/**
	 * 회원용 인증토큰(JwtAuthenticationToken)에만 적용
	 */
	@Override
	public boolean supports(Class<?> authentication) {
		return JwtAuthenticationToken.class.isAssignableFrom(authentication);
	}
}