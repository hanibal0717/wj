package com.wjthinkbig.aimath.security.auth.ajax;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.security.exception.AuthMethodNotSupportedException;
import com.wjthinkbig.aimath.security.exception.JwtExpiredTokenException;
import com.wjthinkbig.aimath.security.exception.NoTokenHeaderException;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 16. 
  * @프로그램 설명 : 인증실패시 처리핸들러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 16.     Lee Seung Hyuk              최초작성
  * </pre>
 */
@Component("ajaxAwareAuthenticationFailureHandler")
@Slf4j
public class AjaxAwareAuthenticationFailureHandler implements AuthenticationFailureHandler {
	private final ObjectMapper mapper;
	
	@Autowired
	public AjaxAwareAuthenticationFailureHandler(ObjectMapper mapper) {
		this.mapper = mapper;
	}

	/**
	 * 인증처리 중 발생하는 예외 (AuthenticationException 타입)
	 *  - BadCredentialsException  : JWT 토큰의 유효성에 문제가 있는 모든 경우 
	 *  - JwtExpiredTokenException : 토큰이 만료된 경우
	 *  - AuthMethodNotSupportedException : 토큰 추출을 위한 헤더 정보가 유효하지 않은 경우
	 *  - UsernameNotFoundException : (로그인) 해당 사용자 정보가 없을 경우
	 *  - InsufficientAuthenticationException : 권한이 부여되어 있지 않을 경우
	 */
	@Override
	public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException e) throws IOException, ServletException {
		response.setCharacterEncoding("UTF-8");
		response.setStatus(HttpStatus.UNAUTHORIZED.value());
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		
		log.error("인증처리 중 예외 발생 : {} ({})", e.getClass().getSimpleName(), e.getMessage());
		
		// 인증시 특정 유형에 해당하지 않는 기본 오류코드
		String msgKey = "S003003"; // 인증에 실패하였습니다.
		String msg = e.getMessage();
		
		CommonResult result = new CommonResult();
		
		if (e instanceof BadCredentialsException | e instanceof UsernameNotFoundException) {	
			msgKey = "S001006"; // 계정이 존재하지 않거나 계정정보가 올바르지 않습니다.
		} else if (e instanceof JwtExpiredTokenException) {
			msgKey = "E000018"; // 토큰이 만료되었습니다.
		} else if (e instanceof AuthMethodNotSupportedException) {
			msgKey = "S003003"; // 인증에 실패하였습니다.
		} else if (e instanceof NoTokenHeaderException) {
			msgKey = "S003001"; // 헤더 정보가 존재하지 않거나 올바르지 않습니다.
		}
		
		result.setCode(msgKey);
		result.setMsg(msg);
		
		mapper.writeValue(response.getWriter(), result);
	}
}