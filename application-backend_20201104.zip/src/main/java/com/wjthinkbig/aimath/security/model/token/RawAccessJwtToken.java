/**
 * 
 */
package com.wjthinkbig.aimath.security.model.token;

import org.springframework.security.authentication.BadCredentialsException;

import com.wjthinkbig.aimath.security.exception.JwtExpiredTokenException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.jsonwebtoken.UnsupportedJwtException;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 15. 
  * @프로그램 설명 : 전달받은 토큰 문자열을 파싱하여 토큰에 있는 정보를 가져온다. 만료되거나 유효하지 않은 토큰이면 예외를 반환한다. 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 15.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
public class RawAccessJwtToken  implements JwtToken {

	/**
	 * 토큰 문자열
	 */
	private String token;
	
	public RawAccessJwtToken(String token) {
		this.token = token;
	}	

	/**
	  * @Method 설명 : 생성자를 통해 받은 토큰이 정상적으로 서명된 유효한 토큰이면 토큰정보를 반환한다. 아니면 예외처리  
	  * @param signingKey 토큰 서명키
	  * @return
	  * @throws BadCredentialsException  : JWT 토큰의 유효성에 문제가 있는 모든 경우
	  * @throws JwtExpiredTokenException : 토큰이 만료된 경우
	 */
	public Jws<Claims> parseClaim(String signingKey) {
		try {
			return Jwts.parser().setSigningKey(signingKey).parseClaimsJws(this.token);
		} catch (UnsupportedJwtException | MalformedJwtException | SignatureException | IllegalArgumentException ex) {
			/**
			 * UnsupportedJwtException : 수신한 JWT의 형식이 애플리케이션에서 원하는 형식과 맞지 않는 경우. 예를 들어, 암호화된 JWT를 사용하는 어플리케이션에 암호화되지 않은 JWT가 전달되는 경우에 이 예외가 발생합니다.
			 * MalformedJwtException : 구조적인 문제가 있는 JWT인 경우
			 * SignatureException : 시그너처 연산이 실패하였거나, JWT의 시그너처 검증이 실패한 경우 : JWT signature does not match locally computed signature. JWT validity cannot be asserted and should not be trusted.
			 */
			log.error("1) parseClaim 실패({}) : {}", ex.getClass().getSimpleName(), ex.getMessage());
 
			throw new BadCredentialsException("Invalid JWT Token", ex); 
		} catch (ExpiredJwtException ex) {  
			log.error("1) parseClaim 실패({}) : {}", ex.getClass().getSimpleName(), ex.getMessage());
			throw new JwtExpiredTokenException(this, "JWT Token expired", ex);
		}	
	}

	@Override
	public String getToken() {
		return this.token;
	}
}