package com.wjthinkbig.aimath.security.auth.ajax.user;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wjthinkbig.aimath.mbr.vo.MbrLoginVO;
import com.wjthinkbig.aimath.security.user.UserAuthenticationToken;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 21. 
  * @프로그램 설명 : 사용자 로그인 인증필터
  *  - 사용자 로그인 경로에 대해 작동
  *  - AbstractAuthenticationProcessingFilter의 doFilter 로직
  *  - AjaxUserAuthenticationProvider.authenticate() 인증처리
  *  - 성공 또는 실패에 따른 핸들러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 21.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Slf4j
public class AjaxUserLoginProcessingFilter extends AbstractAuthenticationProcessingFilter {
	private AuthenticationSuccessHandler successHandler;
	private AuthenticationFailureHandler failureHandler;
	private final ObjectMapper objectMapper;
	
	public AjaxUserLoginProcessingFilter(String defaultFilterProcessesUrl, AuthenticationSuccessHandler successHandler, AuthenticationFailureHandler failureHandler, ObjectMapper objectMapper) {
		super(defaultFilterProcessesUrl);
		this.successHandler = successHandler;
		this.failureHandler = failureHandler;
		this.objectMapper = objectMapper;
	}

	/**
	 * 인증을 시도하여 인증된 사용자에 대해서는 인증토큰 객체를 반환한다. 인증이 진행중이면 null을, 실패하면 AuthenticationException을 반환한다.
	 *  - UsernameNotFoundException : 해당 사용자 없을 경우
	 *  - BadCredentialsException   : 비밀번호 불일치
	 *  - InsufficientAuthenticationException : 권한이 부여되어 있지 않을 경우
	 */
	@Override
	public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) throws AuthenticationException, IOException, ServletException {
		MbrLoginVO mbr = objectMapper.readValue(request.getReader(), MbrLoginVO.class);
		
		log.debug("사용자 로그인 인증요청정보 : {}", mbr);
		
		// 전송된 이메일 암호화
		try {
			mbr.getEmailAdrsEn();
		} catch (Exception e) {
			
		}
		
		// 인증할 정보를 담은 UsernamePasswordAuthenticationToken
		UserAuthenticationToken token = new UserAuthenticationToken(mbr.getEmailAdrs(), mbr.getPw());
		
		// AjaxUserAuthenticationProvider.authenticate()
		return this.getAuthenticationManager().authenticate(token);
	}

	@Override
	protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authResult) throws IOException, ServletException {
		successHandler.onAuthenticationSuccess(request, response, authResult);
	}

	@Override
	protected void unsuccessfulAuthentication(HttpServletRequest request, HttpServletResponse response, AuthenticationException failed) throws IOException, ServletException {
		SecurityContextHolder.clearContext();		
		failureHandler.onAuthenticationFailure(request, response, failed);
	}
}