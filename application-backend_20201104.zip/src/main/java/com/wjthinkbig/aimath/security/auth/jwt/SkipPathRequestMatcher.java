/**
 * 
 */
package com.wjthinkbig.aimath.security.auth.jwt;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.security.web.util.matcher.OrRequestMatcher;
import org.springframework.security.web.util.matcher.RequestMatcher;

/**
  * @Date : 2020. 10. 14. 
  * @프로그램 설명 : 인증 예외경로와 인증대상 경로를 기준으로 요청한 API 경로가 인증을 필요로 하는 경로인지 판별한다.  
  * - 인증예외경로와 인증이 필요한 경로를 생성자로 받아 API 요청이 인증이 필요한지 여부를 판별할 수 있도록 하는 기능을 제공한다.  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class SkipPathRequestMatcher implements RequestMatcher {
	private OrRequestMatcher matchers;
	private RequestMatcher processingMatcher;

	/**
	 * @param pathToSkip 인증이 필요없는 요청경로 (로그인, 토큰재발급 등)
	 * @param processingPath 인증처리해야 하는 요청경로
	 */
	public SkipPathRequestMatcher(List<String> pathToSkip, String processingPath) {
		List<RequestMatcher> requestMatchers = pathToSkip.stream().map(path -> new AntPathRequestMatcher(path)).collect(Collectors.toList());
		matchers = new OrRequestMatcher(requestMatchers);		
		processingMatcher = new AntPathRequestMatcher(processingPath);		
	}

	@Override
	public boolean matches(HttpServletRequest request) {
		// 인증이 필요없으면 false
		if(matchers.matches(request)) {			
			return false;
		}
		
		// 인증대상 경로이면 true, 아니면 false
		return processingMatcher.matches(request) ? true : false; 
	}
}