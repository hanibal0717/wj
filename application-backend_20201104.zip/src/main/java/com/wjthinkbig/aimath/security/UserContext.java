package com.wjthinkbig.aimath.security;

/**
  * @Date : 2020. 10. 9. 
  * @프로그램 설명 : Spring Security Principal(MbrAccount, AdminAccount)의 인터페이스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 9.     Lee Seung Hyuk              최초작성
  * </pre>
 */
public interface UserContext {
	
	/**
	  * @Method 설명 : 사용자 ID를 반환한다.
	  * @return 가입회원 ID 또는 관리자 ID
	 */
	public String getUserId();
}