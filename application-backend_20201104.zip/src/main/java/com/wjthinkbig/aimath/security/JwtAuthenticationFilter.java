/**
 * 
 */
package com.wjthinkbig.aimath.security;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.filter.OncePerRequestFilter;

import com.wjthinkbig.aimath.acnt.vo.AcntVO;
import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.config.WebSecurityConfig;
import com.wjthinkbig.aimath.core.utils.JsonUtils;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.mbr.vo.MbrVO;
import com.wjthinkbig.aimath.security.auth.jwt.extractor.TokenExtractor;
import com.wjthinkbig.aimath.security.config.JwtSettings;
import com.wjthinkbig.aimath.security.exception.JwtExpiredTokenException;
import com.wjthinkbig.aimath.security.model.token.RawAccessJwtToken;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 11. 
  * @프로그램 설명 : JWT 인증 필터
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 11.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
public class JwtAuthenticationFilter extends OncePerRequestFilter {
	private final JwtSettings jwtSettings;
	private final TokenExtractor tokenExtractor;
	
	@Autowired
	public JwtAuthenticationFilter(TokenExtractor tokenExtractor, JwtSettings jwtSettings) {
		this.tokenExtractor = tokenExtractor;
		this.jwtSettings = jwtSettings;
	}
		
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
		
		// Authorization 헤더에서  Bearer 토큰을 추출하여 인증용 토큰(JwtAuthenticationToken)을 생성
		String headerPayload = request.getHeader(WebSecurityConfig.AUTHENTICATION_HEADER_NAME);
		
		try {
			// 헤더에서 토큰을 가져오지 못했을 경우 NoTokenHeaderException 발생
			RawAccessJwtToken rawAccessJwtToken = new RawAccessJwtToken(tokenExtractor.extract(headerPayload));
			String token = rawAccessJwtToken.getToken();
			
			// 토큰 유효성 검증에 실패시 BadCredentialsException, JwtExpiredTokenException 발생 
			Jws<Claims> jwsClaims = rawAccessJwtToken.parseClaim(jwtSettings.getTokenSigningKey());
			
			log.debug("1) JwtAuthenticationFilter => 추출 토큰 : {}", token);			
			
			/*String jti = jwsClaims.getBody().getId(); // 리프레시 토큰 표식			
			if(StringUtils.isNotBlank(jti)) {
				// 리프레시 토큰은 인증토큰으로 사용불허
				log.debug("리프레시 토큰은 인증토큰으로 사용불허 - jti : {}", jti);
				return;
			}*/
			
			String subject = jwsClaims.getBody().getSubject(); // 회원용 토큰의 sub는 이메일주소
			List<String> scopes = jwsClaims.getBody().get("ath", List.class);
			List<SimpleGrantedAuthority> authorities = scopes.stream().map(SimpleGrantedAuthority::new).collect(Collectors.toList());
			
			boolean isUser = scopes.contains("ROLE_USER");
			boolean isAdmin = scopes.contains("ROLE_ADMIN");
			
			log.info("2) 전송된 토큰 구분 : 사용자({}), 관리자({})", isUser, isAdmin);
			
			User user = null;	
			if(isUser) {			
				MbrVO mbrVO = new MbrVO();
				mbrVO.setMbrId(jwsClaims.getBody().get("mbr").toString());
				mbrVO.setPw("");
				mbrVO.setEmailAdrs(subject);
				mbrVO.setRoles(scopes);
				
				user = new MbrAccount(mbrVO);
			} else if(isAdmin) {
				AcntVO acntVO = new AcntVO();
				acntVO.setMngtUserId(subject);
				acntVO.setPw("");
				acntVO.setRoles(scopes);

				user = new AdminAccount(acntVO);
			}
			
			log.info("3) 추출 토큰에서 인증된 어댑터 객체 : {}", user);
			
			// 토큰으로부터 
			Authentication authentication = new UsernamePasswordAuthenticationToken(user, null, user.getAuthorities());
			
			// 인증컨텐스트에 저장
			SecurityContextHolder.getContext().setAuthentication(authentication);						
		} catch (Exception ex) {
			log.debug("4) JwtAuthenticationFilter Exception : {}", ex.getClass().getSimpleName());
			
			// 액세스 만료된 경우에만 결과를 주고 나머지는 공통 처리 (인증 및 권한부족 예외)
			if(ex instanceof JwtExpiredTokenException) {
				response.setCharacterEncoding("UTF-8");
				response.setStatus(HttpStatus.UNAUTHORIZED.value());
				response.setContentType(MediaType.APPLICATION_JSON_VALUE);
				
				CommonResult result = new CommonResult();
				result.setCode("E000018");
				result.setMsg("Token has expired.");
				response.getWriter().write(JsonUtils.convertObjectToJson(result));
				
				return;
			}	
		}

		filterChain.doFilter(request, response);
	}
}