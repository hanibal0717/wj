package com.wjthinkbig.aimath.security.exception;

/**
  * @Date : 2020. 10. 21. 
  * @프로그램 설명 : 유효하지 않는 JwtToken에 대한 예외
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 21.     Lee Seung Hyuk              최초작성
  * </pre>
 */
public class InvalidJwtToken extends RuntimeException {
	private static final long serialVersionUID = -1922267684150270206L;
}