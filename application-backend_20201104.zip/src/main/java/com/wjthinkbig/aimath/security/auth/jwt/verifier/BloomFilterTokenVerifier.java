/**
 * 
 */
package com.wjthinkbig.aimath.security.auth.jwt.verifier;

import org.springframework.stereotype.Component;

import com.wjthinkbig.aimath.core.utils.StringUtils;

/**
  * @Date : 2020. 10. 14. 
  * @프로그램 설명 : 리프레시 토큰임을 판별하는 Verifier
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Component("tokenVerifier")
public class BloomFilterTokenVerifier implements TokenVerifier {

	@Override
	public boolean verify(String jti) {
		// You should ideally implement your own TokenVerifier to check for revoked tokens.
		return StringUtils.isNotBlank(jti) ? true : false;
	}
}