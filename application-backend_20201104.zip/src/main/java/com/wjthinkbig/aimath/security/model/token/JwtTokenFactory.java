/**
 * 
 */
package com.wjthinkbig.aimath.security.model.token;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;

import com.wjthinkbig.aimath.core.exception.BizException;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.security.config.JwtSettings;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 15. 
  * @프로그램 설명 :
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 15.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Component("jwtTokenFactory")
@Slf4j
public class JwtTokenFactory {	
	private final JwtSettings settings;

	@Autowired
	public JwtTokenFactory(JwtSettings settings) {
		super();
		this.settings = settings;
	}
	
	@Autowired
	private MessageSource messageSource;
	
	
	/**
	  * @Method 설명 : 사용자 인증정보로부터 액세스 토큰을 생성한다. 
	  * @param userContext 사용자 인증객체 (회원/관리자)
	  * @param additionalClaims 토큰에 추가할 정보
	  * @return AccessJwtToken 객체
	 */
	public AccessJwtToken createAccessJwtToken(User userContext, HashMap<String, String> additionalClaims) {
		if(StringUtils.isBlank(userContext.getUsername())) {
			throw new BizException(messageSource, "S002358", ""); // 토큰을 생성 할 수 없습니다.
		}
		
		Claims claims = Jwts.claims().setSubject(userContext.getUsername());
		
		// "ath" 항목에 인증된 사용자의 권한을 넣는다.
		claims.put("ath", userContext.getAuthorities().stream().map(s -> s.toString()).collect(Collectors.toList()));
		
		if(additionalClaims != null) {
			Set<Map.Entry<String,String>> entries = additionalClaims.entrySet();
			for (Map.Entry<String, String> entry : entries) {
				claims.put(entry.getKey(), entry.getValue());
	        }
		}
		
		LocalDateTime currentTime = LocalDateTime.now();
		
		String token = Jwts.builder()
				.setClaims(claims) // JWT Body
		        .setIssuer(settings.getTokenIssuer()) // 토큰 발급자
		        .setIssuedAt(Date.from(currentTime.atZone(ZoneId.systemDefault()).toInstant()))	// 발급시간
		        .setExpiration(Date.from(currentTime.plusMinutes(settings.getAccessTokenExpirationTime()).atZone(ZoneId.systemDefault()).toInstant())) // 만료시간
		        .signWith(SignatureAlgorithm.HS512, settings.getTokenSigningKey())
		        .compact();
		
		if(log.isDebugEnabled()) {
			log.debug("==========================================================");
	        log.debug("tokenExpirationTime : {} min", settings.getAccessTokenExpirationTime());
	        log.debug("expiration : {}", Date.from(currentTime.plusMinutes(settings.getAccessTokenExpirationTime()).atZone(ZoneId.systemDefault()).toInstant()));
	        log.debug("access token : {}", token);
	        log.debug("authorities : {}", userContext.getAuthorities());
	        log.debug("==========================================================");
		}
		
		return new AccessJwtToken(token, claims);
	}
	
	/**
	  * @Method 설명 : 사용자 인증정보로부터 리프레시 토큰을 생성한다.
	  * @param userContext 사용자 인증객체 (회원/관리자)
	  * @param additionalClaims 추가할 클레임정보
	  * @return 리프레시 토큰객체 (AccessJwtToken)
	 */
	public JwtToken createRefreshToken(User userContext, HashMap<String, String> additionalClaims) {
		if(StringUtils.isBlank(userContext.getUsername())) {
			throw new BizException(messageSource, "S002358", ""); // 토큰을 생성 할 수 없습니다.
		}
		
		Claims claims = Jwts.claims().setSubject(userContext.getUsername());
		
		// "ath" 항목에 인증된 사용자의 권한을 넣는다.
		claims.put("ath", userContext.getAuthorities().stream().map(s -> s.toString()).collect(Collectors.toList()));
		
		if(additionalClaims != null) {
			Set<Map.Entry<String,String>> entries = additionalClaims.entrySet();
			for (Map.Entry<String, String> entry : entries) {
				claims.put(entry.getKey(), entry.getValue());
	        }
		}
		
		LocalDateTime currentTime = LocalDateTime.now();
		
		String token = Jwts.builder()
				.setClaims(claims) // JWT Body
				.setId(UUID.randomUUID().toString()) // 리프레시 토큰 표식
		        .setIssuer(settings.getTokenIssuer()) // 토큰 발급자
		        .setIssuedAt(Date.from(currentTime.atZone(ZoneId.systemDefault()).toInstant()))	// 발급시간
		        .setExpiration(Date.from(currentTime.plusMinutes(settings.getRefreshTokenExpirationTime()).atZone(ZoneId.systemDefault()).toInstant())) // 만료시간
		        .signWith(SignatureAlgorithm.HS512, settings.getTokenSigningKey())
		        .compact();
		
		if(log.isDebugEnabled()) {
			log.debug("==========================================================");
	        log.debug("tokenExpirationTime : {} min", settings.getAccessTokenExpirationTime());
	        log.debug("expiration : {}", Date.from(currentTime.plusMinutes(settings.getRefreshTokenExpirationTime()).atZone(ZoneId.systemDefault()).toInstant()));
	        log.debug("refresh token : {}", token);
	        log.debug("authorities : {}", userContext.getAuthorities());
	        log.debug("==========================================================");
		}      
		
		return new AccessJwtToken(token, claims);
	}
}