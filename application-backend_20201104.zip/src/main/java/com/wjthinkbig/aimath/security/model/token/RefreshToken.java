/**
 * 
 */
package com.wjthinkbig.aimath.security.model.token;

import java.util.List;
import java.util.Optional;

import org.springframework.security.authentication.BadCredentialsException;

import com.wjthinkbig.aimath.core.utils.StringUtils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;

/**
  * @Date : 2020. 10. 14. 
  * @프로그램 설명 : 리프레시 토큰
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14.     Lee Seung Hyuk            최초작성
  * </pre>
  */
public class RefreshToken implements JwtToken {
	private Jws<Claims> claims;
	
	private RefreshToken(Jws<Claims> claims) {
		this.claims = claims;
	}
	
	/**
	  * @Method 설명 : 리프레시 토큰을 생성한다. 리프레시 토큰이 아니면(jti로 판별) 빈 값을 반환한다.
	  * @param token RawAccessJwtToken 
	  * @param signingKey JWT 토큰 서명키
	  * @throws BadCredentialsException, JwtExpiredTokenException
	  * @return Optional<RefreshToken>
	 */
	public static Optional<RefreshToken> create(RawAccessJwtToken token, String signingKey) {
		Jws<Claims> claims = token.parseClaim(signingKey);
		
		List<String> scopes = claims.getBody().get("ath", List.class);
		String jti = claims.getBody().getId();
		if(scopes == null || scopes.isEmpty() || StringUtils.isBlank(jti)) {
			return Optional.empty();
		}
		return Optional.of(new RefreshToken(claims));
	}

	@Override
	public String getToken() {		
		return null;
	}

	public String getJti() {
		return claims.getBody().getId();		
	}
	
	public String getSubject() {
		return claims.getBody().getSubject();
	}
	
	public Jws<Claims> getClaims() {
		return this.claims;
	}
}