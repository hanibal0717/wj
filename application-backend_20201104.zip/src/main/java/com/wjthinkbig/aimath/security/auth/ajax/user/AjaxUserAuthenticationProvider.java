package com.wjthinkbig.aimath.security.auth.ajax.user;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.wjthinkbig.aimath.security.user.CustomMbrDetailsService;
import com.wjthinkbig.aimath.security.user.UserAuthenticationToken;

/**
  * @Date : 2020. 10. 21. 
  * @프로그램 설명 : 사용자 로그인 인증 프로바이더
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 21.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Component("ajaxUserAuthenticationProvider")
public class AjaxUserAuthenticationProvider implements AuthenticationProvider {
	/**
	 * 단방향 암호화 처리기
	 */
	@Resource(name = "passwordEncoder")
	private final PasswordEncoder passwordEncoder;
	
	/**
	 * 사용자 조회를 위한 UserDetailsService 구현체
	 */
	@Resource(name = "userDetailsService")
	private final UserDetailsService userDetailsService;
	
	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	public AjaxUserAuthenticationProvider(PasswordEncoder passwordEncoder, CustomMbrDetailsService userDetailsService) {
		this.passwordEncoder = passwordEncoder;
		this.userDetailsService = userDetailsService;
	}	
	
	/**
	 * @throws AuthenticationException
	 *  - UsernameNotFoundException : 해당 사용자 없을 경우 (S001006)
	 *  - BadCredentialsException   : 비밀번호 불일치 (S001006)
	 *  - InsufficientAuthenticationException : 권한이 부여되어 있지 않을 경우 (S003004)
	 */
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {	
		String username = (String) authentication.getPrincipal();
        String password = (String) authentication.getCredentials();
        
        // 해당 사용자 없을 경우 - UsernameNotFoundException (AuthenticationException)
        UserDetails user = userDetailsService.loadUserByUsername(username);
        
        // 비밀번호 불일치 - BadCredentialsException (AuthenticationException)
        if (!passwordEncoder.matches(password, user.getPassword())) {
        	throw new BadCredentialsException(messageSource.getMessage("S001006", null, LocaleContextHolder.getLocale())); // 계정이 존재하지 않거나 계정정보가 올바르지 않습니다.
        }
        
        // 부여된 역할이 없을 경우 - InsufficientAuthenticationException (AuthenticationException)
        if (user.getAuthorities() == null) throw new InsufficientAuthenticationException(messageSource.getMessage("S003004", null, LocaleContextHolder.getLocale())); // 사용자에게 할당된 역할이 없습니다.
        
        // 인증된 객체를 반환 
     	return new UserAuthenticationToken(user, null, user.getAuthorities());
	}

	@Override
	public boolean supports(Class<?> authentication) {
		return UserAuthenticationToken.class.isAssignableFrom(authentication);
	}
}