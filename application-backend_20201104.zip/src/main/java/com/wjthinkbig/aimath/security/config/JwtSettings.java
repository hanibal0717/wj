package com.wjthinkbig.aimath.security.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

/**
  * @Date : 2020. 10. 9. 
  * @프로그램 설명 : 토큰 설정 클래스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 9.     Lee Seung Hyuk     최초작성
  * </pre>
 */
@Configuration
@ConfigurationProperties(prefix = "security.jwt")
@Setter
@Getter
public class JwtSettings {

    /**
     * {@link JwtToken} Access Token 유효 시간(분)
     */
    private Integer accessTokenExpirationTime;

    /**
     * {@link JwtToken} Refresh Token 유효 시간(분)
     */
    private Integer refreshTokenExpirationTime;
    
    /**
     * 토큰 발행자
     */
    private String tokenIssuer;

    /**
     * {@link JwtToken} 서명키
     */
    private String tokenSigningKey;
}