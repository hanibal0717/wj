package com.wjthinkbig.aimath.common.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @FileName : CommonCodeVO.java
 * @Project : application-backend
 * @Date : 2020. 8. 20. 
 * @작성자 : 19001861
 * @프로그램 설명 : 공통 코드 VO
 * @변경이력 :
*/
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="공통 코드 정보")
public class CommonCodeVO {
	
	@ApiModelProperty(value="공통코드")
	@FieldName("공통코드")
	private String cmnCd;					/* 공통코드 */
	
	@ApiModelProperty(value="상위코드")
	@FieldName("상위코드")
	private String upCd;					/* 상위코드 */
	
	@ApiModelProperty(value="코드명")
	@FieldName("코드명")
	private String cdNm;					/* 코드명 */
	
}
