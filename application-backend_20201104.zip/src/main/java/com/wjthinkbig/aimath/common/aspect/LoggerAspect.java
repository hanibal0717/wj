package com.wjthinkbig.aimath.common.aspect;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@Aspect
public class LoggerAspect {

	@Around("execution(* com..controller.*Controller.*(..)) or execution(* com..service.impl.*ServiceImpl.*(..)) or execution(* com..service.dao.*Dao.*(..)) ")
	public Object logPrint(ProceedingJoinPoint joinPoint) throws Throwable {

		String type = "";
		String name = joinPoint.getSignature().getDeclaringTypeName();		
		if(name.indexOf("Controller") > -1) {
			type = "[Controller] : ";
		} else if(name.indexOf("Service") > -1) {
			type = "[Service] : ";
		} else if(name.indexOf("Dao") > -1) {
			type = "[Dao] : ";
		}
		
		// 실행시간 측정시작
		StopWatch stopWatch = new StopWatch();
		stopWatch.start();
		
		// 비즈니스 프로세스 실행
		Object result = joinPoint.proceed();
		
		// 실행시간 측정종료
		stopWatch.stop();
		
		log.info(type + name + "." + joinPoint.getSignature().getName() + "() : " + stopWatch.getTotalTimeMillis() + "ms");
		
		return result;
	}
}