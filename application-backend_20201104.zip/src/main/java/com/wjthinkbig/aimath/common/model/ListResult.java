package com.wjthinkbig.aimath.common.model;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ListResult<T> extends CommonResult {

	@ApiModelProperty(value = "응답 데이터(리스트)")
	private List<T> data;
}
