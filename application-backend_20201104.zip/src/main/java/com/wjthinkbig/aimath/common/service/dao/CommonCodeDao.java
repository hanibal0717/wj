package com.wjthinkbig.aimath.common.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.common.vo.CommonCodeVO;
import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;

/**
 * @FileName : CommonCodeDao.java
 * @Project : application-backend
 * @Date : 2020. 8. 20. 
 * @작성자 : 19001861
 * @프로그램 설명 :
 * @변경이력 :
 */
@Mapper("commonCodeDao")
public interface CommonCodeDao {
	
	/**
	  * @Method Name : selectCommonCodeList
	  * @작성일 : 2020. 8. 20.
	  * @작성자 : 19001861
	  * @Method 설명 : 공통 코드 리스트 조회
	  * @변경이력 :  
	  * @param up_cd
	  * @return
	  * @throws Exception
	 */
	List<CommonCodeVO> selectCommonCodeList(String up_cd) throws Exception;
	
}
