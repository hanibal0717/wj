package com.wjthinkbig.aimath.common.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.service.CommonCodeService;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.common.vo.CommonCodeVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
 * @FileName : CommonCodeController.java
 * @Project : application-backend
 * @Date : 2020. 8. 20. 
 * @작성자 : 19001861
 * @프로그램 설명 : 공통 코드
 * @변경이력 :
 */
/**
 * @Date : 2020. 8. 20. 
 * @프로그램 설명 : 공통코드 조회
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 8. 20.     19001861            최초작성
 * </pre>
*/
@Slf4j
@Api(description="공통 코드")
@RestController
public class CommonCodeController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 공통코드 서비스
	 */
	@Resource(name = "commonCodeService")
	private CommonCodeService commonCodeService;
	
	/**
	  * @Method 설명 : 공통 코드 정보 조회
	  * @param  id 부모코드
	  * @return 검색된 공통코드 리스트
	  * @throws Exception
	 */
	@ApiOperation(value="공통 코드 정보 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/code/{code}")	
	public ListResult<CommonCodeVO> selectCodeList(@ApiParam(value = "부모 코드") @PathVariable(name="code", required=true) String up_cd) throws Exception {		
		List<CommonCodeVO> commonCodeList = commonCodeService.selectCommonCodeList(up_cd);
		return responseService.getListResult(commonCodeList);
	}
}
