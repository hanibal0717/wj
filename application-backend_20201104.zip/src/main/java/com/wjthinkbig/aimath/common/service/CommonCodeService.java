package com.wjthinkbig.aimath.common.service;

import java.util.List;

import com.wjthinkbig.aimath.common.vo.CommonCodeVO;

/**
 * @FileName : CommonCodeService.java
 * @Project : application-backend
 * @Date : 2020. 8. 20. 
 * @작성자 : 19001861
 * @프로그램 설명 :
 * @변경이력 :
 */
public interface CommonCodeService {
	
	/**
	  * @Method Name : selectCommonCodeList
	  * @작성일 : 2020. 8. 20.
	  * @작성자 : 19001861
	  * @Method 설명 : 공통 코드 리스트 조회
	  * @변경이력 :  
	  * @param up_cd
	  * @return
	  * @throws Exception
	 */
	public List<CommonCodeVO> selectCommonCodeList(String up_cd) throws Exception;
	
}
