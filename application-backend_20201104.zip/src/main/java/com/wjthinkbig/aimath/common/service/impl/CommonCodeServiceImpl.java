package com.wjthinkbig.aimath.common.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.common.service.CommonCodeService;
import com.wjthinkbig.aimath.common.service.dao.CommonCodeDao;
import com.wjthinkbig.aimath.common.vo.CommonCodeVO;
import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;

/**
 * @FileName : CommonCodeServiceImpl.java
 * @Project : application-backend
 * @Date : 2020. 8. 20. 
 * @작성자 : 19001861
 * @프로그램 설명 :
 * @변경이력 :
 */
@Service("commonCodeService")
public class CommonCodeServiceImpl extends BaseServiceImpl implements CommonCodeService {
	
	@Resource(name = "commonCodeDao")
	private CommonCodeDao commonCodeDao;
	
	@Override
	public List<CommonCodeVO> selectCommonCodeList(String up_cd) throws Exception {
		return commonCodeDao.selectCommonCodeList(up_cd);
	}

}
