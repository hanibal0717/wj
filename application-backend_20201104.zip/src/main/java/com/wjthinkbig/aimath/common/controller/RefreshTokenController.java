package com.wjthinkbig.aimath.common.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.config.WebSecurityConfig;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.mbr.vo.MbrAccount;
import com.wjthinkbig.aimath.security.auth.jwt.extractor.TokenExtractor;
import com.wjthinkbig.aimath.security.auth.jwt.verifier.TokenVerifier;
import com.wjthinkbig.aimath.security.config.JwtSettings;
import com.wjthinkbig.aimath.security.exception.InvalidJwtToken;
import com.wjthinkbig.aimath.security.exception.JwtExpiredTokenException;
import com.wjthinkbig.aimath.security.model.token.AccessJwtToken;
import com.wjthinkbig.aimath.security.model.token.JwtTokenFactory;
import com.wjthinkbig.aimath.security.model.token.RawAccessJwtToken;
import com.wjthinkbig.aimath.security.model.token.RefreshToken;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 10. 
  * @프로그램 설명 : Refresh Token으로 새로운 Access Token을 발급 한다.
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 10.     Lee Seung Hyuk              최초작성
  * </pre>
 */
@Slf4j
@Api(tags = "Token", value = "토큰 재발급", description = "토큰 재발급")
@RestController
public class RefreshTokenController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 사용자정보 조회를 위한 UserDetailsService 구현체
	 */
	@Resource(name = "userDetailsService")
	private UserDetailsService userDetailsService;
	
	/**
	 * 관리자정보 조회를 위한 UserDetailsService 구현체
	 */
	@Resource(name = "adminDetailsService")
	private UserDetailsService adminDetailsService;
	
	/**
	 * Redis Template
	 */
	@Resource(name = "redisTemplate")
	private RedisTemplate<String, Object> redisTemplate;
	
	@Autowired
	private JwtSettings jwtSettings;
	
	@Autowired
	private TokenExtractor tokenExtractor;
	
	@Autowired
	private JwtTokenFactory tokenFactory;
	
	@Autowired
	private TokenVerifier tokenVerifier;
	
	/**
	  * @Method 설명 : Refresh Token으로 새로운 Access Token을 발급 한다.
	  * @param request HttpServletRequest
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="Refresh Token으로 새로운 Access Token을 발급 한다.", tags = "인증")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/auth/token")	
	public SingleResult<HashMap<String, String>> refreshToken(@ApiParam(value="HttpServletRequest") HttpServletRequest request, @ApiParam(value = "HttpServletResponse") HttpServletResponse response) throws Exception {
		// Authorization 헤더에서  Bearer 토큰을 추출하여 인증용 토큰(JwtAuthenticationToken)을 생성
		String headerPayload = request.getHeader(WebSecurityConfig.AUTHENTICATION_HEADER_NAME);
				
		try {
			// 헤더에서 토큰을 가져오지 못했을 경우 NoTokenHeaderException 발생
			RawAccessJwtToken rawAccessJwtToken = new RawAccessJwtToken(tokenExtractor.extract(headerPayload));
			
			// 가져온 리프레시 토큰을 검증 : BadCredentialsException, JwtExpiredTokenException 발생, 리프레시 토큰이 아니면 InvalidJwtToken 발생
			RefreshToken refreshToken = RefreshToken.create(rawAccessJwtToken, jwtSettings.getTokenSigningKey()).orElseThrow(() -> new InvalidJwtToken());
			Jws<Claims> claims = refreshToken.getClaims();
			
			log.debug("1) 리프레시 토큰 추출 ID : {}", refreshToken.getJti());
			
			String jti = refreshToken.getJti();
			if(!tokenVerifier.verify(jti)) {
				throw this.processException("S002360"); // 리프레시 토큰이 아닙니다.
			}
			
			List<String> scopes = claims.getBody().get("ath", List.class);
			
			boolean isUser = scopes.contains("ROLE_USER");
			boolean isAdmin = scopes.contains("ROLE_ADMIN");
			
			log.info("2) 리프레시 토큰 구분 : 사용자({}), 관리자({})", isUser, isAdmin);
			
			// 해당 리프레시 토큰이 정말 사용자의 토큰인지 확인 (ID로 토큰키를 Redis에서 가져와 비교)
			ValueOperations<String, Object> vop = redisTemplate.opsForValue();
			
			// 토큰에 있는 사용자로(username)부터 해당 사용자정보(UserDetails)를 가져와 액세스 토큰을 발급한다.
			AccessJwtToken accessToken = null;
			UserDetails userDetails = null;
			if(isUser) {
				// 회원식별ID로 Redis에 해당 식별ID로 저장되어 있는 리프레시 토큰을 확인
				String userId = (String)claims.getBody().get("mbr");
				log.info("userId : {}", userId);
				
				String redisKey = "token:refresh:" + userId;
				String redisToken = (String)vop.get(redisKey);
				log.info("redisToken for user {} : {}", userId, redisToken);
				
				// Redis에 저장되어 있는 토큰이 없으면 로그인을 거쳐야 한다. 
				if(StringUtils.isBlank(redisToken)) {
					throw this.processException("S002361");	// 리프레시 토큰이 일치하지 않습니다.
				}
				
				userDetails = userDetailsService.loadUserByUsername(refreshToken.getSubject());
				
				// DB에서 조회한 사용자 정보로 새로운 access 토큰을 생성
				HashMap<String, String> additionalClaims = new HashMap<String, String>();
				additionalClaims.put("mbr", ((MbrAccount)userDetails).getUserId()); // 가입회원의  회원 아이디를 토큰에 추가한다.
				
				accessToken = tokenFactory.createAccessJwtToken((MbrAccount)userDetails, additionalClaims);					
			} else if(isAdmin) {
				String userId = refreshToken.getSubject();				
				
				String redisKey = "token:refresh:" + userId;				
				String redisToken = (String)vop.get(redisKey);
				log.info("redisToken for manager {} : {}", userId, redisToken);
				
				if(StringUtils.isBlank(redisToken)) {
					throw this.processException("S002361");	// 리프레시 토큰이 일치하지 않습니다.
				}
				
				// DB에서 조회한 사용자 정보로 새로운 access 토큰을 생성
				userDetails = adminDetailsService.loadUserByUsername(refreshToken.getSubject());
				
				accessToken = tokenFactory.createAccessJwtToken((AdminAccount)userDetails, null);
			}
			
			HashMap<String, String> data = new HashMap<>();
			data.put("accessToken", accessToken.getToken());

			return responseService.getSingleResult(data);
		} catch (Exception ex) {
			log.debug("3) Access 토큰 재발급 Exception : {}", ex.getClass().getSimpleName());
			
			// 액세스 만료된 경우에만 결과를 주고 나머지는 공통 처리 (인증 및 권한부족 예외)
			if(ex instanceof JwtExpiredTokenException) {
				throw this.processException("E000018");	// 토큰이 만료되었습니다.			
			} else {
				// 헤더에 토큰이 없거나 만료되었거나 유효하지 않은 경우
				throw this.processException("S002359");	// 토큰이 만료되었거나 유효하지 않은 토큰입니다.
			}
		}		
	} 
}