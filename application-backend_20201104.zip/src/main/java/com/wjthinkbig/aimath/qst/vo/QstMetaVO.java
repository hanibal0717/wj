package com.wjthinkbig.aimath.qst.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 17.
  * @프로그램 설명 : 커리큘럼 문항 메타 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 17.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 문항 메타 정보")
public class QstMetaVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;						/* 문항코드 */
	
	@NotBlank(groups = Groups.Insert.class)
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;						/* 언어코드 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="문항내용")
	@FieldName("문항내용")
	private String qstCn;						/* 문항내용 */
	
	@ApiModelProperty(value="보기내용")
	@FieldName("보기내용")
	private String exmpCn;						/* 보기내용 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="지문내용")
	@FieldName("지문내용")
	private String textCn;						/* 지문내용 */
}
