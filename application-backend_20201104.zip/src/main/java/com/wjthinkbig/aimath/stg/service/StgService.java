package com.wjthinkbig.aimath.stg.service;

import java.util.List;

import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.stg.vo.StgSearchVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;

/**
 * @Date : 2020. 8. 22. 
 * @프로그램 설명 : 소주제(스테이지) 관리 서비스
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2020. 8. 22.     Lee Seung Hyuk     최초작성
 * </pre>
*/
public interface StgService {
	
	/**
	  * @Method 설명 : 검색된 커리큘럼 소주제 전체 리스트를 가져온다.
	  * @param stgSearch 검색할 조건 정보를 담은 소주제 검색 VO
	  * @return 검색된 소주제 리스트
	  * @throws Exception
	 */
	public List<StgVO> selectStgList(StgSearchVO stgSearch) throws Exception;
		
	/**
	  * @Method 설명 : 커리큘럼 소주제 리스트 수를 가져온다.(검색조건 적용)
	  * @param stgSearch
	  * @return
	  * @throws Exception
	  */
	public int selectStgListCnt(StgSearchVO stgSearch) throws Exception;
	
	/**
	  * @Method 설명 : 커리큘럼 특정 소주제정보를 가져온다. 
	  * @param stgSearch 검색할 조건 정보를 담은 소주제 검색 VO
	  * @return 해당 코드의 소주제 정보
	  * @throws Exception
	 */
	public StgVO selectStgById(StgSearchVO stgSearch) throws Exception;
	
	/**
	  * @Method 설명 : 커리큘럼 소주제코드 중복 체크
	  * @param stg_cd 중복체크할 소주제 식별코드
	  * @return 소주제중복 여부
	  * @throws Exception
	 */
	public int selectStgCdDplctCheck(String stg_cd) throws Exception;
	
	/**
	  * @Method 설명 : 소주제 정보 신규등록
	  * @param stg 등록할 소주제정보를 담은 VO
	  * @throws Exception
	 */
	public void insertStg(StgVO stg) throws Exception;
	
	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 소주제정보를 변경한다.
	  * @param stg 변경할 정보를 담은 소주제 VO
	  * @throws Exception
	 */
	public void updateStg(StgVO stg) throws Exception;
	
	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 소주제정보를 삭제한다.
	  * @param stg_cd 삭제하고자 하는 소주제 식별코드
	  * @return 삭제된 레코드 건 수
	  * @throws Exception
	 */
	public int deleteStg(String stg_cd) throws Exception;
	
	/**
	  * @Method 설명 : 등록된 특정 커리큘럼 소주제 리스트 정보를 삭제한다.
	  * @param saveStg 삭제하고자 하는 소주제 객체
	  * @return 삭제된 레코드 건 수
	  * @throws Exception
	 */
	public int deleteStgList(SaveVO<StgVO> saveStg) throws Exception;
}