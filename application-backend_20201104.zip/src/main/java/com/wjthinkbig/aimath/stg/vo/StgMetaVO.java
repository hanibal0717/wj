package com.wjthinkbig.aimath.stg.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
 * @FileName : StgMetaVO.java
 * @Project : application-backend
 * @Date : 2020. 8. 25. 
 * @작성자 : 19001861
 * @프로그램 설명 : 커리큘럼 소주제 언어관련 개념메타 VO
 * @변경이력 :
*/
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="커리큘럼 소주제 언어관련 개념메타 정보")
public class StgMetaVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="스테이지코드")
	@FieldName("소주제 코드")
	private String stgCd; 			/* 소주제코드(스테이지코드) */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd; 			/* 언어코드 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="소주제명")
	@FieldName("소주제명")
	private String stgNm;			/* 소주제명 */
	
	@ApiModelProperty(value="스텝명")
	@FieldName("스텝명")
	private String stepNm;			/* 스텝명 */
	
	@ApiModelProperty(value="상세내용")
	@FieldName("상세내용")
	private String dtlCn;			/* 상세내용 */
	
	@ApiModelProperty(value="개념메타")
	@FieldName("개념메타")
	private String cncpMeta;		/* 개념메타 */
}
