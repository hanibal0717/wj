package com.wjthinkbig.aimath.chn.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.chn.service.ChnService;
import com.wjthinkbig.aimath.chn.vo.ChnSearchVO;
import com.wjthinkbig.aimath.chn.vo.ChnVO;
import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 21.
  * @프로그램 설명 : 채널 관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 21.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="채널 관리")
@RestController
public class ChnController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 채널 관리 서비스
	 */
	@Resource(name = "chnService")
	private ChnService chnService;
	
	/**
	  * @Method 설명 : 채널 리스트 정보 조회
	  * @param chnSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="채널 리스트 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/channel")
	public SingleResult<Map<String, Object>> selectChnList(@ModelAttribute ChnSearchVO chnSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		List<ChnVO> chnList = chnService.selectChnList(chnSearch);
		
		resultMap.put("chnList", chnList);
		resultMap.put("totalCnt", chnService.selectChnListCnt(chnSearch));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 채널 정보 단일 조회
	  * @param chn_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="채널 정보 단일 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/channel/{channel}")
	public SingleResult<ChnVO> selectChnById(@ApiParam(value = "채널 코드") @PathVariable(name="channel",required=true) String chn_cd) throws Exception {
		ChnVO chn = chnService.selectChnById(chn_cd);
		if(chn == null) {
			throw this.processException("S001003", chn_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(chn);
	}
	
	/**
	  * @Method 설명 : 채널코드 중복 체크
	  * @param chn_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="채널코드 중복 체크")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/channel/check/{channel}")
	public SingleResult<String> selectChnCdDplctCheck(@ApiParam(value = "채널 코드") @PathVariable(name="channel",required=true) String chn_cd) throws Exception {
		String result = "N";
		
		if( chnService.selectChnCdDplctCheck(chn_cd) > 0 ){
			result = "Y";
		}
		
		return responseService.getSingleResult(result);
	}
	
	/**
	  * @Method 설명 : 신규 채널 정보를 등록한다. (파일업로드 필수, 서비스단에서 Validation 처리)
	  * @param chn 등록할 정보를 담은 채널 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="신규 채널 정보 등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/channel")
	public CommonResult insertChn(@ApiParam("등록할 정보를 담은 채널 객체") @ModelAttribute ChnVO chn) throws Exception {
		//채널코드 중복체크
		if( chnService.selectChnCdDplctCheck(chn.getChnCd()) > 0 ) {
			throw this.processException("S001001"); // 이미 존재하는 데이터입니다.
		}
		
		chnService.insertChn(chn);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 채널 정보 변경
	  * @param chn
	  * @param chn_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value = "채널 정보 변경")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/channel/{channel}")
	public CommonResult updateChn(@ApiParam("변경할 정보를 담은 채널 객체") @ModelAttribute ChnVO chn, @ApiParam("변경할 채널의 고유키") @PathVariable(name="channel", required=true) String chn_cd) throws Exception {
		chn.setChnCd(chn_cd);
		chnService.updateChn(chn);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 등록된 채널 삭제
	  * @param chn_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="등록된 채널 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/channel/{channel}")	
	public CommonResult deleteChn(@ApiParam("삭제대상 채널정보의 고유키") @PathVariable("channel") String chn_cd) throws Exception {
		int rows = chnService.deleteChn(chn_cd);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
}
