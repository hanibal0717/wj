package com.wjthinkbig.aimath.chn.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.chn.service.ChnService;
import com.wjthinkbig.aimath.chn.service.dao.ChnDao;
import com.wjthinkbig.aimath.chn.vo.ChnSearchVO;
import com.wjthinkbig.aimath.chn.vo.ChnVO;
import com.wjthinkbig.aimath.common.vo.FileVO;
import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.FileUtils;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.core.validator.groups.Groups;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 21.
  * @프로그램 설명 : 채널 관리 서비스
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 21.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Service("chnService")
public class ChnServiceImpl extends BaseServiceImpl implements ChnService {
	
	/**
	 * 채널관리 Dao
	 */
	@Resource(name = "chnDao")
	private ChnDao chnDao;
	
	/**
	 * AWS S3 도메인
	 */
	private static String domain;
	@Value("${aws.domain}")
	public void setDomain(String url) {
		domain = url;
	}
	
	/**
	 * AWS S3 bucketName 키값
	 */
	private static String bucketName;
	@Value("${aws.bucket.name}")
	public void setBucketName(String name) {
		bucketName = name;
	}
	
	@Override
	public List<ChnVO> selectChnList(ChnSearchVO chnSearch) throws Exception {
		List<ChnVO> chnList = chnDao.selectChnList(chnSearch);
		
		if( chnList != null ) {
			for( int i = 0; i < chnList.size(); i++ ) {
				chnList.get(i).setImgFilePath( domain + "/" + bucketName + chnList.get(i).getImgFilePath() );
			}
		}
		
		return chnList;
	}


	@Override
	public int selectChnListCnt(ChnSearchVO chnSearch) throws Exception {
		return chnDao.selectChnListCnt(chnSearch);
	}
	
	@Override
	public ChnVO selectChnById(String chn_cd) throws Exception {
		ChnVO chn = chnDao.selectChnById(chn_cd);
		
		//파일 경로에 S3 도메인을 넣어준다
		if( chn != null && StringUtils.isNotEmpty(chn.getImgFilePath()) ) {
			chn.setImgFilePath(domain + "/" + bucketName + chn.getImgFilePath());
		}
		return chn;
	}

	@Override
	public int selectChnCdDplctCheck(String chn_cd) throws Exception {
		return chnDao.selectChnCdDplctCheck(chn_cd);
	}

	@Override
	public void insertChn(ChnVO chn) throws Exception {
		MultipartFile mFile = chn.getMFile();

		//첨부파일 확인 후 등록
		if( mFile != null && !mFile.isEmpty() ) {
			FileVO file = FileUtils.sendAWSS3(mFile, "channel");
			
			if( file != null ) {
				//객체 저장
				chn.setImgFilePath(file.getFilePath());
				chn.setImgFileNm(file.getFileNm());
			}
		}
		
		// Insert Group에 대한 빈 검증 (신규등록 시의 검증, 파일업로드 이후 파일첨부 필수여부 확인) 
		this.validateOrElseThrow(chn, Groups.Insert.class);
		
		chnDao.insertChn(chn);
	}

	@Override
	public void updateChn(ChnVO chn) throws Exception {
		MultipartFile mFile = chn.getMFile();
		
		//첨부파일 확인 후 등록
		if( mFile != null ) {
			//기존 파일 경로를 가져와 파일 삭제 후 재 업로드 한다.
			ChnVO tmp = chnDao.selectChnById(chn.getChnCd());
			
			if( FileUtils.deleteAWSS3(tmp.getImgFilePath(), tmp.getImgFileNm()) ) {
				//파일 업로드
				FileVO file = FileUtils.sendAWSS3(mFile, "channel");
				
				if( file != null ) {
					//객체 저장
					chn.setImgFilePath(file.getFilePath());
					chn.setImgFileNm(file.getFileNm());
				}
			}
		}
		
		// Update Group에 대한 빈 검증
		this.validateOrElseThrow(chn, Groups.Update.class);
		
		chnDao.updateChn(chn);
	}

	@Override
	public int deleteChn(String chn_cd) throws Exception {
		//기존 파일 경로를 가져와 파일 삭제
		ChnVO chn = chnDao.selectChnById(chn_cd);
		
		if( chn != null && StringUtils.isNotEmpty(chn.getImgFilePath()) && StringUtils.isNotEmpty(chn.getImgFileNm()) ) {
			FileUtils.deleteAWSS3(chn.getImgFilePath(), chn.getImgFileNm());
		}
		
		return chnDao.deleteChn(chn_cd);
	}
	
}
