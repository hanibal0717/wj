package com.wjthinkbig.aimath.chn.vo;

import javax.validation.constraints.NotBlank;

import org.springframework.web.multipart.MultipartFile;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 21.
  * @프로그램 설명 : 채널 정보 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 21.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="채널 정보")
public class ChnVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class, Groups.Delete.class})
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;						/* 채널코드 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="채널명")
	@FieldName("채널명")
	private String chnNm;						/* 채널명 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="이미지파일경로")
	@FieldName("이미지파일경로")
	private String imgFilePath;					/* 이미지파일경로 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="이미지파일명")
	@FieldName("이미지파일명")
	private String imgFileNm;					/* 이미지파일명 */
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Update.class})
	@ApiModelProperty(value="학습설정구분코드")
	@FieldName("학습설정구분코드")
	private String lrnConfigScnCd;				/* 학습설정구분코드 */
	
	@ApiModelProperty(value="학습설정구분코드명")
	@FieldName("학습설정구분코드명")
	private String lrnConfigScnNm;				/* 학습설정구분코드명 */
	
	@ApiModelProperty(value="이미지 첨부파일")
	@FieldName("이미지 첨부파일")
	private MultipartFile mFile;				/* 이미지 첨부파일 */
	
}
