package com.wjthinkbig.aimath.acnt.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.acnt.service.AcntService;
import com.wjthinkbig.aimath.acnt.vo.AcntSearchVO;
import com.wjthinkbig.aimath.acnt.vo.AcntVO;
import com.wjthinkbig.aimath.acnt.vo.AdminAccount;
import com.wjthinkbig.aimath.acnt.vo.LoginAdminVO;
import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.support.api.Token;
import com.wjthinkbig.aimath.core.validator.groups.Groups;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 9. 7.
  * @프로그램 설명 : 관리자 계정 관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 7.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="관리자 계정 정보")
@RestController
public class AcntController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 관리자 관리 서비스
	 */
	@Resource(name = "acntService")
	private AcntService acntService;
	
	/**
	  * @Method 설명 : 전체 관리자 계정 정보 리스트 조회
	  * @param acntSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="전체 관리자 계정 정보 리스트 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/account")
	public SingleResult<Map<String, Object>> selectAcntList(@ModelAttribute AcntSearchVO acntSearch) throws Exception {
		Map<String, Object> resultMap = new HashMap<>();
		List<AcntVO> acntList = acntService.selectAcntList(acntSearch);
		resultMap.put("acntList", acntList);
		resultMap.put("totalCnt", acntService.selectAcntCnt(acntSearch));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 전체 관리자 계정 정보 리스트 수 조회
	  * @param acntSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="전체 관리자 계정 정보 리스트 수 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/account/cnt")
	public SingleResult<Integer> selectAcntCnt(@ModelAttribute AcntSearchVO acntSearch) throws Exception {
		int cnt = acntService.selectAcntCnt(acntSearch);
		return responseService.getSingleResult(cnt);
	}
	
	/**
	  * @Method 설명 : 관리자 정보 단일 조회
	  * @param mngt_user_id 관리자ID(PK 필드)
	  * @return 해당 식별코드를 갖는 관리자 정보 VO
	  * @throws Exception
	 */
	@ApiOperation(value="관리자 정보 단일 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/account/{account}")	
	public SingleResult<AcntVO> selectAcntById(@ApiParam(value = "관리자ID") @PathVariable(name="account",required=true) String mngt_user_id) throws Exception {
		AcntVO acnt = acntService.selectAcntById(mngt_user_id);
		if(acnt == null) {
			throw this.processException("S001003", mngt_user_id);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(acnt);
	}
	
	/**
	  * @Method 설명 : 신규 관리자 정보 등록
	  * @param acnt
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="신규 관리자 정보 등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/account")
	public CommonResult insertAcnt(@ApiParam("등록할 정보를 담은 관리자 객체") @Validated(value=Groups.Insert.class) @RequestBody(required=true) AcntVO acnt) throws Exception {
		int userCnt = acntService.selectUserIdDplctCheck(acnt.getMngtUserId());
		if(userCnt > 0) {
			throw this.processException("S001004"); // 이미 사용자가 등록되어 있습니다.
		}
		
		acntService.insertAcnt(acnt);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 관리자 정보 수정
	  * @param acnt
	  * @param mngt_user_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="관리자 정보 수정")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/account/{account}")
	public CommonResult updateAcnt(@ApiParam("수정할 정보를 담은 관리자 객체") @RequestBody(required=true) AcntVO acnt,
			@ApiParam(value = "관리자ID") @PathVariable(name="account",required=true) String mngt_user_id) throws Exception {
		acnt.setMngtUserId(mngt_user_id);
		acntService.updateAcnt(acnt);
		
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 관리자 정보 삭제
	  * @param mngt_user_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="관리자 정보 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/account/{account}")
	public CommonResult deleteAcnt(@ApiParam(value = "관리자ID") @PathVariable(name="account",required=true) String mngt_user_id) throws Exception {
		int rows = acntService.deleteAcnt(mngt_user_id);
		if(rows == 0) {
			throw this.processException("S001002"); // 처리된 데이터가 0건입니다.
		}
		
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 관리자 로그인
	  * @param user 로그인정보를 담고 있는 VO
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="관리자 로그인")	
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/account/signin")	
	public SingleResult<HashMap<String, String>> login(@ApiParam(value="로그인 VO") @Valid @RequestBody LoginAdminVO user) throws Exception {
		log.debug("로그인 인증요청정보 : {}", user);
		Token token = acntService.signin(user);
		log.info("발급된 토큰 : {}", token);
		
		HashMap<String, String> data = new HashMap<>();
		data.put("accessToken", token.getAccessToken());
		data.put("refreshToken", token.getRefreshToken());
		
		// 최근 비밀번호 변경일로부터의 경과일수가 6개월(180일)을 초과시 변경대상자 표시
		String isNeedToChange = "N";
		long elapsedDays = acntService.selectPassedDaysFromChangeDt(user.getMngtUserId());
		log.info("비밀번호 최근 변경일로부터 {}일 경과", elapsedDays);
		if(elapsedDays > 180) {
			isNeedToChange = "Y";
		}
		
		data.put("isNeedToChange", isNeedToChange);
		
		// 최종로그인일시 갱신
		acntService.updateLastLoginDt(user.getMngtUserId());
		
		return responseService.getSingleResult(data);
	}	
	
	/**
	  * @Method 설명 : 관리자 로그아웃
	  * @param userContext AdminAccount
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value="관리자 로그아웃", tags = "인증")	
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/account/signout")	
	public CommonResult logout(@ApiParam(value="로그인 관리자 객체") @AuthenticationPrincipal User userContext) throws Exception {
		if(userContext instanceof AdminAccount) {
			log.info("관리자 로그아웃 : ({}) {}", userContext.getClass().getSimpleName(), userContext.getUsername());
			
			// Redis에서 이 회원의 리프레시 토큰을 제거한다.
			acntService.signout(userContext);
		
			return responseService.getResult(true);	
		} else {
			// 관리자 로그인을 통해 발급된 토큰이 아닌 경우 
			return responseService.getResult(false);
		}
	}
	
	@ApiOperation(value="관리자 비밀번호 다음에 변경하기")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/account/{account}/expiration-date")
	public CommonResult updatePasswordChangeDate(@ApiParam(value = "관리자ID") @PathVariable(name="account",required=true) String mngt_user_id) throws Exception {
		// 현재 로그인 관리자와 인증토큰의 sub 항목이 같은지 검증
		AdminAccount account = (AdminAccount)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(!mngt_user_id.equals(account.getUsername())) {
			throw this.processException("S001028");	// 본인의 정보만 변경할 수 있습니다.
		}
		
		// 관리자의 비밀번호 만료도래일을 1달 후로 갱신처리
		acntService.updatePasswordChangeDate(account.getUsername());		
		
		return responseService.getResult(true);
	}
}