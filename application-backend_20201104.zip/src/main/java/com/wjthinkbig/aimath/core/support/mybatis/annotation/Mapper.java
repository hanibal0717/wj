/**
 * 
 */
package com.wjthinkbig.aimath.core.support.mybatis.annotation;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
  * @FileName : Mapper.java
  * @Project : application-backend
  * @Date : 2020. 8. 14. 
  * @작성자 : 10013871
  * @프로그램 설명 : 기본 데이터소스에 대한 매퍼
  * @변경이력 :
  */
@Documented
@Inherited
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)
public @interface Mapper {
	String value() default "";
}
