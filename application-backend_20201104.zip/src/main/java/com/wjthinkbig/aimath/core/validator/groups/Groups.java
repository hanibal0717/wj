package com.wjthinkbig.aimath.core.validator.groups;

import javax.validation.groups.Default;

/**
  * @Date : 2020. 8. 24. 
  * @프로그램 설명 : JSR380 Validation 처리를 위한 추가적인 Groups 정보를 제공한다.
  * <pre> 
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 24.     Lee Seung Hyuk            최초작성
  * </pre>
 */
public interface Groups {
	interface Insert extends Default {
	}

	interface Update extends Default {
	}

	interface Delete extends Default {
	}
}