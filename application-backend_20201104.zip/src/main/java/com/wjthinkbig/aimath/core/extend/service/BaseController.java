package com.wjthinkbig.aimath.core.extend.service;

public abstract class BaseController extends BaseSupport {
	
	
}
