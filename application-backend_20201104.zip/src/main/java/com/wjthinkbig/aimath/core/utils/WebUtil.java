package com.wjthinkbig.aimath.core.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URLEncodedUtils;
import org.springframework.http.MediaType;
import org.springframework.mobile.device.DevicePlatform;
import org.springframework.mobile.device.DeviceResolver;
import org.springframework.mobile.device.DeviceType;
import org.springframework.mobile.device.LiteDeviceResolver;
import org.springframework.security.web.savedrequest.SavedRequest;
import org.springframework.util.ObjectUtils;

/**
 * <pre>
 *
 * </pre>
 *
 * @author Kang Seok Han
 * @version 1.0
 * @since
 * <pre>
 * since            author             description
 * =============    ===============    ===========================
 * 2019. 09. 19.    Kang Seok Han      최초 생성
 * </pre>
 */
public class WebUtil {

    private static final String XML_HTTP_REQUEST = "XMLHttpRequest";
    private static final String X_REQUESTED_WITH = "X-Requested-With";

    private static final String CONTENT_TYPE = "Content-type";
    private static final String CONTENT_TYPE_JSON = "application/json";

    private static final DeviceResolver deviceResolver =  new LiteDeviceResolver();

    /**
     * AJAX 요청인지 체크
     * @param request
     * @return
     */
    public static boolean isAjax(HttpServletRequest request) {

    	String contentType = request.getHeader("Content-Type");

    	if(MediaType.APPLICATION_JSON_VALUE.equals(contentType)
    			|| MediaType.APPLICATION_JSON_UTF8_VALUE.equals(contentType)
         		|| request.getHeader("X-AJAX-REQ") != null
         		|| StringUtils.isTrimToNotEmpty(request.getHeader("X-Requested-With"))){
    		return true;
    	}
    	return false;
    }

    /**
     * JSON 요청인지 체크
     * @param request
     * @return
     */
    public static boolean isContentTypeJson(SavedRequest request) {
        return request.getHeaderValues(CONTENT_TYPE).contains(CONTENT_TYPE_JSON);
    }

    /**
     * 파라미터 값을 가져옴
     */
    @SuppressWarnings("unused")
    public static <T> T getParameter(HttpServletRequest request , String name) {
    	HttpServletRequest req = request;
    	if( ObjectUtils.isEmpty(req)) return null;
    	return (T)req.getParameter(name);
    }

    /**
     * 파라미터 값을 가져옴 없을 경우 Attribute에서 가져옴
     */
    @SuppressWarnings("unused")
    public static <T> T getParameterOrElseAttribute(HttpServletRequest request , String name) {
    	HttpServletRequest req = request;
    	if( ObjectUtils.isEmpty(req)) return null;
    	T p = (T)req.getParameter(name);
    	return p != null ?  p : (T)req.getAttribute(name);
    }

    /**
     * 파라미터 값을 가져옴
     */
    @SuppressWarnings("unused")
    public static <T> T getAttribute(HttpServletRequest request , String name) {
    	HttpServletRequest req = request;
    	if( ObjectUtils.isEmpty(req)) return null;
    	return (T)req.getAttribute(name);
    }

    /**
     * 안드로이드 인지 체크
     * @return
     */
    public static boolean isAndroid(HttpServletRequest request) {
    	return deviceResolver.resolveDevice(request).getDevicePlatform().name().equals(DevicePlatform.ANDROID);
    }

    /**
     * IOS 인지 체크
     * @return
     */
    public static boolean isIOS(HttpServletRequest request) {
    	return deviceResolver.resolveDevice(request).getDevicePlatform().name().equals(DevicePlatform.IOS);
    }

    /**
     * APP인지 체크한다.
     * @param request
     * @return
     */
    public static boolean isApp(HttpServletRequest request) {

    	String userAgent = request.getHeader("User-Agent");

    	if( userAgent.indexOf("WJAPP") != -1) {
    		return true;
    	}else {
    		return false;
    	}
    }

    /**
     * 모바일인지 체크
     * @return
     */
    public static boolean isMobile(HttpServletRequest request) {
    	return deviceResolver.resolveDevice(request).isMobile();
    	//return DeviceUtils.getCurrentDevice(request).isMobile();
    }

    /**
     * PC인지 체크
     * @return
     */
    public static boolean isPc(HttpServletRequest request) {
    	return deviceResolver.resolveDevice(request).isNormal();
    }

    /**
     * 태블릿(PAD)인지 체크
     * @return
     */
    public static boolean isTablet(HttpServletRequest request) {
    	return deviceResolver.resolveDevice(request).isTablet();
    	//return DeviceUtils.getCurrentDevice(request).isNormal();
    }

    /**
     * 디바이스 종류 반환
     * @return
     */
    public static String getDeviceKind(HttpServletRequest request) {
    	if(isMobile(request)) {
			return DeviceType.MOBILE.name();
		} else if(isTablet(request)) {
			return DeviceType.TABLET.name();
		} else {
			return DeviceType.NORMAL.name();
		}
    }
    
    /**
     * OS 종류 반환
     * @param request
     */
    public static String getOsKind(HttpServletRequest request) {
    	String userUA = request.getHeader("user-agent");
    	if(userUA.toUpperCase().indexOf("IPHONE") > -1 || userUA.toUpperCase().indexOf("IPAD") > -1 || userUA.toUpperCase().indexOf("IPOD") > -1) {
			return "IOS";
		} else if(userUA.toUpperCase().indexOf("ANDROID") > -1) {
			return "ANDOID";
		} else if(userUA.toUpperCase().indexOf("WINDOWS") > -1){
			return "WINDOWS";
		} else if(userUA.toUpperCase().indexOf("MAC") > -1) {
			return "MAC";
		} else if(userUA.toUpperCase().indexOf("X11") > -1) {
			return "UNIX";
		} else {
			return "UNKNOWN";
		}
    }

    /**
     * 쿠키 생성
     * @param response
     */
    public static void setCookie(HttpServletResponse response, Cookie cookie){
	    response.addCookie(cookie);
    }

    /**
     * 쿠키 가져오기
     * @param request
     * @return
     */
	public static Cookie getCookie(HttpServletRequest request, String name) {

		Cookie[] getCookie = request.getCookies();
		if (getCookie != null) {
			for (int i = 0; i < getCookie.length; i++) {
				Cookie c = getCookie[i];
				if( name.equals(c.getName())) return c;
			}
		}

		return null;
	}

	 /**
     * 쿠키 값 가져오기
     * @param request
     * @return
     */
	public static String getCookieValue(HttpServletRequest request, String name) {

		Cookie[] getCookie = request.getCookies();
		if (getCookie != null) {
			for (int i = 0; i < getCookie.length; i++) {
				Cookie c = getCookie[i];
				if( name.equals(c.getName())) return c.getValue();
			}
		}

		return null;
	}

	/**
	 * 원 요청 클라이언트 아이피 조회
	 * @param request
	 * @return
	 */
	public static String getRemoteAddr(HttpServletRequest request) {
		String ip = null;
        ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.length()  == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-Real-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("X-RealIP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("REMOTE_ADDR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }

        // 프록시 아이피 리스트에서 가장 첫번째 원아이피 주소만 반환한다.
        if(ip.contains(",")) {
        	ip = ip.trim().split(",")[0];
        }

        return "0:0:0:0:0:0:0:1".equals(ip) ? "127.0.0.1" : ip;
	}

	/**
	 * 쿼리스트링 바디 -> Map으로 변환
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@SuppressWarnings("rawtypes")
	public static Map<String, Object> convertBodyQueryStringToMap(HttpServletRequest request) throws IOException {
		Map<String, Object> rsltMap = new HashMap<String, Object>();

		List<NameValuePair> params = URLEncodedUtils.parse(WebUtil.getBodyString(request), StandardCharsets.UTF_8);

		for( NameValuePair e : params) {
			if(params.stream().filter( x -> x.getName().equals(e.getName())).count() > 1) {
				if( rsltMap.containsKey( e.getName())) {
					((List)rsltMap.get(e.getName())).add(e.getValue());
				}else {
					List<Object> array = new ArrayList<Object>();
					array.add(e.getValue());
					rsltMap.put(e.getName(), array);
				}
			}else {
				rsltMap.put(e.getName(), e.getValue());
			}
		}

		return rsltMap;
	}

	/**
	 * 바디의 스트링을 읽어온다.
	 * @param request
	 * @return
	 * @throws IOException
	 */
	public static String getBodyString(HttpServletRequest request) throws IOException {
        String body = null;
        StringBuilder stringBuilder = new StringBuilder();
        BufferedReader bufferedReader = null;

        try {
            InputStream inputStream = request.getInputStream();
            if (inputStream != null) {
                bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                char[] charBuffer = new char[128];
                int bytesRead = -1;
                while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
                    stringBuilder.append(charBuffer, 0, bytesRead);
                }
            }
        } catch (IOException ex) {
            throw ex;
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException ex) {
                    throw ex;
                }
            }
        }

        body = stringBuilder.toString();

        if( StringUtils.isEmpty(body)) {
        	return null;
        }

        return body;
    }

	/**
	 * 요청으로 부터 바디를 가져오는 함수
	 * @param request
	 * @return
	 * @throws IOException
	 */
	 public static Map<String, Object> getBody(HttpServletRequest request) throws IOException {

			 return JsonUtils.readValue(getBodyString(request), HashMap.class);
    }
}
