package com.wjthinkbig.aimath.core.support.api;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 9. 
  * @프로그램 설명 : 발급된 토큰에 대한 정보 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 9.     Lee Seung Hyuk              최초작성
  * </pre>
 */
@Setter
@Getter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class Token {

	/**
	 * Principal (가입회원ID, 관리자 ID)
	 */
	private String principal;
	
	/**
	 * Access 토큰
	 */
	private String accessToken;
	
	/**
	 * Refresh 토큰
	 */
	private String refreshToken;		
}
