/**
 * 
 */
package com.wjthinkbig.aimath.core.web.method.support;

import javax.servlet.ServletRequest;

import org.springframework.core.MethodParameter;
import org.springframework.util.Assert;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.annotation.ModelAttributeMethodProcessor;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;

import com.wjthinkbig.aimath.core.utils.LoginUtils;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

/**
  * @Date : 2020. 10. 20. 
  * @프로그램 설명 : 컨트롤러에서 @ModelAttribute 어노테이션을 적용한 BaseVO의 최초등록자ID, 최종수정자ID를 로그인 정보를 기반으로 자동 할당 한다.
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20.     Lee Seung Hyuk    최초작성
  * </pre>
  */
public class CustomModelAttributeArgumentResolver extends ModelAttributeMethodProcessor implements HandlerMethodArgumentResolver {

	public CustomModelAttributeArgumentResolver() {
		super(false);
	}
	
	/**
	 * @param annotationNotRequired
	 */
	public CustomModelAttributeArgumentResolver(boolean annotationNotRequired) {
		super(annotationNotRequired); 		
	}	
	
	@Override
	protected Object createAttribute(String attributeName, MethodParameter parameter,
			WebDataBinderFactory binderFactory, NativeWebRequest webRequest) throws Exception {
		Object attribute = super.createAttribute(attributeName, parameter, binderFactory, webRequest);

		if (attribute != null) {
			if (BaseVO.class.isAssignableFrom(parameter.getParameterType()) == true) {
				BaseVO vo =  (BaseVO)attribute;

				if (LoginUtils.isLogin() == true) { 
					vo.setLoginUser(LoginUtils.getUserId());
				}
			}
		}

		return attribute;
	}
	
	@Override
	protected void bindRequestParameters(WebDataBinder binder, NativeWebRequest request) {
		ServletRequest servletRequest = request.getNativeRequest(ServletRequest.class);
		Assert.state(servletRequest != null, "No ServletRequest");
		ServletRequestDataBinder servletBinder = (ServletRequestDataBinder) binder;
		servletBinder.bind(servletRequest);
	}

	@Override
	public boolean supportsParameter(MethodParameter parameter) {

		return parameter.hasParameterAnnotation(ModelAttribute.class) &&
				BaseVO.class.isAssignableFrom(parameter.getParameterType());
	}	
}