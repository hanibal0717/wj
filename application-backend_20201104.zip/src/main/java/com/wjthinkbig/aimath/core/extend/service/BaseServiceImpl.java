package com.wjthinkbig.aimath.core.extend.service;

public abstract class BaseServiceImpl extends BaseSupport {

}
