package com.wjthinkbig.aimath.core.utils;

import java.net.URI;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLrnStatusVO;

import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 14 
  * @프로그램 설명 :  ApiUtil.java  외부api 호출을 위한 유틸 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14          Kim Hee Seok       최초작성
  * </pre>
  */
@Slf4j
@Component
public class ApiUtil {
	/**
	 * @Method 설명 : externalApi 외부 API 사용 
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param url
	 * @param reqObj
	 * @param HttpMethod
	 * @return HashMap
	 * @throws Exception
	 */
	public HashMap<String, Object> externalApi(String url, Object reqObj, HttpMethod method) throws Exception {
		HashMap<String, Object> result = new HashMap<String, Object>();
		try {
			HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
			factory.setConnectionRequestTimeout(5000);
			factory.setReadTimeout(5000);
			RestTemplate restTemplate = new RestTemplate(factory);
			HttpHeaders header = new HttpHeaders();
			HttpEntity<?> entity = new HttpEntity<>(header);
			
			//VO 를 String URI 변환 
			ObjectMapper mapper = new ObjectMapper();
			MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
			Map<String, String> map=mapper.convertValue(reqObj, new com.fasterxml.jackson.core.type.TypeReference<Map<String,String>>(){});
			queryParams.setAll(map);

			URI uri = UriComponentsBuilder.fromUriString(url).queryParams(queryParams).build().toUri();
			ResponseEntity<?> resultMap = restTemplate.exchange(uri, method, entity,Map.class);
			result.put("statusCode", resultMap.getStatusCodeValue()); //http status code를 확인
            result.put("body", resultMap.getBody()); //실제 데이터 정보 확인
		} catch (HttpClientErrorException | HttpServerErrorException e ) {
			result.put("statusCode", e.getRawStatusCode());
            result.put("body"  , e.getStatusText());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/**
	 * @Method 설명 : jugeAnswer 정답 판단 (정답 : Y/오답 : N /빈값 : B/정답유형 오류 : E)
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @param ansrCw
	 * @param qstCransr
	 * @param cransrTyScnCd
	 * @return
	 */
	public String jugeAnswer(String ansrCw, String qstCransr, String cransrTyScnCd) {
		String result="N";
		String [] qstCransrArray = qstCransr.split(";");
		String [] ansrCwArray = ansrCw.split(";");
		switch (cransrTyScnCd) {
		case "CTS01": //모두 정답(순차순)
			if(Arrays.equals(qstCransrArray,ansrCwArray)) {
				result = "Y";
			}
			log.info("모두 정답(순차순) {}",result);
 			break;
		
		case "CTS02": //모두 정답(순서상관없음)
			if(qstCransrArray.length == ansrCwArray.length) {
				for(int i = 0;i < ansrCwArray.length;i++) {
					result = "Y";
					if(ansrCwArray[i].toString().trim().length() == 0) {
						result = "B";
						break;
					}
					boolean isAns = Arrays.asList(qstCransrArray).contains(ansrCwArray[i]);
					if(!isAns) {
						result = "N";
						break;
					}
				}
				log.info("모두 정답(순서상관없음) {} ",result);
			} else {
				result = "B";
				log.info("빈값이 있음  {} ",result);
			}
			
			break;
		case "CTS03": //둘 중 하나
			boolean isAns = Arrays.asList(qstCransrArray).contains(ansrCw);
			if(isAns) {
				result = "Y";
			}
			log.info("둘 중 하나 {} ",result);
			break;
		default: 
			log.info("에러  {} ",result);
			result = "E";
			break;
		}
		return result;
	}
	
	
	/**
	 * @Method 설명 : randomDgnsPrsCd 진행코드 테스트용 함수 
	 * @author Kim Hee Seok [2020. 10. 16]
	 * @return
	 */
	public String randomDgnsPrsCd() {
		String [] qstCransrArray = {"W", "W", "W", "W", "W", "W", "W", "W", "W", "E"};
		int num ;
		Random rd = new Random();
		num = rd.nextInt(10);
		return qstCransrArray[num];
	}
	
	public HashMap<String, String> converLrnStatus(NoteLrnStatusVO noteLrnStatus) {
		String status = "BEFORE-LEARNING";
		String term = "";
		if(noteLrnStatus != null) {
			if((Integer.parseInt(noteLrnStatus.getMaxLvlStgCnt()) == Integer.parseInt(noteLrnStatus.getUserStgCnt()))
					&& (noteLrnStatus.getMaxLvlStgCd().equals(noteLrnStatus.getUserStgCd()))
					) {
				if(noteLrnStatus.getUserMaxPrgsCd() != null) {
					status = "COMPLETED-LEARNING"; //학습완료
					term = noteLrnStatus.getLrnTerm(); 
				} else {
					status = "NOW-LEARNING"; //학습진행중 
					term = noteLrnStatus.getLrnTerm().split("~")[0]+"~"; 
				}
			} else {
				status = "NOW-LEARNING"; //학습진행중 
				term = noteLrnStatus.getLrnTerm().split("~")[0]+"~"; 
			}
		}
		HashMap<String, String> rst = new HashMap<String, String>();
		rst.put("status", status);
		rst.put("term", term);
		return rst;
	}
}
