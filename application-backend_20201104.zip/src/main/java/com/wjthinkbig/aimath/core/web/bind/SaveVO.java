package com.wjthinkbig.aimath.core.web.bind;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;
import javax.validation.groups.ConvertGroup;

import org.apache.commons.lang3.StringUtils;

import com.wjthinkbig.aimath.core.validator.groups.Groups;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 28. 
  * @프로그램 설명 : 일괄 적용(등록/수정/삭제)을 처리 하기 위한 기본 클래스로 Validation(JSR380)을 적용하기 위한 기본 설정 제공한다.
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 28.     Lee Seung Hyuk            최초작성
  * </pre>
 */
@Getter
@Setter
@ToString
public class SaveVO<T extends BaseVO> implements Serializable {

	private static final long serialVersionUID = 1900561543294585920L;

	/**
	 * 추가 할 목록
	 */
	private List<@ConvertGroup(to = Groups.Insert.class) @Valid T> insertList = new ArrayList<T>();

	/**
	 * 수정 할 목록
	 */
	private List<@ConvertGroup(to = Groups.Update.class) @Valid T> updateList = new ArrayList<T>();

	/**
	 * 삭제 할 목록
	 */
	private List<@ConvertGroup(to = Groups.Delete.class) @Valid T> deleteList = new ArrayList<T>();

	/**
	  * @Method 설명 : 로그인한 사용자의 ID로 등록자와 수정자 및 등록/수정 시간을 세팅
	  * @param user 로그인 사용자(또는 관리자) ID
	 */
	public void setLoginUser(String user) {
		LocalDateTime now = LocalDateTime.now();
		
		insertList.stream().forEach(x -> {			
			if(StringUtils.isBlank(x.getRgtnUser())) {
				x.setRgtnUser(user);
			}			
			x.setRgtnDt(now);
			if(StringUtils.isBlank(x.getModUser())) {
				x.setModUser(user);	
			}			
			x.setModDt(now);
		});

		updateList.stream().forEach(x -> {
			if(StringUtils.isBlank(x.getRgtnUser())) {
				x.setRgtnUser(user);
			}			
			x.setRgtnDt(now);
			if(StringUtils.isBlank(x.getModUser())) {
				x.setModUser(user);	
			}			
			x.setModDt(now);
		});

		deleteList.stream().forEach(x -> {
			if(StringUtils.isBlank(x.getRgtnUser())) {
				x.setRgtnUser(user);
			}			
			x.setRgtnDt(now);
			if(StringUtils.isBlank(x.getRgtnUser())) {
				x.setModUser(user);	
			}			
			x.setModDt(now); 
		});
	}
}