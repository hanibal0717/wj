package com.wjthinkbig.aimath.core.utils;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Hashtable;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;
import javax.servlet.http.HttpSessionBindingListener;

import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;
/**
  * @Date : 2020. 10. 14 
  * @프로그램 설명 :  SessionUtils.java  서버 세션 정보를 다룬다.
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 14          Kim Hee Seok       최초작성
  * </pre>
  */
@Slf4j
@Component
public class SessionUtils implements HttpSessionBindingListener{
	private static SessionUtils sessionUtil=null;
	private static Hashtable<HttpSession, String> mbrLrns = new Hashtable<HttpSession, String>();
	
	public static synchronized SessionUtils getInstance() {
	    if(sessionUtil == null) {
	    	sessionUtil = new SessionUtils();
	    }
	    return sessionUtil;
	}
	
	//세션연결시 호출 
	@Override
	public void valueBound(HttpSessionBindingEvent event) {
		mbrLrns.put(event.getSession(),event.getName());
		log.info("진입한 학습회원 {}", event.getName());
	}
	
	//세션이 끊겼을시 호출 
	@Override
	public void valueUnbound(HttpSessionBindingEvent event) {
		mbrLrns.remove(event.getSession());
		log.info("아웃된 학습회원 {}", event.getName());
		log.info("현재 접속자 수 : {}",getUserCount());
	}
	
	public void removeSession(String mbrLrnId) {
		Enumeration<HttpSession> e = mbrLrns.keys();
		HttpSession session = null;
		while(e.hasMoreElements()) {
			session = (HttpSession)e.nextElement();
            if(mbrLrns.get(session).equals(mbrLrnId)){
                //세션이 invalidate될때 HttpSessionBindingListener를 
                //구현하는 클레스의 valueUnbound()함수가 호출된다.
                session.invalidate();
            }
		}
	}
	
	
	/**
	 * @Method 설명 : 해당 아이디의 동시 사용을 막기위해서 이미 사용중인 아이디 인지를 확인한다.
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @param mbrLrnId
	 * @return
	 */
	public boolean isUsing(String mbrLrnId){
       return mbrLrns.containsValue(mbrLrnId);
	}

	/**
	 * @Method 설명 : 진입을 완료한 사용자의 아이디를 세션에 저장하는 메소드
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @param session
	 * @param userId
	 */
	public void setSession(HttpSession session, String mbrLrnId){
	   //이순간에 Session Binding이벤트가 일어나는 시점
	   //name값으로 mbrLrnId, value값으로 자기자신(HttpSessionBindingListener를 구현하는 Object)
	   session.setAttribute(mbrLrnId, this);//login에 자기자신을 집어넣는다.
	}

	/**
	 * @Method 설명 : 현재 진입한 학습회원 수
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @return int
	 */
	public int getUserCount() {
		return mbrLrns.size();
	}
	
	/**
	 * @Method 설명 : 입력받은 세션Object로 아이디를 리턴한다
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @param session
	 * @return
	 */
	public String getUserID(HttpSession session){
       return (String)mbrLrns.get(session);
    }


		
	/**
	 * @Method 설명 : 현재 접속중인 모든 사용자 아이디를 출력
	 * @author Kim Hee Seok [2020. 10. 13]
	 */
	public void printMbrLrn(){
	   Enumeration<HttpSession> e = mbrLrns.keys();
	   HttpSession session = null;
	   System.out.println("==================학습회원 리스트 START=========================");
	   int i = 0;
	   while(e.hasMoreElements()){
	       session = (HttpSession)e.nextElement();
	       log.info((++i) + ". 학습회원  : " +  mbrLrns.get(session));
	   }
	   System.out.println("====================학습회원 리스트 END=======================");
	}

	
	/**
	 * @Method 설명 : 현재 접속중인 모든 사용자 리스트를 리턴 
	 * @author Kim Hee Seok [2020. 10. 13]
	 * @return collection
	 */
	public Collection<String> getMbrLrns(){
		Collection<String> collection = mbrLrns.values();
	    return collection;
	}

}
