package com.wjthinkbig.aimath.lrn.thma.service;

import java.util.List;

import com.wjthinkbig.aimath.lrn.thma.vo.LrnThmaSearchVO;
import com.wjthinkbig.aimath.lrn.thma.vo.LrnThmaVO;

/**
  * @Date : 2020. 10. 20.
  * @프로그램 설명 : 사용자 주제학습 관련 Service
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20.     19001861            최초작성
  * </pre>
  */
public interface LrnThmaService {
	
	/**
	  * @Method 설명 : 주제학습 대주제 리스트 조회
	  * @param lrnThmaSearch
	  * @return
	  * @throws Exception
	  */
	public List<LrnThmaVO> selectLrnThmaList(LrnThmaSearchVO lrnThmaSearch) throws Exception;
	
	/**
	  * @Method 설명 : 주제학습 소주제 리스트 조회
	  * @param lrnThmaSearch
	  * @return
	  * @throws Exception
	  */
	public List<LrnThmaVO> selectLrnThmaStgList(LrnThmaSearchVO lrnThmaSearch) throws Exception;
}
