package com.wjthinkbig.aimath.lrn.note.service.dao;

import java.util.HashMap;
import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAccumDataVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAnalysisVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteBstWrstVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLrnStatusVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLvlVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteMgntVO;
import com.wjthinkbig.aimath.lrn.note.vo.NotePrgsListByStgVO;

@Mapper("noteDao")
public interface NoteDao {

	/**
	 * @Method 설명 : selectLvlListByMbr  학습자 아이디와 언어코드로  학습레벨 리스트 조회
	 * @author Kim Hee Seok [2020. 10. 20]
	 * @param lvlVO
	 * @return
	 */
	List<NoteLvlVO> selectListLvlByMbr(NoteLvlVO lvlVO);

	/**
	 * @Method 설명 : selectLvlNameByStgCd 특정학습자의 학습노트 시작 레벨과 레벨명을 가져온다.
	 * @author Kim Hee Seok [2020. 10. 21]
	 * @param lvlVO
	 * @return
	 */
	NoteLvlVO selectLvlNameByStgCd(NoteLvlVO lvlVO);

	/**
	 * @Method 설명 : selectStgListByLvl 사용자 레벨별 진도 리스트
	 * @author Kim Hee Seok [2020. 10. 22]
	 * @param nsListVO
	 * @return
	 */
	NoteMgntVO selectStgListByLvl(NoteMgntVO nsListVO);

	/**
	 * @Method 설명 : selectLrnStatus 학습상태와 날짜를 셋팅한다.
	 * @author Kim Hee Seok [2020. 10. 23]
	 * @param param
	 * @return
	 */
	NoteLrnStatusVO selectLrnStatus(HashMap<String, String> param);

	/**
	 * @Method 설명 : selectAnalysisByLvl 학습노트 분석
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param analysVO
	 * @return
	 */
	NoteAnalysisVO selectAnalysisByLvl(NoteAnalysisVO analysVO);

	/**
	 * @Method 설명 : selectPrgsByStg 해당 레벨에 스테이지 학습상태 
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param param
	 * @return
	 */
	List<NotePrgsListByStgVO> selectPrgsByStg(HashMap<String, String> param);

	/**
	 * @Method 설명 : selectBstWrstStg 잘한 스테이지 & 힘든 스테이지
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param param
	 * @return
	 */
	List<NoteBstWrstVO> selectBstWrstStg(HashMap<String, String> param);

	/**
	 * @Method 설명 : selectAccumData 해당 레벨의 학습자  누적 데이터를 가져온다.
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param param
	 * @return
	 */
	NoteAccumDataVO selectAccumData(HashMap<String, String> param);

	/**
	 * @Method 설명 : selectBstStg 가장 잘한 스테이지 
	 * @author Kim Hee Seok [2020. 10. 29]
	 * @param param
	 * @return
	 */
	NoteBstWrstVO selectBstStg(HashMap<String, String> param);

	/**
	 * @Method 설명 : selectWrstStg 가장 힘든 스테이지 
	 * @author Kim Hee Seok [2020. 10. 29]
	 * @param param
	 * @return
	 */
	NoteBstWrstVO selectWrstStg(HashMap<String, String> param);
	
}
