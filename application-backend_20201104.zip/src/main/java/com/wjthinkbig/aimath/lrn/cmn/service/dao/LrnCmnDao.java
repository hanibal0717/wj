package com.wjthinkbig.aimath.lrn.cmn.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnResSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnResVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnWransrSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnWransrVO;

/**
  * @Date : 2020. 10. 21.
  * @프로그램 설명 : 학습하기 공통
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 21.     19001861            최초작성
  * </pre>
  */
@Mapper("lrnCmnDao")
public interface LrnCmnDao {
	
	/**
	  * @Method 설명 : 학습하기 공통 문항정보 조회
	  * @param lrnCmnSearch
	  * @return
	  */
	LrnCmnVO selectQstInfo(LrnCmnSearchVO lrnCmnSearch);
	
	/**
	  * @Method 설명 : 주제학습 오답 수 조회
	  * @param lrnCmnSearch
	  * @return
	  */
	int selectThmaWransrCnt(LrnCmnSearchVO lrnCmnSearch);
	
	/**
	  * @Method 설명 : 코스학습 오답 수 조회
	  * @param lrnCmnSearch
	  * @return
	  */
	int selectCousWransrCnt(LrnCmnSearchVO lrnCmnSearch);
	
	/**
	  * @Method 설명 : 코스학습 결과 정보 조회
	  * @param lrnCmnResSearch
	  * @return
	  */
	LrnCmnResVO selectLrnCousRes(LrnCmnResSearchVO lrnCmnResSearch);
	
	/**
	  * @Method 설명 : 주제학습 결과 정보 조회
	  * @param lrnCmnResSearch
	  * @return
	  */
	LrnCmnResVO selectLrnThmaRes(LrnCmnResSearchVO lrnCmnResSearch);
	
	/**
	  * @Method 설명 : 코스학습 결과 이력 그래프 정보 조회
	  * @param lrnCmnResSearch
	  * @return
	  */
	List<LrnCmnResVO> selectLrnCmnCousHstGraphInfoList(LrnCmnResSearchVO lrnCmnResSearch);
	
	/**
	  * @Method 설명 : 주제학습 결과 이력 그래프 정보 조회
	  * @param lrnCmnResSearch
	  * @return
	  */
	List<LrnCmnResVO> selectLrnCmnThmaHstGraphInfoList(LrnCmnResSearchVO lrnCmnResSearch);
	
	/**
	  * @Method 설명 : 코스학습 오답 노트 리스트
	  * @param lrnWransrSearch
	  * @return
	  */
	List<LrnWransrVO> selectLrnCmnCousWransrList(LrnWransrSearchVO lrnWransrSearch);
	
	/**
	  * @Method 설명 : 주제학습 오답 노트 리스트
	  * @param lrnWransrSearch
	  * @return
	  */
	List<LrnWransrVO> selectLrnCmnThmaWransrList(LrnWransrSearchVO lrnWransrSearch);
	
	/**
	  * @Method 설명 : 개념메타 URL 조회
	  * @param lrnCmnSearch
	  * @return
	  */
	String selectCncpMeta(LrnCmnSearchVO lrnCmnSearch);
	
	/**
	  * @Method 설명 : 주제오답노트 등록
	  * @param lrnWransr
	  */
	void insertThmaWransr(LrnWransrVO lrnWransr);
	
	/**
	  * @Method 설명 : 코스오답노트 등록
	  * @param lrnWransr
	  */
	void insertCousWransr(LrnWransrVO lrnWransr);
	
	/**
	  * @Method 설명 : 주제학습 결과 이력 등록
	  * @param lrnCmnVO
	  */
	void insertThmaStgHst(LrnCmnVO lrnCmnVO);
	
	/**
	  * @Method 설명 : 코스학습 결과 이력 등록
	  * @param lrnCmnVO
	  */
	void insertCousStgHst(LrnCmnVO lrnCmnVO);
	
	/**
	  * @Method 설명 : 주제오답노트 삭제
	  * @param lrnWransr
	  * @return
	  */
	int deleteThmaWransr(LrnWransrVO lrnWransr);
	
	/**
	  * @Method 설명 : 코스오답노트 삭제
	  * @param lrnWransr
	  * @return
	  */
	int deleteCousWransr(LrnWransrVO lrnWransr);
}
