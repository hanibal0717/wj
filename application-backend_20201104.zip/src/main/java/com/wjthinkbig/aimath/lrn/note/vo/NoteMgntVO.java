package com.wjthinkbig.aimath.lrn.note.vo;

import java.util.List;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 
  * @프로그램 설명 :  학습노트 진도 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29          Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = " 학습노트 진도 ")
public class NoteMgntVO {
	
	/**
	 *  레벨코드  
	 */
	@NotBlank
	@ApiModelProperty(value="레벨코드")
	@FieldName("레벨코드")
	private String lvlCd;
	
	/**
	 *  레벨명  
	 */
	@ApiModelProperty(value="레벨명")
	@FieldName("레벨명")
	private String lvlNm;
	
	/**
	 * 학습회원 아이디
	 */
	@NotBlank
	@ApiModelProperty(value="학습회원 아이디")
	@FieldName("학습회원 아이디 ")
	private String lrnMbrId;
	
	/**
	 * 언어코드 
	 */
	@NotBlank
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;
	
	/**
	 * 학습상태 
	 */
	@ApiModelProperty(value="학습상태")
	@FieldName("학습상태")
	private String status;
	
	/**
	 * 학습기간 
	 */
	@ApiModelProperty(value="학습기간")
	@FieldName("학습기간")
	private String term;
	
	
	/**
	 * 실제 학습일 
	 */
	@ApiModelProperty(value="실제 학습일")
	@FieldName("실제 학습일 ")
	private String lrnDay;
	
	/**
	 * 해당레벨 스테이지 리스트 
	 */
	@ApiModelProperty(value="해당레벨 스테이지 리스트")
	@FieldName("해당레벨 스테이지 리스트")
	private List<NoteStgListByLvlVO> stgListByLvl; 
	
	

}
