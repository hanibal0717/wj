package com.wjthinkbig.aimath.lrn.thma.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.lrn.thma.service.LrnThmaService;
import com.wjthinkbig.aimath.lrn.thma.vo.LrnThmaSearchVO;
import com.wjthinkbig.aimath.lrn.thma.vo.LrnThmaVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 20.
  * @프로그램 설명 : 사용자 코스학습
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="사용자 주제학습")
@RestController
public class LrnThmaController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 사용자 주제학습 서비스
	 */
	@Resource(name = "lrnThmaService")
	private LrnThmaService lrnThmaService;
	
	/**
	  * @Method 설명 : 주제학습 대주제 리스트 조회
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="주제학습 대주제 리스트 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/thema/member/{lrnMbrId}")	
	public ListResult<LrnThmaVO> selectLrnThmaList(@ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id) throws Exception {
		//검색 조건 셋팅
		LrnThmaSearchVO lrnThmaSearch = new LrnThmaSearchVO();
		lrnThmaSearch.setLrnMbrId(lrn_mbr_id);
		
		List<LrnThmaVO> lrnThmaList = lrnThmaService.selectLrnThmaList(lrnThmaSearch);
		return responseService.getListResult(lrnThmaList);
	}
	
	/**
	  * @Method 설명 : 주제학습 소주제 리스트 조회
	  * @param thma_cd
	  * @param lang_cd
	  * @param lrn_mbr_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="주제학습 소주제 리스트 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/thema/language/{language}/member/{lrnMbrId}/thema/{thmaCd}/stage")	
	public ListResult<LrnThmaVO> selectLrnThmaStgList(@ApiParam(value = "대주제코드") @PathVariable(name="thmaCd",required=true) String thma_cd
			, @ApiParam(value = "언어코드") @PathVariable(name="language", required=true) String lang_cd
			, @ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id) throws Exception {
		//검색 조건 셋팅
		LrnThmaSearchVO lrnThmaSearch = new LrnThmaSearchVO();
		lrnThmaSearch.setThmaCd(thma_cd);
		lrnThmaSearch.setLangCd(lang_cd);
		lrnThmaSearch.setLrnMbrId(lrn_mbr_id);
		
		List<LrnThmaVO> lrnThmaList = lrnThmaService.selectLrnThmaStgList(lrnThmaSearch);
		
		return responseService.getListResult(lrnThmaList);
	}
}
