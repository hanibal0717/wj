package com.wjthinkbig.aimath.lrn.cmn.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.lrn.cmn.service.LrnCmnService;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnResSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnResVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnWransrSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnWransrVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 21.
  * @프로그램 설명 : 사용자 학습하기 공통
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 21.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="사용자 학습하기 공통")
@RestController
public class LrnCmnController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 사용자 학습하기 공통 서비스
	 */
	@Resource(name = "lrnCmnService")
	private LrnCmnService lrnCmnService;
	
	/**
	  * @Method 설명 : 학습하기 AI 예측 문항수, 풀이시간 조회
	  * @param stg_cd
	  * @param lrn_mbr_id
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="학습하기 AI 예측 문항수, 풀이시간 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/common/member/{lrnMbrId}/stage/{stgCd}")	
	public SingleResult<LrnCmnVO> selectLrnCmnAIPrediction(@ApiParam(value = "소주제코드") @PathVariable(name="stgCd", required=true) String stg_cd
			, @ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id) throws Exception {
		
		LrnCmnSearchVO lrnCmnSearch = new LrnCmnSearchVO();
		lrnCmnSearch.setLrnMbrId(lrn_mbr_id);
		lrnCmnSearch.setStgCd(stg_cd);
		
		LrnCmnVO lrnCmn = lrnCmnService.selectAIPredictionInfo(lrnCmnSearch);
		
		return responseService.getSingleResult(lrnCmn);
	}
	
	/**
	  * @Method 설명 : 학습하기 AI 예측 정보 및 문항정보 조회
	  * @param stg_cd
	  * @param lrn_mbr_id
	  * @param lang_cd
	  * @param chn_cd
	  * @param lrn_enty_scn_cd
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="학습하기 AI 예측 정보 및 문항정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/common/language/{language}/member/{lrnMbrId}/entry/{lrnEntyScnCd}/stage/{stgCd}")	
	public SingleResult<LrnCmnVO> selectLrnCmnAIPrdcnQst(@ApiParam(value = "소주제코드") @PathVariable(name="stgCd", required=true) String stg_cd
			, @ApiParam(value = "학습회원ID") @PathVariable(name="lrnMbrId", required=true) String lrn_mbr_id
			, @ApiParam(value = "언어코드") @PathVariable(name="language", required=true) String lang_cd
			, @ApiParam(value = "학습진입코드") @PathVariable(name="lrnEntyScnCd", required=true) String lrn_enty_scn_cd) throws Exception {
		
		LrnCmnSearchVO lrnCmnSearch = new LrnCmnSearchVO();
		lrnCmnSearch.setLrnMbrId(lrn_mbr_id);
		lrnCmnSearch.setStgCd(stg_cd);
		lrnCmnSearch.setLangCd(lang_cd);
		lrnCmnSearch.setLrnEntyScnCd(lrn_enty_scn_cd);
		
		//예측정보 및 문항정보 조회
		LrnCmnVO lrnCmn = lrnCmnService.selectAIPrdcnQst(lrnCmnSearch);
		
		return responseService.getSingleResult(lrnCmn);
	}
	
	/**
	  * @Method 설명 : 학습하기 정오답 체크
	  * @param lrnCmn
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="학습하기 정오답 체크")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/common/cransr/check")
	public SingleResult<Map<String, Object>> cransrCheck(@ApiParam("정답 체크를 위한 객체") @RequestBody(required=true) LrnCmnVO lrnCmn) throws Exception {
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("checkYn", lrnCmnService.cransrCheck(lrnCmn));
		
		return responseService.getSingleResult(resultMap);
	}
	
	/**
	  * @Method 설명 : 학습하기 진행 및 종료
	  * @param lrnCmn
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="학습하기 진행 및 종료")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/common/study")
	public SingleResult<LrnCmnVO> procLrnCmnStudy(@ApiParam("학습하기 객체") @RequestBody(required=true) LrnCmnVO lrnCmn) throws Exception {
		LrnCmnVO lrnCmnRes = lrnCmnService.procLrnCmnStudy(lrnCmn);
		return responseService.getSingleResult(lrnCmnRes);
	}
	
	/**
	  * @Method 설명 : 학습하기 결과 정보 조회
	  * @param lrnCmnResSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="학습하기 결과 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/common/result")
	public SingleResult<LrnCmnResVO> selectLrnCmnResult(@ApiParam("결과 검색 객체") @RequestBody(required=true) LrnCmnResSearchVO lrnCmnResSearch) throws Exception {
		LrnCmnResVO lrnCmnRes = lrnCmnService.selectLrnCmnRes(lrnCmnResSearch);
		return responseService.getSingleResult(lrnCmnRes);
	}
	
	/**
	  * @Method 설명 : 학습하기 오답 노트 리스트 조회
	  * @param lrnWransrSearch
	  * @return
	  * @throws Exception
	  */
	@ApiOperation(value="학습하기 오답 노트 리스트 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/common/wransr")
	public ListResult<LrnWransrVO> selectLrnCmnWransr(@ApiParam("오답노트 검색 객체") @RequestBody(required=true) LrnWransrSearchVO lrnWransrSearch) throws Exception {
		List<LrnWransrVO> lrnWransrList = lrnCmnService.selectLrnCmnWransr(lrnWransrSearch);
		return responseService.getListResult(lrnWransrList);
	}
}
