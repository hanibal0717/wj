package com.wjthinkbig.aimath.lrn.cous.service.dao;

import java.util.List;

import com.wjthinkbig.aimath.core.support.mybatis.annotation.Mapper;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousSearchVO;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousVO;

/**
  * @Date : 2020. 10. 13.
  * @프로그램 설명 : 사용자 코스학습 관련 Dao
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13.     19001861            최초작성
  * </pre>
  */
@Mapper("lrnCousDao")
public interface LrnCousDao {
	
	/**
	  * @Method 설명 : 코스학습 시작 소주제 코드 조회
	  * @param lrnCousSearch
	  * @return
	  */
	String selectStartStgCd(LrnCousSearchVO lrnCousSearch);
	
	/**
	  * @Method 설명 : 코스학습 리스트 조회
	  * @param lrnCousSearch
	  * @return
	  */
	List<LrnCousVO> selectLrnCousList(LrnCousSearchVO lrnCousSearch);
	
	/**
	  * @Method 설명 : 코스학습 완료 리스트 조회
	  * @param lrnCousSearch
	  * @return
	  */
	List<LrnCousVO> selectLrnCousEndList(LrnCousSearchVO lrnCousSearch);
	
	/**
	  * @Method 설명 : 코스학습 현재 레벨 정보 조회
	  * @param lrnCousSearch
	  * @return
	  */
	LrnCousVO selectLrnCousLvlInfo(LrnCousSearchVO lrnCousSearch);
	
	/**
	  * @Method 설명 : 코스학습 완료 단일 정보 조회
	  * @param lrnCousSearch
	  * @return
	  */
	LrnCousVO selectLrnCousEndInfo(LrnCousSearchVO lrnCousSearch);
	
	/**
	  * @Method 설명 : 코스학습 레벨 결과 정보 조회
	  * @param lrnCousSearch
	  * @return
	  */
	LrnCousVO selectLrnCousLvlRes(LrnCousSearchVO lrnCousSearch);
	
	/**
	  * @Method 설명 : 코스학습 레벨 완료 이력 등록
	  * @param lrnCous
	  */
	void insertLnrLvlentyHst(LrnCousVO lrnCous);
}
