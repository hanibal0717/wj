package com.wjthinkbig.aimath.lrn.note.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 
  * @프로그램 설명 :  학습상태 판단을 위한 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "학습상태 판단을 위한 VO")
public class NoteLrnStatusVO {
	
	/**
	 * 학습기간 
	 */
	@ApiModelProperty(value="학습기간")
	@FieldName("학습기간")
	private String lrnTerm;
	
	/**
	 * 학습회원 최종 스테이지 
	 */
	@ApiModelProperty(value="학습회원 최종 스테일지")
	@FieldName("학습회원 최종 스테일지")
	private String userStgCd;
	
	/**
	 *  최상 상태코드 
	 */
	@ApiModelProperty(value="최상 상태코드 ")
	@FieldName("최상 상태코드 ")
	private String userMaxPrgsCd;
	
	/**
	 * 사용자 스테이지 수 
	 */
	@ApiModelProperty(value="사용자 스테이지 수")
	@FieldName("사용자 스테이지 수")
	private String userStgCnt;
	
	/**
	 * 레벨 스테이지 수
	 */
	@ApiModelProperty(value="레벨 스테이지 수")
	@FieldName("레벨 스테이지 수")
	private String maxLvlStgCnt;
	
	/**
	 * 레벨 최종 스테이지 
	 */
	@ApiModelProperty(value="레벨 최종 스테이지 ")
	@FieldName("레벨코드")
	private String maxLvlStgCd;
	
	/**
	 * 실제 학습일 
	 */
	@ApiModelProperty(value="실제 학습일")
	@FieldName("실제 학습일 ")
	private String lrnDay;
}
