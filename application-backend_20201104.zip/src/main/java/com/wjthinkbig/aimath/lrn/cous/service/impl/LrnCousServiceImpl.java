package com.wjthinkbig.aimath.lrn.cous.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.lrn.cous.service.LrnCousService;
import com.wjthinkbig.aimath.lrn.cous.service.dao.LrnCousDao;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousSearchVO;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousVO;

/**
  * @Date : 2020. 10. 13.
  * @프로그램 설명 : 사용자 코스학습 관련 Service
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 13.     19001861            최초작성
  * </pre>
  */
@Service("lrnCousService")
public class LrnCousServiceImpl extends BaseServiceImpl implements LrnCousService {
	
	/**
	 * 사용자 코스학습 Dao
	 */
	@Resource(name = "lrnCousDao")
	private LrnCousDao lrnCousDao;
	
	/**
	 * AWS S3 도메인
	 */
	private static String domain;
	@Value("${aws.domain}")
	public void setDomain(String url) {
		domain = url;
	}
	
	/**
	 * AWS S3 bucketName 키값
	 */
	private static String bucketName;
	@Value("${aws.bucket.name}")
	public void setBucketName(String name) {
		bucketName = name;
	}
	
	@Override
	public String selectStartStgCd(LrnCousSearchVO lrnCousSearch) throws Exception {
		return lrnCousDao.selectStartStgCd(lrnCousSearch);
	}

	@Override
	public List<LrnCousVO> selectLrnCousList(LrnCousSearchVO lrnCousSearch) throws Exception {
		List<LrnCousVO> lrnCousList = lrnCousDao.selectLrnCousList(lrnCousSearch);
		
		if( lrnCousList != null && lrnCousList.size() > 0 ) {
			for( int i = 0; i < lrnCousList.size(); i++ ) {
				//파일 경로에 S3 도메인을 넣어준다
				if( StringUtils.isNotEmpty(lrnCousList.get(i).getStgImgFilePath()) ) {
					lrnCousList.get(i).setStgImgFilePath(domain + "/" + bucketName + lrnCousList.get(i).getStgImgFilePath());
				}
			}
		}
		
		return lrnCousList;
	}
	
	@Override
	public List<LrnCousVO> selectLrnCousEndList(LrnCousSearchVO lrnCousSearch) throws Exception {
		return lrnCousDao.selectLrnCousEndList(lrnCousSearch);
	}
	
	@Override
	public LrnCousVO selectLrnCousLvlInfo(LrnCousSearchVO lrnCousSearch) throws Exception {
		return lrnCousDao.selectLrnCousLvlInfo(lrnCousSearch);
	}

	@Override
	public LrnCousVO selectLrnCousEndInfo(LrnCousSearchVO lrnCousSearch) throws Exception {
		LrnCousVO lrnCous = lrnCousDao.selectLrnCousEndInfo(lrnCousSearch);
		
		if( lrnCous != null ) {
			//파일 경로에 S3 도메인을 넣어준다
			if( StringUtils.isNotEmpty(lrnCous.getStgImgFilePath()) ) {
				lrnCous.setStgImgFilePath(domain + "/" + bucketName + lrnCous.getStgImgFilePath());
			}
		}
		
		return lrnCous;
	}

	@Override
	public LrnCousVO selectLrnCousLvlRes(LrnCousSearchVO lrnCousSearch) throws Exception {
		return lrnCousDao.selectLrnCousLvlRes(lrnCousSearch);
	}

	@Override
	public void insertLnrLvlentyHst(LrnCousVO lrnCous) throws Exception {
		lrnCousDao.insertLnrLvlentyHst(lrnCous);
	}
}
