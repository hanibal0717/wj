package com.wjthinkbig.aimath.lrn.note.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 
  * @프로그램 설명 :  해당 레벨의 스테이지 리스트와 스테이지별 학습 결과 VO  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "해당 레벨의 스테이지 리스트와 스테이지별 학습 결과 VO")
public class NotePrgsListByStgVO {
	
	/*
	 * 스테이지순번 
	 */
	@ApiModelProperty(value="스테이지순번")
	@FieldName("스테이지순번")
	private int rowNum;
	
	/*
	 * 학습결과코드 
	 */
	@ApiModelProperty(value="학습결과코드 ")
	@FieldName("학습결과코드 ")
	private String prgsCd;
	
	/*
	 * 결과코드명
	 */
	@ApiModelProperty(value="결과코드명 ")
	@FieldName("결과코드명 ")
	private String cdNm;
	
	/*
	 * 완료스테이지 코드
	 */
	@ApiModelProperty(value="완료스테이지 코드")
	@FieldName("완료스테이지 코드")
	private String compStgCd; 
}
