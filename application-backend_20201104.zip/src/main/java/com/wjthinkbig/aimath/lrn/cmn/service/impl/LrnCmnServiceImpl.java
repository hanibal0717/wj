package com.wjthinkbig.aimath.lrn.cmn.service.impl;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.ApiUtil;
import com.wjthinkbig.aimath.core.utils.JsonUtils;
import com.wjthinkbig.aimath.core.utils.WebUtil;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.lrn.cmn.service.LrnCmnService;
import com.wjthinkbig.aimath.lrn.cmn.service.dao.LrnCmnDao;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnResSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnResVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnCmnVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnWransrSearchVO;
import com.wjthinkbig.aimath.lrn.cmn.vo.LrnWransrVO;
import com.wjthinkbig.aimath.lrn.cous.service.dao.LrnCousDao;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousSearchVO;
import com.wjthinkbig.aimath.lrn.cous.vo.LrnCousVO;

/**
  * @Date : 2020. 10. 21.
  * @프로그램 설명 : 사용자 학습하기 공통
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 21.     19001861            최초작성
  * </pre>
  */
@Service("lrnCmnService")
public class LrnCmnServiceImpl extends BaseServiceImpl implements LrnCmnService {

	/**
	 * 학습하기 공통 Dao
	 */
	@Resource(name = "lrnCmnDao")
	private LrnCmnDao lrnCmnDao;
	
	/**
	 * 코스학습 Dao
	 */
	@Resource(name = "lrnCousDao")
	private LrnCousDao lrnCousDao;
	
	/**
	 * 학습하기 API 관련 Util
	 */
	@Autowired
	ApiUtil apiUtil;
	
	@Override
	public LrnCmnVO selectAIPredictionInfo(LrnCmnSearchVO lrnCmnSearch) throws Exception {
		LrnCmnVO lrnCmn = null;
		
		// ai API param 셋팅
		Map<String, Object> aiParam = new HashMap<String, Object>();
		aiParam.put("lrnMbrId", lrnCmnSearch.getLrnMbrId());				//학습회원ID
		aiParam.put("stgCd", lrnCmnSearch.getStgCd());						//소주제코드
		aiParam.put("deviceScnCd", WebUtil.getDeviceKind(((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest()));		//입력방식(시작시에만 디바이스 정보)
		
		//AI 예측 통신 시작
		//ApiUtil apiUtil = new ApiUtil();
		//Map<String, Object> aiRes = apiUtil.externalApi("url", aiParam, HttpMethod.POST);
		
		Map<String, String> aiRes = new HashMap<String, String>();
		aiRes.put("statusCode", "200");
		aiRes.put("body", "{\"aiPrdcnQstCt\":24, \"estDiagDur\":15}");
		
		if( aiRes != null && "200".equals(aiRes.get("statusCode")) ) {
			Map<String, String> aiResMap = JsonUtils.readValue((String)aiRes.get("body"));
			lrnCmn = new LrnCmnVO();
			
			lrnCmn.setAiPrdcnQstCt(Integer.parseInt(aiResMap.get("aiPrdcnQstCt")));			//예측 문항 수
			lrnCmn.setEstDiagDur(Integer.parseInt(aiResMap.get("estDiagDur")));		//예측 풀이 시간(ms단위)
		}
		
		return lrnCmn;
	}

	@Override
	public LrnCmnVO selectAIPrdcnQst(LrnCmnSearchVO lrnCmnSearch) throws Exception {
		LrnCmnVO lrnCmn = null;
		
		// ai API param 셋팅
		Map<String, Object> aiParam = new HashMap<String, Object>();
		aiParam.put("lrnMbrId", lrnCmnSearch.getLrnMbrId());				//학습회원ID
		aiParam.put("lrnEntyScnCd", lrnCmnSearch.getLrnEntyScnCd());		//학습진입 구분코드
		aiParam.put("stgCd", lrnCmnSearch.getStgCd());						//소주제코드
		aiParam.put("deviceScnCd", WebUtil.getDeviceKind(((ServletRequestAttributes)RequestContextHolder.getRequestAttributes()).getRequest()));	//입력방식(시작시에만 디바이스 정보)
		
		//AI 예측 통신 시작
		//ApiUtil apiUtil = new ApiUtil();
		//Map<String, Object> aiRes = apiUtil.externalApi("url", aiParam, HttpMethod.POST);
		
		Map<String, String> aiRes = new HashMap<String, String>();
		aiRes.put("statusCode", "200");
		aiRes.put("body", "{\"lrnMbrId\":\"LRN20201005160000136\", \"aiPrdcnQstCt\":24, \"estDiagDur\":15, \"qstCd\":\"Z00010001\", \"corPosiQstYn\":\"Y\", \"estQstDurMax\":20000}");
		
		if( aiRes != null && "200".equals(aiRes.get("statusCode")) ) {
			Map<String, String> aiResMap = JsonUtils.readValue((String)aiRes.get("body"));
			
			//동일 학습회차가 존재할경우 오답노트 삭제
			LrnWransrVO lrnWransr = new LrnWransrVO();
			lrnWransr.setLrnMbrId(lrnCmnSearch.getLrnMbrId());
			lrnWransr.setStgCd(lrnCmnSearch.getStgCd());
			lrnWransr.setLrnTmeSn(Integer.parseInt(aiResMap.get("lrnStgCt")));
			
			if( "LESC01".equals(lrnCmnSearch.getLrnEntyScnCd()) ) {
				//코스학습 오답노트 삭제
				lrnCmnDao.deleteCousWransr(lrnWransr);
			} else if( "LESC02".equals(lrnCmnSearch.getLrnEntyScnCd()) ) {
				//주제학습 오답노트 삭제
				lrnCmnDao.deleteThmaWransr(lrnWransr);
			}
			
			//문항 정보 조회
			String qst_cd = aiResMap.get("qstCd");
			
			if( StringUtils.isNotEmpty(qst_cd) ) {
				lrnCmnSearch.setQstCd(qst_cd);
				lrnCmn = lrnCmnDao.selectQstInfo(lrnCmnSearch);
				
				if( lrnCmn != null ) {
					lrnCmn.setAiPrdcnQstCt(Integer.parseInt(aiResMap.get("aiPrdcnQstCt")));		//예측 문항 수
					lrnCmn.setEstDiagDur(Integer.parseInt(aiResMap.get("estDiagDur")));			//예측 풀이 시간(ms단위)
					lrnCmn.setCorPsbleQstYn(aiResMap.get("corPsbleQstYn"));						//맞출 수 있는 문제 여부 - Y인 문제는 틀릴 경우 맞출 수 있었던 문제라는 메시지 노출 필요
					lrnCmn.setEstQstDurMax(Long.parseLong(aiResMap.get("estQstDurMax")));		//문제의 예측 풀이 시간 최대 값(ms단위) - 해당 시간 경과 후 집중하라는 메시지 노출
				}
			}
		}
		
		return lrnCmn;
	}

	@Override
	public String cransrCheck(LrnCmnVO lrnCmn) throws Exception {
		String result = "N";
		
		if( StringUtils.isNotEmpty(lrnCmn.getQstCd()) ) {
			LrnCmnSearchVO lrnCmnSearch = new LrnCmnSearchVO();
			lrnCmnSearch.setQstCd(lrnCmn.getQstCd());
			lrnCmnSearch.setLangCd(lrnCmn.getLangCd());
			
			LrnCmnVO qstInfo = lrnCmnDao.selectQstInfo(lrnCmnSearch);
			
			if( qstInfo != null && StringUtils.isNotEmpty(lrnCmn.getQstCransr()) ) {
				String cransrTy = apiUtil.jugeAnswer(lrnCmn.getQstCransr(), qstInfo.getQstCransr(), qstInfo.getCransrTyScnCd());
				result = "Y".equals(cransrTy) ? "Y" : "N";
			} else {
				throw this.processException("S001003", lrnCmn.getQstCd());		//해당 데이터({0})는 존재하지 않습니다.
			}
		} else {
			throw this.processException("S001011");		//필수값 오류입니다.
		}
		
		return result;
	}

	@Override
	public LrnCmnVO procLrnCmnStudy(LrnCmnVO lrnCmn) throws Exception {
		LrnCmnVO qstInfo = null;		//문항정보
		String ansrCwYn = "N";			//정오답 여부
		LrnCmnVO lrnCmnInfo = null;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
		
		if( "U".equals(lrnCmn.getPrgsCd()) || "X".equals(lrnCmn.getPrgsCd()) ) {
			//사용자 종료일 또는 시간 초과로 종료 되었을 경우
			// ai API param 셋팅
			Map<String, Object> aiParam = new HashMap<String, Object>();
			aiParam.put("lrnMbrId", lrnCmn.getLrnMbrId());						//학습회원ID
			aiParam.put("prgsCd", lrnCmn.getPrgsCd());							//진행코드
			aiParam.put("lrnEntyScnCd", lrnCmn.getLrnEntyScnCd());				//학습진입 구분코드
			aiParam.put("qstCd", lrnCmn.getQstCd());							//푼문제의 문항코드
			aiParam.put("overTmYn", lrnCmn.getOverTmYn());						//시간초과여부
			aiParam.put("lrnTotScond", lrnCmn.getLrnTotScond());				//누적학습시간
			
			//AI 예측 통신 시작
			//ApiUtil apiUtil = new ApiUtil();
			//Map<String, Object> aiRes = apiUtil.externalApi("url", aiParam, HttpMethod.POST);
			
			//Response에 상관 없이 종료
			return null;
		} else {
			/***********************************
			 * 정오답 체크 로직
			 ***********************************/
			if( StringUtils.isNotEmpty(lrnCmn.getQstCd()) ) {
				//문항정보 조회
				LrnCmnSearchVO lrnCmnSearch = new LrnCmnSearchVO();
				lrnCmnSearch.setQstCd(lrnCmn.getQstCd());
				lrnCmnSearch.setLangCd(lrnCmn.getLangCd());
				
				qstInfo = lrnCmnDao.selectQstInfo(lrnCmnSearch);
				
				if( qstInfo != null && StringUtils.isNotEmpty(lrnCmn.getQstCransr()) ) {
					//정오답 공통 체크 호출
					ansrCwYn = apiUtil.jugeAnswer(lrnCmn.getQstCransr(), qstInfo.getQstCransr(), qstInfo.getCransrTyScnCd());
				} else {
					throw this.processException("S001003", lrnCmn.getQstCd());		//해당 데이터({0})는 존재하지 않습니다.
				}
			} else {
				throw this.processException("S001011");		//필수값 오류입니다.
			}
			
			/***********************************
			 * AI 모듈 API 통신
			 ***********************************/
			// ai API param 셋팅
			Map<String, Object> aiParam = new HashMap<String, Object>();
			aiParam.put("lrnMbrId", lrnCmn.getLrnMbrId());						//학습회원ID
			aiParam.put("prgsCd", lrnCmn.getPrgsCd());							//진행코드
			aiParam.put("lrnEntyScnCd", lrnCmn.getLrnEntyScnCd());				//학습진입 구분코드
			aiParam.put("qstCd", lrnCmn.getQstCd());							//푼문제의 문항코드
			aiParam.put("qstCransr", lrnCmn.getQstCransr());					//입력한 답 내용
			aiParam.put("inputTy", lrnCmn.getInputTy());						//입력방식
			aiParam.put("ansrCwYn", "Y".equals(ansrCwYn) ? "Y" : "N");			//정오답여부
			aiParam.put("blkYn", "B".equals(ansrCwYn) ? "Y" : "N");				//빈칸여부
			aiParam.put("overTmYn", lrnCmn.getOverTmYn());						//시간초과여부
			aiParam.put("movieSkipYn", lrnCmn.getMovieSkipYn());				//개념영상 skip 여부
			aiParam.put("movieTm", lrnCmn.getMovieTm());						//개념영상 시간
			aiParam.put("lrnTotScond", lrnCmn.getLrnTotScond());				//누적학습시간
			aiParam.put("slvTime", lrnCmn.getSlvTime());						//문제풀이시간
			aiParam.put("inptTime", lrnCmn.getInptTime());						//입력에 소요된 시간
			
			//AI 예측 통신 시작
			//ApiUtil apiUtil = new ApiUtil();
			//Map<String, Object> aiRes = apiUtil.externalApi("url", aiParam, HttpMethod.POST);
			
			/*************************************************************
			 * 임시 데이터
			 *************************************************************/
			Map<String, String> aiRes = new HashMap<String, String>();
			StringBuffer sb = new StringBuffer();
			//진행시 임시 데이터
//			sb.append("{");
//			sb.append("\"lrnMbrId\":\"LRN20201005160000136\",");			//회원ID
//			sb.append("\"prgsCd\":\"W\",");									//진행코드 - W 진행, C 개념확인 후 진행, D 드릴다운, E 종료, T 주제 추천 후 종료
//			sb.append("\"totQstCt\":24,");									//총 문항수
//			sb.append("\"estQstNowNo\":1,");								//현재까지 문항 수
//			sb.append("\"qstCd\":\"Z00010001\",");							//다음 문제의 문항코드
//			sb.append("\"corPsbleQstYn\":\"N\",");							//맞출 수 있는 문제여부
//			sb.append("\"estQstDurMax\":60000,");							//다음 문제의 예측 풀이 시간 최대값(ms)
//			sb.append("\"explSpedCd\":\"ESC01\",");							//풀이 속도 코드
//			sb.append("\"lrnTmeSn\":1");									//학습회차순번
//			sb.append("}");
			
			//종료시 임시 데이터
			sb.append("{");
			sb.append("\"lrnMbrId\":\"LRN20201005160000136\",");			//회원ID
			sb.append("\"prgsCd\":\"E\",");									//진행코드 - W 진행, C 개념확인 후 진행, D 드릴다운, E 종료, T 주제 추천 후 종료
			sb.append("\"totQstCt\":24,");									//총 문항수
			sb.append("\"aiPrdcnQstCt\":24,");								//학습 진입시 예측 문항수
			sb.append("\"estQstNowNo\":1,");								//현재까지 문항 수
			sb.append("\"drilldwCt\":0,");									//drill down 횟수
			sb.append("\"drilldwStgCd\":\"\",");							//drill down 소주제
			sb.append("\"drilldwDepth\":\"1\",");							//drill down depth
			sb.append("\"explSpedCd\":\"ESC01\",");							//풀이 속도 코드
			sb.append("\"rcmnSbthmaCd\":\"\",");							//추천 소주제 코드
			sb.append("\"lrnBgnDt\":\"2020-10-26 13:11:20\",");				//학습시작일시
			sb.append("\"lrnEndDt\":\"2020-10-26 14:01:20\",");				//학습종료일시
			sb.append("\"drilldwQstCt\":0,");								//drill down으로 푼 문항 수
			sb.append("\"cransrQstCt\":20,");								//정답문항 수
			sb.append("\"drilldwCransrQstCt\":0,");							//drill down 정답 수
			sb.append("\"lrnPrgsStsCd\":\"LPSC01\",");						//학습 진행 상태 코드
			sb.append("\"acrcyCd\":\"C\",");								//풀이 정확도 코드
			sb.append("\"lrnTmeSn\":1");									//학습회차순번
			sb.append("}");
			
			aiRes.put("statusCode", "200");
			aiRes.put("body", sb.toString());
			
			if( aiRes != null && "200".equals(aiRes.get("statusCode")) ) {
				//통신 성공
				Map<String, String> aiResMap = JsonUtils.readValue((String)aiRes.get("body"));
				
				/***********************************
				 * 오답이력 등록 로직
				 ***********************************/
				if( !"Y".equals(ansrCwYn) ) {											//오답일 경우에만 처리
					LrnWransrVO lrnWransr = new LrnWransrVO();
					lrnWransr.setLrnMbrId(lrnCmn.getLrnMbrId());						//학습회원ID
					lrnWransr.setStgCd(lrnCmn.getStgCd());								//소주제코드
					lrnWransr.setQstCd(lrnCmn.getQstCd());								//문항코드
					lrnWransr.setCorPsbleQstYn(lrnCmn.getCorPsbleQstYn());				//맞힐수있는데 틀린문항 여부
					lrnWransr.setMbrAnsr(lrnCmn.getQstCransr());						//회원답안
					lrnWransr.setLrnTmeSn(Integer.parseInt(aiResMap.get("lrnTmeSn")));	//이번 스테이지를 학습한 횟수
					lrnWransr.setRgtnUser(lrnCmn.getRgtnUser());						//등록자
					lrnWransr.setDrilldwQstYn("D".equals(aiResMap.get("prgsCd")) ? "Y" : "N");				//맞힐수있는데 틀린문항 여부
					
					//필수값 체크
					this.validateOrElseThrow(lrnWransr, Groups.Insert.class);
					
					if( "LESC01".equals(lrnCmn.getLrnEntyScnCd()) ) {
						//코스학습 오답노트 등록
						lrnCmnDao.insertCousWransr(lrnWransr);
					} else if( "LESC02".equals(lrnCmn.getLrnEntyScnCd()) ) {
						//주제학습 오답노트 등록
						lrnCmnDao.insertThmaWransr(lrnWransr);
					}
				}
				
				/***********************************
				 * 결과에 따른 return 로직
				 ***********************************/
				if( "W".equals(aiResMap.get("prgsCd")) || "C".equals(aiResMap.get("prgsCd")) || "D".equals(aiResMap.get("prgsCd")) ) {
					//계속 진행 - W: 진행, C: 개념확인 후 진행, D: 드릴다운
					//문항 정보 조회
					String qst_cd = aiResMap.get("qstCd");
					
					if( StringUtils.isNotEmpty(qst_cd) ) {
						//다음 문항 정보 조회
						LrnCmnSearchVO lrnCmnSearch = new LrnCmnSearchVO();
						lrnCmnSearch.setQstCd(qst_cd);
						lrnCmnSearch.setLangCd(lrnCmn.getLangCd());
						
						lrnCmnInfo = lrnCmnDao.selectQstInfo(lrnCmnSearch);
						
						if( lrnCmnInfo != null ) {
							if( "C".equals(aiResMap.get("prgsCd")) ) {
								//개념확인 후 진행일 경우 개념영상 URL 조회
								lrnCmnSearch.setStgCd(lrnCmn.getStgCd());
								lrnCmnInfo.setCncpMeta(lrnCmnDao.selectCncpMeta(lrnCmnSearch));
							}
							
							//통신 결과 셋팅
							lrnCmnInfo.setLrnTotScond(lrnCmn.getLrnTotScond());											//누적학습시간(초)
							lrnCmnInfo.setLrnMbrId(aiResMap.get("lrnMbrId"));											//회원ID
							lrnCmnInfo.setPrgsCd(aiResMap.get("prgsCd"));												//진행코드 - W 진행, C 개념확인 후 진행, D 드릴다운, E 종료, T 주제 추천 후 종료
							lrnCmnInfo.setTotQstCt(Integer.parseInt(aiResMap.get("totQstCt")));							//총 문항 수
							lrnCmnInfo.setEstQstNowNo(Integer.parseInt(aiResMap.get("estQstNowNo")));					//현재까지 문항 수(이번문항 포함)
							lrnCmnInfo.setCorPsbleQstYn(aiResMap.get("corPsbleQstYn"));									//맞출 수 있는 문제 여부 - Y인 문제는 틀릴 경우 맞출 수 있었던 문제라는 메시지 노출 필요
							lrnCmnInfo.setEstQstDurMax(Long.parseLong(aiResMap.get("estQstDurMax")));					//문제의 예측 풀이 시간 최대 값(ms단위) - 해당 시간 경과 후 집중하라는 메시지 노출
							lrnCmnInfo.setExplSpedCd(aiResMap.get("explSpedCd"));										//풀이속도 코드 - ESC01: 느림, ESC02: 보통, ESC03: 빠름
							lrnCmnInfo.setLrnTmeSn(Integer.parseInt(aiResMap.get("lrnTmeSn")));							//이번 소주제를 학습한 횟수
						} else {
							throw this.processException("S001003", qst_cd);				//해당 데이터({0})는 존재하지 않습니다.
						}
					}
				} else {
					//종료
					lrnCmnInfo = new LrnCmnVO();
					
					//통신 결과 셋팅
					lrnCmnInfo.setStgCd(lrnCmn.getStgCd());														//소주제코드
					lrnCmnInfo.setRgtnUser(lrnCmn.getRgtnUser());												//등록자
					lrnCmnInfo.setLrnTotScond(lrnCmn.getLrnTotScond());											//누적학습시간(초)
					
					lrnCmnInfo.setLrnMbrId(aiResMap.get("lrnMbrId"));											//회원ID
					lrnCmnInfo.setPrgsCd(aiResMap.get("prgsCd"));												//진행코드 - W 진행, C 개념확인 후 진행, D 드릴다운, E 종료, T 주제 추천 후 종료
					lrnCmnInfo.setTotQstCt(Integer.parseInt(aiResMap.get("totQstCt")));							//총 문항 수
					lrnCmnInfo.setAiPrdcnQstCt(Integer.parseInt(aiResMap.get("aiPrdcnQstCt")));					//학습 진입시 예측 문항 수
					lrnCmnInfo.setEstQstNowNo(Integer.parseInt(aiResMap.get("estQstNowNo")));					//현재까지 문항 수(이번문항 포함)
					lrnCmnInfo.setDrilldwCt(Integer.parseInt(aiResMap.get("drilldwCt")));						//드릴다운 횟수
					lrnCmnInfo.setDrilldwStgCd(aiResMap.get("drilldwStgCd"));									//드릴다운 소주제코드
					lrnCmnInfo.setDrilldwDepth(aiResMap.get("drilldwDepth"));									//드릴다운 뎁스
					lrnCmnInfo.setExplSpedCd(aiResMap.get("explSpedCd"));										//풀이속도 코드 - ESC01: 느림, ESC02: 보통, ESC03: 빠름
					lrnCmnInfo.setRcmnSbthmaCd(aiResMap.get("rcmnSbthmaCd"));									//추천 소주제 코드
					lrnCmnInfo.setLrnBgnDt(LocalDateTime.parse(aiResMap.get("lrnBgnDt"), formatter));			//학습 시작일시
					lrnCmnInfo.setLrnEndDt(LocalDateTime.parse(aiResMap.get("lrnEndDt"), formatter));			//학습 종료일시
					lrnCmnInfo.setDrilldwQstCt(Integer.parseInt(aiResMap.get("drilldwQstCt")));					//드릴다운으로 푼 문항수
					lrnCmnInfo.setCransrQstCt(Integer.parseInt(aiResMap.get("cransrQstCt")));					//이번학습중 전체 정답수
					lrnCmnInfo.setDrilldwCransrQstCt(Integer.parseInt(aiResMap.get("drilldwCransrQstCt")));		//이번학습중 드릴다운 정답수
					lrnCmnInfo.setLrnPrgsStsCd(aiResMap.get("lrnPrgsStsCd"));									//학습진행상태코드 - LPSC01: 노력, LPSC02: 기본, LPSC03: 충분, LPSC04: 훌륭
					lrnCmnInfo.setAcrcyCd(aiResMap.get("acrcyCd"));												//풀이 정확도 코드 - D: 미달, C: 보통, B: 높음, A: 완벽
					lrnCmnInfo.setLrnTmeSn(Integer.parseInt(aiResMap.get("lrnTmeSn")));							//이번 소주제를 학습한 횟수
					lrnCmnInfo.setDrilldwWransrQstCt(lrnCmnInfo.getDrilldwQstCt() - lrnCmnInfo.getDrilldwCransrQstCt());	//드릴다운 오답 문항 수
					lrnCmnInfo.setWransrQstCt(lrnCmnInfo.getTotQstCt() - lrnCmnInfo.getCransrQstCt());			//오답 문항 수
					
					//오답수 조회를 위해 searchVO 셋팅
					LrnCmnSearchVO lrnCmnSearch = new LrnCmnSearchVO();
					lrnCmnSearch.setStgCd(lrnCmnInfo.getStgCd());
					lrnCmnSearch.setLrnTmeSn(lrnCmnInfo.getLrnTmeSn());
					lrnCmnSearch.setLrnMbrId(lrnCmnInfo.getLrnMbrId());
					
					//종료 이력 등록
					if( "LESC01".equals(lrnCmn.getLrnEntyScnCd()) ) {
						//코스학습 이력 등록
						lrnCmnDao.insertCousStgHst(lrnCmnInfo);
					} else if( "LESC02".equals(lrnCmn.getLrnEntyScnCd()) ) {
						//주제학습 이력 등록
						lrnCmnDao.insertThmaStgHst(lrnCmnInfo);
					}
				}
			}
		}
		
		return lrnCmnInfo;
	}

	@Override
	public LrnCmnResVO selectLrnCmnRes(LrnCmnResSearchVO lrnCmnResSearch) throws Exception {
		LrnCmnResVO lrnCmnRes = null;
		
		if( "LESC01".equals(lrnCmnResSearch.getLrnEntyScnCd()) ) {
			//코스학습
			lrnCmnRes = lrnCmnDao.selectLrnCousRes(lrnCmnResSearch);
			
			if( lrnCmnRes != null ) {
				/************************************************
				 * 현재 완료한 소주제 이력 리스트 조회 (그래프용)
				 ************************************************/
				lrnCmnRes.setLrnCmnResList(lrnCmnDao.selectLrnCmnCousHstGraphInfoList(lrnCmnResSearch));
				
				/************************************************
				 * 다음 소주제 정보 조회
				 ************************************************/
				LrnCousSearchVO lrnCousSearch = new LrnCousSearchVO();
				lrnCousSearch.setChnCd(lrnCmnResSearch.getChnCd());
				lrnCousSearch.setLrnMbrId(lrnCmnResSearch.getLrnMbrId());
				
				//현재 레벨 완료했는지 체크
				LrnCousVO lrnCousLvlInfo = lrnCousDao.selectLrnCousLvlInfo(lrnCousSearch);
				
				if( lrnCousLvlInfo != null  ) {
					if( lrnCousLvlInfo.getTotalCnt() == lrnCousLvlInfo.getEndCnt() ) {
						//현재 레벨 완료로 레벨완료 페이지로 이동해야하기 때문에 레벨 완료 페이지로 이동
						lrnCmnRes.setLvlCd(lrnCousLvlInfo.getLvlCd());
					} else {
						//다음 소주제 코드 조회
						String nextStgCd = lrnCousDao.selectStartStgCd(lrnCousSearch);
						lrnCmnRes.setNextStgCd(nextStgCd);
					}
				}
			} else {
				throw this.processException("S001003", lrnCmnResSearch.getStgCd());				//해당 데이터({0})는 존재하지 않습니다.
			}
			
		} else if( "LESC02".equals(lrnCmnResSearch.getLrnEntyScnCd()) ) {
			//주제학습
			lrnCmnRes = lrnCmnDao.selectLrnThmaRes(lrnCmnResSearch);
			
			if( lrnCmnRes != null ) {
				/************************************************
				 * 현재 완료한 소주제 이력 리스트 조회 (그래프용)
				 ************************************************/
				lrnCmnRes.setLrnCmnResList(lrnCmnDao.selectLrnCmnThmaHstGraphInfoList(lrnCmnResSearch));
			}
		}
		
		return lrnCmnRes;
	}

	@Override
	public List<LrnWransrVO> selectLrnCmnWransr(LrnWransrSearchVO lrnWransrSearch) throws Exception {
		List<LrnWransrVO> lrnWransrList = null;
		
		if( "LESC01".equals(lrnWransrSearch.getLrnEntyScnCd()) ) {
			//코스학습
			lrnWransrList = lrnCmnDao.selectLrnCmnCousWransrList(lrnWransrSearch);
		} else if( "LESC02".equals(lrnWransrSearch.getLrnEntyScnCd()) ) {
			//주제학습
			lrnWransrList = lrnCmnDao.selectLrnCmnThmaWransrList(lrnWransrSearch);
		}
		
		return lrnWransrList;
	}

}
