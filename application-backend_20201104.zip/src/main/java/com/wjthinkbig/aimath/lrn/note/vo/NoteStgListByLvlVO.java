package com.wjthinkbig.aimath.lrn.note.vo;

import java.util.List;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 
  * @프로그램 설명 : 해당레벨의 학습자 학습 스테이지 리스트 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29          Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "해당레벨의 학습자 학습 스테이지 리스트 VO")
public class NoteStgListByLvlVO {
	
	/**
	 * 레벨코드
	 */
	@ApiModelProperty(value="레벨코드")
	@FieldName("레벨코드")
	private String lvlCd;
	
	/**
	 * 스테이지 코드 
	 */
	@ApiModelProperty(value="스테이지 코드")
	@FieldName("스테이지 코드")
	private String stgCd;
	
	/**
	 * 학습회원 아이디 
	 */
	@ApiModelProperty(value="스테이지명")
	@FieldName("스테이지명")
	private String stgNm;
	
	/**
	 * 종료날짜 학습진행 리스트 
	 */
	@ApiModelProperty(value="종료날짜 학습진행 리스트")
	@FieldName("종료날짜 학습진행 리스트")
	private List<NoteEndDtListByStgVO>  noteEndDtListByStg;
	
	
}
