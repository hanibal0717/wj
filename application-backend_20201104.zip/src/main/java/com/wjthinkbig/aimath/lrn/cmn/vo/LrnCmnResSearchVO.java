package com.wjthinkbig.aimath.lrn.cmn.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 27.
  * @프로그램 설명 : 학습하기 결과 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 27.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="학습하기 결과 검색 정보")
public class LrnCmnResSearchVO {
	
	@ApiModelProperty(value="학습진입코드")
	@FieldName("학습진입코드")
	private String lrnEntyScnCd;				/* 학습진입코드 */
	
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;						/* 언어코드 */
	
	@ApiModelProperty(value="학습회원ID")
	@FieldName("학습회원ID")
	private String lrnMbrId;					/* 학습회원ID */
	
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd;						/* 소주제코드 */
	
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;						/* 채널코드 */
	
}
