package com.wjthinkbig.aimath.lrn.cmn.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 22.
  * @프로그램 설명 : 학습하기 오류이력 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 22.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="학습하기 오류이력 정보")
public class LrnWransrVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="학습회원ID")
	@FieldName("학습회원ID")
	private String lrnMbrId;					/* 학습회원ID */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="소주제코드")
	@FieldName("소주제코드")
	private String stgCd;						/* 소주제코드 */
	
	@ApiModelProperty(value="학습회차순번")
	@FieldName("학습회차순번")
	private int lrnTmeSn;						/* 학습회차순번 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="문항코드")
	@FieldName("문항코드")
	private String qstCd;						/* 문항코드 */
	
	@ApiModelProperty(value="회원답안")
	@FieldName("회원답안")
	private String mbrAnsr;						/* 회원답안 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="맞힐수있는데 틀린문항 여부")
	@FieldName("맞힐수있는데 틀린문항 여부")
	private String corPsbleQstYn;				/* 맞힐수있는데 틀린문항 여부 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="드릴다운 문항여부")
	@FieldName("드릴다운 문항여부")
	private String drilldwQstYn;				/* 드릴다운 문항여부 */
	
	@ApiModelProperty(value="문항내용")
	@FieldName("문항내용")
	private String qstCn;						/* 문항내용 */
	
	@ApiModelProperty(value="지문내용")
	@FieldName("지문내용")
	private String textCn;						/* 지문내용 */
	
	@ApiModelProperty(value="문항정답")
	@FieldName("문항정답")
	private String qstCransr;					/* 문항정답 */
}
