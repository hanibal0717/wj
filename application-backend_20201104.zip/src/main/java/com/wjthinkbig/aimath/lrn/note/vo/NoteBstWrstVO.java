package com.wjthinkbig.aimath.lrn.note.vo;



import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 
  * @프로그램 설명 : 가장 잘한 스테이지 가장 힘든페이지 VO  
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29          Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "가장 잘한 스테이지 가장 힘든페이지 VO ")
public class NoteBstWrstVO {
	
	/*
	 * 스테이지 타입  
	 */
	@ApiModelProperty(value="스테이지 타입")
	@FieldName("스테이지 타입")
	private String stgType;
	
	/*
	 * 스테이지 코드 
	 */
	@ApiModelProperty(value="스테이지 코드")
	@FieldName("스테이지 코드")
	private String stgCd;
	
	/*
	 * 학습결과점수 (정답률 + (1000-풀이속도))
	 */
	@ApiModelProperty(value="학습결과점수")
	@FieldName("학습결과점수")
	private long rate;
	
	
	/*
	 * 스테이지 명
	 */
	@ApiModelProperty(value="스테이지 명")
	@FieldName("스테이지 명")
	private String stgNm;	
	
	/*
	 * 풀이속도 명 
	 */
	@ApiModelProperty(value="풀이속도 명")
	@FieldName("풀이속도 명")
	private String cdNm;
	
	/*
	 * 정답률 
	 */
	@ApiModelProperty(value="정답률")
	@FieldName("정답률")
	private String crRate;
	
	/*
	 * 노력갯수  
	 */
	@ApiModelProperty(value="노력갯수")
	@FieldName("노력갯수")
	private String lpscCount;
	
	/*
	 * 학습결과명 
	 */
	@ApiModelProperty(value="학습결과명")
	@FieldName("학습결과명")
	private String lcdNm;
}
