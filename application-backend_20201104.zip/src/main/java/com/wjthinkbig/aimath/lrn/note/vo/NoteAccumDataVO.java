package com.wjthinkbig.aimath.lrn.note.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 10. 29 
  * @프로그램 설명 : 해당 레벨에 총 누적 데이터 VO
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 29     Kim Hee Seok       최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper = true)
@ApiModel(description = "해당 레벨에 총 누적 데이터 VO")
public class NoteAccumDataVO {
	
	/*
	 * 누적 날짜 
	 */
	@ApiModelProperty(value="시작 날짜")
	@FieldName("시작 날짜")
	private String accumStartDate;
	
	/*
	 * 누적 맞힌 문제수 
	 */
	@ApiModelProperty(value="누적 맞힌 문제수")
	@FieldName("누적 맞힌 문제수")
	private int accumRightQst;
	
	/*
	 * 기본개수 
	 */
	@ApiModelProperty(value="기본개수")
	@FieldName("기본개수")
	private int totalBasic;
	
	/*
	 * 충분개수
	 */
	@ApiModelProperty(value="충분개수")
	@FieldName("충분개수")
	private int totalEnough;
	
	/*
	 * 훌륭개수
	 */
	@ApiModelProperty(value="훌륭개수")
	@FieldName("훌륭개수")
	private int totalGood;
}
