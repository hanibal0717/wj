package com.wjthinkbig.aimath.lrn.note.controller;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.ApiUtil;
import com.wjthinkbig.aimath.lrn.note.service.NoteService;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAccumDataVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteAnalysisVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteBstWrstVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLrnStatusVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteLvlVO;
import com.wjthinkbig.aimath.lrn.note.vo.NoteMgntVO;
import com.wjthinkbig.aimath.lrn.note.vo.NotePrgsListByStgVO;
import com.wjthinkbig.aimath.mbr.service.MbrService;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 10. 20 
  * @프로그램 설명 :  NoteController.java   AI 연산 학습노트 
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20     Kim Hee Seok       최초작성
  * </pre>
  */
@Slf4j
@Api(description = "학습노트")
@RestController
public class NoteController extends BaseController {
	/**
	 * 채널구분코드
	 */
	@Value("${systemId}")
	String sysScnCd;
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 학습노트 서비스 
	 */
	@Resource(name = "noteService")
	private NoteService noteService;
	
	/**
	 * 회원 서비스 
	 */
	@Resource(name = "mbrService")
	private MbrService mbrService;
	
	/**
	 * 외부 API 사용 유틸
	 */
	@Resource(name = "apiUtil")
	private ApiUtil apiUtil;
	
	/**
	 * @Method 설명 : selectListLvlByMbr 학습자 아이디와 언어코드로  학습레벨 및 리스트 /학습시작점  조회
	 * @author Kim Hee Seok [2020. 10. 23]
	 * @param learner
	 * @param lvlVO
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "학습자 아이디와 언어코드로  학습레벨 및 리스트 /학습시작점  조회 ")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/learning/note/level/learners/{learner}")
	public SingleResult<List<NoteLvlVO>> selectListLvlByMbr(@ApiParam(value = "학습자 아이디") @PathVariable(name = "learner") String learner
			, @ApiParam(value = "레벨명객체") NoteLvlVO lvlVO) throws Exception {
		MbrLrnVO mbrLrn = mbrService.selectMbrLrnById(learner);
		if(mbrLrn == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		lvlVO.setLrnMbrId(learner);
		// 코스 학습이력이 없을 경우 시작점을 찾는다. 
		List<NoteLvlVO> lvlList = noteService.selectListLvlByMbr(lvlVO);
		if(lvlList.size() == 0) {
			//진단학습에서 완료 스테이지의 레벨과 이름을 기져온다 
			lvlVO = noteService.selectLvlNameByStgCd(lvlVO);
			lvlList.add(lvlVO);
		}
		return responseService.getSingleResult(lvlList);
	}
	
	/**
	 * @Method 설명 : selectStgListByLvl 학습노트 진도 
	 * @author Kim Hee Seok [2020. 10. 23]
	 * @param learner
	 * @param level
	 * @param language
	 * @param mgntVO
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "학습노트 (진도) ")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/note/magnitude/learners/{learner}/levels/{level}/languages/{language}")
	public SingleResult<NoteMgntVO> selectStgListByLvl(@ApiParam(value = "학습자 아이디") @PathVariable(name = "learner") String learner
			, @ApiParam(value = "레벨") @PathVariable(name = "level") String level
			, @ApiParam(value = "언어 코드") @PathVariable(name = "language") String language
			, @ApiParam(value = "학습노트 진도 객체") @Valid @RequestBody NoteMgntVO mgntVO) throws Exception {
		// 경로변수 체크 
		if((StringUtils.isNotBlank(mgntVO.getLrnMbrId()) && !learner.equals(mgntVO.getLrnMbrId()))
				|| (StringUtils.isNotBlank(mgntVO.getLvlCd()) && !level.equals(mgntVO.getLvlCd()))
				|| (StringUtils.isNotBlank(mgntVO.getLangCd()) && !language.equals(mgntVO.getLangCd()))) {
			throw this.processException("S002008"); // 데이터가 일치하지 않습니다.
		}
		// 회원체크 
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrLrnSrc == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		
		mgntVO = noteService.selectStgListByLvl(mgntVO);
		// 학습상태와 날짜를 셋팅한다.
		HashMap<String, String> param = new HashMap<String, String>();
		param.put("lrnMbrId", mgntVO.getLrnMbrId());
		param.put("lvlCd", mgntVO.getLvlCd());
		
		NoteLrnStatusVO lrnStatusVO = noteService.selectLrnStatus(param);
		HashMap<String, String> status = apiUtil.converLrnStatus(lrnStatusVO);
		mgntVO.setStatus(status.get("status"));
		mgntVO.setTerm(status.get("term"));
		mgntVO.setLrnDay(lrnStatusVO.getLrnDay());
		return responseService.getSingleResult(mgntVO);
	}
	
	/**
	 * @Method 설명 : selectAnalysisLrn 학습노트 진도 
	 * @author Kim Hee Seok [2020. 10. 26]
	 * @param learner
	 * @param level
	 * @param language
	 * @param analysVO
	 * @return
	 * @throws Exception
	 */
	@ApiOperation(value = "학습노트 (분석) ")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/learning/note/analysis/learners/{learner}/levels/{level}/languages/{language}")
	public SingleResult<NoteAnalysisVO> selectAnalysisLrn(@ApiParam(value = "학습자 아이디") @PathVariable(name = "learner") String learner
			, @ApiParam(value = "레벨") @PathVariable(name = "level") String level
			, @ApiParam(value = "언어 코드") @PathVariable(name = "language") String language
			, @ApiParam(value = "학습노트 진도 객체") @Valid @RequestBody NoteAnalysisVO analysVO
			) throws Exception {
		// 경로변수 체크 
		if((StringUtils.isNotBlank(analysVO.getLrnMbrId()) && !learner.equals(analysVO.getLrnMbrId()))
				|| (StringUtils.isNotBlank(analysVO.getLvlCd()) && !level.equals(analysVO.getLvlCd()))
				|| (StringUtils.isNotBlank(analysVO.getLangCd()) && !language.equals(analysVO.getLangCd()))) {
			throw this.processException("S002008"); //데이터가 일치하지 않습니다.
		}
		// 회원체크 
		MbrLrnVO mbrLrnSrc = mbrService.selectMbrLrnById(learner);
		if(mbrLrnSrc == null) {
			throw this.processException("S001005");		// 해당 사용자가 존재하지 않습니다.
		}
		analysVO = noteService.selectAnalysisByLvl(analysVO);
		if(analysVO == null) {
			throw this.processException("S002006");		// 아직 학습한 스테이지가 없습니다.
		}
		// 학습상태와 날짜를 셋팅한다.
		HashMap<String, String> param = new HashMap<String, String>();
		param.put("lrnMbrId", analysVO.getLrnMbrId());
		param.put("lvlCd", analysVO.getLvlCd());
		param.put("langCd", analysVO.getLangCd());
		
		NoteLrnStatusVO lrnStatusVO = noteService.selectLrnStatus(param);
		HashMap<String, String> status = apiUtil.converLrnStatus(lrnStatusVO);
		analysVO.setStatus(status.get("status"));
		analysVO.setTerm(status.get("term"));
		
		// 해당 레벨별 스테이지 학습결과 리스트 
		List<NotePrgsListByStgVO> prgsByStgVO = noteService.selectPrgsByStg(param); 
		if(prgsByStgVO == null) {
			throw this.processException("S002006");		// 아직 학습한 스테이지가 없습니다.
		}
		analysVO.setPrgsByStgList(prgsByStgVO);
		
		// 잘한 스테이지 & 힘든 스테이지 
		NoteBstWrstVO bstVO = noteService.selectBstStg(param); 
		analysVO.setBestStgInfo(bstVO);
		NoteBstWrstVO wrstVO = noteService.selectWrstStg(param);
		analysVO.setWrostStgInfo(wrstVO);
		
		
		// 누적 학습기록 
		NoteAccumDataVO accumDataVO = noteService.selectAccumData(param); 
		analysVO.setAccumtData(accumDataVO);
		return responseService.getSingleResult(analysVO);
	}
}
