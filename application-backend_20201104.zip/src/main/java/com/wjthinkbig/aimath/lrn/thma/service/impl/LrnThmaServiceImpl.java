package com.wjthinkbig.aimath.lrn.thma.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.wjthinkbig.aimath.core.extend.service.BaseServiceImpl;
import com.wjthinkbig.aimath.core.utils.StringUtils;
import com.wjthinkbig.aimath.lrn.thma.service.LrnThmaService;
import com.wjthinkbig.aimath.lrn.thma.service.dao.LrnThmaDao;
import com.wjthinkbig.aimath.lrn.thma.vo.LrnThmaSearchVO;
import com.wjthinkbig.aimath.lrn.thma.vo.LrnThmaVO;

/**
  * @Date : 2020. 10. 20.
  * @프로그램 설명 : 사용자 주제학습 관련 Service
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 10. 20.     19001861            최초작성
  * </pre>
  */
@Service("lrnThmaService")
public class LrnThmaServiceImpl extends BaseServiceImpl implements LrnThmaService {
	
	/**
	 * 사용자 주제학습 Dao
	 */
	@Resource(name = "lrnThmaDao")
	private LrnThmaDao lrnThmaDao;
	
	/**
	 * AWS S3 도메인
	 */
	private static String domain;
	@Value("${aws.domain}")
	public void setDomain(String url) {
		domain = url;
	}
	
	/**
	 * AWS S3 bucketName 키값
	 */
	private static String bucketName;
	@Value("${aws.bucket.name}")
	public void setBucketName(String name) {
		bucketName = name;
	}
	
	@Override
	public List<LrnThmaVO> selectLrnThmaList(LrnThmaSearchVO lrnThmaSearch) throws Exception {
		List<LrnThmaVO> lrnThmaList = lrnThmaDao.selectLrnThmaList(lrnThmaSearch);
		
		if( lrnThmaList != null && lrnThmaList.size() > 0 ) {
			//파일 경로에 S3 도메인을 넣어준다
			for( int i = 0; i < lrnThmaList.size(); i++ ) {
				if( StringUtils.isNotEmpty(lrnThmaList.get(i).getImgFilePath()) ) {
					lrnThmaList.get(i).setImgFilePath(domain + "/" + bucketName + lrnThmaList.get(i).getImgFilePath());
				}
			}
		}
		
		return lrnThmaList;
	}

	@Override
	public List<LrnThmaVO> selectLrnThmaStgList(LrnThmaSearchVO lrnThmaSearch) throws Exception {
		List<LrnThmaVO> lrnThmaList = lrnThmaDao.selectLrnThmaStgList(lrnThmaSearch);
		
		if( lrnThmaList != null && lrnThmaList.size() > 0 ) {
			//파일 경로에 S3 도메인을 넣어준다
			for( int i = 0; i < lrnThmaList.size(); i++ ) {
				if( StringUtils.isNotEmpty(lrnThmaList.get(i).getImgFilePath()) ) {
					lrnThmaList.get(i).setImgFilePath(domain + "/" + bucketName + lrnThmaList.get(i).getImgFilePath());
				}
				
				if( StringUtils.isNotEmpty(lrnThmaList.get(i).getStgImgFilePath()) ) {
					lrnThmaList.get(i).setStgImgFilePath(domain + "/" + bucketName + lrnThmaList.get(i).getStgImgFilePath());
				}
			}
		}
		
		return lrnThmaList;
	}
	
}
