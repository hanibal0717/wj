/**
 * 
 */
package com.wjthinkbig.aimath.sample.controller;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.mobile.device.Device;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.utils.WebUtil;
import com.wjthinkbig.aimath.core.web.bind.SaveVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLoginVO;
import com.wjthinkbig.aimath.mbr.vo.MbrLrnVO;
import com.wjthinkbig.aimath.sample.service.SampleService;
import com.wjthinkbig.aimath.sample.vo.InputVO;
import com.wjthinkbig.aimath.stg.vo.StgVO;
import com.wjthinkbig.aimath.thma.vo.ThmaVO;

import egovframework.rte.fdl.idgnr.EgovIdGnrService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 26. 
  * @프로그램 설명 : 샘플 예제 제공을 위한 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 26.     Lee Seung Hyuk            최초작성
  * </pre>
  */
@Slf4j
@Api(description = "샘플 예제 제공을 위한 서비스 컨트롤러")
@ApiImplicitParams({
	@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR"),
	@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")
})
@RestController
public class SampleController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 샘플 서비스
	 */
	@Resource(name = "sampleService")
	private SampleService sampleService;

	/**
	 * 회원ID 생성 서비스
	 */
	@Resource(name = "mbrIdGenService")
	private EgovIdGnrService mbrIdGenService;
	
	/**
	 * Redis Template
	 */
	@Resource(name = "redisTemplate")
	private RedisTemplate<String, Object> redisTemplate;
	
	/**
	  * @Method 설명 : StgVO 빈에 대해 일괄 업무처리(등록/수정/삭제) 및 검증을 수행한다.
	  * @param stgSaveVO StgVO의 (등록/수정/삭제용) 리스트 객체 
	  * @return
	  * @throws Exception
	 */
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@ApiOperation(value = "등록/수정/삭제 등 일괄처리 수행", notes = "전송한 VO 리스트에 대해 일괄적으로 등록, 수정 또는 삭제 처리를 한다.")	
	@PostMapping("/api/sample/stage/batch")
	public CommonResult stgInfoBatchProcess(@Valid @RequestBody @ApiParam(value = "일괄처리 StgVO 리스트") SaveVO<StgVO> stgSaveVO) throws Exception {
		sampleService.stgInfoBatchProcess(stgSaveVO);
		return responseService.getResult(true);
	}

	/**
	  * @Method 설명 : ID 생성 서비스 수행 테스트
	  * @param key
	  * @return
	  * @throws Exception
	 */
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@ApiOperation(value = "ID 생성 서비스 수행 테스트", notes = "문자열 기반의 ID 생성을 위한 서비스 실행결과 확인.")
	@ResponseBody
	@GetMapping("/api/sample/id/{key}")
	public String getGenId(@PathVariable String key) throws Exception {
		
		if("mbrId".equals(key)) {
			return mbrIdGenService.getNextStringId();			
		} else {
			return "해당 키의 ID 정보 없음";
		}
	}
	
	/**
	  * @Method 설명 : @CustomEmail을 이용한 이메일 Validator
	  * @param inputVO
	  * @return
	 */
	@ApiOperation(value = "@CustomEmail을 이용한 이메일 Validator", notes = "@CustomEmail Validator 테스트")
	@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")	
	@PostMapping("/api/sample/validation/email")
	public CommonResult validateCustomEamil(@Valid @RequestBody InputVO inputVO) {
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : @Password를 이용한 비밀번호 Validator
	  * @param inputVO 테스트를 위한 입력값 VO
	  * @return
	 */
	@ApiOperation(value = "@Password를 이용한 비밀번호 Validator", notes = "@Password Validator 테스트")
	@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")	
	@PostMapping("/api/sample/validation/password")
	public CommonResult validateCustomPassword(@Valid @RequestBody InputVO inputVO) {
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : @UserID를 이용한 아이디 Validator
	  * @param inputVO 테스트를 위한 입력값 VO
	  * @return
	 */
	@ApiOperation(value = "@UserID를 이용한 아이디 Validator", notes = "@UserID Validator 테스트")
	@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")	
	@PostMapping("/api/sample/validation/userid")
	public CommonResult validateCustomUserID(@Valid @RequestBody InputVO inputVO) {
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : PhoneNo를 이용한 전화번호(휴대폰) Validator
	  * @param inputVO 테스트를 위한 입력값 VO
	  * @return
	 */
	@ApiOperation(value = "@PhoneNo를 이용한 전화번호(휴대폰) Validator", notes = "@PhoneNo Validator 테스트")
	@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")	
	@PostMapping("/api/sample/validation/phone")
	public CommonResult validateCustomPhoneNo(@Valid @RequestBody InputVO inputVO) {
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : StgVO 빈에 대해 일괄 업무처리(등록/수정/삭제) 및 검증을 수행한다.
	  * @param stgSaveVO StgVO의 (등록/수정/삭제용) 리스트 객체 
	  * @return
	  * @throws Exception
	 */
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@ApiOperation(value = "등록/수정/삭제 등 일괄처리 수행", notes = "전송한 VO 리스트에 대해 일괄적으로 등록, 수정 또는 삭제 처리를 한다.")	
	@PostMapping("/api/sample/learners")
	public CommonResult learnersUpdate(@Valid @RequestBody @ApiParam(value = "일괄처리 MbrLrnVO 리스트") SaveVO<MbrLrnVO> mbrLrnSaveVO) throws Exception {
		sampleService.learnersUpdate(mbrLrnSaveVO);
		return responseService.getResult(true); 
	}
	
	/**
	  * @Method 설명 : 클라이언트 IP 가져오기
	  * @param request HttpServletRequest
	  * @return 클라이언트 IP
	 */
	@ApiOperation(value = "클라이언트 IP 조회")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/sample/client/ip")
	public String getRemoteAddr(@ApiParam(value = "HttpServletRequest") HttpServletRequest request) {
		String accessIp = WebUtil.getRemoteAddr(request);	
		
		return accessIp;
	}
	
	/**
	  * @Method 설명 : 디바이스정보 가져오기
	  * @param request HttpServletRequest
	  * @return 디바이스정보 PC이면 "NORMAL", 태블릿이면 "TABLET", 모바일이면 "MOBILE"
	 */
	@ApiOperation(value = "Request로부터 디바이스 정보 가져오기")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/sample/device")
	public String getDeviceInfo(@ApiParam(value = "HttpServletRequest") HttpServletRequest request) {
		
		// 디바이스 정보 (태블릿이면 "TABLET", 모바일이면 "MOBILE" 반환, 그외는 PC로 간주하여 "NORMAL" 반환)
		String device = WebUtil.getDeviceKind(request);
	
		// PC-태블릿-모바일 구분은 isPc, isTablet, isMobile 사용

		// PC인지 여부 확인
		if(WebUtil.isPc(request)) {
			log.info("디바이스 인식결과 : PC"); 
		} else if(WebUtil.isTablet(request)) {
			// 태블릿인지 여부 확인
			log.info("디바이스 인식결과 : TABLET"); 
		} else if(WebUtil.isMobile(request)) {
			// 모바일인지 여부 확인
			log.info("디바이스 인식결과 : MOBILE"); 
		} 
		
		return device;
	}
	
	/**
	  * @Method 설명 : 디바이스정보 가져오기
	  * @param request HttpServletRequest
	  * @return 디바이스정보 PC이면 "NORMAL", 태블릿이면 "TABLET", 모바일이면 "MOBILE"
	 */
	@ApiOperation(value = "Resolver로부터 디바이스 정보 가져오기")
	@ApiImplicitParams({@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")})
	@GetMapping("/api/sample/device/of/resolver")
	public String getDeviceFromResolver(@ApiParam(value = "Device 인식을 위한 아규먼트") Device device, @ApiParam(value = "HttpServletRequest") HttpServletRequest request) {
		
		log.debug("is normal : {}", device.isNormal());
		log.debug("is mobile : {}", device.isMobile());
		log.debug("device platform : {}", device.getDevicePlatform().name());
		
		
		return device.getDevicePlatform().name();
		
	}
	
	@ApiOperation(value = "Redis 테스트", notes = "Redis 테스트")
	@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")	
	@GetMapping("/api/sample/redis")
	public String testRedis() throws Exception {
	
		// get/set을 위한 객체
        ValueOperations<String, Object> vop = redisTemplate.opsForValue();
		
		String key = "mykey";
		String value = UUID.randomUUID().toString();
		vop.set(key, value, 1, TimeUnit.MINUTES);
		String opsValue = (String)vop.get(key);
		
		log.info("mykey : {}", opsValue);
		
		MbrLoginVO vo = new MbrLoginVO();
		vo.setEmailAdrs("test@wjtb.net");
		vo.setPw("qkfhtpa#1234");
		vo.setMbrId("홍길동");
		
		vop.set("mbr", vo);
		
//		MbrLoginVO redisVO = (MbrLoginVO)vop.get("mbr");
//		log.info("redisVO : {}", redisVO.getEmailAdrs());
		
//		String digestedVal = DigestUtils.md5DigestAsHex(opsValue.getBytes());
//		log.info("DigestUtils.md5DigestAsHex : {}", digestedVal);

		return opsValue;
	}
	
	/**
	  * @Method 설명 : 외부 API 호출하기 
	  * @param 
	  * @return jsonString
	 */
	@ApiOperation(value = "외부 api 호출하기")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR"),
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")
	})
	@GetMapping("/getData")
	public  SingleResult<HashMap<String, Object>>  ExternalData() throws Exception{
		HashMap<String, Object> result = new HashMap<String, Object>();
		try {
			HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory();
			factory.setConnectionRequestTimeout(5000);
			factory.setReadTimeout(5000);
			RestTemplate restTemplate = new RestTemplate(factory);
			
			HttpHeaders header = new HttpHeaders();
			HttpEntity<?> entity = new HttpEntity<>(header);
			
			String url = "http://www.kobis.or.kr/kobisopenapi/webservice/rest/boxoffice/searchDailyBoxOfficeList.json";
			UriComponents uri = UriComponentsBuilder.fromHttpUrl(url+"?"+"key=430156241533f1d058c603178cc3ca0e&targetDt=20201001").build();
			
			ResponseEntity<?> resultMap = restTemplate.exchange(uri.toString(), HttpMethod.GET, entity, Map.class);
            result.put("statusCode", resultMap.getStatusCodeValue()); //http status code를 확인
            result.put("header", resultMap.getHeaders()); //헤더 정보 확인
            result.put("body", resultMap.getBody()); //실제 데이터 정보 확인

		} catch (HttpClientErrorException | HttpServerErrorException e) {
			result.put("statusCode", e.getRawStatusCode());
            result.put("body"  , e.getStatusText());
		} catch (Exception e) {
			
		}
		return responseService.getSingleResult(result);
	}
	
	@ApiOperation(value = "@RequestBody에 로그인 사용자 정보 주입")	              
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR"),
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")
	})
	@PostMapping("/api/sample/injection/requestbody")
	public SingleResult<ThmaVO> injectLoginUserForRequestBody(@ApiParam(value = "소주제 VO") @RequestBody ThmaVO thmaVO) throws Exception {
		
		log.info("RequestBody : {}", thmaVO);
		
		return responseService.getSingleResult(thmaVO);
	}
	
	@ApiOperation(value = "@ModelAttribute에 로그인 사용자 정보 주입")	              
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR"),
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")
	})
	@PostMapping("/api/sample/injection/modelattribute")
	public SingleResult<ThmaVO> injectLoginUserForModelAttribute(@ModelAttribute("thmaVO") ThmaVO thmaVO) throws Exception {
		
		log.info("ModelAttribute : {}", thmaVO);
		
		return responseService.getSingleResult(thmaVO);
	}
	
	@ApiOperation(value = "세션 생성")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR"),
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer ")
	})
	@GetMapping("/api/sample/session")
	public SingleResult<HashMap<String, String>> createSession(Device device, HttpSession session) throws Exception {
		
		log.debug("Session ID : {}", session.getId());
		log.debug("Session maxInactiveInterval : {}", session.getMaxInactiveInterval());
		log.debug("Session lastAccessedTime : {}", LocalDateTime.ofInstant(Instant.ofEpochMilli(session.getLastAccessedTime()), TimeZone.getDefault().toZoneId()));
		
		// 세션값
		Enumeration<String> enumerations = session.getAttributeNames();
		while(enumerations.hasMoreElements()) {
			String element = enumerations.nextElement();
			String value = (String) session.getAttribute(element);
			
			log.debug("세션값 {} : {}", element, value);
		}		
		
		String deviceName = (String)session.getAttribute("hello");
		
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("session-device",  deviceName);
		map.put("current-device",  device.getDevicePlatform().name() + " at " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
				
		if(deviceName == null) {
			log.debug("session id : {} at {}", session.getId(), LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));
			session.setAttribute("hello", device.getDevicePlatform().name() + " at " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));	
		}
		
		return responseService.getSingleResult(map);
	}
}