package com.wjthinkbig.aimath.lvl.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.wjthinkbig.aimath.common.model.CommonResult;
import com.wjthinkbig.aimath.common.model.ListResult;
import com.wjthinkbig.aimath.common.model.SingleResult;
import com.wjthinkbig.aimath.common.service.ResponseService;
import com.wjthinkbig.aimath.core.extend.service.BaseController;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.lvl.service.LvlService;
import com.wjthinkbig.aimath.lvl.vo.LvlSearchVO;
import com.wjthinkbig.aimath.lvl.vo.LvlStgSearchVO;
import com.wjthinkbig.aimath.lvl.vo.LvlStgVO;
import com.wjthinkbig.aimath.lvl.vo.LvlVO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

/**
  * @Date : 2020. 8. 28.
  * @프로그램 설명 : 코스학습 관리 컨트롤러
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 28.     19001861            최초작성
  * </pre>
  */
@Slf4j
@Api(description="커리큘럼 코스학습")
@RestController
public class LvlController extends BaseController {
	
	/**
	 * API 응답메시지처리 서비스
	 */
	@Resource(name = "responseService")
	private ResponseService responseService;
	
	/**
	 * 레벨관리 서비스
	 */
	@Resource(name = "lvlService")
	private LvlService lvlService;
	
	/**
	  * @Method 설명 : 코스학습 레벨 리스트 정보 조회
	  * @param  lvlSearch 코스학습 레벨 검색 조건 VO
	  * @return 검색된 레벨 리스트
	  * @throws Exception
	 */
	@ApiOperation(value="코스학습 레벨 리스트 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/level")
	public ListResult<LvlVO> selectLvlList(@ModelAttribute LvlSearchVO lvlSearch) throws Exception {
		List<LvlVO> lvlList = lvlService.selectLvlList(lvlSearch);
		return responseService.getListResult(lvlList);
	}
	
	/**
	  * @Method 설명 : 코스학습 레벨 정보 단일 조회
	  * @param  lvlSearch 코스학습 레벨 검색 조건 VO
	  * @return 검색된 레벨 단일 정보
	  * @throws Exception
	 */
	@ApiOperation(value="코스학습 레벨 정보 단일 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/level/{level}")
	public SingleResult<LvlVO> selectLvlById(@ModelAttribute LvlSearchVO lvlSearch, @ApiParam(value = "레벨 코드") @PathVariable(name="level",required=true) String lvl_cd) throws Exception {
		lvlSearch.setLvlCd(lvl_cd);
		
		LvlVO lvl = lvlService.selectLvlById(lvlSearch);
		if(lvl == null) {
			throw this.processException("S001003", lvl_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(lvl);
	}
	
	/**
	  * @Method 설명 : 신규 레벨정보를 등록한다.
	  * @param lvl 등록할 레벨정보 VO
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="신규 레벨정보 등록")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/level")
	public CommonResult insertLvl( @RequestBody(required=true) LvlVO lvl) throws Exception {
		lvlService.insertLvl(lvl);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 코스학습 레벨 정보를 변경한다.
	  * @param lvl 변경할 정보를 담은 VO
	  * @param lvl_cd 변경하고자 하는 레벨정보의 식별코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "코스학습 레벨 정보를 변경")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/level/{level}")
	public CommonResult updateLvl(@ApiParam("변경할 정보를 담은 코스학습 레벨 객체") @RequestBody(required=true) LvlVO lvl, @ApiParam("변경할 코스학습 레벨의 고유키") @PathVariable(name="level", required=true) String lvl_cd) throws Exception {
		lvl.setLvlCd(lvl_cd);
		lvlService.updateLvl(lvl);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 등록된 코스학습 레벨 삭제
	  * @param lvl_cd 레벨 식별코드
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="등록된 코스학습 레벨 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/level/{level}")	
	public CommonResult deleteLvl(@ApiParam("삭제할 정보를 담은 코스학습 레벨 객체") @RequestBody(required=true) LvlVO lvl, @ApiParam("삭제대상 레벨정보의 고유키") @PathVariable("level") String lvl_cd) throws Exception {
		lvl.setLvlCd(lvl_cd);
		
		int rows = lvlService.deleteLvl(lvl);
		if(rows == 0) {			
			throw this.processException("S001003", lvl_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getResult(true);
	}
	
	/******************************************************************
	 * 아래부터는 하위 소주제 관련 API
	 ******************************************************************/
	
	/**
	  * @Method 설명 : 코스학습 레벨 소주제 리스트 정보 조회
	  * @param  lvlSearch 코스학습 레벨 검색 조건 VO
	  * @return 검색된 레벨 리스트
	  * @throws Exception
	 */
	@ApiOperation(value="코스학습 레벨 소주제 리스트 정보 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/level/stage")
	public ListResult<LvlStgVO> selectLvlStgList(@ModelAttribute LvlStgSearchVO lvlStgSearch) throws Exception {		
		List<LvlStgVO> lvlStgList = lvlService.selectLvlStgList(lvlStgSearch);
		return responseService.getListResult(lvlStgList);
	}
	
	/**
	  * @Method 설명 : 코스학습 레벨 소주제 정보 단일 조회
	  * @param  lvlSearch 코스학습 레벨 검색 조건 VO
	  * @return 검색된 레벨 단일 정보
	  * @throws Exception
	 */
	@ApiOperation(value="코스학습 레벨 소주제 정보 단일 조회")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/level/stage/{level}")
	public SingleResult<LvlStgVO> selectLvlStgById(@ModelAttribute LvlStgSearchVO lvlStgSearch
			, @ApiParam(value = "레벨 코드") @PathVariable(name="level",required=true) String lvl_cd) throws Exception {
		lvlStgSearch.setLvlCd(lvl_cd);
		
		LvlStgVO lvlStg = lvlService.selectLvlStgById(lvlStgSearch);
		if(lvlStg == null) {
			throw this.processException("S001003", lvlStgSearch.getStgCd());		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getSingleResult(lvlStg);
	}
	
	/**
	  * @Method 설명 : 코스학습 레벨 소주제 정보를 등록한다.
	  * @param lvlStg 등록할 레벨정보 VO
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="코스학습 레벨 소주제 정보를 등록한다.")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PostMapping("/api/level/stage")
	public CommonResult insertLvlStg(@ApiParam("등록할 정보를 담은 코스학습 레벨 소주제 객체") @Validated(value=Groups.Insert.class) @RequestBody(required=true) LvlStgVO lvlStg) throws Exception {
		lvlService.insertLvlStg(lvlStg);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 코스학습 레벨 소주제 정보를 변경한다.
	  * @param lvl 변경할 정보를 담은 VO
	  * @param lvl_cd 변경하고자 하는 레벨정보의 식별코드
	  * @return
	  * @throws Exception
	 */
	@ApiOperation(value = "코스학습 레벨 소주제 정보를 변경")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@PutMapping("/api/level/stage/{stage}")
	public CommonResult updateLvlStg(@ApiParam("변경할 정보를 담은 코스학습 레벨 소주제 객체") @RequestBody(required=true) LvlStgVO lvlStg
			, @ApiParam("변경할 코스학습 레벨 소주제의 고유키") @PathVariable(name="stage", required=true) String stg_cd) throws Exception {
		lvlStg.setStgCd(stg_cd);
		lvlService.updateLvlStg(lvlStg);
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 등록된 코스학습 레벨 소주제 삭제
	  * @param lvl_cd 레벨 식별코드
	  * @return 
	  * @throws Exception
	 */
	@ApiOperation(value="등록된 코스학습 레벨 소주제 삭제")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@DeleteMapping("/api/level/stage/{stage}")	
	public CommonResult deleteLvlStg(@ApiParam("삭제할 정보를 담은 코스학습 레벨 소주제 객체") @RequestBody(required=true) LvlStgVO lvlStg
			, @ApiParam("삭제대상 레벨 소주제 정보의 고유키") @PathVariable("stage") String stg_cd) throws Exception {
		lvlStg.setStgCd(stg_cd);
		
		int rows = lvlService.deleteLvlStg(lvlStg);
		if(rows == 0) {
			throw this.processException("S001003", stg_cd);		//해당 데이터({0})는 존재하지 않습니다.
		}
		return responseService.getResult(true);
	}
	
	/**
	  * @Method 설명 : 코스학습 레벨 전체 조회 및 하위 스테이지까지 포함 조회
	  * @param lvlSearch
	  * @return
	  * @throws Exception
	  */
	@ApiImplicitParams({
		@ApiImplicitParam(name = "Authorization", value = "Authorization Header", required = false, dataType = "string", paramType = "header", defaultValue = "Bearer "),
		@ApiImplicitParam(name = "Accept-language", value = "Accept-language 헤더", required = false, dataType = "string", paramType = "header", defaultValue = "ko-KR")
	})
	@GetMapping("/api/level/all")
	public ListResult<LvlVO> selectLvlAllList(@ModelAttribute LvlSearchVO lvlSearch) throws Exception {
		List<LvlVO> lvlList = lvlService.selectLvlAllList(lvlSearch);
		return responseService.getListResult(lvlList);
	}
}
