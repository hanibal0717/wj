package com.wjthinkbig.aimath.lvl.vo;

import javax.validation.constraints.NotBlank;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;
import com.wjthinkbig.aimath.core.validator.groups.Groups;
import com.wjthinkbig.aimath.core.web.bind.BaseVO;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 9. 18.
  * @프로그램 설명 : 코스학습 레벨 메타 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 9. 18.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="코스학습 레벨 메타 정보")
public class LvlMetaVO extends BaseVO {
	
	@NotBlank(groups = {Groups.Insert.class, Groups.Delete.class})
	@ApiModelProperty(value="레벨코드")
	@FieldName("레벨코드")
	private String lvlCd;						/* 레벨코드 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;						/* 언어 */
	
	@NotBlank(groups = {Groups.Insert.class})
	@ApiModelProperty(value="레벨명")
	@FieldName("레벨명")
	private String lvlNm;						/* 레벨명 */
	
}
