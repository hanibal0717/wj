package com.wjthinkbig.aimath.lvl.vo;

import com.wjthinkbig.aimath.core.validator.annotation.FieldName;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

/**
  * @Date : 2020. 8. 28.
  * @프로그램 설명 : 코스학습 레벨 검색 정보
  * <pre>
  * since            author             description
  * =============    ===============    ===========================
  * 2020. 8. 28.     19001861            최초작성
  * </pre>
  */
@Getter
@Setter
@ToString(callSuper=true)
@ApiModel(description="코스학습 레벨 검색 정보")
public class LvlSearchVO {
	
	@ApiModelProperty(value="레벨코드")
	@FieldName("레벨코드")
	private String lvlCd;						/* 레벨코드 */
	
	@ApiModelProperty(value="채널코드")
	@FieldName("채널코드")
	private String chnCd;						/* 채널코드 */
	
	@ApiModelProperty(value="언어코드")
	@FieldName("언어코드")
	private String langCd;						/* 언어코드 */
	
}
